# Restore journal atomic-publication failure matrix — 2026-11-14

## Scope

This increment extends the restore-journal crash model and source-structure checks. It does not change production C# code.

## Cases added

- Simulate `File.Replace` publication failure while a durable journal already exists; verify the prior published journal remains byte-for-byte intact and the temporary file is cleaned.
- Simulate initial `File.Move` publication failure when no journal exists; verify no partial published journal is accepted and the temporary file is cleaned.
- Simulate a publication failure followed by temporary-file cleanup failure; verify the old published journal remains authoritative, the orphan temporary file remains identifiable, and the next startup cleanup removes only that exact GUID-N temporary file.
- Assert the C# writer creates a unique GUID-N temporary file, flushes it durably, publishes through `File.Replace` or `File.Move`, and attempts temporary cleanup in `finally`.

## Validation boundary

These are Python fault-model tests and C# source-structure assertions. They do not execute the compiled C# writer or prove platform-specific atomicity. No production C# logic, database schema, WPF screen, or ERP module was modified. A .NET SDK and Windows runtime were unavailable, so C# build, WPF execution, Windows sharing/ACL behavior, and SQLite integration remain untested.
