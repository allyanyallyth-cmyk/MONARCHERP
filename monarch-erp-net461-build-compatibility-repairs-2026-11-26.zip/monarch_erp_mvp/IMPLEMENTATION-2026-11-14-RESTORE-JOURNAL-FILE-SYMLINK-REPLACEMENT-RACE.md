# Restore-journal file-symlink replacement race — 2026-11-14

## Scope
Added regression coverage for a matching GUID-N abandoned journal-temp path that was enumerated as a regular file and replaced by a symbolic link to an existing regular file before deletion.

## Expected safety properties
- Cleanup unlinks the captured directory entry only.
- The existing target remains present with byte-for-byte identical content.
- The test exercises the file-symlink case separately from directory-symlink and dangling-link cases.
- A C# source guard preserves direct single-entry `File.Delete` semantics and rejects link resolution, `File.Exists` preflight, and recursive directory deletion.

## Change boundary
Tests and documentation only. No production C#, database schema, WPF, installer, or ERP module changed.

## Validation limits
Filesystem behavior is exercised through the Python model on the current host. The C# assertion inspects source structure only. This does not establish Windows/NTFS reparse-point semantics, compiled C# behavior, WPF runtime behavior, or ACL/sharing-violation behavior. Those remain Windows validation tasks.
