# MONARCH ERP implementation record — 2026-11-13
## Committed restore cleanup failure retains its journal

### Defect addressed
Committed recovery previously called the best-effort `TryDelete` helper for the rollback database and quarantined WAL/SHM files, then also best-effort deleted the restore journal. If Windows denied deletion (for example, a sharing violation or access-control failure), the journal could be removed while rollback artifacts remained. That left untracked recovery files and removed the automatic retry marker.

### Change
- Added `DeleteIfExistsStrict`, which treats a missing path as already clean but allows filesystem deletion exceptions to propagate.
- Committed recovery now strictly deletes rollback DB, rollback WAL, rollback SHM, and finally the journal.
- If any rollback artifact cannot be deleted, execution stops before journal deletion. The committed journal remains available for the next startup/recovery attempt.
- Existing best-effort `TryDelete` remains in unrelated cleanup paths (temporary files and retention), unchanged.

### Scope
- Modified production file: `src/Monarch.Core/Backup/BackupRecoveryService.cs`.
- Modified test file: `tests/test_backup_restore_crash_recovery_journal.py`.
- No schema migration, module removal, module rewrite, or WPF change.

### Validation
- `pytest -q`: 653 passed.
- `python -m unittest discover -s tests -p 'test_*.py'`: 365 tests OK.
- Added a simulated sharing-violation test proving the journal remains when rollback cleanup fails, plus source-structure assertions for strict deletion ordering.
- These Python/model and source-structure checks do not execute the C# service. .NET SDK was unavailable; C# build, WPF runtime, and Windows filesystem/SQLite integration were not run.
