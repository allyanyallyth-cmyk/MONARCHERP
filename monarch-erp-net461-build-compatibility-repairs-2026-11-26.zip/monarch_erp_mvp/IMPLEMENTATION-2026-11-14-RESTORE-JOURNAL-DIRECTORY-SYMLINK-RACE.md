# Restore-journal directory-symlink race safety — 2026-11-14

## Change
Added a focused regression for a time-of-check/time-of-use race in abandoned restore-journal temp cleanup: a matching path already yielded by file enumeration is replaced by a directory symbolic link before strict deletion.

## Safety contract exercised
- Strict file-only cleanup fails closed when the raced entry resolves as a directory link in the Python filesystem model.
- The link and target directory remain intact; protected target content is unchanged.
- No recursive directory deletion fallback is permitted by the C# source guard.
- After the raced link is removed, a regular GUID-N temp at the same path can be removed on retry.

## Validation
- `pytest -q`: 747 passed.
- `python -m unittest discover -s tests -p 'test_*.py'`: 365 tests OK.
- XML/XAML/project/config parsing: 7 parsed, 0 errors.

## Scope and limitations
This is Python filesystem-model and C# source-structure coverage only. No C# production code, schema, WPF, or ERP module was changed. No .NET build, WPF runtime, or Windows/NTFS reparse-point/ACL/sharing integration was run. In particular, this test does not establish Windows directory-symlink semantics for the compiled service.
