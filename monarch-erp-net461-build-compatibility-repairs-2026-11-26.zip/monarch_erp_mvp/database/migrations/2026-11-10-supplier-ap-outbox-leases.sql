-- Explicit additive migration. Back up the tenant database before applying.
-- Never execute automatically at application startup.
-- Lease tokens fence stale workers; expired leases are reclaimable after process failure.
ALTER TABLE monarch_supplier_invoice_accounting_outbox ADD COLUMN lease_token TEXT NULL;
ALTER TABLE monarch_supplier_invoice_accounting_outbox ADD COLUMN lease_expires_utc TEXT NULL;
ALTER TABLE monarch_supplier_payment_accounting_outbox ADD COLUMN lease_token TEXT NULL;
ALTER TABLE monarch_supplier_payment_accounting_outbox ADD COLUMN lease_expires_utc TEXT NULL;
CREATE INDEX IF NOT EXISTS ix_supplier_invoice_outbox_claim ON monarch_supplier_invoice_accounting_outbox(company_id,branch_id,processed_utc,lease_expires_utc,created_utc);
CREATE INDEX IF NOT EXISTS ix_supplier_payment_outbox_claim ON monarch_supplier_payment_accounting_outbox(company_id,branch_id,processed_utc,lease_expires_utc,created_utc);
