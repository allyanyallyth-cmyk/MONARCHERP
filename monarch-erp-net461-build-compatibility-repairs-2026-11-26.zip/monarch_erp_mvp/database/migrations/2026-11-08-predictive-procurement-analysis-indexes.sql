-- Explicit additive performance migration for predictive procurement reads.
-- No operational data is rewritten and no migration runs automatically at startup.
CREATE INDEX IF NOT EXISTS ix_stock_demand_window
 ON monarch_stock_movements(company_id,branch_id,warehouse_id,occurred_utc,movement_type,item_id);
CREATE INDEX IF NOT EXISTS ix_purchase_order_open_item
 ON monarch_purchase_order_lines(company_id,item_id,order_id,quantity_milli,received_quantity_milli);
CREATE INDEX IF NOT EXISTS ix_purchase_order_scope_status
 ON monarch_purchase_orders(company_id,branch_id,warehouse_id,status,id);
