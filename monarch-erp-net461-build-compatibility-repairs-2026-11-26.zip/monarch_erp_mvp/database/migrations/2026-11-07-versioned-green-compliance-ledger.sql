-- Explicit additive migration. Back up first; never execute automatically at startup.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS monarch_carbon_factor_versions (
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES monarch_companies(id) ON DELETE RESTRICT,
 activity_code TEXT NOT NULL,
 unit_code TEXT NOT NULL,
 kg_co2e_per_unit TEXT NOT NULL,
 source_reference TEXT NOT NULL,
 version_code TEXT NOT NULL,
 effective_from_utc TEXT NOT NULL,
 effective_to_utc TEXT NULL,
 approval_state TEXT NOT NULL DEFAULT 'Draft' CHECK(approval_state IN('Draft','Approved','Retired')),
 created_by TEXT NOT NULL REFERENCES monarch_users(id) ON DELETE RESTRICT,
 created_utc TEXT NOT NULL,
 approved_by TEXT NULL REFERENCES monarch_users(id) ON DELETE RESTRICT,
 approved_utc TEXT NULL,
 UNIQUE(company_id,activity_code,version_code),
 CHECK(effective_to_utc IS NULL OR effective_to_utc > effective_from_utc),
 CHECK(CAST(kg_co2e_per_unit AS REAL) >= 0)
);
CREATE INDEX IF NOT EXISTS ix_carbon_factor_effective
 ON monarch_carbon_factor_versions(company_id,activity_code,approval_state,effective_from_utc,effective_to_utc);

CREATE TABLE IF NOT EXISTS monarch_tax_rule_versions (
 id TEXT PRIMARY KEY,
 jurisdiction_code TEXT NOT NULL,
 rule_code TEXT NOT NULL,
 version_code TEXT NOT NULL,
 rate TEXT NOT NULL,
 official_source TEXT NOT NULL,
 effective_from_utc TEXT NOT NULL,
 effective_to_utc TEXT NULL,
 approval_state TEXT NOT NULL DEFAULT 'Draft' CHECK(approval_state IN('Draft','Approved','Retired')),
 created_by TEXT NOT NULL REFERENCES monarch_users(id) ON DELETE RESTRICT,
 created_utc TEXT NOT NULL,
 approved_by TEXT NULL REFERENCES monarch_users(id) ON DELETE RESTRICT,
 approved_utc TEXT NULL,
 UNIQUE(jurisdiction_code,rule_code,version_code),
 CHECK(effective_to_utc IS NULL OR effective_to_utc > effective_from_utc),
 CHECK(CAST(rate AS REAL) >= 0)
);
CREATE INDEX IF NOT EXISTS ix_tax_rule_effective
 ON monarch_tax_rule_versions(jurisdiction_code,rule_code,approval_state,effective_from_utc,effective_to_utc);

CREATE TABLE IF NOT EXISTS monarch_carbon_document_snapshots (
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES monarch_companies(id) ON DELETE RESTRICT,
 branch_id TEXT NULL,
 document_type TEXT NOT NULL,
 document_id TEXT NOT NULL,
 activity_code TEXT NOT NULL,
 quantity TEXT NOT NULL,
 kg_co2e TEXT NOT NULL,
 factor_version_id TEXT NOT NULL REFERENCES monarch_carbon_factor_versions(id) ON DELETE RESTRICT,
 transaction_utc TEXT NOT NULL,
 recorded_by TEXT NOT NULL REFERENCES monarch_users(id) ON DELETE RESTRICT,
 recorded_utc TEXT NOT NULL,
 UNIQUE(company_id,document_type,document_id,activity_code),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_carbon_snapshots_tenant_date
 ON monarch_carbon_document_snapshots(company_id,branch_id,transaction_utc);

CREATE TRIGGER IF NOT EXISTS trg_carbon_factor_approved_immutable
BEFORE UPDATE ON monarch_carbon_factor_versions
WHEN OLD.approval_state IN('Approved','Retired')
BEGIN SELECT RAISE(ABORT,'Approved carbon factor versions are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_carbon_factor_no_delete
BEFORE DELETE ON monarch_carbon_factor_versions
BEGIN SELECT RAISE(ABORT,'Carbon factor versions cannot be deleted'); END;
CREATE TRIGGER IF NOT EXISTS trg_tax_rule_approved_immutable
BEFORE UPDATE ON monarch_tax_rule_versions
WHEN OLD.approval_state IN('Approved','Retired')
BEGIN SELECT RAISE(ABORT,'Approved tax rule versions are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_tax_rule_no_delete
BEFORE DELETE ON monarch_tax_rule_versions
BEGIN SELECT RAISE(ABORT,'Tax rule versions cannot be deleted'); END;
CREATE TRIGGER IF NOT EXISTS trg_carbon_snapshot_no_update
BEFORE UPDATE ON monarch_carbon_document_snapshots
BEGIN SELECT RAISE(ABORT,'Carbon document snapshots are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_carbon_snapshot_no_delete
BEFORE DELETE ON monarch_carbon_document_snapshots
BEGIN SELECT RAISE(ABORT,'Carbon document snapshots cannot be deleted'); END;
