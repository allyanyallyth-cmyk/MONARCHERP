-- Explicit additive migration. Back up the tenant database before applying.
-- Receipt posting records carbon snapshots atomically when an approved factor exists.
-- Missing factors are recorded as measurement gaps; they never fabricate a zero-emission result.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS monarch_carbon_measurement_gaps (
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES monarch_companies(id) ON DELETE RESTRICT,
 branch_id TEXT NOT NULL,
 document_type TEXT NOT NULL,
 document_id TEXT NOT NULL,
 activity_code TEXT NOT NULL,
 unit_code TEXT NOT NULL,
 quantity_milli INTEGER NOT NULL CHECK(quantity_milli > 0),
 transaction_utc TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN('Pending','Resolved','NotApplicable')),
 created_by TEXT NOT NULL REFERENCES monarch_users(id) ON DELETE RESTRICT,
 created_utc TEXT NOT NULL,
 resolved_by TEXT NULL REFERENCES monarch_users(id) ON DELETE RESTRICT,
 resolved_utc TEXT NULL,
 resolution_reference TEXT NULL,
 UNIQUE(company_id,document_type,document_id,activity_code,unit_code),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_carbon_measurement_gaps_queue
 ON monarch_carbon_measurement_gaps(company_id,branch_id,status,created_utc);
CREATE TRIGGER IF NOT EXISTS trg_carbon_measurement_gap_no_delete
BEFORE DELETE ON monarch_carbon_measurement_gaps
BEGIN SELECT RAISE(ABORT,'Carbon measurement gaps cannot be deleted'); END;
