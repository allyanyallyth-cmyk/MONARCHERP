-- Durable, tenant-scoped delivery intents. This migration does not send notifications.
CREATE TABLE IF NOT EXISTS monarch_supplier_ap_alert_delivery_intents (
    id TEXT PRIMARY KEY NOT NULL,
    company_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    recipient_user_id TEXT NOT NULL,
    alert_code TEXT NOT NULL CHECK (alert_code IN (
        'supplier_ap_heartbeat_failures', 'supplier_ap_lease_ownership_loss'
    )),
    source_last_occurred_utc TEXT NOT NULL,
    severity TEXT NOT NULL CHECK (severity IN ('Warning', 'Critical')),
    escalation_level INTEGER NOT NULL CHECK (escalation_level IN (1, 2)),
    channel TEXT NOT NULL CHECK (channel = 'InApp'),
    reason_code TEXT NOT NULL,
    due_utc TEXT NOT NULL,
    created_utc TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_supplier_ap_alert_delivery_once
ON monarch_supplier_ap_alert_delivery_intents(
    company_id, branch_id, recipient_user_id, alert_code,
    source_last_occurred_utc, escalation_level, channel
);
CREATE INDEX IF NOT EXISTS ix_supplier_ap_alert_delivery_recipient
ON monarch_supplier_ap_alert_delivery_intents(
    company_id, branch_id, recipient_user_id, created_utc DESC
);
CREATE TRIGGER IF NOT EXISTS trg_supplier_ap_alert_delivery_no_update
BEFORE UPDATE ON monarch_supplier_ap_alert_delivery_intents
BEGIN SELECT RAISE(ABORT, 'supplier AP alert delivery intents are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_ap_alert_delivery_no_delete
BEFORE DELETE ON monarch_supplier_ap_alert_delivery_intents
BEGIN SELECT RAISE(ABORT, 'supplier AP alert delivery intents are immutable'); END;
