CREATE TABLE IF NOT EXISTS monarch_supplier_ap_alert_lifecycle (
    id TEXT PRIMARY KEY NOT NULL,
    company_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    alert_code TEXT NOT NULL CHECK (alert_code IN (
        'supplier_ap_heartbeat_failures', 'supplier_ap_lease_ownership_loss'
    )),
    source_last_occurred_utc TEXT NOT NULL,
    action TEXT NOT NULL CHECK (action IN ('Viewed', 'Acknowledged')),
    occurred_utc TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_supplier_ap_alert_lifecycle_once
    ON monarch_supplier_ap_alert_lifecycle(company_id, branch_id, user_id, alert_code, source_last_occurred_utc, action);
CREATE INDEX IF NOT EXISTS ix_supplier_ap_alert_lifecycle_scope
    ON monarch_supplier_ap_alert_lifecycle(company_id, branch_id, user_id, alert_code, occurred_utc DESC);
CREATE TRIGGER IF NOT EXISTS trg_supplier_ap_alert_lifecycle_no_update
BEFORE UPDATE ON monarch_supplier_ap_alert_lifecycle
BEGIN SELECT RAISE(ABORT, 'supplier AP alert lifecycle is append-only'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_ap_alert_lifecycle_no_delete
BEFORE DELETE ON monarch_supplier_ap_alert_lifecycle
BEGIN SELECT RAISE(ABORT, 'supplier AP alert lifecycle is append-only'); END;
