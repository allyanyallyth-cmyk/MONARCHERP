-- Apply explicitly to existing databases; never run automatically at application startup.
INSERT OR IGNORE INTO monarch_permissions(code,description) VALUES
 ('inventory.read','عرض بيانات المخزون وأرصدته'),
 ('inventory.movements.manage','تسجيل حركات المخزون والتحويلات');
INSERT OR IGNORE INTO monarch_role_permissions(role_id,permission_code) VALUES
 ('role-admin','inventory.read'),('role-admin','inventory.movements.manage'),
 ('role-accountant','inventory.read'),('role-viewer','inventory.read');
