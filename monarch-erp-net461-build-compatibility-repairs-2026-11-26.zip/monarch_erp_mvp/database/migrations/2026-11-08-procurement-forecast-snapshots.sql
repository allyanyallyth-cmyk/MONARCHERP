-- Immutable forecast snapshots captured atomically with a predictive PO draft.
-- Apply explicitly after 2026-11-08-durable-procurement-recommendation-idempotency.sql.
CREATE TABLE IF NOT EXISTS monarch_procurement_forecast_snapshots (
    company_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    warehouse_id TEXT NOT NULL,
    item_id TEXT NOT NULL,
    recommendation_key TEXT NOT NULL,
    purchase_order_id TEXT NOT NULL,
    forecast_demand_milli INTEGER NOT NULL CHECK(forecast_demand_milli >= 0),
    horizon_days INTEGER NOT NULL CHECK(horizon_days BETWEEN 1 AND 180),
    window_start_utc TEXT NOT NULL,
    window_end_utc TEXT NOT NULL,
    policy_version TEXT NOT NULL,
    created_utc TEXT NOT NULL,
    PRIMARY KEY(company_id,branch_id,warehouse_id,recommendation_key),
    CHECK(window_end_utc > window_start_utc),
    FOREIGN KEY(company_id,branch_id,warehouse_id,recommendation_key)
      REFERENCES monarch_procurement_recommendation_runs(company_id,branch_id,warehouse_id,recommendation_key)
);
CREATE INDEX IF NOT EXISTS ix_procurement_forecast_accuracy
 ON monarch_procurement_forecast_snapshots(company_id,branch_id,window_end_utc,item_id);
