-- Explicit additive migration. Back up the database before applying.
-- Durable decision snapshots and an in-app notification outbox. No startup auto-migration.
CREATE TABLE IF NOT EXISTS monarch_procurement_decision_history (
 id TEXT NOT NULL PRIMARY KEY,
 company_id TEXT NOT NULL,
 branch_id TEXT NOT NULL,
 queue_id TEXT NOT NULL,
 purchase_order_id TEXT NOT NULL,
 decision TEXT NOT NULL CHECK(decision IN ('Approved','Rejected')),
 rationale_snapshot TEXT NOT NULL,
 decision_note TEXT NULL,
 order_number_snapshot TEXT NOT NULL,
 supplier_id_snapshot TEXT NOT NULL,
 currency_code_snapshot TEXT NOT NULL,
 total_minor_snapshot INTEGER NOT NULL,
 decided_by TEXT NOT NULL,
 decided_utc TEXT NOT NULL,
 UNIQUE(company_id, branch_id, queue_id),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(decided_by) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_procurement_decision_history_timeline
ON monarch_procurement_decision_history(company_id,branch_id,purchase_order_id,decided_utc);
CREATE TRIGGER IF NOT EXISTS trg_procurement_decision_history_no_update
BEFORE UPDATE ON monarch_procurement_decision_history
BEGIN SELECT RAISE(ABORT,'Procurement decision history is append-only'); END;
CREATE TRIGGER IF NOT EXISTS trg_procurement_decision_history_no_delete
BEFORE DELETE ON monarch_procurement_decision_history
BEGIN SELECT RAISE(ABORT,'Procurement decision history is append-only'); END;

CREATE TABLE IF NOT EXISTS monarch_procurement_notification_outbox (
 id TEXT NOT NULL PRIMARY KEY,
 company_id TEXT NOT NULL,
 branch_id TEXT NOT NULL,
 recipient_user_id TEXT NOT NULL,
 event_type TEXT NOT NULL CHECK(event_type IN ('ApprovalRequested','ApprovalApproved','ApprovalRejected')),
 queue_id TEXT NOT NULL,
 purchase_order_id TEXT NOT NULL,
 title TEXT NOT NULL,
 body TEXT NOT NULL,
 created_utc TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending','Delivered','Failed')),
 attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts>=0),
 delivered_utc TEXT NULL,
 UNIQUE(company_id,branch_id,recipient_user_id,event_type,queue_id),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(recipient_user_id) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_procurement_notification_inbox
ON monarch_procurement_notification_outbox(recipient_user_id,status,created_utc);
