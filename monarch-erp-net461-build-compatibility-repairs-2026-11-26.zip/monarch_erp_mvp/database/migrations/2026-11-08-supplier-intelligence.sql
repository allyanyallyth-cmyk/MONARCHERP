-- Explicit migration: supplier-item commercial terms and measured delivery performance.
CREATE TABLE IF NOT EXISTS monarch_supplier_item_terms (
 id TEXT NOT NULL PRIMARY KEY,
 company_id TEXT NOT NULL,
 supplier_id TEXT NOT NULL,
 item_id TEXT NOT NULL,
 currency_code TEXT NOT NULL CHECK(length(currency_code)=3),
 currency_scale INTEGER NOT NULL CHECK(currency_scale BETWEEN 0 AND 4),
 unit_cost_minor INTEGER NOT NULL CHECK(unit_cost_minor>=0),
 tax_rate_bps INTEGER NOT NULL CHECK(tax_rate_bps BETWEEN 0 AND 10000),
 lead_time_days INTEGER NOT NULL CHECK(lead_time_days BETWEEN 0 AND 3650),
 minimum_order_quantity_milli INTEGER NOT NULL DEFAULT 1000 CHECK(minimum_order_quantity_milli>0),
 effective_from TEXT NOT NULL,
 effective_to TEXT NULL,
 source_reference TEXT NOT NULL,
 is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN(0,1)),
 created_by TEXT NOT NULL,
 created_utc TEXT NOT NULL,
 FOREIGN KEY(company_id,supplier_id) REFERENCES monarch_parties(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,item_id) REFERENCES monarch_items(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(created_by) REFERENCES monarch_users(id) ON DELETE RESTRICT,
 CHECK(effective_to IS NULL OR date(effective_to)>=date(effective_from))
);
CREATE INDEX IF NOT EXISTS ix_supplier_item_terms_lookup
 ON monarch_supplier_item_terms(company_id,item_id,is_active,effective_from,effective_to,supplier_id);
CREATE UNIQUE INDEX IF NOT EXISTS ux_supplier_item_terms_active_start
 ON monarch_supplier_item_terms(company_id,supplier_id,item_id,effective_from) WHERE is_active=1;
