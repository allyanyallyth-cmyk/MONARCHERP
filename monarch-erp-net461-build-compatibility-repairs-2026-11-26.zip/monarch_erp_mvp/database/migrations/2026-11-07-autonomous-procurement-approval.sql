-- Explicit additive migration. Review and back up the database before applying.
-- This migration does not run automatically at application startup.
PRAGMA foreign_keys = ON;

INSERT OR IGNORE INTO monarch_permissions(code,description)
VALUES('commercial.purchases.approve','اعتماد أو رفض مسودات أوامر الشراء');
INSERT OR IGNORE INTO monarch_role_permissions(role_id,permission_code)
VALUES('role-admin','commercial.purchases.approve');

CREATE TABLE IF NOT EXISTS monarch_procurement_approval_queue (
 id TEXT NOT NULL PRIMARY KEY,
 company_id TEXT NOT NULL,
 branch_id TEXT NOT NULL,
 purchase_order_id TEXT NOT NULL,
 assigned_permission_code TEXT NOT NULL DEFAULT 'commercial.purchases.approve'
   CHECK(assigned_permission_code='commercial.purchases.approve'),
 status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN('Pending','Approved','Rejected','Cancelled')),
 rationale TEXT NOT NULL CHECK(length(trim(rationale))>0),
 created_by TEXT NOT NULL,
 created_utc TEXT NOT NULL,
 decided_by TEXT NULL,
 decided_utc TEXT NULL,
 decision_note TEXT NULL,
 UNIQUE(company_id,purchase_order_id),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,purchase_order_id) REFERENCES monarch_purchase_orders(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(created_by) REFERENCES monarch_users(id) ON DELETE RESTRICT,
 FOREIGN KEY(decided_by) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_procurement_approval_queue_inbox
ON monarch_procurement_approval_queue(assigned_permission_code,status,company_id,branch_id,created_utc);

-- Once a draft has entered the approval queue, direct status changes cannot bypass it.
CREATE TRIGGER IF NOT EXISTS trg_procurement_queue_requires_decision
BEFORE UPDATE OF status ON monarch_purchase_orders
WHEN OLD.status='Draft' AND NEW.status='Approved'
 AND EXISTS(SELECT 1 FROM monarch_procurement_approval_queue q
            WHERE q.company_id=OLD.company_id AND q.purchase_order_id=OLD.id)
 AND NOT EXISTS(SELECT 1 FROM monarch_procurement_approval_queue q
                WHERE q.company_id=OLD.company_id AND q.purchase_order_id=OLD.id
                  AND q.status='Approved' AND q.decided_by=NEW.approved_by)
BEGIN
 SELECT RAISE(ABORT,'Autonomous procurement draft requires an authorized approval-queue decision');
END;

CREATE TRIGGER IF NOT EXISTS trg_procurement_queue_decision_immutable
BEFORE UPDATE ON monarch_procurement_approval_queue
WHEN OLD.status IN('Approved','Rejected','Cancelled')
BEGIN SELECT RAISE(ABORT,'Procurement approval decision is immutable'); END;
