CREATE TABLE IF NOT EXISTS monarch_supplier_ap_worker_diagnostics (
    id TEXT PRIMARY KEY NOT NULL,
    company_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    event_code TEXT NOT NULL CHECK (event_code IN ('heartbeat_failed', 'lease_ownership_lost')),
    entity_kind TEXT NOT NULL CHECK (entity_kind IN ('batch', 'invoice', 'payment')),
    entity_id TEXT NULL,
    occurred_utc TEXT NOT NULL,
    detail_code TEXT NOT NULL CHECK (length(detail_code) <= 80)
);
CREATE INDEX IF NOT EXISTS ix_supplier_ap_worker_diagnostics_scope_time
    ON monarch_supplier_ap_worker_diagnostics(company_id, branch_id, occurred_utc DESC, id DESC);
