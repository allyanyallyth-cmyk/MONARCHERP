-- Operator-visible dead-letter queue and append-only manual-retry audit.
-- Attempt numbers remain globally monotonic per intent across retry cycles.
PRAGMA foreign_keys=OFF;
BEGIN;
ALTER TABLE monarch_supplier_ap_alert_dispatch_attempts RENAME TO monarch_supplier_ap_alert_dispatch_attempts_v1;
CREATE TABLE monarch_supplier_ap_alert_dispatch_attempts (
    id TEXT PRIMARY KEY NOT NULL,
    intent_id TEXT NOT NULL REFERENCES monarch_supplier_ap_alert_delivery_intents(id),
    attempt_number INTEGER NOT NULL CHECK (attempt_number BETWEEN 1 AND 100000),
    outcome TEXT NOT NULL CHECK (outcome IN ('Delivered','RetryScheduled','DeadLetter')),
    error_code TEXT NULL CHECK (error_code IS NULL OR length(error_code) <= 80),
    attempted_utc TEXT NOT NULL,
    next_attempt_utc TEXT NULL
);
INSERT INTO monarch_supplier_ap_alert_dispatch_attempts
(id,intent_id,attempt_number,outcome,error_code,attempted_utc,next_attempt_utc)
SELECT id,intent_id,attempt_number,outcome,error_code,attempted_utc,next_attempt_utc
FROM monarch_supplier_ap_alert_dispatch_attempts_v1;
DROP TABLE monarch_supplier_ap_alert_dispatch_attempts_v1;
CREATE INDEX IF NOT EXISTS ix_supplier_ap_alert_dispatch_attempts_intent
ON monarch_supplier_ap_alert_dispatch_attempts(intent_id, attempted_utc DESC);
CREATE TRIGGER IF NOT EXISTS trg_supplier_ap_alert_dispatch_attempts_no_update
BEFORE UPDATE ON monarch_supplier_ap_alert_dispatch_attempts
BEGIN SELECT RAISE(ABORT, 'supplier AP dispatch attempts are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_ap_alert_dispatch_attempts_no_delete
BEFORE DELETE ON monarch_supplier_ap_alert_dispatch_attempts
BEGIN SELECT RAISE(ABORT, 'supplier AP dispatch attempts are immutable'); END;
CREATE TABLE IF NOT EXISTS monarch_supplier_ap_alert_dead_letter_actions (
    id TEXT PRIMARY KEY NOT NULL,
    intent_id TEXT NOT NULL REFERENCES monarch_supplier_ap_alert_delivery_intents(id),
    company_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    actor_user_id TEXT NOT NULL,
    action TEXT NOT NULL CHECK(action='ManualRetryQueued'),
    previous_attempt_count INTEGER NOT NULL,
    occurred_utc TEXT NOT NULL,
    reason_code TEXT NOT NULL CHECK(length(reason_code) BETWEEN 1 AND 80)
);
CREATE INDEX IF NOT EXISTS ix_supplier_ap_alert_dead_letter_actions_scope
ON monarch_supplier_ap_alert_dead_letter_actions(company_id,branch_id,occurred_utc DESC);
CREATE TRIGGER IF NOT EXISTS trg_supplier_ap_alert_dead_letter_actions_no_update
BEFORE UPDATE ON monarch_supplier_ap_alert_dead_letter_actions
BEGIN SELECT RAISE(ABORT, 'supplier AP dead-letter actions are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_ap_alert_dead_letter_actions_no_delete
BEFORE DELETE ON monarch_supplier_ap_alert_dead_letter_actions
BEGIN SELECT RAISE(ABORT, 'supplier AP dead-letter actions are immutable'); END;
COMMIT;
PRAGMA foreign_keys=ON;
