-- Durable in-app alert dispatch queue. This migration does not perform external delivery.
CREATE TABLE IF NOT EXISTS monarch_supplier_ap_alert_dispatch_state (
    intent_id TEXT PRIMARY KEY NOT NULL REFERENCES monarch_supplier_ap_alert_delivery_intents(id),
    status TEXT NOT NULL CHECK (status IN ('Pending','Claimed','Delivered','DeadLetter')),
    attempt_count INTEGER NOT NULL DEFAULT 0 CHECK (attempt_count BETWEEN 0 AND 8),
    next_attempt_utc TEXT NOT NULL,
    lease_token TEXT NULL,
    lease_expires_utc TEXT NULL,
    last_error_code TEXT NULL CHECK (last_error_code IS NULL OR length(last_error_code) <= 80),
    updated_utc TEXT NOT NULL,
    CHECK ((status = 'Claimed' AND lease_token IS NOT NULL AND lease_expires_utc IS NOT NULL)
        OR (status <> 'Claimed' AND lease_token IS NULL AND lease_expires_utc IS NULL))
);
CREATE INDEX IF NOT EXISTS ix_supplier_ap_alert_dispatch_due
ON monarch_supplier_ap_alert_dispatch_state(status, next_attempt_utc, lease_expires_utc);

CREATE TABLE IF NOT EXISTS monarch_supplier_ap_alert_dispatch_attempts (
    id TEXT PRIMARY KEY NOT NULL,
    intent_id TEXT NOT NULL REFERENCES monarch_supplier_ap_alert_delivery_intents(id),
    attempt_number INTEGER NOT NULL CHECK (attempt_number BETWEEN 1 AND 8),
    outcome TEXT NOT NULL CHECK (outcome IN ('Delivered','RetryScheduled','DeadLetter')),
    error_code TEXT NULL CHECK (error_code IS NULL OR length(error_code) <= 80),
    attempted_utc TEXT NOT NULL,
    next_attempt_utc TEXT NULL,
    UNIQUE(intent_id, attempt_number)
);
CREATE INDEX IF NOT EXISTS ix_supplier_ap_alert_dispatch_attempts_intent
ON monarch_supplier_ap_alert_dispatch_attempts(intent_id, attempted_utc DESC);
CREATE TRIGGER IF NOT EXISTS trg_supplier_ap_alert_dispatch_attempts_no_update
BEFORE UPDATE ON monarch_supplier_ap_alert_dispatch_attempts
BEGIN SELECT RAISE(ABORT, 'supplier AP dispatch attempts are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_ap_alert_dispatch_attempts_no_delete
BEFORE DELETE ON monarch_supplier_ap_alert_dispatch_attempts
BEGIN SELECT RAISE(ABORT, 'supplier AP dispatch attempts are immutable'); END;

-- Existing intents become pending dispatch work exactly once.
INSERT OR IGNORE INTO monarch_supplier_ap_alert_dispatch_state
(intent_id,status,attempt_count,next_attempt_utc,updated_utc)
SELECT id,'Pending',0,due_utc,created_utc
FROM monarch_supplier_ap_alert_delivery_intents;
CREATE TRIGGER IF NOT EXISTS trg_supplier_ap_alert_intent_enqueue
AFTER INSERT ON monarch_supplier_ap_alert_delivery_intents
BEGIN
    INSERT OR IGNORE INTO monarch_supplier_ap_alert_dispatch_state
    (intent_id,status,attempt_count,next_attempt_utc,updated_utc)
    VALUES(NEW.id,'Pending',0,NEW.due_utc,NEW.created_utc);
END;
