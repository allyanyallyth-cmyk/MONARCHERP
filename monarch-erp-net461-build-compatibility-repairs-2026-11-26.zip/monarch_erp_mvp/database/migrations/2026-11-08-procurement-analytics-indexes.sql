-- Additive query indexes for the read-only procurement analytics dashboard.
-- Apply explicitly after a verified backup; no startup auto-migration.
CREATE INDEX IF NOT EXISTS ix_procurement_decisions_analytics
 ON monarch_procurement_decision_history(company_id,branch_id,decided_utc,decision,purchase_order_id);
CREATE INDEX IF NOT EXISTS ix_purchase_receipts_analytics
 ON monarch_purchase_receipts(company_id,branch_id,posted_utc,purchase_order_id);
CREATE INDEX IF NOT EXISTS ix_stock_movements_procurement_analytics
 ON monarch_stock_movements(company_id,branch_id,occurred_utc,movement_type,item_id);

CREATE INDEX IF NOT EXISTS ix_purchase_receipt_lines_supplier_item
 ON monarch_purchase_receipt_lines(company_id,receipt_id,item_id,quantity_milli,unit_cost_minor);
