-- Additive integrity guard for globally monotonic attempt numbering per delivery intent.
-- Apply after 2026-11-11-supplier-ap-alert-dead-letter-operations.sql.
-- The index creation intentionally fails if pre-existing duplicate sequence numbers exist;
-- inspect and reconcile such corruption rather than silently deleting or renumbering history.
CREATE UNIQUE INDEX IF NOT EXISTS ux_supplier_ap_alert_attempt_sequence
ON monarch_supplier_ap_alert_dispatch_attempts(intent_id, attempt_number);

-- Support bounded operator history inspection and incident reconstruction.
CREATE INDEX IF NOT EXISTS ix_supplier_ap_alert_dead_letter_actions_intent
ON monarch_supplier_ap_alert_dead_letter_actions(intent_id, occurred_utc DESC);
