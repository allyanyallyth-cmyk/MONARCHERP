-- Durable idempotency ledger for predictive procurement drafts.
-- Apply explicitly before enabling recommendation-key based draft orchestration.
-- Claim, purchase order, lines, manager queue and audit are written in one SQLite transaction.
CREATE TABLE IF NOT EXISTS monarch_procurement_recommendation_runs (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    warehouse_id TEXT NOT NULL,
    item_id TEXT NOT NULL,
    recommendation_key TEXT NOT NULL,
    purchase_order_id TEXT NOT NULL,
    approval_queue_id TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_utc TEXT NOT NULL,
    UNIQUE(company_id, branch_id, warehouse_id, recommendation_key)
);
CREATE INDEX IF NOT EXISTS ix_procurement_recommendation_item
 ON monarch_procurement_recommendation_runs(company_id,branch_id,warehouse_id,item_id,created_utc);
