-- Additive, explicit migration. Run after backing up the database.
-- Read state is stored separately so existing notification outbox rows and delivery states remain untouched.
CREATE TABLE IF NOT EXISTS monarch_procurement_notification_reads (
    notification_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    read_utc TEXT NOT NULL,
    PRIMARY KEY(notification_id,user_id),
    FOREIGN KEY(notification_id) REFERENCES monarch_procurement_notification_outbox(id) ON DELETE RESTRICT,
    FOREIGN KEY(user_id) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_procurement_notification_reads_user
ON monarch_procurement_notification_reads(user_id,read_utc);
CREATE INDEX IF NOT EXISTS ix_procurement_decision_history_recent
ON monarch_procurement_decision_history(company_id,branch_id,decided_utc DESC);
