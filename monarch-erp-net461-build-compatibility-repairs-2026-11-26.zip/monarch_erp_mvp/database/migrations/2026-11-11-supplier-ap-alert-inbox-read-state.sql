-- Durable recipient-specific read state; delivery and reading remain separate concepts.
CREATE TABLE IF NOT EXISTS monarch_supplier_ap_alert_inbox_events (
    id TEXT PRIMARY KEY NOT NULL,
    intent_id TEXT NOT NULL REFERENCES monarch_supplier_ap_alert_delivery_intents(id),
    company_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    recipient_user_id TEXT NOT NULL,
    action TEXT NOT NULL CHECK (action IN ('Viewed','Acknowledged')),
    occurred_utc TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_supplier_ap_alert_inbox_event_once
ON monarch_supplier_ap_alert_inbox_events(intent_id, recipient_user_id, action);
CREATE INDEX IF NOT EXISTS ix_supplier_ap_alert_inbox_recipient
ON monarch_supplier_ap_alert_inbox_events(company_id, branch_id, recipient_user_id, occurred_utc DESC);
CREATE TRIGGER IF NOT EXISTS trg_supplier_ap_alert_inbox_events_no_update
BEFORE UPDATE ON monarch_supplier_ap_alert_inbox_events
BEGIN SELECT RAISE(ABORT, 'supplier AP inbox events are append-only'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_ap_alert_inbox_events_no_delete
BEFORE DELETE ON monarch_supplier_ap_alert_inbox_events
BEGIN SELECT RAISE(ABORT, 'supplier AP inbox events are append-only'); END;
