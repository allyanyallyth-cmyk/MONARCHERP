PRAGMA foreign_keys = ON;
-- Immutable valuation snapshots; each run is reproducible from the movement ledger.
CREATE TABLE IF NOT EXISTS monarch_inventory_valuation_runs (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL,
 warehouse_id TEXT NOT NULL, item_id TEXT NOT NULL, cost_method TEXT NOT NULL CHECK(cost_method IN('Fifo','MovingWeightedAverage')),
 closing_quantity_milli INTEGER NOT NULL, closing_value_minor INTEGER NOT NULL,
 average_unit_cost_minor INTEGER NOT NULL, movement_count INTEGER NOT NULL CHECK(movement_count>=0),
 calculated_utc TEXT NOT NULL, calculated_by TEXT NOT NULL,
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,warehouse_id) REFERENCES monarch_warehouses(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,item_id) REFERENCES monarch_items(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(calculated_by) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_inventory_valuation_latest ON monarch_inventory_valuation_runs(company_id,warehouse_id,item_id,calculated_utc);
CREATE TABLE IF NOT EXISTS monarch_inventory_valuation_entries (
 run_id TEXT NOT NULL, line_number INTEGER NOT NULL CHECK(line_number>0), movement_id TEXT NOT NULL,
 balance_quantity_milli INTEGER NOT NULL, balance_value_minor INTEGER NOT NULL,
 movement_cost_minor INTEGER NOT NULL, average_unit_cost_minor INTEGER NOT NULL,
 PRIMARY KEY(run_id,line_number), UNIQUE(run_id,movement_id),
 FOREIGN KEY(run_id) REFERENCES monarch_inventory_valuation_runs(id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS monarch_inventory_valuation_layers (
 run_id TEXT NOT NULL, layer_number INTEGER NOT NULL CHECK(layer_number>0),
 remaining_quantity_milli INTEGER NOT NULL CHECK(remaining_quantity_milli>0), unit_cost_minor INTEGER NOT NULL CHECK(unit_cost_minor>=0),
 PRIMARY KEY(run_id,layer_number), FOREIGN KEY(run_id) REFERENCES monarch_inventory_valuation_runs(id) ON DELETE RESTRICT
);
CREATE TRIGGER IF NOT EXISTS trg_valuation_run_no_update BEFORE UPDATE ON monarch_inventory_valuation_runs BEGIN SELECT RAISE(ABORT,'Valuation runs are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_valuation_run_no_delete BEFORE DELETE ON monarch_inventory_valuation_runs BEGIN SELECT RAISE(ABORT,'Valuation runs are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_valuation_entry_no_update BEFORE UPDATE ON monarch_inventory_valuation_entries BEGIN SELECT RAISE(ABORT,'Valuation entries are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_valuation_entry_no_delete BEFORE DELETE ON monarch_inventory_valuation_entries BEGIN SELECT RAISE(ABORT,'Valuation entries are immutable'); END;
