PRAGMA foreign_keys = ON;
-- Permit the one-time key normalization from the earliest textual seed IDs to GUID IDs.
PRAGMA foreign_keys = OFF;

-- Organization directory foundation. The legacy monarch_accounts/monarch_journals tables
-- remain single-company for compatibility. Multi-company accounting uses the isolated
-- monarch_tenant_* tables created by tenant-accounting.sql.
CREATE TABLE IF NOT EXISTS monarch_companies (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE COLLATE NOCASE,
  legal_name TEXT NOT NULL,
  display_name TEXT NOT NULL,
  country_code TEXT NOT NULL DEFAULT 'SA' CHECK(length(country_code)=2),
  base_currency_code TEXT NOT NULL REFERENCES monarch_currencies(code),
  tax_registration_number TEXT NULL,
  time_zone_id TEXT NOT NULL DEFAULT 'Asia/Riyadh',
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
  created_utc TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS monarch_branches (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES monarch_companies(id) ON DELETE RESTRICT,
  code TEXT NOT NULL COLLATE NOCASE,
  name TEXT NOT NULL,
  address TEXT NULL,
  phone TEXT NULL,
  is_head_office INTEGER NOT NULL DEFAULT 0 CHECK(is_head_office IN (0,1)),
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
  created_utc TEXT NOT NULL,
  UNIQUE(company_id, code),
  UNIQUE(company_id, id)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_monarch_one_head_office
  ON monarch_branches(company_id) WHERE is_head_office=1;
CREATE INDEX IF NOT EXISTS ix_monarch_branches_company
  ON monarch_branches(company_id, is_active, code);

-- Explicit user-to-company access. Role assignment here is scoped to the company,
-- rather than relying only on the legacy global role mapping.
CREATE TABLE IF NOT EXISTS monarch_user_company_access (
  user_id TEXT NOT NULL REFERENCES monarch_users(id) ON DELETE CASCADE,
  company_id TEXT NOT NULL REFERENCES monarch_companies(id) ON DELETE RESTRICT,
  role_code TEXT NOT NULL CHECK(role_code IN ('Administrator','Accountant','Viewer')),
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
  granted_by_user_id TEXT NULL REFERENCES monarch_users(id),
  granted_utc TEXT NOT NULL,
  PRIMARY KEY(user_id, company_id)
);
CREATE INDEX IF NOT EXISTS ix_monarch_company_access_company
  ON monarch_user_company_access(company_id, is_active, user_id);

CREATE TABLE IF NOT EXISTS monarch_user_branch_access (
  user_id TEXT NOT NULL,
  company_id TEXT NOT NULL,
  branch_id TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
  PRIMARY KEY(user_id, branch_id),
  FOREIGN KEY(user_id, company_id) REFERENCES monarch_user_company_access(user_id, company_id) ON DELETE CASCADE,
  FOREIGN KEY(company_id, branch_id) REFERENCES monarch_branches(company_id, id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS monarch_company_audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id TEXT NOT NULL REFERENCES monarch_companies(id) ON DELETE RESTRICT,
  branch_id TEXT NULL,
  actor_user_id TEXT NULL REFERENCES monarch_users(id),
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NULL,
  details TEXT NULL,
  occurred_utc TEXT NOT NULL,
  FOREIGN KEY(company_id, branch_id) REFERENCES monarch_branches(company_id, id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_monarch_company_audit_time
  ON monarch_company_audit_log(company_id, occurred_utc);

-- Upgrade databases created by the first organization-directory prototype.
UPDATE monarch_branches SET company_id='00000000-0000-0000-0000-000000000001' WHERE company_id='default-company';
UPDATE monarch_user_company_access SET company_id='00000000-0000-0000-0000-000000000001' WHERE company_id='default-company';
UPDATE monarch_user_branch_access SET company_id='00000000-0000-0000-0000-000000000001' WHERE company_id='default-company';
UPDATE monarch_company_audit_log SET company_id='00000000-0000-0000-0000-000000000001' WHERE company_id='default-company';
UPDATE monarch_user_branch_access SET branch_id='00000000-0000-0000-0000-000000000002' WHERE branch_id='default-branch';
UPDATE monarch_company_audit_log SET branch_id='00000000-0000-0000-0000-000000000002' WHERE branch_id='default-branch';
UPDATE monarch_companies SET id='00000000-0000-0000-0000-000000000001' WHERE id='default-company';
UPDATE monarch_branches SET id='00000000-0000-0000-0000-000000000002' WHERE id='default-branch';

INSERT OR IGNORE INTO monarch_companies
(id,code,legal_name,display_name,country_code,base_currency_code,time_zone_id,is_active,created_utc)
VALUES
('00000000-0000-0000-0000-000000000001','DEFAULT','MONARCH Default Company','MONARCH','SA','SAR','Asia/Riyadh',1,strftime('%Y-%m-%dT%H:%M:%fZ','now'));
INSERT OR IGNORE INTO monarch_branches
(id,company_id,code,name,is_head_office,is_active,created_utc)
VALUES
('00000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-000000000001','HQ','المقر الرئيسي',1,1,strftime('%Y-%m-%dT%H:%M:%fZ','now'));
PRAGMA foreign_keys = ON;
