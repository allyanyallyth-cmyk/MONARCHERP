PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS monarch_roles (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS monarch_permissions (
  code TEXT PRIMARY KEY,
  description TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS monarch_role_permissions (
  role_id TEXT NOT NULL REFERENCES monarch_roles(id) ON DELETE CASCADE,
  permission_code TEXT NOT NULL REFERENCES monarch_permissions(code) ON DELETE CASCADE,
  PRIMARY KEY(role_id, permission_code)
);
CREATE TABLE IF NOT EXISTS monarch_users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  display_name TEXT NOT NULL,
  password_salt BLOB NOT NULL,
  password_hash BLOB NOT NULL,
  password_iterations INTEGER NOT NULL CHECK(password_iterations >= 100000),
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
  failed_login_count INTEGER NOT NULL DEFAULT 0 CHECK(failed_login_count >= 0),
  lockout_until_utc TEXT NULL,
  created_utc TEXT NOT NULL,
  last_login_utc TEXT NULL
);
CREATE TABLE IF NOT EXISTS monarch_user_roles (
  user_id TEXT NOT NULL REFERENCES monarch_users(id) ON DELETE CASCADE,
  role_id TEXT NOT NULL REFERENCES monarch_roles(id),
  PRIMARY KEY(user_id, role_id)
);
CREATE TABLE IF NOT EXISTS monarch_audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NULL REFERENCES monarch_users(id),
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NULL,
  details TEXT NULL,
  occurred_utc TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_monarch_audit_time ON monarch_audit_log(occurred_utc);

INSERT OR IGNORE INTO monarch_roles(id,code,name) VALUES
 ('role-admin','Administrator','مدير النظام'),
 ('role-accountant','Accountant','محاسب'),
 ('role-viewer','Viewer','مشاهد');
INSERT OR IGNORE INTO monarch_permissions(code,description) VALUES
 ('accounts.read','عرض دليل الحسابات'),
 ('accounts.manage','إدارة الحسابات'),
 ('journals.read','عرض القيود اليومية'),
 ('journals.create','إنشاء القيود'),
 ('journals.post','ترحيل القيود'),
 ('reports.read','عرض التقارير'),
 ('users.manage','إدارة المستخدمين'),
 ('backups.manage','إنشاء النسخ الاحتياطية والتحقق منها');
INSERT OR IGNORE INTO monarch_role_permissions(role_id,permission_code)
 SELECT 'role-admin',code FROM monarch_permissions;
INSERT OR IGNORE INTO monarch_role_permissions(role_id,permission_code) VALUES
 ('role-accountant','accounts.read'),('role-accountant','journals.read'),
 ('role-accountant','journals.create'),('role-accountant','journals.post'),('role-accountant','reports.read'),
 ('role-viewer','accounts.read'),('role-viewer','journals.read'),('role-viewer','reports.read');
-- Dedicated inventory master-data permissions; Administrator receives these through the
-- role-admin INSERT...SELECT above when this schema is initialized/upgraded.
INSERT OR IGNORE INTO monarch_permissions(code,description) VALUES
 ('inventory.items.manage','إدارة الأصناف وتعطيلها'),
 ('inventory.warehouses.manage','إدارة المستودعات وتعطيلها');
INSERT OR IGNORE INTO monarch_role_permissions(role_id,permission_code) VALUES
 ('role-admin','inventory.items.manage'),
 ('role-admin','inventory.warehouses.manage');

-- Purchasing workflow permissions. Administrator receives this dedicated permission.
INSERT OR IGNORE INTO monarch_permissions(code,description) VALUES
 ('commercial.purchases.manage','إدارة أوامر الشراء واعتمادها');
INSERT OR IGNORE INTO monarch_role_permissions(role_id,permission_code) VALUES
 ('role-admin','commercial.purchases.manage');

-- ZATCA integration and commercial sales permissions (new roles receive explicit grants only).
INSERT OR IGNORE INTO monarch_permissions(code,description) VALUES
 ('commercial.sales.manage','إدارة فواتير المبيعات'),
 ('zatca.integration.manage','إدارة ربط الفوترة الإلكترونية مع هيئة الزكاة والضريبة والجمارك');
INSERT OR IGNORE INTO monarch_role_permissions(role_id,permission_code) VALUES
 ('role-admin','commercial.sales.manage'),('role-admin','zatca.integration.manage'),
 ('role-accountant','commercial.sales.manage');

-- Explicit inventory operation permissions. Read access is granted to the standard
-- accountant/viewer roles; stock mutation remains Administrator-only by default.
INSERT OR IGNORE INTO monarch_permissions(code,description) VALUES
 ('inventory.read','عرض بيانات المخزون وأرصدته'),
 ('inventory.movements.manage','تسجيل حركات المخزون والتحويلات');
INSERT OR IGNORE INTO monarch_role_permissions(role_id,permission_code) VALUES
 ('role-admin','inventory.read'),('role-admin','inventory.movements.manage'),
 ('role-accountant','inventory.read'),('role-viewer','inventory.read');
