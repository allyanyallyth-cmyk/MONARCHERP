PRAGMA foreign_keys = ON;

-- Tenant-scoped ledger. Legacy single-company tables remain untouched for rollback;
-- new multi-company accounting operations use only these tables.
CREATE TABLE IF NOT EXISTS monarch_tenant_accounts (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES monarch_companies(id) ON DELETE RESTRICT,
  code TEXT NOT NULL COLLATE NOCASE,
  name TEXT NOT NULL,
  account_type TEXT NOT NULL CHECK(account_type IN ('Asset','Liability','Equity','Revenue','Expense')),
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
  created_utc TEXT NOT NULL,
  UNIQUE(company_id,id),
  UNIQUE(company_id,code)
);
CREATE INDEX IF NOT EXISTS ix_tenant_accounts_company_active
  ON monarch_tenant_accounts(company_id,is_active,code);

CREATE TABLE IF NOT EXISTS monarch_tenant_journals (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES monarch_companies(id) ON DELETE RESTRICT,
  branch_id TEXT NOT NULL,
  number TEXT NOT NULL COLLATE NOCASE,
  business_date TEXT NOT NULL,
  description TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('Draft','Posted','Reversed')),
  reversal_of_id TEXT NULL,
  posted_at_utc TEXT NULL,
  created_utc TEXT NOT NULL,
  CHECK(reversal_of_id IS NULL OR reversal_of_id <> id),
  UNIQUE(company_id,id),
  UNIQUE(company_id,number),
  FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
  FOREIGN KEY(company_id,reversal_of_id) REFERENCES monarch_tenant_journals(company_id,id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_tenant_journals_company_date
  ON monarch_tenant_journals(company_id,business_date,status);
CREATE INDEX IF NOT EXISTS ix_tenant_journals_company_branch
  ON monarch_tenant_journals(company_id,branch_id,business_date);
CREATE UNIQUE INDEX IF NOT EXISTS ux_tenant_journal_single_reversal
  ON monarch_tenant_journals(company_id,reversal_of_id) WHERE reversal_of_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS monarch_tenant_journal_lines (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id TEXT NOT NULL,
  journal_id TEXT NOT NULL,
  account_id TEXT NOT NULL,
  debit_minor INTEGER NOT NULL DEFAULT 0 CHECK(debit_minor >= 0),
  credit_minor INTEGER NOT NULL DEFAULT 0 CHECK(credit_minor >= 0),
  CHECK((debit_minor > 0 AND credit_minor = 0) OR (credit_minor > 0 AND debit_minor = 0)),
  FOREIGN KEY(company_id,journal_id) REFERENCES monarch_tenant_journals(company_id,id) ON DELETE RESTRICT,
  FOREIGN KEY(company_id,account_id) REFERENCES monarch_tenant_accounts(company_id,id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_tenant_lines_company_account
  ON monarch_tenant_journal_lines(company_id,account_id,journal_id);

CREATE TRIGGER IF NOT EXISTS tenant_account_company_active
BEFORE INSERT ON monarch_tenant_accounts
WHEN NOT EXISTS(SELECT 1 FROM monarch_companies WHERE id=NEW.company_id AND is_active=1)
BEGIN SELECT RAISE(ABORT,'Company is inactive or missing'); END;

CREATE TRIGGER IF NOT EXISTS tenant_journal_insert_draft
BEFORE INSERT ON monarch_tenant_journals WHEN NEW.status <> 'Draft'
BEGIN SELECT RAISE(ABORT,'Journal must be inserted as Draft'); END;

CREATE TRIGGER IF NOT EXISTS tenant_journal_branch_active
BEFORE INSERT ON monarch_tenant_journals
WHEN NOT EXISTS(SELECT 1 FROM monarch_branches b JOIN monarch_companies c ON c.id=b.company_id
  WHERE b.company_id=NEW.company_id AND b.id=NEW.branch_id AND b.is_active=1 AND c.is_active=1)
BEGIN SELECT RAISE(ABORT,'Company or branch is inactive'); END;

CREATE TRIGGER IF NOT EXISTS tenant_journal_valid_transition
BEFORE UPDATE OF status ON monarch_tenant_journals
WHEN NOT ((OLD.status='Draft' AND NEW.status='Posted') OR (OLD.status='Posted' AND NEW.status='Reversed'))
BEGIN SELECT RAISE(ABORT,'Invalid journal status transition'); END;

CREATE TRIGGER IF NOT EXISTS tenant_journal_post_requires_balanced
BEFORE UPDATE OF status ON monarch_tenant_journals WHEN OLD.status='Draft' AND NEW.status='Posted'
BEGIN
 SELECT CASE WHEN (SELECT COUNT(*) FROM monarch_tenant_journal_lines WHERE company_id=NEW.company_id AND journal_id=NEW.id)<2
 THEN RAISE(ABORT,'Journal requires at least two lines') END;
 SELECT CASE WHEN COALESCE((SELECT SUM(debit_minor) FROM monarch_tenant_journal_lines WHERE company_id=NEW.company_id AND journal_id=NEW.id),0)
 <> COALESCE((SELECT SUM(credit_minor) FROM monarch_tenant_journal_lines WHERE company_id=NEW.company_id AND journal_id=NEW.id),0)
 THEN RAISE(ABORT,'Journal is not balanced') END;
 SELECT CASE WHEN EXISTS(SELECT 1 FROM monarch_tenant_journal_lines l JOIN monarch_tenant_accounts a
   ON a.company_id=l.company_id AND a.id=l.account_id
   WHERE l.company_id=NEW.company_id AND l.journal_id=NEW.id AND a.is_active=0)
 THEN RAISE(ABORT,'Inactive account cannot be posted') END;
 SELECT CASE WHEN NEW.reversal_of_id IS NOT NULL AND EXISTS(
   SELECT account_id FROM (
     SELECT account_id FROM monarch_tenant_journal_lines WHERE company_id=NEW.company_id AND journal_id=NEW.id
     UNION SELECT account_id FROM monarch_tenant_journal_lines WHERE company_id=NEW.company_id AND journal_id=NEW.reversal_of_id
   ) x
   WHERE COALESCE((SELECT SUM(debit_minor) FROM monarch_tenant_journal_lines WHERE company_id=NEW.company_id AND journal_id=NEW.id AND account_id=x.account_id),0)
      <> COALESCE((SELECT SUM(credit_minor) FROM monarch_tenant_journal_lines WHERE company_id=NEW.company_id AND journal_id=NEW.reversal_of_id AND account_id=x.account_id),0)
      OR COALESCE((SELECT SUM(credit_minor) FROM monarch_tenant_journal_lines WHERE company_id=NEW.company_id AND journal_id=NEW.id AND account_id=x.account_id),0)
      <> COALESCE((SELECT SUM(debit_minor) FROM monarch_tenant_journal_lines WHERE company_id=NEW.company_id AND journal_id=NEW.reversal_of_id AND account_id=x.account_id),0))
 THEN RAISE(ABORT,'Reversal does not exactly invert original') END;
END;

CREATE TRIGGER IF NOT EXISTS tenant_reversal_target_must_be_posted
BEFORE INSERT ON monarch_tenant_journals WHEN NEW.reversal_of_id IS NOT NULL
BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM monarch_tenant_journals WHERE company_id=NEW.company_id AND id=NEW.reversal_of_id AND status='Posted')
 THEN RAISE(ABORT,'Only a posted journal in the same company can be reversed') END;
END;

CREATE TRIGGER IF NOT EXISTS tenant_original_reversal_requires_posted_inverse
BEFORE UPDATE OF status ON monarch_tenant_journals WHEN OLD.status='Posted' AND NEW.status='Reversed'
BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM monarch_tenant_journals WHERE company_id=OLD.company_id AND reversal_of_id=OLD.id AND status='Posted')
 THEN RAISE(ABORT,'Posted inverse journal required') END;
END;

CREATE TRIGGER IF NOT EXISTS tenant_lines_insert_draft_only
BEFORE INSERT ON monarch_tenant_journal_lines
WHEN (SELECT status FROM monarch_tenant_journals WHERE company_id=NEW.company_id AND id=NEW.journal_id)<>'Draft'
BEGIN SELECT RAISE(ABORT,'Lines may only be added to drafts'); END;
CREATE TRIGGER IF NOT EXISTS tenant_lines_update_draft_only
BEFORE UPDATE ON monarch_tenant_journal_lines
WHEN (SELECT status FROM monarch_tenant_journals WHERE company_id=OLD.company_id AND id=OLD.journal_id)<>'Draft'
  OR (SELECT status FROM monarch_tenant_journals WHERE company_id=NEW.company_id AND id=NEW.journal_id)<>'Draft'
BEGIN SELECT RAISE(ABORT,'Lines may only be changed between drafts'); END;
CREATE TRIGGER IF NOT EXISTS tenant_lines_delete_draft_only
BEFORE DELETE ON monarch_tenant_journal_lines
WHEN (SELECT status FROM monarch_tenant_journals WHERE company_id=OLD.company_id AND id=OLD.journal_id)<>'Draft'
BEGIN SELECT RAISE(ABORT,'Posted lines are immutable'); END;
CREATE TRIGGER IF NOT EXISTS tenant_journals_immutable_header
BEFORE UPDATE OF company_id,branch_id,number,business_date,description,reversal_of_id ON monarch_tenant_journals
WHEN OLD.status<>'Draft'
BEGIN SELECT RAISE(ABORT,'Posted journal header is immutable'); END;

CREATE TRIGGER IF NOT EXISTS tenant_journals_immutable_delete
BEFORE DELETE ON monarch_tenant_journals WHEN OLD.status<>'Draft'
BEGIN SELECT RAISE(ABORT,'Posted journals cannot be deleted'); END;
