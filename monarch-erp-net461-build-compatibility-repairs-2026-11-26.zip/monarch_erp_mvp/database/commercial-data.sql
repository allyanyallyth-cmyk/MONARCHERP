PRAGMA foreign_keys = ON;
-- MONARCH commercial master data and immutable inventory movement ledger.
CREATE TABLE IF NOT EXISTS monarch_parties (
 id TEXT NOT NULL, company_id TEXT NOT NULL, code TEXT NOT NULL COLLATE NOCASE,
 party_type TEXT NOT NULL CHECK(party_type IN ('Customer','Supplier','Both')),
 legal_name TEXT NOT NULL CHECK(length(trim(legal_name))>0), display_name TEXT NOT NULL,
 tax_number TEXT NULL, phone TEXT NULL, email TEXT NULL, address TEXT NULL,
 credit_limit_minor INTEGER NOT NULL DEFAULT 0 CHECK(credit_limit_minor>=0),
 payment_terms_days INTEGER NOT NULL DEFAULT 0 CHECK(payment_terms_days>=0),
 is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN(0,1)), created_utc TEXT NOT NULL,
 PRIMARY KEY(company_id,id), UNIQUE(company_id,code),
 FOREIGN KEY(company_id) REFERENCES monarch_companies(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_monarch_parties_name ON monarch_parties(company_id,display_name);
CREATE TABLE IF NOT EXISTS monarch_item_groups (
 id TEXT NOT NULL, company_id TEXT NOT NULL, parent_id TEXT NULL, code TEXT NOT NULL COLLATE NOCASE,
 name TEXT NOT NULL CHECK(length(trim(name))>0), is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN(0,1)),
 PRIMARY KEY(company_id,id), UNIQUE(company_id,code),
 FOREIGN KEY(company_id) REFERENCES monarch_companies(id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,parent_id) REFERENCES monarch_item_groups(company_id,id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS monarch_units (
 id TEXT NOT NULL, company_id TEXT NOT NULL, code TEXT NOT NULL COLLATE NOCASE, name TEXT NOT NULL,
 decimal_places INTEGER NOT NULL DEFAULT 0 CHECK(decimal_places BETWEEN 0 AND 6),
 PRIMARY KEY(company_id,id), UNIQUE(company_id,code),
 FOREIGN KEY(company_id) REFERENCES monarch_companies(id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS monarch_items (
 id TEXT NOT NULL, company_id TEXT NOT NULL, group_id TEXT NULL, unit_id TEXT NOT NULL,
 sku TEXT NOT NULL COLLATE NOCASE, barcode TEXT NULL, name TEXT NOT NULL CHECK(length(trim(name))>0),
 item_type TEXT NOT NULL CHECK(item_type IN('Stock','Service','NonStock')),
 cost_minor INTEGER NOT NULL DEFAULT 0 CHECK(cost_minor>=0), sale_price_minor INTEGER NOT NULL DEFAULT 0 CHECK(sale_price_minor>=0),
 reorder_level_milli INTEGER NOT NULL DEFAULT 0 CHECK(reorder_level_milli>=0), allow_negative INTEGER NOT NULL DEFAULT 0 CHECK(allow_negative IN(0,1)),
 is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN(0,1)), created_utc TEXT NOT NULL,
 PRIMARY KEY(company_id,id), UNIQUE(company_id,sku), UNIQUE(company_id,barcode),
 FOREIGN KEY(company_id) REFERENCES monarch_companies(id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,group_id) REFERENCES monarch_item_groups(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,unit_id) REFERENCES monarch_units(company_id,id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS monarch_warehouses (
 id TEXT NOT NULL, company_id TEXT NOT NULL, branch_id TEXT NOT NULL, code TEXT NOT NULL COLLATE NOCASE,
 name TEXT NOT NULL, is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN(0,1)), created_utc TEXT NOT NULL,
 PRIMARY KEY(company_id,id), UNIQUE(company_id,code),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS monarch_stock_movements (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL, warehouse_id TEXT NOT NULL,
 item_id TEXT NOT NULL, ledger_sequence INTEGER NOT NULL DEFAULT 0 CHECK(ledger_sequence>=0), movement_type TEXT NOT NULL CHECK(movement_type IN('Opening','Receipt','Issue','TransferIn','TransferOut','AdjustmentIn','AdjustmentOut','SalesReturn','PurchaseReturn')),
 quantity_milli INTEGER NOT NULL CHECK(quantity_milli>0), unit_cost_minor INTEGER NOT NULL DEFAULT 0 CHECK(unit_cost_minor>=0),
 source_type TEXT NULL, source_id TEXT NULL, idempotency_key TEXT NOT NULL, occurred_utc TEXT NOT NULL,
 actor_user_id TEXT NOT NULL,
 UNIQUE(company_id,idempotency_key), UNIQUE(company_id,id),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,warehouse_id) REFERENCES monarch_warehouses(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,item_id) REFERENCES monarch_items(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(actor_user_id) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
-- Durable per-document inventory cost trace. One row records the cost basis used by a
-- receipt/issue and allows returns to reverse the original cost rather than item defaults.
CREATE TABLE IF NOT EXISTS monarch_inventory_cost_allocations (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL,
 document_id TEXT NOT NULL, document_line_id TEXT NOT NULL, movement_id TEXT NOT NULL,
 allocation_type TEXT NOT NULL CHECK(allocation_type IN('PurchaseReceipt','SalesIssue','SalesReturnReversal','PurchaseReturnReversal')),
 quantity_milli INTEGER NOT NULL CHECK(quantity_milli>0), unit_cost_minor INTEGER NOT NULL CHECK(unit_cost_minor>=0),
 total_cost_minor INTEGER NOT NULL CHECK(total_cost_minor>=0), cost_method TEXT NOT NULL CHECK(cost_method IN('DocumentCost','MovingWeightedAverage','OriginalAllocation')),
 reverses_allocation_id TEXT NULL, created_utc TEXT NOT NULL,
 UNIQUE(company_id,movement_id), UNIQUE(company_id,id),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,document_id) REFERENCES monarch_commercial_documents(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,document_line_id) REFERENCES monarch_commercial_document_lines(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,movement_id) REFERENCES monarch_stock_movements(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,reverses_allocation_id) REFERENCES monarch_inventory_cost_allocations(company_id,id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_inventory_cost_allocation_source_line
 ON monarch_inventory_cost_allocations(company_id,document_line_id,allocation_type);
CREATE TRIGGER IF NOT EXISTS trg_inventory_cost_allocation_no_update BEFORE UPDATE ON monarch_inventory_cost_allocations
 BEGIN SELECT RAISE(ABORT,'Inventory cost allocations are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_inventory_cost_allocation_no_delete BEFORE DELETE ON monarch_inventory_cost_allocations
 BEGIN SELECT RAISE(ABORT,'Inventory cost allocations are immutable'); END;

CREATE INDEX IF NOT EXISTS ix_stock_balance_lookup ON monarch_stock_movements(company_id,warehouse_id,item_id,occurred_utc);
CREATE TRIGGER IF NOT EXISTS trg_stock_movement_no_update BEFORE UPDATE ON monarch_stock_movements BEGIN SELECT RAISE(ABORT,'Stock movements are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_stock_movement_no_delete BEFORE DELETE ON monarch_stock_movements BEGIN SELECT RAISE(ABORT,'Stock movements are immutable'); END;
CREATE VIEW IF NOT EXISTS monarch_stock_balances AS
SELECT company_id,warehouse_id,item_id,
 SUM(CASE WHEN movement_type IN('Opening','Receipt','TransferIn','AdjustmentIn','SalesReturn') THEN quantity_milli ELSE -quantity_milli END) AS quantity_milli
FROM monarch_stock_movements GROUP BY company_id,warehouse_id,item_id;
CREATE TRIGGER IF NOT EXISTS trg_stock_prevent_negative AFTER INSERT ON monarch_stock_movements
WHEN (SELECT allow_negative FROM monarch_items WHERE company_id=NEW.company_id AND id=NEW.item_id)=0
 AND COALESCE((SELECT quantity_milli FROM monarch_stock_balances WHERE company_id=NEW.company_id AND warehouse_id=NEW.warehouse_id AND item_id=NEW.item_id),0)<0
BEGIN SELECT RAISE(ABORT,'Negative inventory is disabled for this item'); END;

-- Sales/purchase document journal. Posted documents are immutable; inventory and
-- accounting hand-off are committed with the document state transition.
CREATE TABLE IF NOT EXISTS monarch_commercial_documents (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL,
 document_type TEXT NOT NULL CHECK(document_type IN('Purchase','Sale')),
 document_number TEXT NOT NULL COLLATE NOCASE, party_id TEXT NOT NULL,
 warehouse_id TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Draft' CHECK(status IN('Draft','Posted','Cancelled')),
 currency_code TEXT NOT NULL CHECK(length(currency_code)=3), currency_scale INTEGER NOT NULL CHECK(currency_scale BETWEEN 0 AND 4),
 subtotal_minor INTEGER NOT NULL DEFAULT 0 CHECK(subtotal_minor>=0), tax_minor INTEGER NOT NULL DEFAULT 0 CHECK(tax_minor>=0), total_minor INTEGER NOT NULL DEFAULT 0 CHECK(total_minor>=0),
 created_utc TEXT NOT NULL, created_by TEXT NOT NULL, posted_utc TEXT NULL, posted_by TEXT NULL,
 UNIQUE(company_id,document_type,document_number), UNIQUE(company_id,id),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,party_id) REFERENCES monarch_parties(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,warehouse_id) REFERENCES monarch_warehouses(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(created_by) REFERENCES monarch_users(id) ON DELETE RESTRICT,
 FOREIGN KEY(posted_by) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS monarch_commercial_document_lines (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, document_id TEXT NOT NULL, line_number INTEGER NOT NULL CHECK(line_number>0),
 item_id TEXT NOT NULL, item_sku_snapshot TEXT NOT NULL, item_name_snapshot TEXT NOT NULL,
 quantity_milli INTEGER NOT NULL CHECK(quantity_milli>0), unit_price_minor INTEGER NOT NULL CHECK(unit_price_minor>=0),
 tax_rate_bps INTEGER NOT NULL DEFAULT 0 CHECK(tax_rate_bps BETWEEN 0 AND 10000),
 net_minor INTEGER NOT NULL CHECK(net_minor>=0), tax_minor INTEGER NOT NULL CHECK(tax_minor>=0), total_minor INTEGER NOT NULL CHECK(total_minor>=0),
 UNIQUE(company_id,document_id,line_number), UNIQUE(company_id,id),
 FOREIGN KEY(company_id,document_id) REFERENCES monarch_commercial_documents(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,item_id) REFERENCES monarch_items(company_id,id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_commercial_document_lines_company_id ON monarch_commercial_document_lines(company_id,id);
CREATE INDEX IF NOT EXISTS ix_commercial_documents_branch ON monarch_commercial_documents(company_id,branch_id,created_utc);
CREATE TABLE IF NOT EXISTS monarch_accounting_posting_outbox (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL, document_id TEXT NOT NULL,
 event_type TEXT NOT NULL CHECK(event_type IN('PurchasePosted','SalePosted')), payload_version INTEGER NOT NULL DEFAULT 1,
 status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN('Pending','Processed','Failed')),
 attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts>=0), last_error TEXT NULL, created_utc TEXT NOT NULL, processed_utc TEXT NULL,
 UNIQUE(company_id,document_id),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,document_id) REFERENCES monarch_commercial_documents(company_id,id) ON DELETE RESTRICT
);
CREATE TRIGGER IF NOT EXISTS trg_posted_document_no_update BEFORE UPDATE ON monarch_commercial_documents
WHEN OLD.status='Posted' BEGIN SELECT RAISE(ABORT,'Posted commercial documents are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_posted_document_no_delete BEFORE DELETE ON monarch_commercial_documents
WHEN OLD.status='Posted' BEGIN SELECT RAISE(ABORT,'Posted commercial documents cannot be deleted'); END;
CREATE TRIGGER IF NOT EXISTS trg_posted_lines_no_insert BEFORE INSERT ON monarch_commercial_document_lines
WHEN (SELECT status FROM monarch_commercial_documents WHERE company_id=NEW.company_id AND id=NEW.document_id)='Posted'
BEGIN SELECT RAISE(ABORT,'Cannot add lines to a posted document'); END;
CREATE TRIGGER IF NOT EXISTS trg_posted_lines_no_update BEFORE UPDATE ON monarch_commercial_document_lines
WHEN (SELECT status FROM monarch_commercial_documents WHERE company_id=OLD.company_id AND id=OLD.document_id)='Posted'
BEGIN SELECT RAISE(ABORT,'Posted document lines are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_posted_lines_no_delete BEFORE DELETE ON monarch_commercial_document_lines
WHEN (SELECT status FROM monarch_commercial_documents WHERE company_id=OLD.company_id AND id=OLD.document_id)='Posted'
BEGIN SELECT RAISE(ABORT,'Posted document lines cannot be deleted'); END;

-- Receipts and supplier payments. Every posted payment is fully allocated in this
-- foundation; advances/unapplied cash are intentionally deferred.
CREATE TABLE IF NOT EXISTS monarch_commercial_payments (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL,
 payment_type TEXT NOT NULL CHECK(payment_type IN('CustomerReceipt','SupplierPayment')),
 payment_number TEXT NOT NULL COLLATE NOCASE, party_id TEXT NOT NULL,
 payment_method TEXT NOT NULL CHECK(payment_method IN('Cash','Bank')),
 cash_bank_account_code TEXT NOT NULL CHECK(length(trim(cash_bank_account_code))>0),
 currency_code TEXT NOT NULL CHECK(length(currency_code)=3), currency_scale INTEGER NOT NULL CHECK(currency_scale BETWEEN 0 AND 4),
 amount_minor INTEGER NOT NULL CHECK(amount_minor>0), payment_date TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'Posted' CHECK(status IN('Posted','Voided')),
 created_utc TEXT NOT NULL, created_by TEXT NOT NULL,
 UNIQUE(company_id,payment_type,payment_number), UNIQUE(company_id,id),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,party_id) REFERENCES monarch_parties(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(created_by) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS monarch_commercial_payment_allocations (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, payment_id TEXT NOT NULL, document_id TEXT NOT NULL,
 amount_minor INTEGER NOT NULL CHECK(amount_minor>0),
 UNIQUE(company_id,payment_id,document_id),
 FOREIGN KEY(company_id,payment_id) REFERENCES monarch_commercial_payments(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,document_id) REFERENCES monarch_commercial_documents(company_id,id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS monarch_payment_accounting_outbox (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL, payment_id TEXT NOT NULL,
 event_type TEXT NOT NULL CHECK(event_type IN('CustomerReceiptPosted','SupplierPaymentPosted')),
 status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN('Pending','Processed','Failed')),
 attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts>=0), last_error TEXT NULL,
 created_utc TEXT NOT NULL, processed_utc TEXT NULL,
 UNIQUE(company_id,payment_id),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,payment_id) REFERENCES monarch_commercial_payments(company_id,id) ON DELETE RESTRICT
);
CREATE TRIGGER IF NOT EXISTS trg_posted_payment_no_update BEFORE UPDATE ON monarch_commercial_payments
WHEN OLD.status='Posted' BEGIN SELECT RAISE(ABORT,'Posted payments are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_posted_payment_no_delete BEFORE DELETE ON monarch_commercial_payments
WHEN OLD.status='Posted' BEGIN SELECT RAISE(ABORT,'Posted payments cannot be deleted'); END;
CREATE TRIGGER IF NOT EXISTS trg_payment_allocation_no_update BEFORE UPDATE ON monarch_commercial_payment_allocations
BEGIN SELECT RAISE(ABORT,'Payment allocations are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_payment_allocation_no_delete BEFORE DELETE ON monarch_commercial_payment_allocations
BEGIN SELECT RAISE(ABORT,'Payment allocations cannot be deleted'); END;
CREATE TRIGGER IF NOT EXISTS trg_payment_allocation_validate BEFORE INSERT ON monarch_commercial_payment_allocations
BEGIN
 SELECT CASE WHEN NOT EXISTS (
  SELECT 1 FROM monarch_commercial_payments p JOIN monarch_commercial_documents d
   ON d.company_id=p.company_id AND d.id=NEW.document_id
  WHERE p.company_id=NEW.company_id AND p.id=NEW.payment_id AND p.status='Posted' AND d.status='Posted'
   AND p.party_id=d.party_id AND p.currency_code=d.currency_code AND p.currency_scale=d.currency_scale
   AND p.branch_id=d.branch_id
   AND ((p.payment_type='CustomerReceipt' AND d.document_type='Sale') OR (p.payment_type='SupplierPayment' AND d.document_type='Purchase'))
 ) THEN RAISE(ABORT,'Payment allocation document does not match payment') END;
 SELECT CASE WHEN COALESCE((SELECT SUM(amount_minor) FROM monarch_commercial_payment_allocations WHERE company_id=NEW.company_id AND payment_id=NEW.payment_id),0)+NEW.amount_minor >
  (SELECT amount_minor FROM monarch_commercial_payments WHERE company_id=NEW.company_id AND id=NEW.payment_id)
  THEN RAISE(ABORT,'Payment allocations exceed payment amount') END;
 SELECT CASE WHEN COALESCE((SELECT SUM(amount_minor) FROM monarch_commercial_payment_allocations WHERE company_id=NEW.company_id AND document_id=NEW.document_id),0)+NEW.amount_minor >
  (SELECT total_minor FROM monarch_commercial_documents WHERE company_id=NEW.company_id AND id=NEW.document_id)
  THEN RAISE(ABORT,'Payment allocations exceed document total') END;
END;
-- Sales and purchase returns. A return is linked to a posted source invoice and
-- creates immutable stock movements plus an accounting outbox event on posting.
CREATE TABLE IF NOT EXISTS monarch_commercial_returns (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL,
 return_type TEXT NOT NULL CHECK(return_type IN('SalesReturn','PurchaseReturn')),
 return_number TEXT NOT NULL COLLATE NOCASE, source_document_id TEXT NOT NULL,
 party_id TEXT NOT NULL, warehouse_id TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'Draft' CHECK(status IN('Draft','Posted','Cancelled')),
 currency_code TEXT NOT NULL CHECK(length(currency_code)=3), currency_scale INTEGER NOT NULL CHECK(currency_scale BETWEEN 0 AND 4),
 subtotal_minor INTEGER NOT NULL DEFAULT 0 CHECK(subtotal_minor>=0), tax_minor INTEGER NOT NULL DEFAULT 0 CHECK(tax_minor>=0), total_minor INTEGER NOT NULL DEFAULT 0 CHECK(total_minor>=0),
 created_utc TEXT NOT NULL, created_by TEXT NOT NULL, posted_utc TEXT NULL, posted_by TEXT NULL,
 UNIQUE(company_id,return_type,return_number), UNIQUE(company_id,id),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,source_document_id) REFERENCES monarch_commercial_documents(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,party_id) REFERENCES monarch_parties(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,warehouse_id) REFERENCES monarch_warehouses(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(created_by) REFERENCES monarch_users(id) ON DELETE RESTRICT,
 FOREIGN KEY(posted_by) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS monarch_commercial_return_lines (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, return_id TEXT NOT NULL, source_line_id TEXT NOT NULL,
 line_number INTEGER NOT NULL CHECK(line_number>0), item_id TEXT NOT NULL,
 item_sku_snapshot TEXT NOT NULL, item_name_snapshot TEXT NOT NULL,
 quantity_milli INTEGER NOT NULL CHECK(quantity_milli>0), unit_price_minor INTEGER NOT NULL CHECK(unit_price_minor>=0),
 tax_rate_bps INTEGER NOT NULL CHECK(tax_rate_bps BETWEEN 0 AND 10000),
 net_minor INTEGER NOT NULL CHECK(net_minor>=0), tax_minor INTEGER NOT NULL CHECK(tax_minor>=0), total_minor INTEGER NOT NULL CHECK(total_minor>=0),
 UNIQUE(company_id,return_id,line_number), UNIQUE(company_id,return_id,source_line_id), UNIQUE(company_id,id), UNIQUE(company_id,return_id,id),
 FOREIGN KEY(company_id,return_id) REFERENCES monarch_commercial_returns(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,source_line_id) REFERENCES monarch_commercial_document_lines(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,item_id) REFERENCES monarch_items(company_id,id) ON DELETE RESTRICT
);
-- Immutable trace of inventory cost reversed by each posted return line.
CREATE TABLE IF NOT EXISTS monarch_inventory_return_cost_allocations (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL,
 return_id TEXT NOT NULL, return_line_id TEXT NOT NULL, source_allocation_id TEXT NOT NULL,
 movement_id TEXT NOT NULL, allocation_type TEXT NOT NULL CHECK(allocation_type IN('SalesReturnReversal','PurchaseReturnReversal')),
 quantity_milli INTEGER NOT NULL CHECK(quantity_milli>0), unit_cost_minor INTEGER NOT NULL CHECK(unit_cost_minor>=0),
 total_cost_minor INTEGER NOT NULL CHECK(total_cost_minor>=0), created_utc TEXT NOT NULL,
 UNIQUE(company_id,movement_id),
 FOREIGN KEY(company_id,return_id) REFERENCES monarch_commercial_returns(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,return_id,return_line_id) REFERENCES monarch_commercial_return_lines(company_id,return_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,source_allocation_id) REFERENCES monarch_inventory_cost_allocations(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,movement_id) REFERENCES monarch_stock_movements(company_id,id) ON DELETE RESTRICT
);
-- Explicit unique indexes also upgrade older customer databases where the base tables
-- predate the composite tenant keys declared in fresh-install CREATE TABLE statements.
CREATE UNIQUE INDEX IF NOT EXISTS ux_stock_movements_company_id ON monarch_stock_movements(company_id,id);
CREATE UNIQUE INDEX IF NOT EXISTS ux_inventory_cost_allocations_company_id ON monarch_inventory_cost_allocations(company_id,id);
CREATE UNIQUE INDEX IF NOT EXISTS ux_return_lines_company_return_id ON monarch_commercial_return_lines(company_id,return_id,id);
CREATE INDEX IF NOT EXISTS ix_inventory_return_cost_source ON monarch_inventory_return_cost_allocations(company_id,source_allocation_id);
CREATE TRIGGER IF NOT EXISTS trg_inventory_return_cost_no_update BEFORE UPDATE ON monarch_inventory_return_cost_allocations
 BEGIN SELECT RAISE(ABORT,'Inventory return cost allocations are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_inventory_return_cost_no_delete BEFORE DELETE ON monarch_inventory_return_cost_allocations
 BEGIN SELECT RAISE(ABORT,'Inventory return cost allocations are immutable'); END;
CREATE INDEX IF NOT EXISTS ix_commercial_returns_source ON monarch_commercial_returns(company_id,source_document_id,status);
CREATE TABLE IF NOT EXISTS monarch_return_accounting_outbox (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL, return_id TEXT NOT NULL,
 event_type TEXT NOT NULL CHECK(event_type IN('SalesReturnPosted','PurchaseReturnPosted')),
 status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN('Pending','Processed','Failed')),
 attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts>=0), last_error TEXT NULL, created_utc TEXT NOT NULL, processed_utc TEXT NULL,
 UNIQUE(company_id,return_id),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,return_id) REFERENCES monarch_commercial_returns(company_id,id) ON DELETE RESTRICT
);
CREATE TRIGGER IF NOT EXISTS trg_return_validate_source BEFORE INSERT ON monarch_commercial_returns
BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM monarch_commercial_documents d WHERE d.company_id=NEW.company_id AND d.id=NEW.source_document_id
  AND d.branch_id=NEW.branch_id AND d.party_id=NEW.party_id AND d.warehouse_id=NEW.warehouse_id AND d.status='Posted'
  AND d.currency_code=NEW.currency_code AND d.currency_scale=NEW.currency_scale
  AND ((NEW.return_type='SalesReturn' AND d.document_type='Sale') OR (NEW.return_type='PurchaseReturn' AND d.document_type='Purchase')))
 THEN RAISE(ABORT,'Return source document does not match return context') END;
END;
CREATE TRIGGER IF NOT EXISTS trg_posted_return_no_update BEFORE UPDATE ON monarch_commercial_returns
WHEN OLD.status='Posted' BEGIN SELECT RAISE(ABORT,'Posted returns are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_posted_return_no_delete BEFORE DELETE ON monarch_commercial_returns
WHEN OLD.status='Posted' BEGIN SELECT RAISE(ABORT,'Posted returns cannot be deleted'); END;
CREATE TRIGGER IF NOT EXISTS trg_posted_return_line_no_insert BEFORE INSERT ON monarch_commercial_return_lines
WHEN (SELECT status FROM monarch_commercial_returns WHERE company_id=NEW.company_id AND id=NEW.return_id)='Posted'
BEGIN SELECT RAISE(ABORT,'Cannot add lines to a posted return'); END;
CREATE TRIGGER IF NOT EXISTS trg_posted_return_line_no_update BEFORE UPDATE ON monarch_commercial_return_lines
WHEN (SELECT status FROM monarch_commercial_returns WHERE company_id=OLD.company_id AND id=OLD.return_id)='Posted'
BEGIN SELECT RAISE(ABORT,'Posted return lines are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_posted_return_line_no_delete BEFORE DELETE ON monarch_commercial_return_lines
WHEN (SELECT status FROM monarch_commercial_returns WHERE company_id=OLD.company_id AND id=OLD.return_id)='Posted'
BEGIN SELECT RAISE(ABORT,'Posted return lines cannot be deleted'); END;
CREATE TRIGGER IF NOT EXISTS trg_return_line_validate BEFORE INSERT ON monarch_commercial_return_lines
BEGIN
 SELECT CASE WHEN NOT EXISTS (
  SELECT 1 FROM monarch_commercial_returns r
  JOIN monarch_commercial_document_lines sl ON sl.company_id=r.company_id AND sl.document_id=r.source_document_id AND sl.id=NEW.source_line_id
  WHERE r.company_id=NEW.company_id AND r.id=NEW.return_id AND r.status='Draft' AND sl.item_id=NEW.item_id
   AND sl.item_sku_snapshot=NEW.item_sku_snapshot AND sl.item_name_snapshot=NEW.item_name_snapshot
   AND sl.unit_price_minor=NEW.unit_price_minor AND sl.tax_rate_bps=NEW.tax_rate_bps
 ) THEN RAISE(ABORT,'Return line must reference an item line in its source invoice') END;
END;
CREATE TRIGGER IF NOT EXISTS trg_return_post_quantity_limit BEFORE UPDATE OF status ON monarch_commercial_returns
WHEN OLD.status='Draft' AND NEW.status='Posted'
BEGIN
 SELECT CASE WHEN EXISTS (
  SELECT 1 FROM monarch_commercial_return_lines current_line
  JOIN monarch_commercial_document_lines source_line ON source_line.company_id=current_line.company_id AND source_line.id=current_line.source_line_id
  WHERE current_line.company_id=NEW.company_id AND current_line.return_id=NEW.id
  AND source_line.quantity_milli < current_line.quantity_milli + COALESCE((
   SELECT SUM(other_line.quantity_milli) FROM monarch_commercial_return_lines other_line
   JOIN monarch_commercial_returns other_return ON other_return.company_id=other_line.company_id AND other_return.id=other_line.return_id
   WHERE other_line.company_id=current_line.company_id AND other_line.source_line_id=current_line.source_line_id
   AND other_return.status='Posted' AND other_return.id<>NEW.id
  ),0)
 ) THEN RAISE(ABORT,'Posted returns exceed source invoice quantity') END;
END;
CREATE TRIGGER IF NOT EXISTS trg_return_status_transition BEFORE UPDATE OF status ON monarch_commercial_returns
WHEN NOT (OLD.status='Draft' AND NEW.status IN('Posted','Cancelled'))
BEGIN SELECT RAISE(ABORT,'Invalid return status transition'); END;

-- Purchase-order workflow. Orders are separate from supplier invoices/receipts;
-- receiving is performed by a posted Purchase commercial document in the next workflow stage.
CREATE TABLE IF NOT EXISTS monarch_purchase_orders (
 id TEXT NOT NULL, company_id TEXT NOT NULL, branch_id TEXT NOT NULL,
 order_number TEXT NOT NULL COLLATE NOCASE, supplier_id TEXT NOT NULL, warehouse_id TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'Draft' CHECK(status IN('Draft','Approved','Cancelled','PartiallyReceived','Received')),
 currency_code TEXT NOT NULL CHECK(length(currency_code)=3), currency_scale INTEGER NOT NULL CHECK(currency_scale BETWEEN 0 AND 4),
 subtotal_minor INTEGER NOT NULL DEFAULT 0 CHECK(subtotal_minor>=0), tax_minor INTEGER NOT NULL DEFAULT 0 CHECK(tax_minor>=0), total_minor INTEGER NOT NULL DEFAULT 0 CHECK(total_minor>=0),
 expected_utc TEXT NULL, notes TEXT NULL, created_utc TEXT NOT NULL, created_by TEXT NOT NULL,
 approved_utc TEXT NULL, approved_by TEXT NULL,
 PRIMARY KEY(company_id,id), UNIQUE(company_id,branch_id,order_number),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,supplier_id) REFERENCES monarch_parties(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,warehouse_id) REFERENCES monarch_warehouses(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(created_by) REFERENCES monarch_users(id) ON DELETE RESTRICT,
 FOREIGN KEY(approved_by) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS monarch_purchase_order_lines (
 id TEXT NOT NULL, company_id TEXT NOT NULL, order_id TEXT NOT NULL, line_number INTEGER NOT NULL CHECK(line_number>0),
 item_id TEXT NOT NULL, item_sku_snapshot TEXT NOT NULL, item_name_snapshot TEXT NOT NULL,
 quantity_milli INTEGER NOT NULL CHECK(quantity_milli>0), received_quantity_milli INTEGER NOT NULL DEFAULT 0 CHECK(received_quantity_milli>=0 AND received_quantity_milli<=quantity_milli),
 unit_cost_minor INTEGER NOT NULL CHECK(unit_cost_minor>=0), tax_rate_bps INTEGER NOT NULL CHECK(tax_rate_bps BETWEEN 0 AND 10000),
 net_minor INTEGER NOT NULL CHECK(net_minor>=0), tax_minor INTEGER NOT NULL CHECK(tax_minor>=0), total_minor INTEGER NOT NULL CHECK(total_minor>=0),
 PRIMARY KEY(company_id,id), UNIQUE(company_id,order_id,line_number),
 FOREIGN KEY(company_id,order_id) REFERENCES monarch_purchase_orders(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,item_id) REFERENCES monarch_items(company_id,id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_purchase_orders_branch_status ON monarch_purchase_orders(company_id,branch_id,status,created_utc);
CREATE TRIGGER IF NOT EXISTS trg_purchase_order_lines_insert_draft BEFORE INSERT ON monarch_purchase_order_lines
WHEN (SELECT status FROM monarch_purchase_orders WHERE company_id=NEW.company_id AND id=NEW.order_id)<>'Draft'
BEGIN SELECT RAISE(ABORT,'Purchase order lines can only be added to draft orders'); END;
DROP TRIGGER IF EXISTS trg_purchase_order_lines_update_draft;
CREATE TRIGGER trg_purchase_order_lines_update_draft BEFORE UPDATE ON monarch_purchase_order_lines
WHEN (SELECT status FROM monarch_purchase_orders WHERE company_id=OLD.company_id AND id=OLD.order_id)<>'Draft'
 AND NOT (
  NEW.id=OLD.id AND NEW.company_id=OLD.company_id AND NEW.order_id=OLD.order_id AND NEW.line_number=OLD.line_number
  AND NEW.item_id=OLD.item_id AND NEW.item_sku_snapshot=OLD.item_sku_snapshot AND NEW.item_name_snapshot=OLD.item_name_snapshot
  AND NEW.quantity_milli=OLD.quantity_milli AND NEW.unit_cost_minor=OLD.unit_cost_minor AND NEW.tax_rate_bps=OLD.tax_rate_bps
  AND NEW.net_minor=OLD.net_minor AND NEW.tax_minor=OLD.tax_minor AND NEW.total_minor=OLD.total_minor
  AND NEW.received_quantity_milli>=OLD.received_quantity_milli AND NEW.received_quantity_milli<=NEW.quantity_milli
 )
BEGIN SELECT RAISE(ABORT,'Approved purchase order lines only allow monotonic received-quantity updates'); END;
CREATE TRIGGER IF NOT EXISTS trg_purchase_order_lines_delete_draft BEFORE DELETE ON monarch_purchase_order_lines
WHEN (SELECT status FROM monarch_purchase_orders WHERE company_id=OLD.company_id AND id=OLD.order_id)<>'Draft'
BEGIN SELECT RAISE(ABORT,'Approved purchase order lines are immutable'); END;

-- Purchase-order receipts are posted atomically with their commercial purchase document,
-- stock movements, valuation cost allocations and accounting outbox hand-off.
CREATE TABLE IF NOT EXISTS monarch_purchase_receipts (
 id TEXT NOT NULL, company_id TEXT NOT NULL, branch_id TEXT NOT NULL,
 purchase_order_id TEXT NOT NULL, commercial_document_id TEXT NOT NULL,
 receipt_number TEXT NOT NULL COLLATE NOCASE,
 status TEXT NOT NULL CHECK(status IN('Posted')),
 created_utc TEXT NOT NULL, created_by TEXT NOT NULL, posted_utc TEXT NOT NULL, posted_by TEXT NOT NULL,
 total_minor INTEGER NOT NULL CHECK(total_minor>=0), currency_code TEXT NOT NULL CHECK(length(currency_code)=3),
 PRIMARY KEY(company_id,id), UNIQUE(company_id,branch_id,receipt_number),
 UNIQUE(company_id,commercial_document_id),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,purchase_order_id) REFERENCES monarch_purchase_orders(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,commercial_document_id) REFERENCES monarch_commercial_documents(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(created_by) REFERENCES monarch_users(id) ON DELETE RESTRICT,
 FOREIGN KEY(posted_by) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS monarch_purchase_receipt_lines (
 id TEXT NOT NULL, company_id TEXT NOT NULL, receipt_id TEXT NOT NULL,
 purchase_order_line_id TEXT NOT NULL, commercial_document_line_id TEXT NOT NULL,
 item_id TEXT NOT NULL, quantity_milli INTEGER NOT NULL CHECK(quantity_milli>0),
 unit_cost_minor INTEGER NOT NULL CHECK(unit_cost_minor>=0),
 PRIMARY KEY(company_id,id),
 UNIQUE(company_id,receipt_id,purchase_order_line_id),
 UNIQUE(company_id,commercial_document_line_id),
 FOREIGN KEY(company_id,receipt_id) REFERENCES monarch_purchase_receipts(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,purchase_order_line_id) REFERENCES monarch_purchase_order_lines(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,commercial_document_line_id) REFERENCES monarch_commercial_document_lines(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,item_id) REFERENCES monarch_items(company_id,id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_purchase_receipts_order ON monarch_purchase_receipts(company_id,purchase_order_id,posted_utc);
CREATE TRIGGER IF NOT EXISTS trg_purchase_receipt_no_update BEFORE UPDATE ON monarch_purchase_receipts
 BEGIN SELECT RAISE(ABORT,'Posted purchase receipts are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_purchase_receipt_no_delete BEFORE DELETE ON monarch_purchase_receipts
 BEGIN SELECT RAISE(ABORT,'Posted purchase receipts cannot be deleted'); END;
CREATE TRIGGER IF NOT EXISTS trg_purchase_receipt_line_no_update BEFORE UPDATE ON monarch_purchase_receipt_lines
 BEGIN SELECT RAISE(ABORT,'Posted purchase receipt lines are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_purchase_receipt_line_no_delete BEFORE DELETE ON monarch_purchase_receipt_lines
 BEGIN SELECT RAISE(ABORT,'Posted purchase receipt lines cannot be deleted'); END;

-- Supplier invoices are separate liabilities documents; they never reuse receipt documents.
CREATE TABLE IF NOT EXISTS monarch_supplier_invoices (
 id TEXT NOT NULL, company_id TEXT NOT NULL, branch_id TEXT NOT NULL, supplier_id TEXT NOT NULL,
 purchase_order_id TEXT NOT NULL, invoice_number TEXT NOT NULL COLLATE NOCASE,
 supplier_invoice_date TEXT NOT NULL, currency_code TEXT NOT NULL CHECK(length(currency_code)=3),
 currency_scale INTEGER NOT NULL CHECK(currency_scale BETWEEN 0 AND 4),
 status TEXT NOT NULL CHECK(status IN('Draft','Posted','Cancelled')),
 subtotal_minor INTEGER NOT NULL DEFAULT 0 CHECK(subtotal_minor>=0), tax_minor INTEGER NOT NULL DEFAULT 0 CHECK(tax_minor>=0), total_minor INTEGER NOT NULL DEFAULT 0 CHECK(total_minor>=0),
 created_utc TEXT NOT NULL, created_by TEXT NOT NULL, posted_utc TEXT NULL, posted_by TEXT NULL,
 PRIMARY KEY(company_id,id), UNIQUE(company_id,branch_id,supplier_id,invoice_number),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,supplier_id) REFERENCES monarch_parties(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,purchase_order_id) REFERENCES monarch_purchase_orders(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(created_by) REFERENCES monarch_users(id) ON DELETE RESTRICT,
 FOREIGN KEY(posted_by) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS monarch_supplier_invoice_lines (
 id TEXT NOT NULL, company_id TEXT NOT NULL, invoice_id TEXT NOT NULL, line_number INTEGER NOT NULL CHECK(line_number>0),
 purchase_order_line_id TEXT NOT NULL, receipt_line_id TEXT NOT NULL, item_id TEXT NOT NULL,
 item_sku_snapshot TEXT NOT NULL, item_name_snapshot TEXT NOT NULL, quantity_milli INTEGER NOT NULL CHECK(quantity_milli>0),
 unit_price_minor INTEGER NOT NULL CHECK(unit_price_minor>=0), tax_rate_bps INTEGER NOT NULL CHECK(tax_rate_bps BETWEEN 0 AND 10000),
 net_minor INTEGER NOT NULL CHECK(net_minor>=0), tax_minor INTEGER NOT NULL CHECK(tax_minor>=0), total_minor INTEGER NOT NULL CHECK(total_minor>=0),
 PRIMARY KEY(company_id,id), UNIQUE(company_id,invoice_id,line_number),
 FOREIGN KEY(company_id,invoice_id) REFERENCES monarch_supplier_invoices(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,purchase_order_line_id) REFERENCES monarch_purchase_order_lines(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,receipt_line_id) REFERENCES monarch_purchase_receipt_lines(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,item_id) REFERENCES monarch_items(company_id,id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_supplier_invoices_branch_status ON monarch_supplier_invoices(company_id,branch_id,status,supplier_invoice_date);
CREATE INDEX IF NOT EXISTS ix_supplier_invoice_lines_receipt ON monarch_supplier_invoice_lines(company_id,receipt_line_id);
CREATE TABLE IF NOT EXISTS monarch_supplier_invoice_accounting_outbox (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL, invoice_id TEXT NOT NULL,
 event_type TEXT NOT NULL CHECK(event_type='SupplierInvoicePosted'), created_utc TEXT NOT NULL,
 processed_utc TEXT NULL, attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts>=0), last_error TEXT NULL,
 lease_token TEXT NULL, lease_expires_utc TEXT NULL,
 UNIQUE(company_id,invoice_id,event_type),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,invoice_id) REFERENCES monarch_supplier_invoices(company_id,id) ON DELETE RESTRICT
);
-- Accounts payable subledger for posted supplier invoices and allocated payments.
CREATE TABLE IF NOT EXISTS monarch_supplier_payables (
 company_id TEXT NOT NULL, invoice_id TEXT NOT NULL, branch_id TEXT NOT NULL, supplier_id TEXT NOT NULL,
 invoice_number TEXT NOT NULL, invoice_date TEXT NOT NULL, due_date TEXT NOT NULL,
 currency_code TEXT NOT NULL CHECK(length(currency_code)=3), currency_scale INTEGER NOT NULL CHECK(currency_scale BETWEEN 0 AND 4),
 original_minor INTEGER NOT NULL CHECK(original_minor>0), status TEXT NOT NULL CHECK(status IN('Open','PartiallyPaid','Paid')),
 created_utc TEXT NOT NULL,
 PRIMARY KEY(company_id,invoice_id),
 FOREIGN KEY(company_id,invoice_id) REFERENCES monarch_supplier_invoices(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,supplier_id) REFERENCES monarch_parties(company_id,id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_supplier_payables_aging ON monarch_supplier_payables(company_id,branch_id,supplier_id,due_date,status);
CREATE TABLE IF NOT EXISTS monarch_supplier_payments (
 id TEXT NOT NULL, company_id TEXT NOT NULL, branch_id TEXT NOT NULL, supplier_id TEXT NOT NULL,
 payment_number TEXT NOT NULL COLLATE NOCASE, payment_date TEXT NOT NULL,
 payment_method TEXT NOT NULL CHECK(payment_method IN('Cash','Bank')),
 cash_bank_account_code TEXT NOT NULL, currency_code TEXT NOT NULL CHECK(length(currency_code)=3),
 currency_scale INTEGER NOT NULL CHECK(currency_scale BETWEEN 0 AND 4), amount_minor INTEGER NOT NULL CHECK(amount_minor>0),
 status TEXT NOT NULL CHECK(status='Posted'), created_utc TEXT NOT NULL, created_by TEXT NOT NULL,
 PRIMARY KEY(company_id,id), UNIQUE(company_id,branch_id,supplier_id,payment_number),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,supplier_id) REFERENCES monarch_parties(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(created_by) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS monarch_supplier_payment_allocations (
 id TEXT NOT NULL, company_id TEXT NOT NULL, payment_id TEXT NOT NULL, invoice_id TEXT NOT NULL,
 amount_minor INTEGER NOT NULL CHECK(amount_minor>0), PRIMARY KEY(company_id,id), UNIQUE(company_id,payment_id,invoice_id),
 FOREIGN KEY(company_id,payment_id) REFERENCES monarch_supplier_payments(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,invoice_id) REFERENCES monarch_supplier_payables(company_id,invoice_id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS monarch_supplier_payment_accounting_outbox (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL, payment_id TEXT NOT NULL,
 event_type TEXT NOT NULL CHECK(event_type='SupplierPaymentPosted'), created_utc TEXT NOT NULL,
 processed_utc TEXT NULL, attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts>=0), last_error TEXT NULL,
 lease_token TEXT NULL, lease_expires_utc TEXT NULL,
 UNIQUE(company_id,payment_id,event_type),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,payment_id) REFERENCES monarch_supplier_payments(company_id,id) ON DELETE RESTRICT
);
CREATE TRIGGER IF NOT EXISTS trg_supplier_payable_insert_posted_invoice BEFORE INSERT ON monarch_supplier_payables
WHEN (SELECT status FROM monarch_supplier_invoices WHERE company_id=NEW.company_id AND id=NEW.invoice_id)<>'Posted'
BEGIN SELECT RAISE(ABORT,'A payable can only be created for a posted supplier invoice'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_payable_financial_fields_immutable BEFORE UPDATE ON monarch_supplier_payables
WHEN OLD.company_id<>NEW.company_id OR OLD.invoice_id<>NEW.invoice_id OR OLD.branch_id<>NEW.branch_id OR
 OLD.supplier_id<>NEW.supplier_id OR OLD.invoice_number<>NEW.invoice_number OR OLD.invoice_date<>NEW.invoice_date OR
 OLD.due_date<>NEW.due_date OR OLD.currency_code<>NEW.currency_code OR OLD.currency_scale<>NEW.currency_scale OR
 OLD.original_minor<>NEW.original_minor OR OLD.created_utc<>NEW.created_utc OR
 NEW.status NOT IN('Open','PartiallyPaid','Paid')
BEGIN SELECT RAISE(ABORT,'Supplier payable financial fields are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_payable_no_delete BEFORE DELETE ON monarch_supplier_payables
 BEGIN SELECT RAISE(ABORT,'Supplier payable records cannot be deleted'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_payment_no_update BEFORE UPDATE ON monarch_supplier_payments
 BEGIN SELECT RAISE(ABORT,'Posted supplier payments are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_payment_no_delete BEFORE DELETE ON monarch_supplier_payments
 BEGIN SELECT RAISE(ABORT,'Posted supplier payments cannot be deleted'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_payment_allocation_no_update BEFORE UPDATE ON monarch_supplier_payment_allocations
 BEGIN SELECT RAISE(ABORT,'Supplier payment allocations are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_payment_allocation_no_delete BEFORE DELETE ON monarch_supplier_payment_allocations
 BEGIN SELECT RAISE(ABORT,'Supplier payment allocations cannot be deleted'); END;

CREATE TRIGGER IF NOT EXISTS trg_supplier_invoice_posted_immutable BEFORE UPDATE ON monarch_supplier_invoices
WHEN OLD.status='Posted' BEGIN SELECT RAISE(ABORT,'Posted supplier invoices are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_invoice_posted_no_delete BEFORE DELETE ON monarch_supplier_invoices
WHEN OLD.status='Posted' BEGIN SELECT RAISE(ABORT,'Posted supplier invoices cannot be deleted'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_invoice_line_draft_insert BEFORE INSERT ON monarch_supplier_invoice_lines
WHEN (SELECT status FROM monarch_supplier_invoices WHERE company_id=NEW.company_id AND id=NEW.invoice_id)<>'Draft'
BEGIN SELECT RAISE(ABORT,'Supplier invoice lines can only be added to draft invoices'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_invoice_line_no_update BEFORE UPDATE ON monarch_supplier_invoice_lines
WHEN (SELECT status FROM monarch_supplier_invoices WHERE company_id=OLD.company_id AND id=OLD.invoice_id)<>'Draft'
BEGIN SELECT RAISE(ABORT,'Posted supplier invoice lines are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_supplier_invoice_line_no_delete BEFORE DELETE ON monarch_supplier_invoice_lines
WHEN (SELECT status FROM monarch_supplier_invoices WHERE company_id=OLD.company_id AND id=OLD.invoice_id)<>'Draft'
BEGIN SELECT RAISE(ABORT,'Posted supplier invoice lines cannot be deleted'); END;

-- ZATCA Phase-2 integration: append-only invoice hash chain and retryable submission outbox.
CREATE TABLE IF NOT EXISTS monarch_zatca_invoice_chain (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL, egs_unit_id TEXT NOT NULL,
 chain_sequence INTEGER NOT NULL CHECK(chain_sequence>0), uuid TEXT NOT NULL, invoice_number TEXT NOT NULL,
 invoice_kind TEXT NOT NULL CHECK(invoice_kind IN('StandardTaxInvoice','SimplifiedTaxInvoice','CreditNote','DebitNote')),
 invoice_hash_base64 TEXT NOT NULL, previous_invoice_hash_base64 TEXT NOT NULL,
 invoice_xml TEXT NOT NULL, qr_payload_base64 TEXT NOT NULL,
 submission_status TEXT NOT NULL CHECK(submission_status IN('Pending','Cleared','Reported','Rejected','Failed')),
 last_response TEXT NULL, cleared_invoice_xml TEXT NULL, cleared_qr_payload_base64 TEXT NULL,
 created_utc TEXT NOT NULL, created_by TEXT NOT NULL, updated_utc TEXT NULL,
 UNIQUE(company_id,id), UNIQUE(company_id,branch_id,egs_unit_id,chain_sequence), UNIQUE(company_id,uuid),
 UNIQUE(company_id,branch_id,egs_unit_id,invoice_number),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(created_by) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_monarch_zatca_chain_pending ON monarch_zatca_invoice_chain(company_id,branch_id,submission_status,chain_sequence);
CREATE TABLE IF NOT EXISTS monarch_zatca_submission_outbox (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL, chain_record_id TEXT NOT NULL,
 submission_status TEXT NOT NULL CHECK(submission_status IN('Pending','Processing','Cleared','Reported','Rejected','Failed')),
 created_utc TEXT NOT NULL, processing_utc TEXT NULL, processed_utc TEXT NULL, attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts>=0), last_error TEXT NULL,
 UNIQUE(company_id,chain_record_id),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,chain_record_id) REFERENCES monarch_zatca_invoice_chain(company_id,id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_monarch_zatca_outbox_claim ON monarch_zatca_submission_outbox(company_id,branch_id,submission_status,processed_utc,attempts,created_utc);
CREATE TRIGGER IF NOT EXISTS trg_monarch_zatca_chain_no_delete BEFORE DELETE ON monarch_zatca_invoice_chain
 BEGIN SELECT RAISE(ABORT,'ZATCA invoice chain records cannot be deleted'); END;
CREATE TRIGGER IF NOT EXISTS trg_monarch_zatca_chain_identity_immutable BEFORE UPDATE ON monarch_zatca_invoice_chain
WHEN OLD.id<>NEW.id OR OLD.company_id<>NEW.company_id OR OLD.branch_id<>NEW.branch_id OR OLD.egs_unit_id<>NEW.egs_unit_id OR
 OLD.chain_sequence<>NEW.chain_sequence OR OLD.uuid<>NEW.uuid OR OLD.invoice_number<>NEW.invoice_number OR OLD.invoice_kind<>NEW.invoice_kind OR
 OLD.invoice_hash_base64<>NEW.invoice_hash_base64 OR OLD.previous_invoice_hash_base64<>NEW.previous_invoice_hash_base64 OR
 OLD.invoice_xml<>NEW.invoice_xml OR OLD.qr_payload_base64<>NEW.qr_payload_base64 OR OLD.created_utc<>NEW.created_utc OR OLD.created_by<>NEW.created_by
 BEGIN SELECT RAISE(ABORT,'ZATCA invoice chain payload is immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_monarch_zatca_outbox_no_delete BEFORE DELETE ON monarch_zatca_submission_outbox
 BEGIN SELECT RAISE(ABORT,'ZATCA submission outbox records cannot be deleted'); END;
CREATE TRIGGER IF NOT EXISTS trg_monarch_zatca_outbox_identity_immutable BEFORE UPDATE ON monarch_zatca_submission_outbox
WHEN OLD.id<>NEW.id OR OLD.company_id<>NEW.company_id OR OLD.branch_id<>NEW.branch_id OR OLD.chain_record_id<>NEW.chain_record_id OR OLD.created_utc<>NEW.created_utc OR NEW.attempts<OLD.attempts
 BEGIN SELECT RAISE(ABORT,'ZATCA outbox identity is immutable'); END;

-- ZATCA EGS onboarding registry. Provision only through the explicit commercial schema migration process.
CREATE TABLE IF NOT EXISTS monarch_zatca_egs_units (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL,
 unit_name TEXT NOT NULL CHECK(length(unit_name) BETWEEN 1 AND 120),
 vat_number TEXT NOT NULL CHECK(length(vat_number)=15 AND substr(vat_number,1,1)='3'),
 environment TEXT NOT NULL CHECK(environment IN('Simulation','Production')),
 lifecycle_state TEXT NOT NULL CHECK(lifecycle_state IN('Draft','CsrGenerated','CompliancePending','CompliancePassed','ProductionPending','Active','Suspended','Revoked')),
 otp_transaction_reference TEXT NULL, csr_fingerprint TEXT NULL, csid_serial_number TEXT NULL,
 csid_certificate_thumbprint TEXT NULL, secret_reference TEXT NULL,
 created_utc TEXT NOT NULL, updated_utc TEXT NOT NULL, created_by TEXT NOT NULL,
 UNIQUE(company_id,id), UNIQUE(company_id,branch_id,id), UNIQUE(company_id,branch_id,unit_name),
 FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(created_by) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_monarch_zatca_egs_scope ON monarch_zatca_egs_units(company_id,branch_id,lifecycle_state);
CREATE TABLE IF NOT EXISTS monarch_zatca_egs_lifecycle (
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL, egs_unit_id TEXT NOT NULL,
 from_state TEXT NOT NULL, to_state TEXT NOT NULL, note TEXT NULL, occurred_utc TEXT NOT NULL, actor_user_id TEXT NOT NULL,
 FOREIGN KEY(company_id,branch_id,egs_unit_id) REFERENCES monarch_zatca_egs_units(company_id,branch_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(actor_user_id) REFERENCES monarch_users(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_monarch_zatca_egs_history ON monarch_zatca_egs_lifecycle(company_id,branch_id,egs_unit_id,occurred_utc);
CREATE TRIGGER IF NOT EXISTS trg_monarch_zatca_egs_lifecycle_no_update BEFORE UPDATE ON monarch_zatca_egs_lifecycle
 BEGIN SELECT RAISE(ABORT,'ZATCA EGS lifecycle events are immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_monarch_zatca_egs_lifecycle_no_delete BEFORE DELETE ON monarch_zatca_egs_lifecycle
 BEGIN SELECT RAISE(ABORT,'ZATCA EGS lifecycle events cannot be deleted'); END;
