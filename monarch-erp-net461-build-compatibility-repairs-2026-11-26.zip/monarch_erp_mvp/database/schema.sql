PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS app_settings (
  setting_key TEXT PRIMARY KEY,
  setting_value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS accounts (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name_ar TEXT NOT NULL,
  parent_id TEXT NULL REFERENCES accounts(id),
  account_type TEXT NOT NULL CHECK(account_type IN ('Asset','Liability','Equity','Revenue','Expense')),
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1))
);

CREATE TABLE IF NOT EXISTS inventory_items (
  id TEXT PRIMARY KEY,
  sku TEXT NOT NULL UNIQUE,
  name_ar TEXT NOT NULL,
  unit TEXT NOT NULL,
  quantity_on_hand NUMERIC NOT NULL DEFAULT 0,
  reorder_level NUMERIC NOT NULL DEFAULT 0,
  suggested_order_quantity NUMERIC NOT NULL DEFAULT 0,
  expiry_date TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1))
);

CREATE TABLE IF NOT EXISTS sales_invoices (
  id TEXT PRIMARY KEY,
  invoice_number TEXT NOT NULL UNIQUE,
  business_date TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  net_total NUMERIC NOT NULL CHECK(net_total >= 0),
  paid_amount NUMERIC NOT NULL DEFAULT 0 CHECK(paid_amount >= 0),
  status TEXT NOT NULL CHECK(status IN ('Draft','Posted','Voided')),
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cash_movements (
  id TEXT PRIMARY KEY,
  business_date TEXT NOT NULL,
  movement_type TEXT NOT NULL CHECK(movement_type IN ('Receipt','Payment')),
  payment_method TEXT NOT NULL CHECK(payment_method IN ('Cash','Bank','Card','Credit','Other')),
  amount NUMERIC NOT NULL CHECK(amount > 0),
  description TEXT NOT NULL,
  source_document_id TEXT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS journal_entries (
  id TEXT PRIMARY KEY,
  entry_number TEXT NOT NULL UNIQUE,
  business_date TEXT NOT NULL,
  description TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('Draft','Posted','Reversed')),
  reversal_of_id TEXT NULL REFERENCES journal_entries(id),
  created_at TEXT NOT NULL,
  CHECK(reversal_of_id IS NULL OR reversal_of_id <> id)
);

CREATE TABLE IF NOT EXISTS journal_entry_lines (
  id TEXT PRIMARY KEY,
  journal_entry_id TEXT NOT NULL REFERENCES journal_entries(id) ON DELETE CASCADE,
  account_id TEXT NOT NULL REFERENCES accounts(id),
  debit NUMERIC NOT NULL DEFAULT 0 CHECK(debit >= 0),
  credit NUMERIC NOT NULL DEFAULT 0 CHECK(credit >= 0),
  CHECK(NOT (debit > 0 AND credit > 0)),
  CHECK(debit > 0 OR credit > 0)
);

CREATE INDEX IF NOT EXISTS idx_sales_date ON sales_invoices(business_date);
CREATE INDEX IF NOT EXISTS idx_cash_date ON cash_movements(business_date);
CREATE INDEX IF NOT EXISTS idx_journal_date ON journal_entries(business_date);
CREATE INDEX IF NOT EXISTS idx_journal_lines_entry ON journal_entry_lines(journal_entry_id);
CREATE INDEX IF NOT EXISTS idx_journal_lines_account ON journal_entry_lines(account_id);
CREATE UNIQUE INDEX IF NOT EXISTS ux_journal_one_reversal_per_entry
  ON journal_entries(reversal_of_id) WHERE reversal_of_id IS NOT NULL;

-- A journal must enter the ledger as a draft; posting is an explicit transition.
CREATE TRIGGER IF NOT EXISTS trg_journal_insert_draft_only
BEFORE INSERT ON journal_entries
WHEN NEW.status <> 'Draft'
BEGIN
  SELECT RAISE(ABORT, 'Journal entries must be created as Draft');
END;

-- A reversal may only reference a currently posted journal.
CREATE TRIGGER IF NOT EXISTS trg_journal_reversal_reference_insert
BEFORE INSERT ON journal_entries
WHEN NEW.reversal_of_id IS NOT NULL
BEGIN
  SELECT CASE
    WHEN NOT EXISTS (
      SELECT 1 FROM journal_entries original
      WHERE original.id = NEW.reversal_of_id AND original.status = 'Posted'
    )
    THEN RAISE(ABORT, 'Only a posted journal can be reversed')
  END;
END;

CREATE TRIGGER IF NOT EXISTS trg_journal_reversal_reference_update
BEFORE UPDATE OF reversal_of_id ON journal_entries
WHEN NEW.reversal_of_id IS NOT NULL
BEGIN
  SELECT CASE
    WHEN OLD.status <> 'Draft' OR NEW.status <> 'Draft'
    THEN RAISE(ABORT, 'Reversal link can only be changed on a draft journal')
  END;
  SELECT CASE
    WHEN NOT EXISTS (
      SELECT 1 FROM journal_entries original
      WHERE original.id = NEW.reversal_of_id AND original.status = 'Posted'
    )
    THEN RAISE(ABORT, 'Only a posted journal can be reversed')
  END;
END;

-- Only Draft -> Posted and Posted -> Reversed are legal state transitions.
CREATE TRIGGER IF NOT EXISTS trg_journal_valid_status_transition
BEFORE UPDATE OF status ON journal_entries
WHEN NOT (
  (OLD.status = 'Draft' AND NEW.status IN ('Draft','Posted')) OR
  (OLD.status = 'Posted' AND NEW.status IN ('Posted','Reversed')) OR
  (OLD.status = 'Reversed' AND NEW.status = 'Reversed')
)
BEGIN
  SELECT RAISE(ABORT, 'Invalid journal status transition');
END;

-- Validate balance, active accounts and exact account-level reversal before posting.
CREATE TRIGGER IF NOT EXISTS trg_journal_post_requires_balance
BEFORE UPDATE OF status ON journal_entries
WHEN NEW.status = 'Posted' AND OLD.status = 'Draft'
BEGIN
  SELECT CASE
    WHEN (SELECT COUNT(*) FROM journal_entry_lines WHERE journal_entry_id = NEW.id) < 2
    THEN RAISE(ABORT, 'A journal entry requires at least two lines')
  END;
  SELECT CASE
    WHEN ABS(
      COALESCE((SELECT SUM(debit) FROM journal_entry_lines WHERE journal_entry_id = NEW.id), 0) -
      COALESCE((SELECT SUM(credit) FROM journal_entry_lines WHERE journal_entry_id = NEW.id), 0)
    ) > 0.0001
    THEN RAISE(ABORT, 'Journal entry is not balanced')
  END;
  SELECT CASE
    WHEN EXISTS (
      SELECT 1 FROM journal_entry_lines l
      JOIN accounts a ON a.id = l.account_id
      WHERE l.journal_entry_id = NEW.id AND a.is_active = 0
    )
    THEN RAISE(ABORT, 'Inactive account cannot be used in a posted journal')
  END;
  SELECT CASE
    WHEN NEW.reversal_of_id IS NOT NULL AND NOT EXISTS (
      SELECT 1 FROM journal_entries original
      WHERE original.id = NEW.reversal_of_id AND original.status = 'Posted'
    )
    THEN RAISE(ABORT, 'Reversal target must still be posted')
  END;
  SELECT CASE
    WHEN NEW.reversal_of_id IS NOT NULL AND EXISTS (
      SELECT account_id
      FROM (
        SELECT account_id FROM journal_entry_lines WHERE journal_entry_id = NEW.id
        UNION
        SELECT account_id FROM journal_entry_lines WHERE journal_entry_id = NEW.reversal_of_id
      ) accounts_involved
      WHERE
        ABS(
          COALESCE((SELECT SUM(debit) FROM journal_entry_lines
                    WHERE journal_entry_id = NEW.id AND account_id = accounts_involved.account_id), 0) -
          COALESCE((SELECT SUM(credit) FROM journal_entry_lines
                    WHERE journal_entry_id = NEW.reversal_of_id AND account_id = accounts_involved.account_id), 0)
        ) > 0.0001
        OR
        ABS(
          COALESCE((SELECT SUM(credit) FROM journal_entry_lines
                    WHERE journal_entry_id = NEW.id AND account_id = accounts_involved.account_id), 0) -
          COALESCE((SELECT SUM(debit) FROM journal_entry_lines
                    WHERE journal_entry_id = NEW.reversal_of_id AND account_id = accounts_involved.account_id), 0)
        ) > 0.0001
    )
    THEN RAISE(ABORT, 'Reversal must exactly invert the original journal by account')
  END;
END;

-- The original cannot be marked Reversed until its inverse journal is posted.
CREATE TRIGGER IF NOT EXISTS trg_journal_reverse_requires_posted_inverse
BEFORE UPDATE OF status ON journal_entries
WHEN OLD.status = 'Posted' AND NEW.status = 'Reversed'
BEGIN
  SELECT CASE
    WHEN NOT EXISTS (
      SELECT 1 FROM journal_entries reversal
      WHERE reversal.reversal_of_id = OLD.id AND reversal.status = 'Posted'
    )
    THEN RAISE(ABORT, 'Post a matching reversal journal before marking the original Reversed')
  END;
END;

CREATE TRIGGER IF NOT EXISTS trg_journal_lines_insert_only_draft
BEFORE INSERT ON journal_entry_lines
WHEN (SELECT status FROM journal_entries WHERE id = NEW.journal_entry_id) <> 'Draft'
BEGIN
  SELECT RAISE(ABORT, 'Journal lines can only be added to draft entries');
END;

CREATE TRIGGER IF NOT EXISTS trg_journal_lines_update_only_draft
BEFORE UPDATE ON journal_entry_lines
WHEN (SELECT status FROM journal_entries WHERE id = OLD.journal_entry_id) <> 'Draft'
  OR (SELECT status FROM journal_entries WHERE id = NEW.journal_entry_id) <> 'Draft'
BEGIN
  SELECT RAISE(ABORT, 'Only draft journal lines can be modified');
END;

CREATE TRIGGER IF NOT EXISTS trg_journal_lines_delete_only_draft
BEFORE DELETE ON journal_entry_lines
WHEN (SELECT status FROM journal_entries WHERE id = OLD.journal_entry_id) <> 'Draft'
BEGIN
  SELECT RAISE(ABORT, 'Posted journal lines cannot be deleted');
END;

CREATE TRIGGER IF NOT EXISTS trg_journal_header_immutable_after_post
BEFORE UPDATE ON journal_entries
WHEN OLD.status IN ('Posted', 'Reversed') AND NOT (
  OLD.status = 'Posted' AND NEW.status = 'Reversed'
  AND NEW.id = OLD.id
  AND NEW.entry_number = OLD.entry_number
  AND NEW.business_date = OLD.business_date
  AND NEW.description = OLD.description
  AND NEW.reversal_of_id IS OLD.reversal_of_id
  AND NEW.created_at = OLD.created_at
)
BEGIN
  SELECT RAISE(ABORT, 'Posted journal entries are immutable; create a reversing entry');
END;

CREATE TRIGGER IF NOT EXISTS trg_journal_header_no_delete_after_post
BEFORE DELETE ON journal_entries
WHEN OLD.status IN ('Posted', 'Reversed')
BEGIN
  SELECT RAISE(ABORT, 'Posted journal entries cannot be deleted');
END;
