PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS monarch_currencies (
  code TEXT PRIMARY KEY CHECK(length(code) = 3),
  name TEXT NOT NULL,
  minor_unit_exponent INTEGER NOT NULL CHECK(minor_unit_exponent BETWEEN 0 AND 4),
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1))
);
INSERT OR IGNORE INTO monarch_currencies(code,name,minor_unit_exponent,is_active) VALUES ('SAR','Saudi Riyal',2,1);
CREATE TABLE IF NOT EXISTS monarch_company_settings (
  id INTEGER PRIMARY KEY CHECK(id = 1),
  company_name TEXT NOT NULL DEFAULT 'MONARCH',
  base_currency_code TEXT NOT NULL REFERENCES monarch_currencies(code),
  created_utc TEXT NOT NULL
);
INSERT OR IGNORE INTO monarch_company_settings(id,company_name,base_currency_code,created_utc)
VALUES (1,'MONARCH','SAR',strftime('%Y-%m-%dT%H:%M:%fZ','now'));
CREATE TABLE IF NOT EXISTS monarch_accounts (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name TEXT NOT NULL,
  account_type TEXT NOT NULL CHECK(account_type IN ('Asset','Liability','Equity','Revenue','Expense')),
  is_active INTEGER NOT NULL CHECK(is_active IN (0,1))
);
CREATE TABLE IF NOT EXISTS monarch_journals (
  id TEXT PRIMARY KEY,
  number TEXT NOT NULL UNIQUE COLLATE NOCASE,
  business_date TEXT NOT NULL,
  description TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('Draft','Posted','Reversed')),
  reversal_of_id TEXT NULL UNIQUE REFERENCES monarch_journals(id),
  posted_at_utc TEXT NULL,
  created_utc TEXT NOT NULL,
  CHECK(reversal_of_id IS NULL OR reversal_of_id <> id)
);
CREATE TABLE IF NOT EXISTS monarch_journal_lines (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  journal_id TEXT NOT NULL REFERENCES monarch_journals(id),
  account_id TEXT NOT NULL REFERENCES monarch_accounts(id),
  debit_minor INTEGER NOT NULL DEFAULT 0 CHECK(debit_minor >= 0),
  credit_minor INTEGER NOT NULL DEFAULT 0 CHECK(credit_minor >= 0),
  CHECK((debit_minor > 0 AND credit_minor = 0) OR (credit_minor > 0 AND debit_minor = 0))
);
CREATE INDEX IF NOT EXISTS ix_monarch_journals_date ON monarch_journals(business_date,status);
CREATE INDEX IF NOT EXISTS ix_monarch_lines_account ON monarch_journal_lines(account_id,journal_id);
CREATE TRIGGER IF NOT EXISTS monarch_journal_insert_draft
BEFORE INSERT ON monarch_journals WHEN NEW.status <> 'Draft'
BEGIN SELECT RAISE(ABORT,'Journal must be inserted as Draft'); END;
CREATE TRIGGER IF NOT EXISTS monarch_journal_valid_transition
BEFORE UPDATE OF status ON monarch_journals
WHEN NOT ((OLD.status='Draft' AND NEW.status='Posted') OR (OLD.status='Posted' AND NEW.status='Reversed'))
BEGIN SELECT RAISE(ABORT,'Invalid journal status transition'); END;
CREATE TRIGGER IF NOT EXISTS monarch_post_requires_balanced
BEFORE UPDATE OF status ON monarch_journals WHEN OLD.status='Draft' AND NEW.status='Posted'
BEGIN
 SELECT CASE WHEN (SELECT COUNT(*) FROM monarch_journal_lines WHERE journal_id=NEW.id)<2
 THEN RAISE(ABORT,'Journal requires at least two lines') END;
 SELECT CASE WHEN COALESCE((SELECT SUM(debit_minor) FROM monarch_journal_lines WHERE journal_id=NEW.id),0)
 <> COALESCE((SELECT SUM(credit_minor) FROM monarch_journal_lines WHERE journal_id=NEW.id),0)
 THEN RAISE(ABORT,'Journal is not balanced') END;
 SELECT CASE WHEN EXISTS(SELECT 1 FROM monarch_journal_lines l JOIN monarch_accounts a ON a.id=l.account_id
 WHERE l.journal_id=NEW.id AND a.is_active=0)
 THEN RAISE(ABORT,'Inactive account cannot be posted') END;
 SELECT CASE WHEN NEW.reversal_of_id IS NOT NULL AND EXISTS(
   SELECT account_id FROM (SELECT account_id FROM monarch_journal_lines WHERE journal_id=NEW.id
   UNION SELECT account_id FROM monarch_journal_lines WHERE journal_id=NEW.reversal_of_id) x
   WHERE COALESCE((SELECT SUM(debit_minor) FROM monarch_journal_lines WHERE journal_id=NEW.id AND account_id=x.account_id),0)
      <> COALESCE((SELECT SUM(credit_minor) FROM monarch_journal_lines WHERE journal_id=NEW.reversal_of_id AND account_id=x.account_id),0)
      OR COALESCE((SELECT SUM(credit_minor) FROM monarch_journal_lines WHERE journal_id=NEW.id AND account_id=x.account_id),0)
      <> COALESCE((SELECT SUM(debit_minor) FROM monarch_journal_lines WHERE journal_id=NEW.reversal_of_id AND account_id=x.account_id),0))
 THEN RAISE(ABORT,'Reversal does not exactly invert original') END;
END;
CREATE TRIGGER IF NOT EXISTS monarch_reversal_target_must_be_posted
BEFORE INSERT ON monarch_journals WHEN NEW.reversal_of_id IS NOT NULL
BEGIN SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM monarch_journals WHERE id=NEW.reversal_of_id AND status='Posted')
 THEN RAISE(ABORT,'Only a posted journal can be reversed') END; END;
CREATE TRIGGER IF NOT EXISTS monarch_original_reversal_requires_posted_inverse
BEFORE UPDATE OF status ON monarch_journals WHEN OLD.status='Posted' AND NEW.status='Reversed'
BEGIN SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM monarch_journals WHERE reversal_of_id=OLD.id AND status='Posted')
 THEN RAISE(ABORT,'Posted inverse journal required') END; END;
CREATE TRIGGER IF NOT EXISTS monarch_lines_insert_draft_only
BEFORE INSERT ON monarch_journal_lines WHEN (SELECT status FROM monarch_journals WHERE id=NEW.journal_id)<>'Draft'
BEGIN SELECT RAISE(ABORT,'Lines may only be added to drafts'); END;
CREATE TRIGGER IF NOT EXISTS monarch_lines_update_draft_only
BEFORE UPDATE ON monarch_journal_lines WHEN (SELECT status FROM monarch_journals WHERE id=OLD.journal_id)<>'Draft'
BEGIN SELECT RAISE(ABORT,'Posted lines are immutable'); END;
CREATE TRIGGER IF NOT EXISTS monarch_lines_delete_draft_only
BEFORE DELETE ON monarch_journal_lines WHEN (SELECT status FROM monarch_journals WHERE id=OLD.journal_id)<>'Draft'
BEGIN SELECT RAISE(ABORT,'Posted lines are immutable'); END;
CREATE TRIGGER IF NOT EXISTS monarch_journals_immutable_delete
BEFORE DELETE ON monarch_journals WHEN OLD.status<>'Draft'
BEGIN SELECT RAISE(ABORT,'Posted journals cannot be deleted'); END;
