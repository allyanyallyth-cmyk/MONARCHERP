from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class TenantSessionContextTests(unittest.TestCase):
    def test_directory_filters_to_authorized_active_branches(self):
        source = (ROOT / "src/Monarch.Core/Organizations/CompanyDirectoryStore.cs").read_text(encoding="utf-8")
        for fragment in ("GetAccessibleBranches(Guid userId, Guid companyId)", "a.role_code='Administrator'", "ba.is_active=1", "u.is_active=1", "c.is_active=1", "b.is_active=1"):
            self.assertIn(fragment, source)

    def test_context_requires_company_and_branch_membership_before_open(self):
        source = (ROOT / "src/Monarch.Core/Accounting/TenantAccountingSession.cs").read_text(encoding="utf-8")
        self.assertIn("GetUserCompanies(session.UserId)", source)
        self.assertIn("GetAccessibleBranches(session.UserId, companyId)", source)
        self.assertIn("ledger.GetEntries(session.UserId, companyId, branchId)", source)
        self.assertIn("UnauthorizedAccessException", source)

    def test_all_context_operations_use_user_company_and_branch_ids(self):
        source = (ROOT / "src/Monarch.Core/Accounting/TenantAccountingSession.cs").read_text(encoding="utf-8")
        expected = (
            "_ledger.GetAccounts(_userId, CompanyId, BranchId)",
            "_ledger.GetEntries(_userId, CompanyId, BranchId)",
            "_ledger.GetTrialBalance(_userId, CompanyId, BranchId, from, to)",
            "_ledger.GetIncomeStatement(_userId, CompanyId, BranchId, from, to)",
            "_ledger.GetBalanceSheet(_userId, CompanyId, BranchId, asOf)",
            "_ledger.AddAccount(_userId, CompanyId, BranchId, account)",
            "_ledger.CreateDraft(_userId, CompanyId, BranchId, number, date, description, lines)",
            "_ledger.Post(_userId, CompanyId, BranchId, journalId)",
            "_ledger.Reverse(_userId, CompanyId, BranchId, journalId",
        )
        for fragment in expected:
            self.assertIn(fragment, source)
        self.assertNotIn("SqliteLedgerStore", source)

    def test_every_public_ledger_api_requires_branch_context(self):
        store = (ROOT / "src/Monarch.Core/Accounting/TenantLedgerStore.cs").read_text(encoding="utf-8")
        for fragment in (
            "GetAccounts(Guid userId, Guid companyId, Guid branchId)",
            "GetEntries(Guid userId, Guid companyId, Guid branchId)",
            "AddAccount(Guid userId, Guid companyId, Guid branchId, Account account)",
            "CreateDraft(Guid userId, Guid companyId, Guid branchId",
            "Post(Guid userId, Guid companyId, Guid selectedBranchId",
            "Reverse(Guid userId, Guid companyId, Guid selectedBranchId",
        ):
            self.assertIn(fragment, store)
        self.assertNotIn("GetAccounts(Guid userId, Guid companyId)", store)
        self.assertNotIn("AddAccount(Guid userId, Guid companyId, Account account)", store)

    def test_authorization_and_ledger_operation_share_one_sqlite_transaction(self):
        store = (ROOT / "src/Monarch.Core/Accounting/TenantLedgerStore.cs").read_text(encoding="utf-8")
        self.assertIn("using var transaction = connection.BeginTransaction();", store)
        self.assertIn("RequireBranchAccess(connection, transaction, userId, companyId, branchId, write:", store)
        self.assertIn("transaction.Commit();", store)
        self.assertIn("JOIN monarch_users u ON u.id=a.user_id AND u.is_active=1", store)
        self.assertIn("JOIN monarch_branches b ON b.id=$branch AND b.company_id=c.id AND b.is_active=1", store)
        self.assertIn("monarch_user_branch_access ba", store)

    def test_post_and_reverse_are_bound_to_the_selected_branch_context(self):
        store = (ROOT / "src/Monarch.Core/Accounting/TenantLedgerStore.cs").read_text(encoding="utf-8")
        session = (ROOT / "src/Monarch.Core/Accounting/TenantAccountingSession.cs").read_text(encoding="utf-8")
        self.assertIn("actualBranch != selectedBranchId", store)
        self.assertIn("MutateJournal(userId, companyId, selectedBranchId, entryId", store)
        self.assertIn("MutateJournal(userId, companyId, selectedBranchId, originalEntryId", store)
        self.assertIn("_ledger.Post(_userId, CompanyId, BranchId, journalId)", session)
        self.assertIn("_ledger.Reverse(_userId, CompanyId, BranchId, journalId", session)


    def test_startup_bootstrap_is_scoped_to_the_authenticated_user(self):
        directory = (ROOT / "src/Monarch.Core/Organizations/CompanyDirectoryStore.cs").read_text(encoding="utf-8")
        desktop = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
        self.assertIn("HasCompanyMembership(Guid userId)", directory)
        self.assertIn("WHERE user_id=$user AND is_active=1", directory)
        self.assertIn("_directory.HasCompanyMembership(_session.UserId)", desktop)
        self.assertNotIn("if (!_directory.HasAnyCompanyMembership()", desktop)

    def test_startup_requires_migration_for_the_default_company(self):
        desktop = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
        self.assertIn("HasCompletedLegacyMigration(defaultCompany)", desktop)

    def test_desktop_opens_authorized_tenant_context_before_building_ui(self):
        source = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
        self.assertIn("TenantAccountingSession.Open(", source)
        self.assertIn("new TenantContextWindow(_directory, _session)", source)
        self.assertIn("HasLegacyLedgerData()", source)
        self.assertNotIn("private SqliteLedgerStore _store;", source)
        self.assertIn("_ledgerSession.GetTrialBalance(", source)

if __name__ == "__main__":
    unittest.main()
