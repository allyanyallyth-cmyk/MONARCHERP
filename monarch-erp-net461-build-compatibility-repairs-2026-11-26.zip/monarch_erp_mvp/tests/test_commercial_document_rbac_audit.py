from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "src/Monarch.Core/Commercial/CommercialDocumentStore.cs").read_text(encoding="utf-8")


def test_draft_uses_document_type_specific_rbac():
    create = SOURCE.split("public CommercialDocumentTotals CreateDraft", 1)[1].split("public void Post", 1)[0]
    assert 'draft.Type == CommercialDocumentType.Sale ? "commercial.sales.manage" : "commercial.purchases.manage"' in create
    assert "RequirePermission(c, tx, userId, companyId, branchId" in create


def test_post_reads_document_type_then_checks_matching_permission():
    post = SOURCE.split("public void Post", 1)[1].split("private static void ValidatePartyAndWarehouse", 1)[0]
    assert 'type == "Sale" ? "commercial.sales.manage" : "commercial.purchases.manage"' in post
    assert post.index('type = r.GetString(0)') < post.index("RequirePermission(c, tx")


def test_draft_audit_is_written_before_commit():
    create = SOURCE.split("public CommercialDocumentTotals CreateDraft", 1)[1].split("public void Post", 1)[0]
    assert "CommercialDocumentDraftCreated" in create
    assert create.index("Audit(c, tx") < create.index("tx.Commit()")


def test_permission_query_enforces_active_user_company_branch_and_role_grant():
    helper = SOURCE.split("private static void RequirePermission", 1)[1].split("private static void Audit", 1)[0]
    for token in ("monarch_users", "monarch_user_company_access", "monarch_user_branch_access",
                  "monarch_branches", "monarch_user_roles", "monarch_role_permissions",
                  "u.is_active=1", "co.is_active=1", "rp.permission_code=$permission"):
        assert token in helper


def test_audit_helper_is_transaction_bound():
    helper = SOURCE.split("private static void Audit", 1)[1].split("private SqliteConnection Open", 1)[0]
    assert "audit.Transaction = tx" in helper
    assert "INSERT INTO monarch_company_audit_log" in helper
