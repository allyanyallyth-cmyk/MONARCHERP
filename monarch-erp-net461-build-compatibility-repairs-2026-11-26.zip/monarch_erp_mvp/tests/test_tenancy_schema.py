import pathlib
import sqlite3
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]


class TenancySchemaTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.db.execute("PRAGMA foreign_keys=ON")
        for name in ("ledger-storage.sql", "security.sql", "tenancy.sql"):
            self.db.executescript((ROOT / "database" / name).read_text(encoding="utf-8"))
        self.db.execute("INSERT INTO monarch_users(id,username,display_name,password_salt,password_hash,password_iterations,is_active,created_utc) VALUES('u1','admin','Admin',?,?,210000,1,'now')", (b's'*16,b'h'*32))
        self.db.execute("INSERT INTO monarch_users(id,username,display_name,password_salt,password_hash,password_iterations,is_active,created_utc) VALUES('u2','staff','Staff',?,?,210000,1,'now')", (b't'*16,b'i'*32))

    def tearDown(self):
        self.db.close()

    def add_company(self, cid, code):
        self.db.execute("INSERT INTO monarch_companies(id,code,legal_name,display_name,country_code,base_currency_code,time_zone_id,created_utc) VALUES(?,?,?,?,'SA','SAR','Asia/Riyadh','now')", (cid,code,code,code))

    def test_default_company_and_head_office_seeded(self):
        self.assertEqual(self.db.execute("SELECT code FROM monarch_companies WHERE id='00000000-0000-0000-0000-000000000001'").fetchone()[0], 'DEFAULT')
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM monarch_branches WHERE company_id='00000000-0000-0000-0000-000000000001' AND is_head_office=1").fetchone()[0], 1)

    def test_default_company_and_branch_ids_are_guid_compatible(self):
        import uuid
        company_id = self.db.execute("SELECT id FROM monarch_companies WHERE code='DEFAULT'").fetchone()[0]
        branch_id = self.db.execute("SELECT id FROM monarch_branches WHERE company_id=? AND is_head_office=1", (company_id,)).fetchone()[0]
        self.assertEqual(str(uuid.UUID(company_id)), company_id)
        self.assertEqual(str(uuid.UUID(branch_id)), branch_id)

    def test_legacy_textual_default_ids_are_migrated_to_guids(self):
        legacy = sqlite3.connect(":memory:")
        legacy.execute("PRAGMA foreign_keys=ON")
        legacy.executescript((ROOT / "database" / "ledger-storage.sql").read_text(encoding="utf-8"))
        legacy.executescript((ROOT / "database" / "security.sql").read_text(encoding="utf-8"))
        schema = (ROOT / "database" / "tenancy.sql").read_text(encoding="utf-8")
        migration_start = schema.index("-- Upgrade databases created by the first organization-directory prototype.")
        migration_end = schema.index("PRAGMA foreign_keys = ON;", migration_start)
        legacy_schema = schema[:migration_start] + schema[migration_end + len("PRAGMA foreign_keys = ON;"):]
        legacy_schema = legacy_schema.replace("00000000-0000-0000-0000-000000000001", "default-company")
        legacy_schema = legacy_schema.replace("00000000-0000-0000-0000-000000000002", "default-branch")
        legacy.executescript(legacy_schema)
        legacy.executescript(schema)
        self.assertEqual(legacy.execute("SELECT id FROM monarch_companies WHERE code='DEFAULT'").fetchone()[0],
                         "00000000-0000-0000-0000-000000000001")
        self.assertEqual(legacy.execute("SELECT id FROM monarch_branches WHERE code='HQ'").fetchone()[0],
                         "00000000-0000-0000-0000-000000000002")
        self.assertEqual(legacy.execute("PRAGMA foreign_key_check").fetchall(), [])
        legacy.close()

    def test_company_currency_must_exist(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("INSERT INTO monarch_companies(id,code,legal_name,display_name,country_code,base_currency_code,time_zone_id,created_utc) VALUES('x','X','X','X','SA','ZZZ','Asia/Riyadh','now')")

    def test_branch_code_is_unique_within_company(self):
        self.add_company('c1','C1')
        self.db.execute("INSERT INTO monarch_branches(id,company_id,code,name,created_utc) VALUES('b1','c1','BR1','Branch 1','now')")
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("INSERT INTO monarch_branches(id,company_id,code,name,created_utc) VALUES('b2','c1','br1','Branch 2','now')")

    def test_branch_cannot_be_linked_to_another_company_membership(self):
        self.add_company('c1','C1'); self.add_company('c2','C2')
        self.db.execute("INSERT INTO monarch_branches(id,company_id,code,name,created_utc) VALUES('b1','c1','BR1','Branch 1','now')")
        self.db.execute("INSERT INTO monarch_user_company_access(user_id,company_id,role_code,granted_utc) VALUES('u1','c2','Viewer','now')")
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("INSERT INTO monarch_user_branch_access(user_id,company_id,branch_id) VALUES('u1','c2','b1')")

    def test_company_access_requires_existing_user_and_company(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("INSERT INTO monarch_user_company_access(user_id,company_id,role_code,granted_utc) VALUES('missing','00000000-0000-0000-0000-000000000001','Viewer','now')")

    def test_access_roles_are_constrained(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("INSERT INTO monarch_user_company_access(user_id,company_id,role_code,granted_utc) VALUES('u1','00000000-0000-0000-0000-000000000001','Root','now')")

    def test_only_one_head_office_per_company(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("INSERT INTO monarch_branches(id,company_id,code,name,is_head_office,created_utc) VALUES('b2','00000000-0000-0000-0000-000000000001','HQ2','Second HQ',1,'now')")

    def test_company_audit_branch_must_belong_to_company(self):
        self.add_company('c1','C1')
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("INSERT INTO monarch_company_audit_log(company_id,branch_id,action,entity_type,occurred_utc) VALUES('c1','00000000-0000-0000-0000-000000000002','test','test','now')")

    def test_company_creation_and_creator_access_are_atomic_in_core_store(self):
        source = (ROOT / "src/Monarch.Core/Organizations/CompanyDirectoryStore.cs").read_text(encoding="utf-8")
        method = source.split("CreateCompanyForAdministrator(", 1)[1].split("public Guid CreateBranch(", 1)[0]
        for required in ("BeginTransaction()", "INSERT INTO monarch_companies", "INSERT INTO monarch_branches",
                         "INSERT INTO monarch_user_company_access", "INSERT INTO monarch_user_branch_access",
                         "INSERT INTO monarch_company_audit_log", "transaction.Commit()"):
            self.assertIn(required, method)

    def test_company_and_branch_access_grant_is_atomic_and_company_scoped(self):
        source = (ROOT / "src/Monarch.Core/Organizations/CompanyDirectoryStore.cs").read_text(encoding="utf-8")
        method = source.split("GrantCompanyAndBranchAccess(", 1)[1].split("public string GetCompanyBaseCurrency(", 1)[0]
        self.assertIn("BeginTransaction()", method)
        self.assertIn("b.company_id=c.id AND b.is_active=1", method)
        self.assertIn("INSERT INTO monarch_user_company_access", method)
        self.assertIn("INSERT INTO monarch_user_branch_access", method)
        self.assertIn("INSERT INTO monarch_company_audit_log", method)
        self.assertIn("transaction.Commit()", method)

    def test_directory_admin_ui_is_global_administrator_only(self):
        source = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
        self.assertIn('string.Equals(_session.RoleCode, "Administrator", StringComparison.OrdinalIgnoreCase)', source)
        self.assertIn("BuildDirectoryAdminTab()", source)
        self.assertIn("CreateCompanyForAdministrator", source)
        self.assertIn("GrantCompanyAndBranchAccess", source)


    def test_directory_mutations_require_global_administrator_at_store_boundary(self):
        source = (ROOT / "src/Monarch.Core/Organizations/CompanyDirectoryStore.cs").read_text(encoding="utf-8")
        branch = source.split("public Guid CreateBranch(", 1)[1].split("public void GrantCompanyAccess(", 1)[0]
        company_access = source.split("public void GrantCompanyAccess(", 1)[1].split("public void GrantBranchAccess(", 1)[0]
        branch_access = source.split("public void GrantBranchAccess(", 1)[1].split("public void GrantCompanyAndBranchAccess(", 1)[0]
        for method in (branch, company_access, branch_access):
            self.assertIn("monarch_user_roles", method)
            self.assertIn("r.code='Administrator'", method)
            self.assertIn("is_active=1", method)
            self.assertIn("BeginTransaction()", method)
        self.assertIn("BranchCreated", branch)
        self.assertIn("CompanyAccessGranted", company_access)
        self.assertIn("BranchAccessChanged", branch_access)
        self.assertIn("$company='00000000-0000-0000-0000-000000000001'", company_access)
        self.assertIn("$role='Administrator'", company_access)
        self.assertIn("NOT EXISTS(SELECT 1 FROM monarch_user_company_access", company_access)

    def test_store_contains_scoped_directory_operations(self):
        source = (ROOT / "src/Monarch.Core/Organizations/CompanyDirectoryStore.cs").read_text(encoding="utf-8")
        for expected in ("CreateCompanyForAdministrator", "CreateBranch", "GrantCompanyAccess", "GetUserCompanies", "GetBranches"):
            self.assertIn(expected, source)


if __name__ == "__main__":
    unittest.main()
