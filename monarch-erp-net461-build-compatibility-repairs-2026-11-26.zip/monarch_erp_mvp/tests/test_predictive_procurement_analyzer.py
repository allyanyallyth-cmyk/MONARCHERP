from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src/Monarch.Core/Autonomy/SqlitePredictiveProcurementAnalyzer.cs"
MIGRATION = ROOT / "database/migrations/2026-11-08-predictive-procurement-analysis-indexes.sql"


def test_analyzer_is_read_only_scoped_and_accounts_for_open_purchase_orders():
    text = SOURCE.read_text(encoding="utf-8")
    assert "public IReadOnlyList<PredictiveProcurementCandidate> Analyze" in text
    assert "i.company_id=$co" in text and "p.branch_id=$br" in text and "p.warehouse_id=$wh" in text
    assert "movement_type IN('Issue','TransferOut','PurchaseReturn')" in text
    assert "p.status IN('Approved','PartiallyReceived')" in text
    assert "l.quantity_milli-l.received_quantity_milli" in text
    assert "BeginTransaction(deferred: true)" in text
    assert "INSERT INTO" not in text.upper() and "UPDATE " not in text.upper()


def test_reorder_point_and_suggested_quantity_math():
    # Milli-unit example: demand 10/day, lead 7 days, safety 20, target cover 14 days.
    avg, lead, safety, cover, on_hand, open_po = 10, 7, 20, 14, 30, 10
    reorder = avg * lead + safety
    position = on_hand + open_po
    suggested = max(0, avg * (lead + cover) + safety - position)
    assert reorder == 90
    assert suggested == 190


def test_indexes_migration_executes_against_minimal_schema():
    sql = MIGRATION.read_text(encoding="utf-8")
    db = sqlite3.connect(":memory:")
    db.executescript("""
      CREATE TABLE monarch_stock_movements(company_id TEXT,branch_id TEXT,warehouse_id TEXT,occurred_utc TEXT,movement_type TEXT,item_id TEXT);
      CREATE TABLE monarch_purchase_order_lines(company_id TEXT,item_id TEXT,order_id TEXT,quantity_milli INTEGER,received_quantity_milli INTEGER);
      CREATE TABLE monarch_purchase_orders(company_id TEXT,branch_id TEXT,warehouse_id TEXT,status TEXT,id TEXT);
    """)
    db.executescript(sql)
    names = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='index'")}
    assert {"ix_stock_demand_window", "ix_purchase_order_open_item", "ix_purchase_order_scope_status"} <= names
