from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MASTER = (ROOT / "src/Monarch.Core/Commercial/InventoryMasterDataStore.cs").read_text(encoding="utf-8")
COMMERCIAL = (ROOT / "src/Monarch.Core/Commercial/CommercialStore.cs").read_text(encoding="utf-8")
WINDOW = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")


class InventoryMasterDataReadAuthorizationTests(unittest.TestCase):
    def test_units_and_groups_use_inventory_read_permission(self):
        units = MASTER.split("public IReadOnlyList<UnitOfMeasure> GetUnits", 1)[1].split("public IReadOnlyList<ItemGroup>", 1)[0]
        groups = MASTER.split("public IReadOnlyList<ItemGroup> GetItemGroups", 1)[1].split("public Guid CreateItemGroup", 1)[0]
        self.assertIn('"inventory.read"', units)
        self.assertIn('"inventory.read"', groups)
        self.assertNotIn('"inventory.items.manage"', units)
        self.assertNotIn('"inventory.items.manage"', groups)

    def test_company_item_read_checks_identity_membership_and_rbac_in_query_transaction(self):
        body = COMMERCIAL.split("public IReadOnlyList<StockItem> GetItems", 1)[1].split("public IReadOnlyList<Warehouse>", 1)[0]
        self.assertIn("using var tx = c.BeginTransaction();", body)
        self.assertIn("RequireCompanyRead(c, tx, userId, companyId);", body)
        self.assertIn("cmd.Transaction = tx;", body)
        helper = COMMERCIAL.split("private static void RequireCompanyRead", 1)[1].split("private static void RequireBranch", 1)[0]
        for term in ("monarch_users", "u.is_active=1", "ca.is_active=1", "monarch_companies", "co.is_active=1", "monarch_user_roles", "monarch_role_permissions", "inventory.read"):
            self.assertIn(term, helper)

    def test_warehouse_read_is_branch_scoped_and_permission_checked_in_same_transaction(self):
        body = COMMERCIAL.split("public IReadOnlyList<Warehouse> GetWarehouses", 1)[1].split("public void RecordMovement", 1)[0]
        self.assertIn("using var tx = c.BeginTransaction();", body)
        self.assertIn("RequireBranch(c, tx, userId, companyId, branchId, false);", body)
        self.assertIn("cmd.Transaction = tx;", body)
        self.assertIn("WHERE company_id=$co AND branch_id=$br", body)

    def test_wpf_inventory_catalog_uses_inventory_read_and_keeps_mutations_manager_only(self):
        self.assertIn('if (_session.HasPermission("inventory.read"))\n            tabs.Items.Add(BuildMasterDataTab());', WINDOW)
        load = WINDOW.split("private void LoadMasterData()", 1)[1].split("private void CreateInventoryItem()", 1)[0]
        self.assertIn('if (!_session.HasPermission("inventory.read"))', load)
        groups_panel = WINDOW.split("private UIElement BuildItemGroupsPanel()", 1)[1].split("private UIElement BuildUnitsPanel()", 1)[0]
        units_panel = WINDOW.split("private UIElement BuildUnitsPanel()", 1)[1].split("private void CreateItemGroup()", 1)[0]
        self.assertIn('if (_session.HasPermission("inventory.items.manage"))', groups_panel)
        self.assertIn('if (_session.HasPermission("inventory.items.manage"))', units_panel)


if __name__ == "__main__":
    unittest.main()
