from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'src/Monarch.Core/Commercial/CommercialReturnStore.cs').read_text(encoding='utf-8')


def test_return_draft_authorization_is_type_specific_and_transactional():
    body = SOURCE.split('public CommercialReturnTotals CreateDraft', 1)[1].split('public void Post', 1)[0]
    assert 'using var tx = c.BeginTransaction();' in body
    assert 'RequirePermission(c, tx, userId, companyId, branchId' in body
    assert 'commercial.sales.manage' in body
    assert 'commercial.purchases.manage' in body
    assert body.index('RequirePermission(') < body.index('LoadSource(')


def test_return_draft_audit_precedes_commit():
    body = SOURCE.split('public CommercialReturnTotals CreateDraft', 1)[1].split('public void Post', 1)[0]
    assert 'SalesReturnDraftCreated' in body or 'draft.Type + "DraftCreated"' in body
    assert 'Audit(c, tx, userId, companyId, branchId' in body
    assert body.index('Audit(') < body.index('tx.Commit()')


def test_return_post_authorization_uses_loaded_return_type_inside_transaction():
    body = SOURCE.split('public void Post', 1)[1].split('private static SourceDocument', 1)[0]
    assert 'using var tx = c.BeginTransaction();' in body
    assert 'type == "SalesReturn" ? "commercial.sales.manage"' in body
    assert 'type == "PurchaseReturn" ? "commercial.purchases.manage"' in body
    assert body.index('SELECT return_type') < body.index('RequirePermission(')
    assert 'RequireBranch(' not in SOURCE


def test_return_permission_query_checks_active_tenant_membership_and_explicit_grant():
    helper = SOURCE.split('private static void RequirePermission', 1)[1].split('private static void Audit', 1)[0]
    for fragment in ('monarch_users', 'u.is_active=1', 'monarch_companies', 'co.is_active=1',
                     'monarch_user_company_access', 'ca.is_active=1', 'monarch_user_branch_access',
                     'ba.is_active=1', 'monarch_branches', 'b.is_active=1',
                     'monarch_user_roles', 'monarch_role_permissions', 'rp.permission_code=$permission',
                     'q.Transaction = tx'):
        assert fragment in helper


def test_return_post_and_draft_audits_are_atomic_with_mutations():
    audit = SOURCE.split('private static void Audit', 1)[1].split('private SqliteConnection Open', 1)[0]
    assert "'CommercialReturn'" in audit
    assert 'audit.Transaction = tx' in audit
    post = SOURCE.split('public void Post', 1)[1].split('private static SourceDocument', 1)[0]
    assert post.index('monarch_company_audit_log') < post.index('tx.Commit()')
    draft = SOURCE.split('public CommercialReturnTotals CreateDraft', 1)[1].split('public void Post', 1)[0]
    assert draft.index('Audit(') < draft.index('tx.Commit()')
