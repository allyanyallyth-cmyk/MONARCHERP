from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
STORE = (ROOT / 'src/Monarch.Core/Commercial/CommercialDocumentStore.cs').read_text()
SCHEMA = (ROOT / 'database/commercial-data.sql').read_text()

class DocumentInventoryCostingTests(unittest.TestCase):
    def test_purchase_receipt_uses_document_line_price_not_item_default(self):
        self.assertIn('l.unit_price_minor FROM monarch_commercial_document_lines', STORE)
        self.assertIn('? line.PurchaseUnitCostMinor', STORE)
        self.assertNotIn('i.cost_minor FROM monarch_commercial_document_lines', STORE)

    def test_sale_issue_cost_is_derived_from_preceding_ledger_in_same_transaction(self):
        self.assertIn('CalculateMovingAverageIssueUnitCost(c, tx, companyId', STORE)
        self.assertIn('InventoryCostMethod.MovingWeightedAverage', STORE)
        self.assertIn('ORDER BY ledger_sequence', STORE)
        self.assertIn('StockMovementType.Issue, quantityMilli, 0', STORE)

    def test_document_movements_receive_persistent_sequence(self):
        self.assertIn('MAX(ledger_sequence),0)+1 FROM monarch_stock_movements', STORE)
        self.assertIn('item_id,ledger_sequence,movement_type', STORE)
        self.assertIn('$sequence', STORE)

    def test_posting_costing_and_outbox_share_document_transaction(self):
        self.assertIn('using var c = Open(); using var tx = c.BeginTransaction();', STORE)
        self.assertIn('InsertMovement(c, tx', STORE)
        self.assertIn('INSERT INTO monarch_accounting_posting_outbox', STORE)
        self.assertIn('tx.Commit();', STORE)

    def test_schema_has_immutable_stock_movement_ledger(self):
        self.assertIn('trg_stock_movement_no_update', SCHEMA)
        self.assertIn('trg_stock_movement_no_delete', SCHEMA)

if __name__ == '__main__':
    unittest.main()

class PersistentCostAllocationTests(unittest.TestCase):
    def test_document_posting_persists_line_to_movement_cost_trace(self):
        self.assertIn('monarch_inventory_cost_allocations', SCHEMA)
        self.assertIn('InsertCostAllocation(c, tx', STORE)
        self.assertIn('line.LineId, movementId', STORE)
        self.assertIn('PurchaseReceipt', STORE)
        self.assertIn('SalesIssue', STORE)

    def test_cost_allocation_is_append_only(self):
        self.assertIn('trg_inventory_cost_allocation_no_update', SCHEMA)
        self.assertIn('trg_inventory_cost_allocation_no_delete', SCHEMA)

    def test_allocation_stores_quantity_unit_cost_total_and_method(self):
        for field in ('quantity_milli', 'unit_cost_minor', 'total_cost_minor', 'cost_method', 'movement_id', 'document_line_id'):
            self.assertIn(field, SCHEMA)
        self.assertIn('MovingWeightedAverage', SCHEMA)
        self.assertIn('DocumentCost', SCHEMA)

class CommercialDocumentAuthorizationTests(unittest.TestCase):
    def test_create_and_post_authorize_inside_their_write_transaction(self):
        create = STORE.split('public CommercialDocumentTotals CreateDraft', 1)[1].split('public void Post', 1)[0]
        post = STORE.split('public void Post', 1)[1].split('private static void ValidatePartyAndWarehouse', 1)[0]
        for body in (create, post):
            self.assertIn('using var c = Open(); using var tx = c.BeginTransaction();', body)
            self.assertIn('RequirePermission(c, tx, userId, companyId, branchId', body)

    def test_authorization_joins_active_company_and_branch_membership(self):
        auth = STORE.split('private static void RequirePermission(', 1)[1].split('private static void Audit(', 1)[0]
        self.assertIn('JOIN monarch_user_branch_access', auth)
        self.assertIn('ca.is_active=1', auth)
        self.assertIn('ba.is_active=1', auth)
        self.assertIn('rp.permission_code=$permission', auth)
        self.assertIn('q.Transaction = tx', auth)

    def test_no_out_of_transaction_commercial_preflight_authorization_remains(self):
        self.assertNotIn('RequireBranch(userId, companyId, branchId, true)', STORE)
