from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_role_change_is_tenant_scoped_and_atomic_with_both_audit_logs():
    source = (ROOT / "src/Monarch.Core/Security/IdentityStore.cs").read_text(encoding="utf-8")
    method = source.split("public void SetUserRole(", 1)[1].split("public IReadOnlyList<UserSummary>", 1)[0]
    assert 'Require(actor, "users.manage")' in method
    assert "RequireCompanyBranchAccess" in method
    assert "monarch_user_company_access" in method
    assert "monarch_user_branch_access" in method
    assert "DELETE FROM monarch_user_roles" in method
    assert "INSERT INTO monarch_user_roles" in method
    assert '"UserRoleChanged"' in method
    assert "WriteAudit(connection, transaction" in method
    assert "WriteCompanyAudit(connection, transaction" in method
    assert method.index("WriteCompanyAudit") < method.rindex("transaction.Commit()")


def test_desktop_user_admin_uses_scoped_identity_mutations():
    source = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
    assert "_identity.CreateUser(_session, _newUsername.Text, _newDisplayName.Text, _newPassword.Password, roleCode, _ledgerSession.CompanyId, _ledgerSession.BranchId)" in source
    assert "_identity.SetUserActive(_session, row.Id, false, _ledgerSession.CompanyId, _ledgerSession.BranchId)" in source
    assert "_identity.SetUserRole(_session, row.Id, (string)role.Tag, _ledgerSession.CompanyId, _ledgerSession.BranchId)" in source
    assert "changeRole.Click += ChangeUserRole_Click" in source
