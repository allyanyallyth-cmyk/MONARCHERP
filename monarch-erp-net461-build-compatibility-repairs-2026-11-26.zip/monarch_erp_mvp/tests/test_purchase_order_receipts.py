import pathlib
import sqlite3
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SCHEMA = (ROOT / 'database/commercial-data.sql').read_text(encoding='utf-8')
STORE = (ROOT / 'src/Monarch.Core/Commercial/PurchaseOrderReceiptStore.cs').read_text(encoding='utf-8')


class PurchaseOrderReceiptTests(unittest.TestCase):
    def test_receipt_schema_links_order_and_posted_commercial_document(self):
        self.assertIn('CREATE TABLE IF NOT EXISTS monarch_purchase_receipts', SCHEMA)
        self.assertIn('CREATE TABLE IF NOT EXISTS monarch_purchase_receipt_lines', SCHEMA)
        self.assertIn('FOREIGN KEY(company_id,purchase_order_id) REFERENCES monarch_purchase_orders(company_id,id)', SCHEMA)
        self.assertIn('FOREIGN KEY(company_id,commercial_document_id) REFERENCES monarch_commercial_documents(company_id,id)', SCHEMA)

    def test_receipt_lines_link_order_and_document_lines(self):
        self.assertIn('FOREIGN KEY(company_id,purchase_order_line_id) REFERENCES monarch_purchase_order_lines(company_id,id)', SCHEMA)
        self.assertIn('FOREIGN KEY(company_id,commercial_document_line_id) REFERENCES monarch_commercial_document_lines(company_id,id)', SCHEMA)

    def test_posted_receipts_are_append_only(self):
        for token in ('trg_purchase_receipt_no_update', 'trg_purchase_receipt_no_delete',
                      'trg_purchase_receipt_line_no_update', 'trg_purchase_receipt_line_no_delete'):
            self.assertIn(token, SCHEMA)

    def test_receive_uses_single_transaction_and_purchase_permission(self):
        self.assertIn('using var tx = c.BeginTransaction()', STORE)
        self.assertIn('Require(c, tx, userId, companyId, branchId, "commercial.purchases.manage")', STORE)
        self.assertIn('tx.Commit()', STORE)
        self.assertIn('PurchaseReceiptPosted', STORE)

    def test_partial_and_full_receipts_update_order_status(self):
        self.assertIn("THEN 'Received' ELSE 'PartiallyReceived' END", STORE)
        self.assertIn('received_quantity_milli=received_quantity_milli+$qty', STORE)
        self.assertIn('received_quantity_milli+$qty<=quantity_milli', STORE)

    def test_over_receipt_and_duplicate_lines_are_rejected(self):
        self.assertIn('input.QuantityMilli > ordered - received', STORE)
        self.assertIn('Distinct().Count() != draft.Lines.Count', STORE)

    def test_receipt_posts_stock_cost_and_accounting_outbox(self):
        self.assertIn("VALUES($id,$co,$br,$wh,$item,$seq,'Receipt'", STORE)
        self.assertIn("'PurchaseReceipt'", STORE)
        self.assertIn('monarch_inventory_cost_allocations', STORE)
        self.assertIn("'PurchasePosted'", STORE)
        self.assertIn('monarch_company_audit_log', STORE)

    def test_receipt_listing_is_scoped_to_company_and_branch(self):
        self.assertIn('r.company_id=$co AND r.branch_id=$br', STORE)
        self.assertIn('Require(c, tx, userId, companyId, branchId, "reports.read")', STORE)

    def test_schema_receipt_tables_enforce_positive_quantities_and_unique_numbers(self):
        db = sqlite3.connect(':memory:')
        db.executescript('''
        PRAGMA foreign_keys=ON;
        CREATE TABLE monarch_branches(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_purchase_orders(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_commercial_documents(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_purchase_order_lines(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_commercial_document_lines(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_items(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_users(id TEXT PRIMARY KEY);
        ''')
        marker = '-- Purchase-order receipts are posted atomically'
        db.executescript(SCHEMA[SCHEMA.index(marker):])
        db.execute("INSERT INTO monarch_branches VALUES('c','b')")
        db.execute("INSERT INTO monarch_purchase_orders VALUES('c','po')")
        db.execute("INSERT INTO monarch_commercial_documents VALUES('c','doc')")
        db.execute("INSERT INTO monarch_purchase_order_lines VALUES('c','pol')")
        db.execute("INSERT INTO monarch_commercial_document_lines VALUES('c','dl')")
        db.execute("INSERT INTO monarch_items VALUES('c','i')")
        db.execute("INSERT INTO monarch_users VALUES('u')")
        db.execute("INSERT INTO monarch_purchase_receipts VALUES('r','c','b','po','doc','GR-1','Posted','n','u','n','u',100,'SAR')")
        db.execute("INSERT INTO monarch_purchase_receipt_lines VALUES('rl','c','r','pol','dl','i',1000,100)")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("UPDATE monarch_purchase_receipts SET total_minor=200 WHERE company_id='c' AND id='r'")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("INSERT INTO monarch_purchase_receipt_lines VALUES('rl2','c','r','pol','dl','i',-1,100)")


if __name__ == '__main__':
    unittest.main()
