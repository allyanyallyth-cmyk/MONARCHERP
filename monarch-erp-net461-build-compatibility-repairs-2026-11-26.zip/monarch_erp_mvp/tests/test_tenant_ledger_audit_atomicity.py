from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "src/Monarch.Core/Accounting/TenantLedgerStore.cs").read_text(encoding="utf-8")


def test_account_creation_and_journal_draft_have_scoped_audit_events():
    assert '"TenantAccountCreated", "TenantAccount"' in SOURCE
    assert '"TenantJournalDraftCreated", "TenantJournal"' in SOURCE
    assert 'entityId(result)' in SOURCE


def test_journal_post_and_reversal_have_distinct_audit_events():
    assert '"TenantJournalPosted"' in SOURCE
    assert '"TenantJournalReversed"' in SOURCE
    assert 'result.Id.ToString("D")' in SOURCE


def test_audit_insert_uses_same_sqlite_transaction_and_tenant_scope():
    helper = SOURCE.split("private static void InsertAudit", 1)[1].split("private static void RequireBranchAccess", 1)[0]
    assert "command.Transaction = transaction" in helper
    assert "INSERT INTO monarch_company_audit_log" in helper
    for column in ("company_id", "branch_id", "actor_user_id", "action", "entity_type", "entity_id", "occurred_utc"):
        assert column in helper
    assert "$company" in helper and "$branch" in helper and "$actor" in helper


def test_ledger_commit_occurs_after_audit_insert():
    mutate = SOURCE.split("private T Mutate<T>", 1)[1].split("private JournalEntry MutateJournal", 1)[0]
    journal = SOURCE.split("private JournalEntry MutateJournal", 1)[1].split("private static IReadOnlyCollection<Account>", 1)[0]
    assert mutate.index("PersistChanges(") < mutate.index("InsertAudit(") < mutate.index("transaction.Commit()")
    assert journal.index("PersistChanges(") < journal.index("InsertAudit(") < journal.index("transaction.Commit()")


def test_legacy_audit_table_is_used_without_schema_migration():
    schema = (ROOT / "database/tenancy.sql").read_text(encoding="utf-8")
    assert "CREATE TABLE IF NOT EXISTS monarch_company_audit_log" in schema
    assert "database/migrations" not in SOURCE
