from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UI = (ROOT / 'src/Monarch.Desktop/MainWindow.xaml.cs').read_text(encoding='utf-8')
CORE = (ROOT / 'src/Monarch.Core/Commercial/InventoryMasterDataStore.cs').read_text(encoding='utf-8')


def test_group_and_unit_tabs_are_permission_gated():
    assert 'HasPermission("inventory.items.manage")' in UI
    assert 'BuildItemGroupsPanel()' in UI and 'BuildUnitsPanel()' in UI


def test_group_ui_uses_core_crud_and_soft_status_api():
    for token in ('CreateItemGroup(', 'UpdateItemGroup(', 'SetItemGroupActive('):
        assert token in UI
        assert token in CORE
    assert 'تعطيل المجموعة' in UI and 'تنشيط المجموعة' in UI
    assert 'DELETE FROM monarch_item_groups' not in CORE


def test_group_parent_is_selected_from_active_company_groups():
    assert 'GetItemGroups(_session.UserId, _ledgerSession.CompanyId)' in UI
    assert 'groups.Any(x => x.Id == parsed && x.IsActive)' in UI
    assert 'groups.Where(x => x.Id != id && x.IsActive)' in UI


def test_unit_ui_validates_precision_and_uses_core_crud():
    assert 'CreateUnit(_session.UserId, _ledgerSession.CompanyId' in UI
    assert 'UpdateUnit(_session.UserId, _ledgerSession.CompanyId' in UI
    assert 'places < 0 || places > 6' in UI
    assert 'UpdateUnit(Guid userId, Guid companyId, UnitOfMeasure unit)' in CORE


def test_master_data_load_populates_groups_and_units_for_inventory_readers():
    assert '_itemGroupsGrid.ItemsSource = groups.Select' in UI
    assert '_unitsGrid.ItemsSource = units.Select' in UI
    assert 'var groups = masterStore.GetItemGroups(_session.UserId, _ledgerSession.CompanyId).ToList();' in UI
    assert 'if (_session.HasPermission("inventory.read"))' in UI
    assert 'if (_session.HasPermission("inventory.items.manage"))' in UI
