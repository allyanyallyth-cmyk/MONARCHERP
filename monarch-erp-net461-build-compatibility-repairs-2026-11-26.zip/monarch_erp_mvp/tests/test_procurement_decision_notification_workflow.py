from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
MIGRATION = ROOT / "database/migrations/2026-11-08-procurement-decision-notifications.sql"
STORE = ROOT / "src/Monarch.Core/Autonomy/ProcurementApprovalQueueStore.cs"


def test_additive_migration_creates_append_only_decision_history_and_notification_outbox():
    c = sqlite3.connect(":memory:")
    c.executescript("""
    PRAGMA foreign_keys=ON;
    CREATE TABLE monarch_branches(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
    CREATE TABLE monarch_users(id TEXT PRIMARY KEY);
    INSERT INTO monarch_branches VALUES('co','br');
    INSERT INTO monarch_users VALUES('manager'),('creator');
    """)
    c.executescript(MIGRATION.read_text(encoding="utf-8"))
    history = {r[1] for r in c.execute("PRAGMA table_info(monarch_procurement_decision_history)")}
    notifications = {r[1] for r in c.execute("PRAGMA table_info(monarch_procurement_notification_outbox)")}
    assert {"rationale_snapshot", "decision_note", "order_number_snapshot", "total_minor_snapshot", "decided_by"} <= history
    assert {"recipient_user_id", "event_type", "queue_id", "status", "attempts"} <= notifications


def test_decision_history_is_immutable():
    c = sqlite3.connect(":memory:")
    c.executescript("""
    CREATE TABLE monarch_branches(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
    CREATE TABLE monarch_users(id TEXT PRIMARY KEY);
    INSERT INTO monarch_branches VALUES('co','br'); INSERT INTO monarch_users VALUES('manager');
    """)
    c.executescript(MIGRATION.read_text(encoding="utf-8"))
    c.execute("""INSERT INTO monarch_procurement_decision_history
    VALUES('h','co','br','q','po','Rejected','rationale','cost concern','PO-1','supplier','SAR',100,'manager','2026-11-08T00:00:00Z')""")
    try:
        c.execute("UPDATE monarch_procurement_decision_history SET decision_note='changed' WHERE id='h'")
        assert False, "decision snapshots must be append-only"
    except sqlite3.IntegrityError as exc:
        assert "append-only" in str(exc)


def test_queue_store_writes_snapshot_and_notifications_inside_decision_transaction():
    source = STORE.read_text(encoding="utf-8")
    assert "ReadDecisionSnapshot(c, tx" in source
    assert "INSERT INTO monarch_procurement_decision_history" in source
    assert "NotifyApprovers(c, tx" in source
    assert "NotifyCreator(c, tx" in source
    assert "monarch_procurement_notification_outbox" in source
    assert "tx.Commit();" in source
