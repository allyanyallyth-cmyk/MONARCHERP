import pathlib
import sqlite3
import unittest

SCHEMA = pathlib.Path(__file__).resolve().parents[1] / "database" / "ledger-storage.sql"


class LedgerStorageSchemaTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.executescript(SCHEMA.read_text(encoding="utf-8"))
        self.db.executemany(
            "INSERT INTO monarch_accounts(id,code,name,account_type,is_active) VALUES(?,?,?,?,1)",
            [("cash", "1000", "Cash", "Asset"), ("capital", "3000", "Capital", "Equity")],
        )

    def tearDown(self):
        self.db.close()

    def draft(self, jid="j1", number="JV-1", reversal=None):
        self.db.execute(
            "INSERT INTO monarch_journals(id,number,business_date,description,status,reversal_of_id,created_utc) "
            "VALUES(?,?,?,'test','Draft',?, 'now')",
            (jid, number, "2026-01-01", reversal),
        )

    def lines(self, jid="j1", debit=10000, credit=10000):
        self.db.executemany(
            "INSERT INTO monarch_journal_lines(journal_id,account_id,debit_minor,credit_minor) VALUES(?,?,?,?)",
            [(jid, "cash", debit, 0), (jid, "capital", 0, credit)],
        )

    def test_default_currency_is_sar_with_two_minor_digits(self):
        self.assertEqual(self.db.execute("SELECT base_currency_code FROM monarch_company_settings").fetchone()[0], "SAR")
        self.assertEqual(self.db.execute("SELECT minor_unit_exponent FROM monarch_currencies WHERE code='SAR'").fetchone()[0], 2)

    def test_balanced_integer_minor_units_can_post(self):
        self.draft(); self.lines(); self.db.execute("UPDATE monarch_journals SET status='Posted' WHERE id='j1'")
        self.assertEqual(self.db.execute("SELECT status FROM monarch_journals WHERE id='j1'").fetchone()[0], "Posted")

    def test_unbalanced_journal_cannot_post(self):
        self.draft(); self.lines(credit=9999)
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("UPDATE monarch_journals SET status='Posted' WHERE id='j1'")

    def test_posted_lines_are_immutable(self):
        self.draft(); self.lines(); self.db.execute("UPDATE monarch_journals SET status='Posted' WHERE id='j1'")
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("DELETE FROM monarch_journal_lines WHERE journal_id='j1'")

    def test_reversal_must_exactly_invert_and_post(self):
        self.draft(); self.lines(); self.db.execute("UPDATE monarch_journals SET status='Posted' WHERE id='j1'")
        self.draft("j2", "JV-2", "j1")
        self.db.executemany(
            "INSERT INTO monarch_journal_lines(journal_id,account_id,debit_minor,credit_minor) VALUES(?,?,?,?)",
            [("j2", "cash", 0, 10000), ("j2", "capital", 10000, 0)],
        )
        self.db.execute("UPDATE monarch_journals SET status='Posted' WHERE id='j2'")
        self.db.execute("UPDATE monarch_journals SET status='Reversed' WHERE id='j1'")
        self.assertEqual(self.db.execute("SELECT status FROM monarch_journals WHERE id='j1'").fetchone()[0], "Reversed")

    def test_duplicate_reversal_is_rejected(self):
        self.draft(); self.lines(); self.db.execute("UPDATE monarch_journals SET status='Posted' WHERE id='j1'")
        self.draft("j2", "JV-2", "j1")
        with self.assertRaises(sqlite3.IntegrityError):
            self.draft("j3", "JV-3", "j1")


if __name__ == "__main__":
    unittest.main()
