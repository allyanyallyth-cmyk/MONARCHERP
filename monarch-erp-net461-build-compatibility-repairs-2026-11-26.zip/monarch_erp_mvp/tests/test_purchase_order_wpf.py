import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
UI = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
STORE = (ROOT / "src/Monarch.Core/Commercial/PurchaseOrderStore.cs").read_text(encoding="utf-8")

class PurchaseOrderWpfTests(unittest.TestCase):
    def test_tab_requires_purchase_management_and_read_permission(self):
        self.assertIn('HasPermission("commercial.purchases.manage") && _session.HasPermission("reports.read")', UI)
        self.assertIn("BuildPurchaseOrdersTab()", UI)

    def test_ui_uses_core_store_for_create_approve_cancel_and_list(self):
        for token in ("CreateDraft(", "store.Approve(", "store.Cancel(", "new PurchaseOrderStore(_databasePath).List("):
            self.assertIn(token, UI)

    def test_ui_uses_branch_scoped_lookups(self):
        self.assertIn("ListActiveSuppliers(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId)", UI)
        self.assertIn("GetWarehouses(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, true)", UI)
        self.assertIn("GetItems(_session.UserId, _ledgerSession.CompanyId, true)", UI)

    def test_ui_does_not_initialize_or_migrate_schema_automatically(self):
        start = UI.index("private TabItem BuildPurchaseOrdersTab()")
        end = UI.index("private TabItem BuildCommercialSchemaUpgradeTab()")
        segment = UI[start:end]
        self.assertNotIn(".Initialize(", segment)
        self.assertNotIn("CommercialSchemaUpgradeService", segment)

    def test_core_supplier_lookup_checks_permissions_inside_transaction(self):
        self.assertIn("BeginTransaction()", STORE)
        self.assertIn('Require(c, tx, userId, companyId, branchId, "reports.read")', STORE)

if __name__ == "__main__":
    unittest.main()
