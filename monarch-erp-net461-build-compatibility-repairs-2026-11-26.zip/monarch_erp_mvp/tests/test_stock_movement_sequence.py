from contextlib import closing
from pathlib import Path
import sqlite3, tempfile, unittest

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = (ROOT / 'database/commercial-data.sql').read_text()
STORE = (ROOT / 'src/Monarch.Core/Commercial/CommercialStore.cs').read_text()
VALUATION = (ROOT / 'src/Monarch.Core/Commercial/InventoryValuationStore.cs').read_text()
ENGINE = (ROOT / 'src/Monarch.Core/Commercial/InventoryValuationEngine.cs').read_text()


class StockMovementSequenceTests(unittest.TestCase):
    def test_new_schema_has_monotonic_sequence_column(self):
        self.assertIn('ledger_sequence INTEGER NOT NULL DEFAULT 0 CHECK(ledger_sequence>=0)', SCHEMA)

    def test_record_and_transfer_assign_sequence_inside_transaction(self):
        self.assertIn('NextMovementSequence(c, tx, companyId, m.WarehouseId, m.ItemId)', STORE)
        self.assertIn('NextMovementSequence(c, tx, companyId, warehouseId, itemId)', STORE)
        self.assertIn('MAX(ledger_sequence),0)+1', STORE)

    def test_legacy_database_upgrade_is_idempotent_and_indexed(self):
        self.assertIn('EnsureMovementSequence(c)', STORE)
        self.assertIn('PRAGMA table_info(monarch_stock_movements)', STORE)
        self.assertIn('ux_stock_movement_ledger_sequence', STORE)

    def test_valuation_uses_persisted_sequence_not_clock(self):
        self.assertIn('ORDER BY ledger_sequence', VALUATION)
        self.assertIn('reader.GetInt64(2)', VALUATION)
        self.assertIn('OrderBy(x => x.Sequence)', ENGINE)

    def test_backfill_preserves_legacy_order_for_equal_timestamps(self):
        with tempfile.TemporaryDirectory() as directory:
            with closing(sqlite3.connect(Path(directory) / 'test.db')) as c:
                c.execute('CREATE TABLE m(id TEXT, company_id TEXT, warehouse_id TEXT, item_id TEXT, occurred_utc TEXT, ledger_sequence INTEGER DEFAULT 0)')
                c.executemany('INSERT INTO m VALUES(?,?,?,?,?,0)', [('b','c','w','i','2026-01-01'),('a','c','w','i','2026-01-01'),('c','c','w','i','2026-01-02')])
                sql = """WITH ranked AS (SELECT rowid rid, ROW_NUMBER() OVER(PARTITION BY company_id,warehouse_id,item_id ORDER BY occurred_utc,rowid) seq FROM m WHERE ledger_sequence=0) UPDATE m SET ledger_sequence=(SELECT seq FROM ranked WHERE ranked.rid=m.rowid) WHERE rowid IN(SELECT rid FROM ranked);"""
                c.executescript(sql)
                self.assertEqual([('b',1),('a',2),('c',3)], c.execute('SELECT id,ledger_sequence FROM m ORDER BY ledger_sequence').fetchall())

    def test_migration_temporarily_bypasses_and_restores_immutable_guard(self):
        self.assertIn('DROP TRIGGER IF EXISTS trg_stock_movement_no_update', STORE)
        self.assertIn('CREATE TRIGGER IF NOT EXISTS trg_stock_movement_no_update', STORE)
        with tempfile.TemporaryDirectory() as directory:
            with closing(sqlite3.connect(Path(directory) / 'test.db')) as c:
                c.executescript("""CREATE TABLE movements(id INTEGER PRIMARY KEY, seq INTEGER); INSERT INTO movements(seq) VALUES(0); CREATE TRIGGER no_update BEFORE UPDATE ON movements BEGIN SELECT RAISE(ABORT, 'immutable'); END;""")
                c.execute('DROP TRIGGER no_update')
                c.execute('UPDATE movements SET seq=1 WHERE id=1')
                c.execute("CREATE TRIGGER no_update BEFORE UPDATE ON movements BEGIN SELECT RAISE(ABORT, 'immutable'); END;")
                with self.assertRaises(sqlite3.IntegrityError):
                    c.execute('UPDATE movements SET seq=2 WHERE id=1')

    def test_sequence_is_scoped_per_warehouse_and_item(self):
        with tempfile.TemporaryDirectory() as directory:
            with closing(sqlite3.connect(Path(directory) / 'test.db')) as c:
                c.execute('CREATE TABLE m(company_id,warehouse_id,item_id,ledger_sequence)')
                c.executemany('INSERT INTO m VALUES(?,?,?,?)',[('c','w1','i',1),('c','w2','i',1),('c','w1','j',1)])
                self.assertEqual(2,c.execute("SELECT COALESCE(MAX(ledger_sequence),0)+1 FROM m WHERE company_id='c' AND warehouse_id='w1' AND item_id='i'").fetchone()[0])


if __name__ == '__main__':
    unittest.main()
