from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'src/Monarch.Desktop/MainWindow.xaml.cs').read_text(encoding='utf-8')


def test_alert_center_is_permission_gated_and_added_to_supplier_reporting_area():
    assert 'if (_session.HasPermission("reports.read"))' in SOURCE
    assert 'tabs.Items.Add(BuildSupplierApAlertsTab())' in SOURCE
    assert 'BuildSupplierApAlertsTab()' in SOURCE


def test_alert_reads_use_current_user_company_and_branch_scope():
    assert 'GetOperationalAlerts(_session.UserId, _ledgerSession.CompanyId' in SOURCE
    assert '_ledgerSession.BranchId, 100' in SOURCE
    assert 'GetStates(_session.UserId, _ledgerSession.CompanyId' in SOURCE


def test_view_and_acknowledge_are_explicit_user_actions():
    assert 'RecordSupplierApAlertLifecycle(false)' in SOURCE
    assert 'RecordSupplierApAlertLifecycle(true)' in SOURCE
    assert '.MarkViewed(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, alert)' in SOURCE
    assert '.Acknowledge(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, alert)' in SOURCE


def test_ui_does_not_trigger_worker_processing_or_accounting_mutations():
    section = SOURCE[SOURCE.index('private TabItem BuildSupplierApAlertsTab()'):SOURCE.index('private void LoadSupplierPayablesSuppliers()')]
    assert '.Process(' not in section
    assert 'PostPayment(' not in section
    assert 'PostJournal' not in section
