from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class DesktopAccountingUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.code = (ROOT / 'src/Monarch.Desktop/MainWindow.xaml.cs').read_text(encoding='utf-8')
        cls.project = (ROOT / 'src/Monarch.Desktop/Monarch.Desktop.csproj').read_text(encoding='utf-8')

    def test_desktop_targets_legacy_framework(self):
        self.assertIn('<TargetFramework>net461</TargetFramework>', self.project)

    def test_schema_is_copied_to_desktop_output(self):
        self.assertIn('ledger-storage.sql', self.project)
        self.assertIn('security.sql', self.project)
        self.assertIn('tenant-accounting.sql', self.project)
        self.assertIn('CopyToOutputDirectory="PreserveNewest"', self.project)

    def test_local_database_path(self):
        self.assertIn('Environment.SpecialFolder.LocalApplicationData', self.code)
        self.assertIn('monarch-ledger.db', self.code)
        self.assertIn('new SqliteLedgerStore(_databasePath).Initialize()', self.code)

    def test_account_creation_is_wired_to_store(self):
        self.assertIn('_ledgerSession.AddAccount(new Account', self.code)
        self.assertIn('دليل الحسابات', self.code)

    def test_journal_creation_and_posting_are_wired(self):
        self.assertIn('_ledgerSession.CreateDraft(', self.code)
        self.assertIn('_ledgerSession.Post(row.Id)', self.code)
        self.assertIn('ترحيل القيد المحدد', self.code)


    def test_multi_line_journal_grid_is_configured(self):
        self.assertIn('ConfigureJournalLinesGrid()', self.code)
        self.assertIn('ObservableCollection<JournalLineDraftRow>', self.code)
        self.assertIn('DataGridComboBoxColumn', self.code)

    def test_multi_line_journal_checks_balance_before_save(self):
        self.assertIn('lines.Sum(x => x.DebitMinor) != lines.Sum(x => x.CreditMinor)', self.code)
        self.assertIn('_ledgerSession.CreateDraft(number', self.code)
        self.assertIn('يجب إدخال سطرين محاسبيين على الأقل', self.code)

    def test_journal_line_amount_is_parsed_in_minor_units(self):
        self.assertIn('MinorUnits.FromMajor(amount, exponent)', self.code)
        self.assertIn('ParseJournalAmount(x.DebitAmount, exponent)', self.code)

    def test_desktop_uses_tenant_session_and_company_currency_exponent(self):
        self.assertIn('TenantAccountingSession.Open(', self.code)
        self.assertIn('_ledgerSession.CurrencyExponent', self.code)
        self.assertIn('MinorUnits.ToMajor(', self.code)
        self.assertNotIn('/ 100m', self.code)
        self.assertIn('GrantCompanyAccess(created.Id, _ledgerSession.CompanyId', self.code)
        self.assertIn('CompanyRoleCode, "Viewer"', self.code)


    def test_tenant_selector_is_shown_only_after_legacy_migration_gate(self):
        selector = self.code.index("new TenantContextWindow(_directory, _session)")
        migration_gate = self.code.index("HasCompletedLegacyMigration(defaultCompany)")
        legacy_data_check = self.code.index("HasLegacyLedgerData()")
        tenant_store_init = self.code.index("_tenantStore = new TenantLedgerStore(_databasePath)")
        session_open = self.code.index("TenantAccountingSession.Open(")
        build_ui = self.code.index("BuildInterface();")
        self.assertLess(tenant_store_init, legacy_data_check)
        self.assertLess(legacy_data_check, migration_gate)
        self.assertLess(migration_gate, selector)
        self.assertLess(selector, session_open)
        self.assertLess(session_open, build_ui)

    def test_desktop_ledger_operations_do_not_fall_back_to_legacy_store(self):
        self.assertIn("private TenantAccountingSession _ledgerSession;", self.code)
        self.assertNotIn("_store.GetAccounts", self.code)
        self.assertNotIn("_store.CreateDraft", self.code)
        self.assertNotIn("_store.Post", self.code)
        self.assertNotIn("SqliteLedgerStore _store", self.code)

    def test_reports_use_real_ledger_data(self):
        self.assertIn('_ledgerSession.GetTrialBalance(', self.code)
        self.assertIn('_ledgerSession.GetEntries()', self.code)

    def test_inventory_lineage_audit_tab_is_permission_gated_and_scoped(self):
        self.assertIn('if (_session.HasPermission("reports.read"))', self.code)
        self.assertIn('tabs.Items.Add(BuildInventoryAuditTab());', self.code)
        self.assertIn('new InventoryMovementLineageStore(_databasePath).Inspect(', self.code)
        self.assertIn('_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, cutoff', self.code)
        self.assertIn('private void InspectInventoryLineage()', self.code)
        self.assertIn('InventoryLineageState.OutboxFailed', self.code)
        self.assertIn('تقرير قراءة فقط', self.code)

    def test_master_data_tab_is_permission_gated_and_read_only(self):
        self.assertIn('tabs.Items.Add(BuildMasterDataTab());', self.code)
        self.assertIn('private TabItem BuildMasterDataTab()', self.code)
        self.assertIn('private void LoadMasterData()', self.code)
        self.assertIn('new CommercialStore(_databasePath)', self.code)
        self.assertIn('store.GetItems(_session.UserId, _ledgerSession.CompanyId, false)', self.code)
        self.assertIn('store.GetWarehouses(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, false)', self.code)
        self.assertIn('لم يُنفذ أي ترحيل', self.code)

    def test_master_data_tab_does_not_initialize_commercial_schema(self):
        start = self.code.index('private void LoadMasterData()')
        end = self.code.find('private TabItem BuildInventoryAuditTab()', start)
        body = self.code[start:end]
        self.assertNotIn('.Initialize(', body)
        self.assertNotIn('INSERT INTO', body.upper())
        self.assertNotIn('UPDATE ', body.upper())

if __name__ == '__main__':
    unittest.main(verbosity=2)
