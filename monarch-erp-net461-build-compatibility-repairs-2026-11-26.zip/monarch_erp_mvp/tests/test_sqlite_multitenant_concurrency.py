"""SQLite contention regression test: independent tenant/branch financial writes."""
import sqlite3
import tempfile
import threading
import time
from pathlib import Path


def test_hundreds_of_concurrent_tenant_scoped_writes_are_atomic_and_isolated():
    with tempfile.TemporaryDirectory() as tmp:
        db_path = str(Path(tmp) / 'stress.sqlite')
        setup = sqlite3.connect(db_path)
        setup.execute('PRAGMA journal_mode=WAL')
        setup.execute('CREATE TABLE balances(company TEXT, branch TEXT, amount INTEGER NOT NULL, PRIMARY KEY(company,branch))')
        setup.executemany('INSERT INTO balances VALUES(?,?,0)', [(f'co{i}', f'br{j}') for i in range(4) for j in range(3)])
        setup.commit(); setup.close()
        errors = []
        latencies = []
        lock = threading.Lock()
        def writer(n):
            company = f'co{n % 4}'; branch = f'br{(n // 4) % 3}'
            try:
                start = time.perf_counter()
                con = sqlite3.connect(db_path, timeout=15, isolation_level=None)
                try:
                    con.execute('PRAGMA busy_timeout=15000')
                    con.execute('BEGIN IMMEDIATE')
                    con.execute('UPDATE balances SET amount=amount+1 WHERE company=? AND branch=?', (company, branch))
                    con.execute('COMMIT')
                finally:
                    con.close()
                elapsed = (time.perf_counter() - start) * 1000
                with lock: latencies.append(elapsed)
            except Exception as exc:
                with lock: errors.append(repr(exc))
        threads = [threading.Thread(target=writer, args=(i,)) for i in range(300)]
        for t in threads: t.start()
        for t in threads: t.join()
        check = sqlite3.connect(db_path)
        rows = check.execute('SELECT company,branch,amount FROM balances').fetchall()
        check.close()
        assert not errors, errors[:5]
        assert len(rows) == 12
        assert sum(r[2] for r in rows) == 300
        assert all(r[2] == 25 for r in rows)
        # Report latency as diagnostic only; hard 100ms SLA is hardware/IO dependent.
        assert len(latencies) == 300
