import sqlite3
from contextlib import closing
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MIGRATION = ROOT / "database/migrations/2026-11-08-durable-procurement-recommendation-idempotency.sql"
GATEWAY = ROOT / "src/Monarch.Core/Autonomy/SqliteAutonomousProcurementDraftGateway.cs"
WORKFLOW = ROOT / "src/Monarch.Core/Autonomy/AutonomousProcurementWorkflow.cs"
ORCHESTRATOR = ROOT / "src/Monarch.Core/Autonomy/PredictiveProcurementDraftOrchestrator.cs"


def test_idempotency_migration_enforces_scope_unique_recommendation_key():
    with closing(sqlite3.connect(":memory:")) as db:
        db.executescript(MIGRATION.read_text(encoding="utf-8"))
        row = db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='monarch_procurement_recommendation_runs'").fetchone()
        assert row == ("monarch_procurement_recommendation_runs",)
        columns = {r[1] for r in db.execute("PRAGMA table_info(monarch_procurement_recommendation_runs)")}
        assert {"company_id", "branch_id", "warehouse_id", "item_id", "recommendation_key", "purchase_order_id", "approval_queue_id"} <= columns
        values = ("r1", "co", "br", "wh", "item", "a" * 64, "po", "queue", "user", "now")
        insert = "INSERT INTO monarch_procurement_recommendation_runs VALUES(?,?,?,?,?,?,?,?,?,?)"
        db.execute(insert, values)
        try:
            db.execute(insert, ("r2",) + values[1:])
        except sqlite3.IntegrityError:
            pass
        else:
            raise AssertionError("duplicate recommendation key was accepted")
        db.execute(insert, ("r3", "co", "br", "wh2", "item", "a" * 64, "po2", "queue2", "user", "now"))

def test_gateway_claim_and_purchase_order_share_one_transaction_and_replay_existing_result():
    source = GATEWAY.read_text(encoding="utf-8")
    assert "monarch_procurement_recommendation_runs" in source
    assert "UNIQUE" not in source  # uniqueness is enforced by the explicit SQLite migration
    assert source.index("INSERT INTO monarch_procurement_recommendation_runs") < source.index("INSERT INTO monarch_purchase_orders")
    assert "Existing recommendation draft returned; no duplicate purchase order was created." in source
    assert "tx.Commit();" in source
    assert "Recommendation key is already bound to a different item" in source


def test_recommendation_key_is_deterministic_and_scoped_to_policy_and_analysis_day():
    source = ORCHESTRATOR.read_text(encoding="utf-8")
    for token in ("BuildRecommendationKey", "SHA256.Create()", "candidate.CompanyId", "candidate.BranchId",
                  "candidate.WarehouseId", "candidate.ItemId", "yyyy-MM-dd", "policy.LookbackDays",
                  "policy.SupplierLeadTimeDays", "policy.TargetCoverageDays"):
        assert token in source
    assert "string? RecommendationKey = null" in WORKFLOW.read_text(encoding="utf-8")
