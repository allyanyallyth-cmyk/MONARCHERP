using Microsoft.Data.Sqlite;
using Monarch.Core.Backup;
using Monarch.Core.Accounting;
using Monarch.Core.Organizations;
using Monarch.Core.Security;
using Monarch.Core.Zatca;
using System.Xml;


// ZATCA QR TLV and UBL/hash-chain smoke checks (no live API calls or taxpayer credentials).
var vatNumber = "310000000000003";
var sellerParty = new ZatcaParty("MONARCH Test LLC", vatNumber,
    new ZatcaAddress("King Road", "1234", "Riyadh", "12345", "Al Olaya"));
var buyerParty = new ZatcaParty("Buyer LLC", "310000000000013",
    new ZatcaAddress("Main Street", "4321", "Riyadh", "54321", "Al Malaz"));
var zatcaDraft = new ZatcaInvoiceDraft(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(),
    "INV-ZATCA-0001", new DateTimeOffset(2026, 11, 7, 10, 30, 0, TimeSpan.Zero),
    ZatcaInvoiceKind.StandardTaxInvoice, "SAR", sellerParty, buyerParty,
    new[] { new ZatcaInvoiceLine("1", "Test item", 1m, "PCE", 10000, 1500, 1500, ZatcaTaxCategory.StandardRated) });
var basicQr = ZatcaQrCodeEncoder.EncodeBasic(sellerParty.LegalName, vatNumber,
    zatcaDraft.IssueDateTime, 11500, 1500);
var basicTags = DecodeTlv(Convert.FromBase64String(basicQr));
Check(basicTags.SequenceEqual(new byte[] { 1, 2, 3, 4, 5 }), "ZATCA basic QR TLV tags 1-5 and Base64");
var phase2Stamp = new ZatcaCryptographicStamp(new byte[] { 1, 2, 3 }, new byte[] { 4, 5, 6 }, new byte[] { 7, 8, 9 });
var phase2Qr = ZatcaQrCodeEncoder.EncodePhase2(sellerParty.LegalName, vatNumber,
    zatcaDraft.IssueDateTime, 11500, 1500, new byte[32], phase2Stamp, true);
var phase2Tags = DecodeTlv(Convert.FromBase64String(phase2Qr));
Check(phase2Tags.SequenceEqual(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 }), "ZATCA simplified QR TLV tags 1-9");
var zatcaBuilt = new ZatcaInvoiceBuilder().Build(zatcaDraft, ZatcaInvoiceBuilder.FirstInvoicePreviousHash);
var zatcaXml = new XmlDocument(); zatcaXml.LoadXml(zatcaBuilt.Xml);
Check(zatcaXml.DocumentElement?.LocalName == "Invoice", "UBL 2.1 invoice XML is well formed");
Check(new ZatcaInvoiceHashService().ComputeHashBase64(zatcaBuilt.Xml) == zatcaBuilt.InvoiceHashBase64,
    "ZATCA invoice SHA-256 digest is reproducible after excluding QR and signature references");
var simplifiedDraft = zatcaDraft with { Kind = ZatcaInvoiceKind.SimplifiedTaxInvoice, Buyer = null, InvoiceNumber = "INV-ZATCA-S-0001" };
ExpectFailure(() => new ZatcaInvoiceBuilder().Build(simplifiedDraft, ZatcaInvoiceBuilder.FirstInvoicePreviousHash),
    "simplified Phase-2 invoice fails closed without EGS stamp and XAdES providers");

var ledger = new LedgerBook();
var cash = new Account(Guid.NewGuid(), "1000", "الصندوق", AccountType.Asset);
var capital = new Account(Guid.NewGuid(), "3000", "رأس المال", AccountType.Equity);
var sales = new Account(Guid.NewGuid(), "4000", "إيرادات المبيعات", AccountType.Revenue);
var expense = new Account(Guid.NewGuid(), "5000", "مصروفات تشغيل", AccountType.Expense);
foreach (var account in new[] { cash, capital, sales, expense }) ledger.AddAccount(account);

Check(MinorUnits.FromMajor(125.75m, 2) == 12575, "minor-unit conversion");
ExpectFailure(() => MinorUnits.FromMajor(1.001m, 2), "fraction precision guard");

var opening = ledger.CreateDraft("JV-0001", new DateOnly(2026, 1, 1), "رأس المال", new[]
{
    JournalLine.Debit(cash.Id, 100_000), JournalLine.Credit(capital.Id, 100_000)
});
ledger.Post(opening.Id);

var sale = ledger.CreateDraft("JV-0002", new DateOnly(2026, 1, 2), "مبيعات نقدية", new[]
{
    JournalLine.Debit(cash.Id, 25_000), JournalLine.Credit(sales.Id, 25_000)
});
ledger.Post(sale.Id);

var cost = ledger.CreateDraft("JV-0003", new DateOnly(2026, 1, 3), "مصروف تشغيل", new[]
{
    JournalLine.Debit(expense.Id, 5_000), JournalLine.Credit(cash.Id, 5_000)
});
ledger.Post(cost.Id);

var trial = ledger.GetTrialBalance(new DateOnly(2026, 1, 1), new DateOnly(2026, 1, 31));
Check(trial.IsBalanced && trial.TotalDebitMinor == 130_000, "trial balance equality");
var income = ledger.GetIncomeStatement(new DateOnly(2026, 1, 1), new DateOnly(2026, 1, 31));
Check(income.NetIncomeMinor == 20_000, "income statement net income");
var balance = ledger.GetBalanceSheet(new DateOnly(2026, 1, 31));
Check(balance.IsBalanced && balance.AssetsMinor == 120_000, "balance sheet equation");

var reversed = ledger.Reverse(sale.Id, "JV-0004", new DateOnly(2026, 1, 4), "إلغاء عملية البيع");
Check(reversed.Status == JournalStatus.Posted, "reversal is posted atomically in domain service");
Check(ledger.Entries.Single(e => e.Id == sale.Id).Status == JournalStatus.Reversed, "original marked reversed");
Check(ledger.GetIncomeStatement(new DateOnly(2026, 1, 1), new DateOnly(2026, 1, 31)).NetIncomeMinor == -5_000,
    "reversal affects reports on its own business date");
ExpectFailure(() => ledger.Reverse(sale.Id, "JV-0005", new DateOnly(2026, 1, 5), "عكس مكرر"), "duplicate reversal guard");

var unbalanced = ledger.CreateDraft("JV-0006", new DateOnly(2026, 1, 5), "قيد غير متوازن", new[]
{
    JournalLine.Debit(cash.Id, 100), JournalLine.Credit(capital.Id, 99)
});
ExpectFailure(() => ledger.Post(unbalanced.Id), "unbalanced journal rejected");
var inactive = new Account(Guid.NewGuid(), "1999", "حساب متوقف", AccountType.Asset, false);
ledger.AddAccount(inactive);
ExpectFailure(() =>
{
    var invalidAccount = ledger.CreateDraft("JV-0007", new DateOnly(2026, 1, 5), "حساب متوقف", new[]
    {
        JournalLine.Debit(inactive.Id, 100), JournalLine.Credit(capital.Id, 100)
    });
    ledger.Post(invalidAccount.Id);
}, "inactive account rejected");

// Durable SQLite round-trip: transactions, integer minor units, and reversal survive reopening.
var databasePath = Path.Combine(Path.GetTempPath(), $"monarch-ledger-{Guid.NewGuid():N}.db");
try
{
    var schemaPath = Path.Combine(AppContext.BaseDirectory, "database", "ledger-storage.sql");
    var store = new SqliteLedgerStore(databasePath);
    store.Initialize(schemaPath);
    Check(store.GetBaseCurrency() == "SAR" && store.GetCurrencyExponent("SAR") == 2, "default SAR currency configuration");
    var persistedCash = new Account(Guid.NewGuid(), "1100", "النقدية", AccountType.Asset);
    var persistedCapital = new Account(Guid.NewGuid(), "3100", "رأس المال", AccountType.Equity);
    store.AddAccount(persistedCash);
    store.AddAccount(persistedCapital);
    var persistedEntry = store.CreateDraft("DB-0001", new DateOnly(2026, 2, 1), "رأس مال افتتاحي", new[]
    {
        JournalLine.Debit(persistedCash.Id, MinorUnits.FromMajor(150.25m, 2)),
        JournalLine.Credit(persistedCapital.Id, MinorUnits.FromMajor(150.25m, 2))
    });
    store.Post(persistedEntry.Id);
    var reopened = new SqliteLedgerStore(databasePath);
    Check(reopened.GetEntries().Single(e => e.Id == persistedEntry.Id).Status == JournalStatus.Posted,
        "posted journal persists after reopening");
    Check(reopened.GetTrialBalance(new DateOnly(2026, 2, 1), new DateOnly(2026, 2, 1)).IsBalanced,
        "persisted trial balance is balanced");
    reopened.Reverse(persistedEntry.Id, "DB-0002", new DateOnly(2026, 2, 2), "اختبار العكس");
    Check(new SqliteLedgerStore(databasePath).GetEntries().Single(e => e.Id == persistedEntry.Id).Status == JournalStatus.Reversed,
        "reversal transaction persists both entries");

    var backupDirectory = Path.Combine(Path.GetTempPath(), "monarch-backup-tests-" + Guid.NewGuid().ToString("N"));
    Directory.CreateDirectory(backupDirectory);
    var backupPath = Path.Combine(backupDirectory, "monarch-test.mbackup");
    var safetyPath = Path.Combine(backupDirectory, "monarch-pre-restore.mbackup");
    const string backupPassword = "Monarch-Test-Backup-2026!";
    try
    {
        var backupService = new BackupRecoveryService(databasePath);
        var backup = backupService.CreateEncryptedBackup(backupPath, backupPassword, 5);
        Check(File.Exists(backup.Path) && backup.IntegrityResult == "ok", "encrypted SQLite backup created and integrity checked");
        Check(backupService.VerifyEncryptedBackup(backupPath, backupPassword).IsValid, "encrypted backup authentication and integrity verification");
        Check(!backupService.VerifyEncryptedBackup(backupPath, "Wrong-Password-2026!").IsValid, "wrong backup password rejected");
        var postBackupAccount = new Account(Guid.NewGuid(), "9998", "يجب أن يختفي بعد الاستعادة", AccountType.Asset);
        new SqliteLedgerStore(databasePath).AddAccount(postBackupAccount);
        var restored = backupService.RestoreEncryptedBackup(backupPath, backupPassword, safetyPath);
        Check(restored.IntegrityResult == "ok" && File.Exists(safetyPath), "restore verifies target and preserves encrypted pre-restore safety copy");
        Check(!new SqliteLedgerStore(databasePath).GetAccounts().Any(a => a.Id == postBackupAccount.Id), "restore returns database to backup point");
        Check(new SqliteLedgerStore(databasePath).GetEntries().Any(e => e.Id == persistedEntry.Id), "restored database retains backed-up journal history");
    }
    finally { if (Directory.Exists(backupDirectory)) Directory.Delete(backupDirectory, true); }
}
finally
{
    SqliteConnection.ClearAllPools();
    foreach (var suffix in new[] { "", "-shm", "-wal" })
        if (File.Exists(databasePath + suffix)) File.Delete(databasePath + suffix);
}

// Multi-company persistence and authorization smoke checks.
var tenantDatabasePath = Path.Combine(Path.GetTempPath(), $"monarch-tenant-{Guid.NewGuid():N}.db");
try
{
    var legacy = new SqliteLedgerStore(tenantDatabasePath);
    legacy.Initialize(Path.Combine(AppContext.BaseDirectory, "database", "ledger-storage.sql"));
    var identity = new IdentityStore(tenantDatabasePath);
    identity.Initialize(Path.Combine(AppContext.BaseDirectory, "database", "security.sql"));
    identity.CreateFirstAdministrator("root", "System Admin", "SafePassphrase123!");
    var admin = identity.Authenticate("root", "SafePassphrase123!") ?? throw new Exception("Administrator login failed.");

    var directory = new CompanyDirectoryStore(tenantDatabasePath);
    directory.Initialize(Path.Combine(AppContext.BaseDirectory, "database", "tenancy.sql"));
    var defaultCompany = Guid.Parse("00000000-0000-0000-0000-000000000001");
    var defaultBranch = Guid.Parse("00000000-0000-0000-0000-000000000002");
    directory.GrantCompanyAccess(admin.UserId, defaultCompany, "Administrator", admin.UserId);
    Check(directory.HasCompanyMembership(admin.UserId), "company membership lookup is scoped to the authenticated user");
    var secondCompany = directory.CreateCompanyForAdministrator("SECOND", "Second Company LLC", "Second Company", "SA", "SAR", "Asia/Riyadh", admin.UserId);
    var secondBranch = directory.GetBranches(secondCompany).Single(b => b.IsHeadOffice).Id;

    var tenantStore = new TenantLedgerStore(tenantDatabasePath);
    tenantStore.Initialize(Path.Combine(AppContext.BaseDirectory, "database", "tenant-accounting.sql"));
    var cashOne = new Account(Guid.NewGuid(), "1000", "Cash", AccountType.Asset);
    var equityOne = new Account(Guid.NewGuid(), "3000", "Capital", AccountType.Equity);
    var cashTwo = new Account(Guid.NewGuid(), "1000", "Cash", AccountType.Asset);
    var equityTwo = new Account(Guid.NewGuid(), "3000", "Capital", AccountType.Equity);
    tenantStore.AddAccount(admin.UserId, defaultCompany, defaultBranch, cashOne);
    tenantStore.AddAccount(admin.UserId, defaultCompany, defaultBranch, equityOne);
    tenantStore.AddAccount(admin.UserId, secondCompany, secondBranch, cashTwo);
    tenantStore.AddAccount(admin.UserId, secondCompany, secondBranch, equityTwo);

    var companyOneJournal = tenantStore.CreateDraft(admin.UserId, defaultCompany, defaultBranch, "OPEN-1",
        new DateOnly(2026, 3, 1), "Opening balance", new[] { JournalLine.Debit(cashOne.Id, 50000), JournalLine.Credit(equityOne.Id, 50000) });
    tenantStore.Post(admin.UserId, defaultCompany, defaultBranch, companyOneJournal.Id);
    var companyTwoJournal = tenantStore.CreateDraft(admin.UserId, secondCompany, secondBranch, "OPEN-1",
        new DateOnly(2026, 3, 1), "Opening balance", new[] { JournalLine.Debit(cashTwo.Id, 90000), JournalLine.Credit(equityTwo.Id, 90000) });
    tenantStore.Post(admin.UserId, secondCompany, secondBranch, companyTwoJournal.Id);

    Check(tenantStore.GetEntries(admin.UserId, defaultCompany, defaultBranch).Single().Id == companyOneJournal.Id,
        "tenant ledger reads only the selected company and branch");
    Check(tenantStore.GetTrialBalance(admin.UserId, defaultCompany, defaultBranch,
        new DateOnly(2026, 3, 1), new DateOnly(2026, 3, 1)).TotalDebitMinor == 50000,
        "tenant trial balance is isolated by company");

    // Exercise the same explicit company/branch context used by the WPF desktop shell.
    var adminContext = TenantAccountingSession.Open(directory, tenantStore, admin, defaultCompany, defaultBranch);
    Check(adminContext.CompanyId == defaultCompany && adminContext.BranchId == defaultBranch,
        "tenant session binds the selected company and branch");
    Check(adminContext.BaseCurrencyCode == "SAR" && adminContext.CurrencyExponent == 2,
        "tenant session resolves company currency precision");
    Check(adminContext.GetEntries().Single().Id == companyOneJournal.Id,
        "tenant session reads only its selected branch");
    Check(adminContext.GetAccounts().Count == 2,
        "tenant session exposes company-scoped chart of accounts through its selected branch");
    Check(adminContext.GetAccounts().All(a => a.Id == cashOne.Id || a.Id == equityOne.Id),
        "company chart contains no account IDs from another company");
    Check(tenantStore.GetAccounts(admin.UserId, secondCompany, secondBranch).All(a => a.Id == cashTwo.Id || a.Id == equityTwo.Id),
        "same account codes remain isolated inside a separate company context");

    identity.CreateUser(admin, "viewer", "Read Only", "ViewerPassphrase123!", "Viewer");
    var viewer = identity.Authenticate("viewer", "ViewerPassphrase123!") ?? throw new Exception("Viewer login failed.");
    var companyCountBeforeDeniedCreate = directory.GetCompanies().Count;
    ExpectFailure(() => directory.CreateCompanyForAdministrator("DENIED", "Denied Company", "Denied", "SA", "SAR", "Asia/Riyadh", viewer.UserId),
        "non-administrator cannot create a company");
    Check(directory.GetCompanies().Count == companyCountBeforeDeniedCreate,
        "denied company creation leaves no partial company or branch records");
    ExpectFailure(() => directory.GrantCompanyAndBranchAccess(viewer.UserId, defaultCompany, defaultBranch, "Viewer", viewer.UserId),
        "non-administrator cannot grant company access");
    ExpectFailure(() => directory.GrantCompanyAccess(viewer.UserId, defaultCompany, "Viewer", viewer.UserId),
        "non-administrator cannot use direct company membership grant");
    ExpectFailure(() => directory.CreateBranch(defaultCompany, "DENIED-BR", "Denied Branch", viewer.UserId),
        "non-administrator cannot create a branch through the core store");
    var auditedBranch = directory.CreateBranch(defaultCompany, "OPS", "Operations", admin.UserId);
    Check(directory.GetBranches(defaultCompany).Any(b => b.Id == auditedBranch),
        "global administrator can create an audited branch");
    directory.GrantCompanyAndBranchAccess(viewer.UserId, defaultCompany, defaultBranch, "Viewer", admin.UserId);
    Check(directory.HasCompanyMembership(viewer.UserId), "second user membership is independently detected");
    ExpectFailure(() => directory.GrantCompanyAndBranchAccess(viewer.UserId, defaultCompany, secondBranch, "Viewer", admin.UserId),
        "company access grant rejects a branch belonging to another company");
    Check(tenantStore.GetEntries(viewer.UserId, defaultCompany, defaultBranch).Count == 1,
        "viewer can read an explicitly assigned branch");
    Check(tenantStore.GetAccounts(viewer.UserId, defaultCompany, defaultBranch).Count == 2,
        "viewer can read the company chart only through an assigned branch context");
    ExpectFailure(() => tenantStore.GetAccounts(viewer.UserId, defaultCompany, auditedBranch),
        "viewer cannot read the company chart through an unassigned branch");
    ExpectFailure(() => tenantStore.AddAccount(viewer.UserId, defaultCompany, defaultBranch,
        new Account(Guid.NewGuid(), "9900", "Denied Account", AccountType.Asset)),
        "viewer cannot mutate the chart even within an assigned branch");
    ExpectFailure(() => tenantStore.Post(admin.UserId, defaultCompany, auditedBranch, companyOneJournal.Id),
        "posting cannot cross the explicitly selected branch context");
    ExpectFailure(() => tenantStore.Reverse(admin.UserId, defaultCompany, auditedBranch, companyOneJournal.Id,
        "BAD-REV", new DateOnly(2026, 3, 3), "Wrong branch"),
        "reversal cannot cross the explicitly selected branch context");
    ExpectFailure(() => tenantStore.GetAccounts(viewer.UserId, secondCompany, secondBranch),
        "user without company membership cannot read another company's chart");
    var viewerContext = TenantAccountingSession.Open(directory, tenantStore, viewer, defaultCompany, defaultBranch);
    Check(viewerContext.CompanyRoleCode == "Viewer" && viewerContext.GetEntries().Count == 1,
        "viewer session opens only its explicitly authorized branch");
    ExpectFailure(() => TenantAccountingSession.Open(directory, tenantStore, viewer, secondCompany, secondBranch),
        "viewer cannot open an unassigned company context");
    ExpectFailure(() => TenantAccountingSession.Open(directory, tenantStore, viewer, defaultCompany, secondBranch),
        "viewer cannot open a branch outside the selected company");
    ExpectFailure(() => tenantStore.CreateDraft(viewer.UserId, defaultCompany, defaultBranch, "DENIED-1",
        new DateOnly(2026, 3, 2), "Should be denied", new[] { JournalLine.Debit(cashOne.Id, 100), JournalLine.Credit(equityOne.Id, 100) }),
        "viewer cannot create a journal");
    directory.GrantBranchAccess(viewer.UserId, defaultCompany, defaultBranch, false, admin.UserId);
    ExpectFailure(() => viewerContext.GetEntries(),
        "an already-open tenant session rechecks branch permission after revocation");
    ExpectFailure(() => viewerContext.GetAccounts(),
        "chart reads recheck current branch permission after revocation");
    var tenantReversal = adminContext.Reverse(companyOneJournal.Id, "OPEN-1-REV",
        new DateOnly(2026, 3, 4), "Tenant reversal smoke test");
    Check(tenantReversal.Status == JournalStatus.Posted &&
          adminContext.GetEntries().Single(e => e.Id == companyOneJournal.Id).Status == JournalStatus.Reversed,
        "tenant reversal is persisted only inside the selected branch");
}
finally
{
    SqliteConnection.ClearAllPools();
    foreach (var suffix in new[] { "", "-shm", "-wal" })
        if (File.Exists(tenantDatabasePath + suffix)) File.Delete(tenantDatabasePath + suffix);
}

Console.WriteLine("PASS: accounting and tenant smoke checks completed.");

static void Check(bool condition, string name)
{
    if (!condition) throw new Exception($"FAIL: {name}");
    Console.WriteLine($"PASS: {name}");
}

static void ExpectFailure(Action action, string name)
{
    try { action(); }
    catch (Exception) { Console.WriteLine($"PASS: {name}"); return; }
    throw new Exception($"FAIL: {name} was not rejected.");
}

static byte[] DecodeTlv(byte[] payload)
{
    var tags = new List<byte>();
    for (var offset = 0; offset < payload.Length;)
    {
        if (offset + 2 > payload.Length) throw new Exception("Malformed TLV header.");
        var tag = payload[offset++]; var length = payload[offset++];
        if (offset + length > payload.Length) throw new Exception("Malformed TLV value.");
        tags.Add(tag); offset += length;
    }
    return tags.ToArray();
}
