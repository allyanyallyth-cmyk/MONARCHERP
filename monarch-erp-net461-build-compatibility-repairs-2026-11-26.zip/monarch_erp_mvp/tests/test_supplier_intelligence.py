import pathlib
import sqlite3

ROOT = pathlib.Path(__file__).resolve().parents[1]


def test_supplier_intelligence_migration_creates_scoped_terms_and_indexes():
    db = sqlite3.connect(':memory:')
    db.executescript('''
      CREATE TABLE monarch_parties(company_id TEXT NOT NULL,id TEXT NOT NULL,PRIMARY KEY(company_id,id));
      CREATE TABLE monarch_items(company_id TEXT NOT NULL,id TEXT NOT NULL,PRIMARY KEY(company_id,id));
      CREATE TABLE monarch_users(id TEXT PRIMARY KEY);
    ''')
    migration = ROOT / 'database/migrations/2026-11-08-supplier-intelligence.sql'
    db.executescript(migration.read_text(encoding='utf-8'))
    names = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    indexes = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='index'")}
    assert 'monarch_supplier_item_terms' in names
    assert 'ix_supplier_item_terms_lookup' in indexes
    assert 'ux_supplier_item_terms_active_start' in indexes


def test_supplier_intelligence_migration_rejects_duplicate_active_effective_terms():
    db = sqlite3.connect(':memory:')
    db.executescript('''
      PRAGMA foreign_keys=ON;
      CREATE TABLE monarch_parties(company_id TEXT NOT NULL,id TEXT NOT NULL,PRIMARY KEY(company_id,id));
      CREATE TABLE monarch_items(company_id TEXT NOT NULL,id TEXT NOT NULL,PRIMARY KEY(company_id,id));
      CREATE TABLE monarch_users(id TEXT PRIMARY KEY);
      INSERT INTO monarch_parties VALUES('co','supplier');
      INSERT INTO monarch_items VALUES('co','item');
      INSERT INTO monarch_users VALUES('user');
    ''')
    db.executescript((ROOT / 'database/migrations/2026-11-08-supplier-intelligence.sql').read_text(encoding='utf-8'))
    sql = '''INSERT INTO monarch_supplier_item_terms
      (id,company_id,supplier_id,item_id,currency_code,currency_scale,unit_cost_minor,tax_rate_bps,lead_time_days,
       minimum_order_quantity_milli,effective_from,source_reference,is_active,created_by,created_utc)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1,?,?)'''
    values = ('one','co','supplier','item','SAR',2,100,1500,7,1000,'2026-01-01','contract-1','user','2026-01-01T00:00:00Z')
    db.execute(sql, values)
    try:
        db.execute(sql, ('two',) + values[1:])
        assert False, 'duplicate active effective terms must be rejected'
    except sqlite3.IntegrityError:
        pass


def test_supplier_intelligence_store_is_tenant_scoped_and_evidence_based():
    source = (ROOT / 'src/Monarch.Core/Commercial/SupplierIntelligenceStore.cs').read_text(encoding='utf-8')
    assert 'commercial.purchases.manage' in source
    assert 'reports.read' in source
    assert 'po.company_id=$co AND po.branch_id=$br' in source
    assert 'source_reference' in (ROOT / 'database/migrations/2026-11-08-supplier-intelligence.sql').read_text(encoding='utf-8')
    assert 'AverageActualLeadTimeDays' in source and 'OnTimeDeliveryRate' in source
