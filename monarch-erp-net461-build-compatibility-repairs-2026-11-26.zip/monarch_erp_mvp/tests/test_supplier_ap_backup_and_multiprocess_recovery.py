"""SQLite-level backup and competing-worker recovery regression tests.

These tests exercise database semantics; they are not a substitute for the C#
BackupRecoveryService build or Windows multi-process runtime tests.
"""
import sqlite3
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MIGRATIONS = ROOT / "database/migrations"
MIGRATION_NAMES = [
    "2026-11-11-supplier-ap-alert-delivery.sql",
    "2026-11-11-supplier-ap-alert-dispatcher.sql",
    "2026-11-11-supplier-ap-alert-inbox-read-state.sql",
    "2026-11-11-supplier-ap-alert-dead-letter-operations.sql",
    "2026-11-12-supplier-ap-alert-dispatch-integrity.sql",
]


def populated_db(path):
    db = sqlite3.connect(path, timeout=10, isolation_level=None)
    db.execute("PRAGMA foreign_keys=ON")
    for name in MIGRATION_NAMES:
        db.executescript((MIGRATIONS / name).read_text(encoding="utf-8"))
    db.execute(
        "INSERT INTO monarch_supplier_ap_alert_delivery_intents VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        ("intent-1", "company-1", "branch-1", "user-1", "supplier_ap_heartbeat_failures",
         "2026-11-12T00:00:00Z", "Critical", 2, "InApp", "critical_immediate_escalation",
         "2026-11-12T00:00:00Z", "2026-11-12T00:00:00Z"),
    )
    return db


def test_backup_copy_preserves_dispatch_and_audit_history(tmp_path):
    source = tmp_path / "live.db"
    backup = tmp_path / "backup.db"
    with populated_db(source) as db:
        db.execute("INSERT INTO monarch_supplier_ap_alert_dispatch_attempts VALUES(?,?,?,?,?,?,?)",
                   ("attempt-1", "intent-1", 1, "RetryScheduled", "TIMEOUT", "2026-11-12T00:01:00Z", "2026-11-12T00:02:00Z"))
        db.execute("INSERT INTO monarch_supplier_ap_alert_dead_letter_actions VALUES(?,?,?,?,?,?,?,?,?)",
                   ("action-1", "intent-1", "company-1", "branch-1", "operator-1", "ManualRetryQueued", 8,
                    "2026-11-12T00:03:00Z", "MANUAL_OPERATOR_RETRY"))
        db.execute("INSERT INTO monarch_supplier_ap_alert_inbox_events VALUES(?,?,?,?,?,?,?)",
                   ("event-1", "intent-1", "company-1", "branch-1", "user-1", "Viewed", "2026-11-12T00:04:00Z"))
        target = sqlite3.connect(backup)
        db.backup(target)
        target.close()
    with sqlite3.connect(backup) as restored:
        assert restored.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert restored.execute("PRAGMA foreign_key_check").fetchall() == []
        assert restored.execute("SELECT COUNT(*) FROM monarch_supplier_ap_alert_dispatch_attempts").fetchone()[0] == 1
        assert restored.execute("SELECT COUNT(*) FROM monarch_supplier_ap_alert_dead_letter_actions").fetchone()[0] == 1
        assert restored.execute("SELECT COUNT(*) FROM monarch_supplier_ap_alert_inbox_events").fetchone()[0] == 1


def test_foreign_key_check_detects_orphaned_rows_that_integrity_check_misses(tmp_path):
    path = tmp_path / "orphan.db"
    with populated_db(path) as db:
        db.execute("PRAGMA foreign_keys=OFF")
        db.execute("INSERT INTO monarch_supplier_ap_alert_dispatch_attempts VALUES(?,?,?,?,?,?,?)",
                   ("orphan-attempt", "missing-intent", 1, "RetryScheduled", "TIMEOUT", "2026-11-12T00:01:00Z", None))
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        violations = db.execute("PRAGMA foreign_key_check").fetchall()
        assert violations and violations[0][0] == "monarch_supplier_ap_alert_dispatch_attempts"


def test_competing_workers_cannot_claim_the_same_due_intent(tmp_path):
    path = tmp_path / "multi-worker.db"
    setup = populated_db(path)
    setup.close()
    barrier = threading.Barrier(2)
    claimed = []
    errors = []

    def worker(token):
        try:
            db = sqlite3.connect(path, timeout=10, isolation_level=None)
            db.execute("PRAGMA busy_timeout=10000")
            barrier.wait(timeout=5)
            db.execute("BEGIN IMMEDIATE")
            row = db.execute(
                "SELECT intent_id FROM monarch_supplier_ap_alert_dispatch_state "
                "WHERE status='Pending' AND next_attempt_utc<=?", ("2026-11-12T00:05:00Z",)
            ).fetchone()
            if row:
                changed = db.execute(
                    "UPDATE monarch_supplier_ap_alert_dispatch_state SET status='Claimed',lease_token=?,"
                    "lease_expires_utc=?,updated_utc=? WHERE intent_id=? AND status='Pending'",
                    (token, "2026-11-12T00:06:00Z", "2026-11-12T00:05:00Z", row[0]),
                ).rowcount
                if changed == 1:
                    claimed.append((row[0], token))
            db.execute("COMMIT")
            db.close()
        except Exception as exc:  # surfaced below in the main test thread
            errors.append(repr(exc))

    threads = [threading.Thread(target=worker, args=(f"token-{i}",)) for i in range(2)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=15)
    assert not errors, errors
    assert all(not thread.is_alive() for thread in threads)
    assert len(claimed) == 1
    with sqlite3.connect(path) as db:
        assert db.execute("SELECT status FROM monarch_supplier_ap_alert_dispatch_state WHERE intent_id='intent-1'").fetchone()[0] == "Claimed"


def test_csharp_backup_validation_includes_foreign_key_check():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    assert 'command.CommandText = "PRAGMA integrity_check;";' in source
    assert 'command.CommandText = "PRAGMA foreign_key_check;";' in source
    assert "CheckIntegrity(tempDatabase)" in source
    assert "CheckIntegrity(temp)" in source
    assert "CheckIntegrity(restoreTemp)" in source
    assert "CheckIntegrity(_databasePath)" in source


def test_csharp_backup_and_restore_share_path_scoped_cross_process_mutex():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    assert "ExecuteWithDatabaseMutex(() => CreateEncryptedBackupCore" in source
    assert "ExecuteWithDatabaseMutex(() => RestoreEncryptedBackupCore" in source
    assert "new Mutex(false, mutexName)" in source
    assert '"MONARCH_DB_OPERATION_"' in source
    assert "SHA256.Create()" in source
    assert "DatabaseOperationLockTimeoutMilliseconds = 30000" in source
    assert "mutex.WaitOne(DatabaseOperationLockTimeoutMilliseconds)" in source
    assert "catch (AbandonedMutexException)" in source
    assert "mutex.ReleaseMutex()" in source


def test_csharp_restore_documents_cooperating_process_boundary():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    assert "All participating MONARCH builds" in source and "must use this lock" in source
    assert "unrelated SQLite clients are not controlled by it" in source


def test_online_backup_api_captures_committed_wal_state_without_copying_sidecars(tmp_path):
    source_path = tmp_path / "wal-live.db"
    backup_path = tmp_path / "wal-backup.db"
    source = sqlite3.connect(source_path, timeout=10, isolation_level=None)
    try:
        assert source.execute("PRAGMA journal_mode=WAL").fetchone()[0].lower() == "wal"
        source.execute("CREATE TABLE wal_sentinel(value TEXT NOT NULL)")
        source.execute("INSERT INTO wal_sentinel VALUES('committed-in-wal')")
        assert Path(str(source_path) + "-wal").exists()
        destination = sqlite3.connect(backup_path)
        try:
            source.backup(destination)
        finally:
            destination.close()
        with sqlite3.connect(backup_path) as copied:
            assert copied.execute("SELECT value FROM wal_sentinel").fetchone()[0] == "committed-in-wal"
            assert copied.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    finally:
        source.close()
