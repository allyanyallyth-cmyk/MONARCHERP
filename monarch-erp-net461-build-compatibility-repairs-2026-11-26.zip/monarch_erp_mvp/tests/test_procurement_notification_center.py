from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
MIGRATION = ROOT / "database/migrations/2026-11-08-procurement-notification-center.sql"
STORE = ROOT / "src/Monarch.Core/Autonomy/ProcurementNotificationCenterStore.cs"
UI = ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs"


def _database():
    c = sqlite3.connect(":memory:")
    c.executescript("""
    PRAGMA foreign_keys=ON;
    CREATE TABLE monarch_users(id TEXT PRIMARY KEY);
    CREATE TABLE monarch_branches(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
    CREATE TABLE monarch_procurement_notification_outbox(id TEXT PRIMARY KEY,company_id TEXT,branch_id TEXT,recipient_user_id TEXT,event_type TEXT,queue_id TEXT,purchase_order_id TEXT,title TEXT,body TEXT,created_utc TEXT,status TEXT,attempts INTEGER);
    CREATE TABLE monarch_procurement_decision_history(id TEXT PRIMARY KEY,company_id TEXT,branch_id TEXT,queue_id TEXT,purchase_order_id TEXT,decision TEXT,rationale_snapshot TEXT,decision_note TEXT,order_number_snapshot TEXT,supplier_id_snapshot TEXT,currency_code_snapshot TEXT,total_minor_snapshot INTEGER,decided_by TEXT,decided_utc TEXT);
    INSERT INTO monarch_users VALUES('u1');
    INSERT INTO monarch_procurement_notification_outbox VALUES('n1','co','br','u1','ApprovalRequested','q1','po1','Approval','Review','2026-11-08T00:00:00Z','Pending',0);
    INSERT INTO monarch_procurement_decision_history VALUES('d1','co','br','q1','po1','Approved','need','ok','PO-1','s1','SAR',100,'u1','2026-11-08T00:01:00Z');
    """)
    c.executescript(MIGRATION.read_text(encoding="utf-8"))
    return c


def test_read_state_is_additive_and_does_not_mutate_outbox_delivery_state():
    c = _database()
    assert {r[1] for r in c.execute("PRAGMA table_info(monarch_procurement_notification_reads)")} == {"notification_id", "user_id", "read_utc"}
    assert c.execute("SELECT status,attempts FROM monarch_procurement_notification_outbox WHERE id='n1'").fetchone() == ("Pending", 0)


def test_notification_read_state_is_unique_and_append_only_by_key():
    c = _database()
    c.execute("INSERT INTO monarch_procurement_notification_reads VALUES('n1','u1','2026-11-08T01:00:00Z')")
    c.execute("INSERT OR IGNORE INTO monarch_procurement_notification_reads VALUES('n1','u1','2026-11-08T02:00:00Z')")
    assert c.execute("SELECT COUNT(*) FROM monarch_procurement_notification_reads").fetchone()[0] == 1
    assert c.execute("SELECT read_utc FROM monarch_procurement_notification_reads").fetchone()[0] == '2026-11-08T01:00:00Z'


def test_store_scopes_inbox_and_read_mutations_to_recipient_company_and_branch():
    source = STORE.read_text(encoding="utf-8")
    assert "n.recipient_user_id=$user" in source
    assert "n.company_id=$co AND n.branch_id=$br" in source
    assert "INSERT OR IGNORE INTO monarch_procurement_notification_reads" in source
    assert "RequireTenantMember(c, tx, userId, companyId, branchId)" in source


def test_decision_timeline_requires_approval_permission_and_is_read_only():
    source = STORE.read_text(encoding="utf-8")
    assert 'RequirePermission(c, tx, userId, companyId, branchId, "commercial.purchases.approve")' in source
    assert "FROM monarch_procurement_decision_history" in source
    assert "ORDER BY decided_utc DESC" in source
    assert "UPDATE monarch_procurement_decision_history" not in source
    assert "DELETE FROM monarch_procurement_decision_history" not in source


def test_wpf_notification_center_and_timeline_are_wired_to_current_tenant():
    ui = UI.read_text(encoding="utf-8")
    assert "BuildProcurementNotificationCenterTab()" in ui
    assert "LoadProcurementNotifications()" in ui
    assert "MarkSelectedProcurementNotificationRead()" in ui
    assert "MarkAllProcurementNotificationsRead()" in ui
    assert "LoadProcurementDecisionTimeline()" in ui
    assert "_ledgerSession.CompanyId, _ledgerSession.BranchId" in ui
