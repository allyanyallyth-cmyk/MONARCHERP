from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STORE = ROOT / 'src/Monarch.Core/Commercial/CommercialStore.cs'


def test_party_reads_require_sales_permission_for_customer_queries():
    source = STORE.read_text(encoding='utf-8')
    body = source.split('public IReadOnlyList<Party> GetParties', 1)[1].split('public void AddUnit', 1)[0]
    assert 'RequireCompanyPermission(c, tx, userId, companyId, "commercial.sales.manage")' in body
    assert 'type == PartyType.Customer' in body


def test_party_reads_require_purchase_permission_for_supplier_queries():
    source = STORE.read_text(encoding='utf-8')
    body = source.split('public IReadOnlyList<Party> GetParties', 1)[1].split('public void AddUnit', 1)[0]
    assert 'RequireCompanyPermission(c, tx, userId, companyId, "commercial.purchases.manage")' in body
    assert 'type == PartyType.Supplier' in body


def test_unfiltered_party_reads_require_both_permissions_and_company_scope():
    source = STORE.read_text(encoding='utf-8')
    body = source.split('public IReadOnlyList<Party> GetParties', 1)[1].split('public void AddUnit', 1)[0]
    assert 'Unfiltered and Both-party queries' in body
    assert 'WHERE company_id=$co' in body
    assert 'cmd.Parameters.AddWithValue("$co", companyId.ToString())' in body


def test_party_read_authorization_and_query_share_transaction():
    source = STORE.read_text(encoding='utf-8')
    body = source.split('public IReadOnlyList<Party> GetParties', 1)[1].split('public void AddUnit', 1)[0]
    assert 'using var tx = c.BeginTransaction();' in body
    assert 'RequireCompanyPermission(c, tx' in body
    assert 'cmd.Transaction = tx;' in body
    assert 'tx.Commit();' in body


def test_party_read_does_not_initialize_or_migrate_schema():
    source = STORE.read_text(encoding='utf-8')
    body = source.split('public IReadOnlyList<Party> GetParties', 1)[1].split('public void AddUnit', 1)[0]
    assert 'Initialize(' not in body
    assert 'ALTER TABLE' not in body
    assert 'CREATE TABLE' not in body
