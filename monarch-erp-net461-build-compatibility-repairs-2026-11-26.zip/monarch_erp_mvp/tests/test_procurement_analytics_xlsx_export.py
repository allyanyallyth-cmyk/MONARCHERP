from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPORTER = ROOT / "src/Monarch.Core/Autonomy/ProcurementAnalyticsXlsxExporter.cs"
UI = ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs"


def test_xlsx_exporter_builds_three_report_worksheets_without_external_packages():
    source = EXPORTER.read_text(encoding="utf-8")
    for title in ("Supplier Items", "Supplier Trends", "Forecast History"):
        assert f'name=\\"{title}\\"' in source
    assert "ZipArchive" in source and "inlineStr" in source
    assert "ProcurementSupplierItemPerformance" in source
    assert "ProcurementSupplierTrend" in source
    assert "ProcurementForecastHistoryRow" in source
    assert "PackageReference" not in source


def test_xlsx_export_preserves_numeric_types_and_neutralizes_formula_execution():
    source = EXPORTER.read_text(encoding="utf-8")
    assert 'value is bool boolean' in source
    assert 'value is double' in source and 'value is decimal' in source
    assert 't=\\"inlineStr\\"' in source
    assert 'Convert.ToString(value, CultureInfo.InvariantCulture)' in source
    assert 'Escape(Convert.ToString(value, CultureInfo.InvariantCulture)' in source


def test_wpf_exports_all_reports_in_one_tenant_scoped_workbook():
    source = UI.read_text(encoding="utf-8")
    assert "ExportProcurementAnalyticsWorkbook()" in source
    block = source[source.index("private void ExportProcurementAnalyticsWorkbook()"):source.index("private TabItem BuildSupplierPayablesTab()")]
    assert 'IdentityStore.Require(_session, "reports.read")' in block
    assert "GetSupplierItemPerformance(userId, companyId, branchId, from, to)" in block
    assert "GetSupplierPerformanceTrends(userId, companyId, branchId, from, to)" in block
    assert "GetForecastHistory(userId, companyId, branchId, from, to)" in block
    assert 'DefaultExt = ".xlsx"' in block
    assert "File.WriteAllBytes(dialog.FileName, content)" in block
