from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_valuation_audit_is_written_before_commit():
    source = (ROOT / "src/Monarch.Core/Commercial/InventoryValuationStore.cs").read_text()
    audit = source.index("InventoryValuationCalculated")
    commit = source.index("tx.Commit();", audit)
    assert audit < commit
    assert "monarch_company_audit_log" in source
    assert "$actor" in source and "$co" in source and "$br" in source


def test_valuation_audit_contains_valuation_context():
    source = (ROOT / "src/Monarch.Core/Commercial/InventoryValuationStore.cs").read_text()
    for field in ("warehouse=", "item=", "method=", "quantityMilli=", "valueMinor=", "movements="):
        assert field in source


def test_valuation_audit_reuses_existing_schema_without_migration():
    source = (ROOT / "src/Monarch.Core/Commercial/InventoryValuationStore.cs").read_text()
    assert "CREATE TABLE" not in source
    assert "INSERT INTO monarch_company_audit_log" in source
