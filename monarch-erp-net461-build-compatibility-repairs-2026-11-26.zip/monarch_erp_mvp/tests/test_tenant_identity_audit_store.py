from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_identity_audit_store_records_in_company_audit_log():
    source = (ROOT / "src/Monarch.Core/Security/TenantIdentityAuditStore.cs").read_text(encoding="utf-8")
    assert "INSERT INTO monarch_company_audit_log" in source
    assert "entity_type,entity_id,details,occurred_utc" in source
    assert "transaction.Commit()" in source


def test_identity_audit_requires_users_manage_and_tenant_branch_access():
    source = (ROOT / "src/Monarch.Core/Security/TenantIdentityAuditStore.cs").read_text(encoding="utf-8")
    assert 'IdentityStore.Require(actor, "users.manage")' in source
    assert "monarch_user_company_access" in source
    assert "monarch_user_branch_access" in source
    assert "ca.is_active=1 AND ba.is_active=1 AND b.is_active=1" in source


def test_identity_audit_read_is_tenant_scoped_and_bounded():
    source = (ROOT / "src/Monarch.Core/Security/TenantIdentityAuditStore.cs").read_text(encoding="utf-8")
    assert "WHERE company_id=$company AND branch_id=$branch" in source
    assert "ORDER BY occurred_utc DESC,id DESC LIMIT $limit" in source
    assert "limit > 5000" in source
    assert "fromUtc.Value > toUtc.Value" in source


def test_identity_audit_does_not_claim_automatic_identity_store_wiring():
    report = (ROOT / "docs/IMPLEMENTATION_REPORT_2026-11-08-TENANT-IDENTITY-AUDIT.md").read_text(encoding="utf-8")
    assert "explicit audit API" in report
    assert "not automatically emitted" in report
