from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_unified_audit_reader_requires_identity_admin_permission_and_active_tenant_scope():
    source = (ROOT / "src/Monarch.Core/Security/TenantAuditLogReader.cs").read_text(encoding="utf-8")
    assert 'IdentityStore.Require(actor, "users.manage")' in source
    assert "monarch_user_company_access" in source
    assert "monarch_user_branch_access" in source
    assert "ca.is_active=1 AND ba.is_active=1 AND b.is_active=1" in source
    assert "a.company_id=$company AND a.branch_id=$branch" in source


def test_unified_audit_reader_uses_parameterized_bounded_filters_and_read_only_query():
    source = (ROOT / "src/Monarch.Core/Security/TenantAuditLogReader.cs").read_text(encoding="utf-8")
    assert "SELECT a.id" in source
    assert "ORDER BY a.occurred_utc DESC,a.id DESC LIMIT $limit" in source
    assert "limit > 5000" in source
    assert 'command.Parameters.AddWithValue("$action"' in source
    assert 'command.Parameters.AddWithValue("$entity"' in source
    assert 'command.Parameters.AddWithValue("$actor"' in source
    assert "INSERT INTO" not in source and "UPDATE " not in source and "DELETE FROM" not in source


def test_wpf_exposes_tenant_audit_viewer_only_for_identity_managers():
    source = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
    assert 'tabs.Items.Add(BuildTenantAuditLogTab())' in source
    assert 'IdentityStore.Require(_session, "users.manage")' in source
    assert 'new TenantAuditLogReader(_databasePath).Read(_session, _ledgerSession.CompanyId, _ledgerSession.BranchId' in source
    assert 'Header = "سجل التدقيق الموحد"' in source
