from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class WindowsCompatibilityTests(unittest.TestCase):
    def test_desktop_targets_legacy_framework(self):
        project = (ROOT / 'src/Monarch.Desktop/Monarch.Desktop.csproj').read_text(encoding='utf-8')
        self.assertIn('<TargetFramework>net461</TargetFramework>', project)
        self.assertIn('<UseWPF>true</UseWPF>', project)

    def test_core_targets_legacy_and_modern_frameworks(self):
        project = (ROOT / 'src/Monarch.Core/Monarch.Core.csproj').read_text(encoding='utf-8')
        self.assertIn('<TargetFrameworks>net8.0;net461</TargetFrameworks>', project)

    def test_legacy_compatibility_shims_are_conditional(self):
        shim = (ROOT / 'src/Monarch.Core/Compatibility/NetFrameworkCompat.cs').read_text(encoding='utf-8')
        self.assertIn('#if NET461', shim)
        self.assertIn('struct DateOnly', shim)
        self.assertIn('class IsExternalInit', shim)

    def test_desktop_publish_does_not_claim_self_contained(self):
        script = (ROOT / 'scripts/build-windows.ps1').read_text(encoding='utf-8')
        self.assertIn('desktop-net461', script)
        self.assertNotIn('--self-contained true', script)
        self.assertNotIn('--runtime win-x64', script)


if __name__ == '__main__':
    unittest.main()
