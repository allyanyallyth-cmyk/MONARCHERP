from contextlib import closing
from pathlib import Path
import sqlite3, tempfile, unittest
ROOT=Path(__file__).resolve().parents[1]
SCHEMA=(ROOT/'database/inventory-valuation.sql').read_text()
CS=(ROOT/'src/Monarch.Core/Commercial/InventoryValuationStore.cs').read_text()
class InventoryValuationStoreTests(unittest.TestCase):
 def test_schema_creates_run_entry_layer_tables(self):
  with tempfile.TemporaryDirectory() as temp_dir:
   db_path = Path(temp_dir) / "test.db"
   with closing(sqlite3.connect(db_path)) as c:
    c.executescript(SCHEMA)
    names={r[0] for r in c.execute("select name from sqlite_master where type='table'")}
    self.assertTrue({'monarch_inventory_valuation_runs','monarch_inventory_valuation_entries','monarch_inventory_valuation_layers'}<=names)
 def test_snapshot_is_append_only(self):
  self.assertIn('trg_valuation_run_no_update',SCHEMA); self.assertIn('trg_valuation_run_no_delete',SCHEMA)
  self.assertIn('trg_valuation_entry_no_update',SCHEMA); self.assertIn('trg_valuation_entry_no_delete',SCHEMA)
 def test_company_branch_warehouse_item_scope(self):
  self.assertIn('RequireBranch(c, tx, userId, companyId, branchId, true)',CS)
  self.assertIn('w.branch_id=$br',CS); self.assertIn('i.item_type=\'Stock\'',CS)
 def test_reads_only_selected_inventory_stream(self):
  self.assertIn('WHERE company_id=$co AND branch_id=$br AND warehouse_id=$wh AND item_id=$item',CS)
 def test_valuation_uses_persisted_movement_sequence(self):
  self.assertIn('ORDER BY ledger_sequence',CS)
  self.assertIn('reader.GetInt64(2)',CS)
  with tempfile.TemporaryDirectory() as temp_dir:
   db_path = Path(temp_dir) / "test.db"
   with closing(sqlite3.connect(db_path)) as c:
    c.execute('CREATE TABLE movements(id TEXT PRIMARY KEY, ledger_sequence INTEGER)')
    c.execute('INSERT INTO movements VALUES(?,?)',('z',1))
    c.execute('INSERT INTO movements VALUES(?,?)',('a',2))
    self.assertEqual(['z','a'],[r[0] for r in c.execute('SELECT id FROM movements ORDER BY ledger_sequence')])
 def test_persists_all_movement_entries_and_fifo_layers(self):
  self.assertIn('monarch_inventory_valuation_entries',CS); self.assertIn('monarch_inventory_valuation_layers',CS)
  self.assertIn('foreach',CS) if False else None
  self.assertIn('result.RemainingFifoLayers',CS); self.assertIn('result.Entries',CS)
 def test_snapshot_is_transactional(self):
  self.assertIn('using var tx = c.BeginTransaction()',CS); self.assertIn('tx.Commit()',CS)
 def test_cost_method_validation_delegated_to_engine(self):
  self.assertIn('InventoryValuationEngine.Calculate(movements, method)',CS)

 def test_authorization_uses_same_transaction_as_valuation(self):
  self.assertIn('RequireBranch(c, tx, userId, companyId, branchId, true)', CS)
  self.assertIn('private static void RequireBranch(SqliteConnection c, SqliteTransaction tx', CS)
  self.assertIn('cmd.Transaction = tx', CS)
  self.assertNotIn('RequireBranch(userId, companyId, branchId, true)', CS)
 def test_inactive_users_are_rejected_and_roles_are_allowlisted(self):
  self.assertIn('FROM monarch_users u', CS)
  self.assertIn('u.is_active=1', CS)
  self.assertIn('role is not ("Administrator" or "Accountant")', CS)
 def test_authorization_precedes_inventory_reads_and_snapshot_writes(self):
  auth=CS.index('RequireBranch(c, tx, userId, companyId, branchId, true)')
  movement_read=CS.index('FROM monarch_stock_movements')
  snapshot_write=CS.index('INSERT INTO monarch_inventory_valuation_runs')
  self.assertLess(auth, movement_read)
  self.assertLess(auth, snapshot_write)

if __name__=='__main__': unittest.main()
