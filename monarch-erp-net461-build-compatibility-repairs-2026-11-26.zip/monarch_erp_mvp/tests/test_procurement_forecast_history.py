from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STORE = ROOT / "src/Monarch.Core/Autonomy/ProcurementAnalyticsStore.cs"


def test_forecast_history_is_matured_tenant_branch_and_warehouse_scoped():
    source = STORE.read_text(encoding="utf-8")
    start = source.index("public IReadOnlyList<ProcurementForecastHistoryRow> GetForecastHistory")
    end = source.index("private static void RequireReportPermission", start)
    method = source[start:end]
    assert "RequireReportPermission(c, tx, userId, companyId, branchId)" in method
    assert "f.company_id=$co AND f.branch_id=$br" in method
    assert "f.window_end_utc<=$until" in method
    assert "m.warehouse_id=f.warehouse_id" in method
    assert "m.item_id=f.item_id" in method
    assert "m.occurred_utc>=f.window_start_utc AND m.occurred_utc<f.window_end_utc" in method
    assert "movement_type IN('Issue','TransferOut','PurchaseReturn')" in method
    assert "ORDER BY f.window_end_utc DESC" in method


def test_forecast_history_reports_zero_actual_as_null_percentage_and_is_read_only():
    source = STORE.read_text(encoding="utf-8")
    assert "actual == 0 ? (double?)null : (double)r.GetInt64(9) / actual" in source
    assert "ProcurementForecastHistoryRow" in source
    assert "AbsoluteErrorMilli" in source
    assert "INSERT INTO" not in source and "UPDATE " not in source and "DELETE FROM" not in source


def test_forecast_history_has_bounded_dates_and_result_count():
    source = STORE.read_text(encoding="utf-8")
    start = source.index("public IReadOnlyList<ProcurementForecastHistoryRow> GetForecastHistory")
    end = source.index("private static void RequireReportPermission", start)
    method = source[start:end]
    assert "if (toDate < fromDate)" in method
    assert "topRows > 2000" in method
    assert 'q.Parameters.AddWithValue("$limit", topRows)' in method
