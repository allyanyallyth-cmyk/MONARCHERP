from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "src/Monarch.Core/Commercial/CommercialPaymentStore.cs").read_text(encoding="utf-8")


def test_payment_type_uses_matching_granular_permission_inside_transaction():
    post = SOURCE.split("public void Post", 1)[1].split("private static void RequirePermission", 1)[0]
    assert 'payment.Type == CommercialPaymentType.CustomerReceipt ? "commercial.sales.manage" : "commercial.purchases.manage"' in post
    assert post.index("using var c = Open(); using var tx = c.BeginTransaction();") < post.index("RequirePermission(c, tx")
    assert "RequireBranch(" not in SOURCE


def test_payment_permission_checks_active_tenant_branch_and_explicit_role_grant():
    helper = SOURCE.split("private static void RequirePermission", 1)[1].split("private static void Audit", 1)[0]
    for token in ("monarch_users", "monarch_user_company_access", "monarch_user_branch_access",
                  "monarch_branches", "monarch_user_roles", "monarch_role_permissions",
                  "u.is_active=1", "co.is_active=1", "rp.permission_code=$permission"):
        assert token in helper
    assert "q.Transaction = tx" in helper


def test_payment_audit_is_written_before_commit_and_is_transaction_bound():
    post = SOURCE.split("public void Post", 1)[1].split("private static void RequirePermission", 1)[0]
    assert "Audit(c, tx, userId" in post
    assert post.index("Audit(c, tx, userId") < post.index("tx.Commit()")
    helper = SOURCE.split("private static void Audit", 1)[1].split("private SqliteConnection Open", 1)[0]
    assert "audit.Transaction = tx" in helper
    assert "INSERT INTO monarch_company_audit_log" in helper
    assert "CommercialPayment" in helper


def test_payment_audit_records_type_amount_currency_method_and_allocations():
    post = SOURCE.split("public void Post", 1)[1].split("private static void RequirePermission", 1)[0]
    for token in ("CustomerReceiptPosted", "SupplierPaymentPosted", "amountMinor=", "currency=",
                  "method=", "allocations=", "payment.PartyId"):
        assert token in post


def test_payment_type_and_method_are_validated():
    post = SOURCE.split("public void Post", 1)[1].split("private static void RequirePermission", 1)[0]
    assert "Enum.IsDefined(typeof(CommercialPaymentType), payment.Type)" in post
    assert "Enum.IsDefined(typeof(CommercialPaymentMethod), payment.Method)" in post
