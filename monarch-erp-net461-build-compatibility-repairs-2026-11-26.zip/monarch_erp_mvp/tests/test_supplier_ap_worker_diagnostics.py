import sqlite3
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MIGRATION = ROOT / 'database/migrations/2026-11-10-supplier-ap-worker-diagnostics.sql'
SOURCE = (ROOT / 'src/Monarch.Core/Commercial/SupplierPayablesAccountingOutboxWorker.cs').read_text(encoding='utf-8')

class SupplierApWorkerDiagnosticsMigrationTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        self.sql = MIGRATION.read_text(encoding='utf-8')
        self.db.executescript(self.sql)

    def tearDown(self):
        self.db.close()

    def test_migration_is_idempotent(self):
        self.db.executescript(self.sql)
        self.assertEqual(self.db.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='monarch_supplier_ap_worker_diagnostics'").fetchone()[0], 1)

    def test_diagnostic_rows_are_scoped_by_company_and_branch(self):
        rows = [
            ('a1', 'co-a', 'br-a', 'heartbeat_failed', 'batch', None, '2026-11-10T10:00:00Z', 'SqliteException'),
            ('a2', 'co-a', 'br-b', 'lease_ownership_lost', 'invoice', 'inv-1', '2026-11-10T10:01:00Z', 'ack_rejected'),
            ('b1', 'co-b', 'br-a', 'lease_ownership_lost', 'payment', 'pay-1', '2026-11-10T10:02:00Z', 'failure_update_rejected'),
        ]
        self.db.executemany('INSERT INTO monarch_supplier_ap_worker_diagnostics VALUES (?,?,?,?,?,?,?,?)', rows)
        scoped = self.db.execute('SELECT id FROM monarch_supplier_ap_worker_diagnostics WHERE company_id=? AND branch_id=? ORDER BY occurred_utc DESC', ('co-a', 'br-a')).fetchall()
        self.assertEqual(scoped, [('a1',)])

    def test_schema_rejects_unknown_event_and_entity_kinds(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute('INSERT INTO monarch_supplier_ap_worker_diagnostics VALUES (?,?,?,?,?,?,?,?)', ('x', 'co', 'br', 'raw_exception', 'batch', None, '2026-11-10T10:00:00Z', 'bad'))
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute('INSERT INTO monarch_supplier_ap_worker_diagnostics VALUES (?,?,?,?,?,?,?,?)', ('y', 'co', 'br', 'heartbeat_failed', 'journal', None, '2026-11-10T10:00:00Z', 'bad'))

    def test_schema_has_no_raw_exception_or_lease_token_storage(self):
        columns = {r[1] for r in self.db.execute('PRAGMA table_info(monarch_supplier_ap_worker_diagnostics)')}
        self.assertNotIn('exception_text', columns)
        self.assertNotIn('lease_token', columns)
        self.assertIn('detail_code', columns)

class SupplierApWorkerDiagnosticsSourceTests(unittest.TestCase):
    def test_diagnostics_are_best_effort_and_count_write_failures(self):
        self.assertIn('RecordDiagnostic(companyId, branchId, "heartbeat_failed"', SOURCE)
        self.assertIn('Interlocked.Increment(ref _diagnosticWriteFailures)', SOURCE)
        self.assertIn('DiagnosticWriteFailures', SOURCE)

    def test_read_path_authorizes_and_filters_company_branch(self):
        self.assertIn('_ledger.GetEntries(userId, companyId, branchId);', SOURCE)
        self.assertIn('WHERE company_id=$co AND branch_id=$br ORDER BY occurred_utc DESC', SOURCE)
        self.assertIn('LIMIT $limit', SOURCE)

    def test_ownership_loss_is_durably_recorded_for_both_queues(self):
        self.assertIn('"lease_ownership_lost", "invoice"', SOURCE)
        self.assertIn('"lease_ownership_lost", "payment"', SOURCE)

    def test_worker_diagnostics_do_not_store_exception_message_or_token(self):
        self.assertIn('ex.GetType().Name', SOURCE)
        self.assertNotIn('ex.Message);', SOURCE)
        self.assertIn('lease_token=$token AND lease_expires_utc>$now', SOURCE)

if __name__ == '__main__':
    unittest.main()
