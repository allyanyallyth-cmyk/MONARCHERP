import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'src/Monarch.Core/Commercial/SupplierPayablesWorkerRecoveryPolicy.cs').read_text(encoding='utf-8')

class SupplierApWorkerRecoveryPolicyTests(unittest.TestCase):
    def test_classifies_only_known_infrastructure_failures_as_transient(self):
        for code in ('sqlite_busy', 'sqlite_locked', 'sqlite_io_error', 'operation_timeout', 'io_error'):
            self.assertIn('"' + code + '"', SOURCE)
        self.assertIn('"unclassified_failure"', SOURCE)
        self.assertIn('"sqlite_nontransient"', SOURCE)

    def test_retry_guidance_is_bounded_exponential_and_not_an_executor(self):
        self.assertIn('BaseRetryDelay = TimeSpan.FromSeconds(15)', SOURCE)
        self.assertIn('MaximumRetryDelay = TimeSpan.FromMinutes(15)', SOURCE)
        self.assertIn('RecommendedDelay(int attempt)', SOURCE)
        self.assertIn('ticks > MaximumRetryDelay.Ticks / 2', SOURCE)
        self.assertIn('never exceed the cap', SOURCE)
        self.assertIn('does not retry', SOURCE)

    def test_alerts_on_permanent_failure_or_repeated_transient_failures(self):
        self.assertIn('DefaultAlertThreshold = 5', SOURCE)
        self.assertIn('var alert = !transient || consecutiveFailures >= alertThreshold', SOURCE)
        self.assertIn('RequiresInvestigation', SOURCE)

    def test_invalid_policy_inputs_are_rejected(self):
        self.assertIn('if (attempt < 1) throw new ArgumentOutOfRangeException', SOURCE)
        self.assertIn('if (consecutiveFailures < 1) throw new ArgumentOutOfRangeException', SOURCE)
        self.assertIn('if (alertThreshold < 1) throw new ArgumentOutOfRangeException', SOURCE)

if __name__ == '__main__':
    unittest.main()
