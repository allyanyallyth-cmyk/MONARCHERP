from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_scoped_create_user_overload_writes_company_audit_in_same_transaction():
    source = (ROOT / "src/Monarch.Core/Security/IdentityStore.cs").read_text(encoding="utf-8")
    method = source.split("public Guid CreateUser(", 1)[1].split("public void SetUserActive(", 1)[0]
    assert "RequireCompanyBranchAccess" in method
    assert "InsertUser(connection, transaction" in method
    assert '"UserCreated"' in method
    assert "WriteCompanyAudit(connection, transaction" in method
    assert "transaction.Commit()" in method


def test_scoped_activation_change_has_tenant_and_legacy_audit_atomically():
    source = (ROOT / "src/Monarch.Core/Security/IdentityStore.cs").read_text(encoding="utf-8")
    method = source.split("public void SetUserActive(UserSession actor, Guid userId, bool active, Guid companyId", 1)[1].split("public IReadOnlyList<UserSummary>", 1)[0]
    assert "RequireCompanyBranchAccess" in method
    assert "UPDATE monarch_users SET is_active" in method
    assert "WriteAudit(connection, transaction" in method
    assert "WriteCompanyAudit(connection, transaction" in method
    assert method.index("WriteCompanyAudit") < method.index("transaction.Commit()")


def test_tenant_audit_checks_active_company_branch_membership():
    source = (ROOT / "src/Monarch.Core/Security/IdentityStore.cs").read_text(encoding="utf-8")
    assert "monarch_user_company_access" in source
    assert "monarch_user_branch_access" in source
    assert "ca.is_active=1 AND ba.is_active=1 AND b.is_active=1" in source
