import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
UI = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
STORE = (ROOT / "src/Monarch.Core/Commercial/PurchaseOrderReceiptStore.cs").read_text(encoding="utf-8")

class PurchaseReceiptWpfTests(unittest.TestCase):
    def test_receipt_ui_uses_core_store(self):
        self.assertIn("new PurchaseOrderReceiptStore(_databasePath).Receive", UI)
        self.assertIn("ListReceiptableLines", UI)

    def test_receipt_ui_requires_purchase_permission_and_confirmation(self):
        self.assertIn('HasPermission("commercial.purchases.manage")', UI)
        self.assertIn("تأكيد الاستلام", UI)

    def test_receipt_ui_shows_remaining_quantities_and_history(self):
        self.assertIn("المتبقية", UI)
        self.assertIn("LoadPurchaseReceipts", UI)
        self.assertIn("_purchaseReceiptsGrid", UI)

    def test_receipt_line_query_is_company_branch_scoped_and_read_authorized(self):
        self.assertIn('Require(c, tx, userId, companyId, branchId, "reports.read")', STORE)
        self.assertIn("p.branch_id=$br", STORE)
        self.assertIn("l.quantity_milli-l.received_quantity_milli", STORE)

if __name__ == "__main__":
    unittest.main()

class PurchaseReceiptMultiLineUiTests(unittest.TestCase):
    def test_grid_supports_multiple_receipt_lines_with_per_line_quantity(self):
        self.assertIn('IsReadOnly = false', UI)
        self.assertIn('ReceiveNow', UI)
        self.assertIn('selectedLines.Select(x => new PurchaseOrderReceiptLineInput', UI)
        self.assertIn('inputs.Length', UI)

    def test_receipt_ui_commits_grid_edits_before_posting(self):
        self.assertIn('CommitEdit(DataGridEditingUnit.Cell, true)', UI)
        self.assertIn('CommitEdit(DataGridEditingUnit.Row, true)', UI)

    def test_core_accepts_multiple_lines_and_rejects_duplicate_line_ids(self):
        self.assertIn('draft.Lines.Count > 500', STORE)
        self.assertIn('Distinct().Count() != draft.Lines.Count', STORE)
