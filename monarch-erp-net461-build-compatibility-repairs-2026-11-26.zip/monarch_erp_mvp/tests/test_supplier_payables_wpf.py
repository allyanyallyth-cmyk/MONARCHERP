from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
UI = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")

class SupplierPayablesWpfTests(unittest.TestCase):
    def test_payables_tab_is_permission_gated_for_reading(self):
        self.assertIn('if (_session.HasPermission("reports.read")) tabs.Items.Add(BuildSupplierPayablesTab());', UI)

    def test_payment_entry_requires_manage_permission(self):
        self.assertIn('if (_session.HasPermission("commercial.purchases.manage"))', UI)
        self.assertIn('new SupplierPayablesStore(_databasePath).PostPayment', UI)

    def test_ui_uses_core_for_open_invoices_and_aging(self):
        self.assertIn('.ListOpenInvoices(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId', UI)
        self.assertIn('.GetAging(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId', UI)

    def test_ui_discloses_outbox_is_not_general_ledger_posting(self):
        self.assertIn('لا يُعد ذلك قيداً في الأستاذ العام', UI)
        self.assertIn('لم يُنشأ قيد أستاذ عام', UI)

if __name__ == "__main__":
    unittest.main()
