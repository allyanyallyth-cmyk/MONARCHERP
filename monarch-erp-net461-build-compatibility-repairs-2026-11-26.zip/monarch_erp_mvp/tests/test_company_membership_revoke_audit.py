from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_company_membership_revoke_is_atomic_and_audited():
    source = (ROOT / "src/Monarch.Core/Organizations/CompanyDirectoryStore.cs").read_text(encoding="utf-8")
    method = source.split("public void RevokeCompanyAccess(", 1)[1].split("public void GrantBranchAccess(", 1)[0]
    assert "BeginTransaction()" in method
    assert "r.code='Administrator'" in method
    assert "a.role_code='Administrator'" in method
    assert "لا يمكن سحب عضوية آخر مدير نشط في المنشأة" in method
    assert "UPDATE monarch_user_branch_access SET is_active=0" in method
    assert "UPDATE monarch_user_company_access SET is_active=0" in method
    assert "CompanyAccessRevoked" in method
    assert "INSERT INTO monarch_company_audit_log" in method
    assert "INSERT INTO monarch_audit_log" in method
    assert method.index("INSERT INTO monarch_company_audit_log") < method.index("transaction.Commit()")
    assert method.index("INSERT INTO monarch_audit_log") < method.index("transaction.Commit()")


def test_wpf_company_directory_exposes_explicit_membership_revocation():
    source = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
    assert 'Button("سحب عضوية المنشأة بالكامل")' in source
    assert "revoke.Click += RevokeDirectoryAccess_Click" in source
    assert "_directory.RevokeCompanyAccess(user.Id, company.Id, _session.UserId)" in source
    assert "MessageBoxButton.YesNo" in source
