import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
GATEWAY = ROOT / 'src/Monarch.Core/Autonomy/SqliteAutonomousProcurementDraftGateway.cs'
WORKFLOW = ROOT / 'src/Monarch.Core/Autonomy/AutonomousProcurementWorkflow.cs'


def test_sqlite_gateway_persists_order_lines_queue_and_audit_in_one_transaction():
    source = GATEWAY.read_text(encoding='utf-8')
    assert 'IProcurementDraftGateway' in source
    assert 'using var tx = c.BeginTransaction();' in source
    assert source.index('using var tx = c.BeginTransaction();') < source.index('INSERT INTO monarch_purchase_orders')
    assert source.index('INSERT INTO monarch_purchase_orders') < source.index('INSERT INTO monarch_purchase_order_lines')
    assert source.index('INSERT INTO monarch_purchase_order_lines') < source.index('INSERT INTO monarch_procurement_approval_queue')
    assert source.index('INSERT INTO monarch_procurement_approval_queue') < source.index('AutonomousPurchaseOrderDraftCreated')
    assert source.index('Audit(c, tx, request.UserId') < source.rindex('tx.Commit();')
    assert "'AutonomousPurchaseOrderDraftCreated'" in source


def test_gateway_enforces_tenant_scope_and_management_permission():
    source = GATEWAY.read_text(encoding='utf-8')
    assert 'commercial.purchases.manage' in source
    assert 'monarch_user_company_access' in source
    assert 'monarch_user_branch_access' in source
    assert 'monarch_companies' in source and 'monarch_branches' in source
    assert 'ValidateSupplierAndWarehouse' in source


def test_gateway_is_draft_only_and_does_not_expose_approval_or_gl_posting():
    source = GATEWAY.read_text(encoding='utf-8')
    assert "'Draft'" in source and "'Pending'" in source
    assert 'Approve(' not in source and 'Post(' not in source
    assert 'monarch_procurement_approval_queue' in source
    assert "'commercial.purchases.approve'" in source


def test_workflow_accepts_only_a_manager_queued_draft_result():
    source = WORKFLOW.read_text(encoding='utf-8')
    assert 'CreateDraftForPurchasingManager' in source
    assert 'result.Status != "Draft"' in source
    assert 'result.ApprovalQueueId == Guid.Empty' in source
