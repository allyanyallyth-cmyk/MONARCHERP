from pathlib import Path
import re
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
SQL = (ROOT / "database/commercial-data.sql").read_text(encoding="utf-8")
CS = (ROOT / "src/Monarch.Core/Zatca/ZatcaEgsRegistry.cs").read_text(encoding="utf-8")


def test_egs_registry_schema_has_scoped_identity_and_lifecycle():
    assert "CREATE TABLE IF NOT EXISTS monarch_zatca_egs_units" in SQL
    assert "UNIQUE(company_id,branch_id,id)" in SQL
    assert "FOREIGN KEY(company_id,branch_id,egs_unit_id)" in SQL
    assert "CREATE TABLE IF NOT EXISTS monarch_zatca_egs_lifecycle" in SQL


def test_egs_schema_executes_and_rejects_invalid_state_and_vat():
    # Execute only the additive EGS DDL against minimal referenced parent tables.
    ddl = SQL[SQL.index("CREATE TABLE IF NOT EXISTS monarch_zatca_egs_units"):]
    con = sqlite3.connect(":memory:")
    con.execute("PRAGMA foreign_keys=ON")
    con.executescript("""
      CREATE TABLE monarch_branches(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
      CREATE TABLE monarch_users(id TEXT PRIMARY KEY);
    """)
    con.executescript(ddl)
    con.execute("INSERT INTO monarch_branches VALUES('co','br')")
    con.execute("INSERT INTO monarch_users VALUES('user')")
    con.execute("INSERT INTO monarch_zatca_egs_units(id,company_id,branch_id,unit_name,vat_number,environment,lifecycle_state,created_utc,updated_utc,created_by) VALUES('id','co','br','unit','300000000000003','Simulation','Draft','now','now','user')")
    try:
        con.execute("INSERT INTO monarch_zatca_egs_units(id,company_id,branch_id,unit_name,vat_number,environment,lifecycle_state,created_utc,updated_utc,created_by) VALUES('bad','co','br','bad','123','Simulation','Unknown','now','now','user')")
        assert False, "invalid EGS record accepted"
    except sqlite3.IntegrityError:
        pass


def test_registry_enforces_tenant_scope_permissions_and_audited_transitions():
    assert "zatca.integration.manage" in CS
    assert "WHERE id=$id AND company_id=$co AND branch_id=$br" in CS
    assert "Allowed(current, target)" in CS
    assert "Audit(c, tx" in CS
    assert "KeyNotFoundException" in CS


def test_secret_material_is_external_and_never_persisted_as_plaintext():
    assert "IZatcaSecretStore" in CS
    assert "secret_reference" in CS
    assert "private_key" not in SQL.lower()
    assert "client_secret" not in SQL.lower()
    assert "otp TEXT" not in SQL.lower()


def test_lifecycle_has_terminal_revocation_and_no_implicit_reactivation():
    assert '"Revoked" => false' in CS or '"Suspended" => to == ZatcaEgsLifecycleState.Active || to == ZatcaEgsLifecycleState.Revoked' in CS
    assert 'to == ZatcaEgsLifecycleState.Revoked' in CS
    assert 'target == ZatcaEgsLifecycleState.Active' in CS


def test_egs_readiness_is_tenant_scoped_and_never_reads_secret_material():
    assert "EvaluateReadiness" in CS
    assert "ZatcaEgsReadiness" in CS
    assert "EGS lifecycle state is not Active." in CS
    assert "External secret-store reference is missing." in CS
    assert "CanSubmitInvoices" in CS
    method = CS[CS.index("public ZatcaEgsReadiness EvaluateReadiness"):CS.index("public IReadOnlyList<ZatcaEgsLifecycleEvent> History")]
    assert "company_id=$co AND branch_id=$br" in method
    assert "Retrieve(" not in method
    assert "ReadOnlyMemory" not in method
