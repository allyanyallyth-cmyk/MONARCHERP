from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "src/Monarch.Core/Commercial/CommercialAccountingOutboxWorker.cs").read_text(encoding="utf-8")

class CommercialAccountingOutboxWorkerTests(unittest.TestCase):
    def test_all_commercial_outbox_workers_pass_branch_to_chart_reads(self):
        for filename in ("CommercialAccountingOutboxWorker.cs", "CommercialPaymentAccountingOutboxWorker.cs", "CommercialReturnAccountingOutboxWorker.cs"):
            source = (ROOT / "src/Monarch.Core/Commercial" / filename).read_text(encoding="utf-8")
            self.assertIn("_ledger.GetAccounts(userId, companyId, branchId)", source)
            self.assertNotIn("_ledger.GetAccounts(userId, companyId)", source)

    def test_worker_uses_tenant_scoped_ledger_authorization(self):
        self.assertIn("_ledger.GetEntries(userId, companyId, branchId)", SOURCE)
        self.assertIn("LoadPending(companyId, branchId, maxItems)", SOURCE)

    def test_deterministic_journal_number_supports_crash_retry(self):
        self.assertIn('"AUTO-COM-" + id.ToString("N").ToUpperInvariant()', SOURCE)
        self.assertIn("existing?.Status == JournalStatus.Posted", SOURCE)
        self.assertIn("journal.Status == JournalStatus.Draft", SOURCE)

    def test_sales_and_purchase_account_mappings_are_explicitly_typed(self):
        for expected in ["ReceivablesCode, AccountType.Asset", "SalesRevenueCode, AccountType.Revenue",
                         "OutputTaxCode, AccountType.Liability", "InventoryCode, AccountType.Asset",
                         "InputTaxCode, AccountType.Asset", "GoodsReceivedNotInvoicedCode, AccountType.Liability"]:
            self.assertIn(expected, SOURCE)

    def test_purchase_stock_and_nonstock_lines_are_posted_to_different_accounts(self):
        self.assertIn("i.item_type='Stock' THEN l.net_minor", SOURCE)
        self.assertIn("i.item_type<>'Stock' THEN l.net_minor", SOURCE)
        self.assertIn("StockSubtotal", SOURCE)
        self.assertIn("NonStockSubtotal", SOURCE)


    def test_sales_posting_recognizes_cogs_from_persisted_issue_allocations(self):
        self.assertIn('CostOfGoodsSoldCode', SOURCE)
        self.assertIn('AccountType.Expense), document.StockCost', SOURCE)
        self.assertIn('AccountType.Asset), document.StockCost', SOURCE)
        self.assertIn("a.allocation_type='SalesIssue'", SOURCE)
        self.assertIn('a.branch_id=d.branch_id', SOURCE)
        self.assertIn('StockAllocationCount == 0', SOURCE)
        self.assertIn('Posted stock sale has no persisted inventory cost allocation', SOURCE)

    def test_sales_cogs_does_not_use_sales_price_as_inventory_cost(self):
        sale_block = SOURCE.split('if (item.EventType == "SalePosted")', 1)[1].split('else if (item.EventType == "PurchasePosted")', 1)[0]
        self.assertIn('document.StockCost', sale_block)
        self.assertNotIn('document.StockSubtotal)', sale_block)
        self.assertIn('CostOfGoodsSoldCode, AccountType.Expense', sale_block)
        self.assertIn('InventoryCode, AccountType.Asset', sale_block)

    def test_outbox_retries_failures_and_records_attempts(self):
        self.assertIn("status IN('Pending','Failed')", SOURCE)
        self.assertIn("attempts=attempts+1,last_error=$error", SOURCE)
        self.assertIn("status='Processed'", SOURCE)

    def test_journal_amounts_are_minor_units_and_zero_lines_are_omitted(self):
        self.assertIn("if (amount > 0) lines.Add(JournalLine.Debit", SOURCE)
        self.assertIn("if (amount > 0) lines.Add(JournalLine.Credit", SOURCE)
        self.assertIn("document.Total <= 0", SOURCE)

if __name__ == "__main__":
    unittest.main()
