from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AUT = ROOT / 'src/Monarch.Core/Autonomy'


def test_autonomous_procurement_is_draft_only_and_manager_queue_bound():
    s = (AUT / 'AutonomousProcurementWorkflow.cs').read_text(encoding='utf-8')
    assert 'CreateDraftForPurchasingManager' in s
    assert 'result.Status != "Draft"' in s
    assert 'ApprovalQueueId' in s
    assert 'no approve/post capability by design' in s
    assert 'CreateDraft' in s


def test_conversational_router_requires_user_company_branch_and_allowlisted_permissions():
    s = (AUT / 'ConversationalErpRouter.cs').read_text(encoding='utf-8')
    assert 'scope.UserId == Guid.Empty' in s
    assert 'scope.CompanyId == Guid.Empty' in s and 'scope.BranchId == Guid.Empty' in s
    assert 'reports.read' in s
    assert 'No SQL is generated from user text' in s
    assert 'Execute(ErpUserScope scope, ErpQueryRequest request)' in s


def test_versioned_carbon_and_tax_rules_are_effective_dated_and_snapshotted():
    s = (AUT / 'VersionedComplianceLedger.cs').read_text(encoding='utf-8')
    assert 'EffectiveFromUtc' in s and 'EffectiveToUtc' in s
    assert 'ResolveCarbonFactor' in s and 'ResolveTaxRule' in s
    assert 'factor.Version' in s
    assert 'versions are immutable and unique' in s


def test_zatca_worker_circuit_breaker_pauses_claims_and_alerts_without_stopping_local_ops():
    s = (ROOT / 'src/Monarch.Core/Zatca/ZatcaSubmissionWorker.cs').read_text(encoding='utf-8')
    assert '_submissionCircuit.TryEnter()' in s
    assert 'return (0, 0, 0)' in s
    assert '_submissionCircuit.RecordFailure()' in s
    assert '_submissionCircuit.RecordSuccess()' in s
    assert '_resilienceAlert?.Invoke' in s
    assert 'Local operations remain available' in s
