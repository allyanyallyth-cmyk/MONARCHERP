from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STORE = (ROOT / 'src/Monarch.Core/Commercial/InventoryMasterDataStore.cs').read_text(encoding='utf-8')
SECURITY = (ROOT / 'database/security.sql').read_text(encoding='utf-8')


def test_inventory_master_data_crud_is_soft_delete_only():
    for method in ('CreateItem(', 'UpdateItem(', 'SetItemActive(', 'CreateWarehouse(', 'UpdateWarehouse(', 'SetWarehouseActive('):
        assert method in STORE
    assert 'DELETE FROM monarch_items' not in STORE
    assert 'DELETE FROM monarch_warehouses' not in STORE
    assert 'SET is_active=$active' in STORE


def test_inventory_permissions_are_independent_and_admin_seeded():
    assert "'inventory.items.manage'" in SECURITY
    assert "'inventory.warehouses.manage'" in SECURITY
    assert "('role-admin','inventory.items.manage')" in SECURITY
    assert "('role-admin','inventory.warehouses.manage')" in SECURITY
    assert "'reports.read'" not in STORE


def test_authorization_and_mutation_share_transaction_and_tenant_scope():
    assert 'using var tx=c.BeginTransaction()' in STORE
    assert 'Require(c,tx,userId,companyId,null,"inventory.items.manage")' in STORE
    assert 'Require(c,tx,userId,companyId,warehouse.BranchId,"inventory.warehouses.manage")' in STORE
    assert 'JOIN monarch_user_company_access' in STORE
    assert 'FROM monarch_user_branch_access ba' in STORE
    assert 'JOIN monarch_role_permissions' in STORE
    assert 'AND u.is_active=1' in STORE
    assert 'Audit(c,tx' in STORE


def test_warehouse_cannot_be_disabled_with_nonzero_stock():
    assert 'monarch_stock_balances' in STORE
    assert 'quantity_milli<>0' in STORE
    assert 'لا يمكن تعطيل مستودع يحتوي على أرصدة مخزنية غير صفرية' in STORE


def test_item_and_warehouse_validation_and_unique_constraints_are_delegated_to_schema():
    assert 'ValidateItem(item)' in STORE
    assert 'warehouse.Code.Trim().Length>32' in STORE
    schema = (ROOT / 'database/commercial-data.sql').read_text(encoding='utf-8')
    assert 'UNIQUE(company_id,sku)' in schema
    assert 'UNIQUE(company_id,barcode)' in schema
    assert 'UNIQUE(company_id,code)' in schema
