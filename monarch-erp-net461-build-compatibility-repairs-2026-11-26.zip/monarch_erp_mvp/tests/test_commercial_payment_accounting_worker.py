from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]

class CommercialPaymentAccountingWorkerTests(unittest.TestCase):
    def test_worker_uses_deterministic_journal_and_retryable_outbox(self):
        src = (ROOT / 'src/Monarch.Core/Commercial/CommercialPaymentAccountingOutboxWorker.cs').read_text()
        self.assertIn('AUTO-PAY-', src)
        self.assertIn("status IN('Pending','Failed')", src)
        self.assertIn("status='Processed'", src)
        self.assertIn("status='Failed',attempts=attempts+1", src)
        self.assertIn('GetEntries(userId, companyId, branchId)', src)

    def test_customer_receipt_debits_cash_and_credits_receivables(self):
        src = (ROOT / 'src/Monarch.Core/Commercial/CommercialPaymentAccountingOutboxWorker.cs').read_text()
        self.assertIn('Debit(cashOrBank, payment.AmountMinor)', src)
        self.assertIn('Credit(Require(map.ReceivablesCode, AccountType.Asset), payment.AmountMinor)', src)

    def test_supplier_payment_debits_payables_and_credits_cash(self):
        src = (ROOT / 'src/Monarch.Core/Commercial/CommercialPaymentAccountingOutboxWorker.cs').read_text()
        self.assertIn('Debit(Require(map.PayablesCode, AccountType.Liability), payment.AmountMinor)', src)
        self.assertIn('Credit(cashOrBank, payment.AmountMinor)', src)

    def test_worker_checks_account_types_and_posted_payment(self):
        src = (ROOT / 'src/Monarch.Core/Commercial/CommercialPaymentAccountingOutboxWorker.cs').read_text()
        self.assertIn('AccountType.Asset', src)
        self.assertIn('AccountType.Liability', src)
        self.assertIn('r.GetString(6) != "Posted"', src)
        self.assertIn('DateOnly.ParseExact', src)

if __name__ == '__main__': unittest.main()
