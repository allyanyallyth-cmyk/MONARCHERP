from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UI = (ROOT / 'src/Monarch.Desktop/MainWindow.xaml.cs').read_text(encoding='utf-8')
CORE = (ROOT / 'src/Monarch.Core/Commercial/InventoryMasterDataStore.cs').read_text(encoding='utf-8')


def test_inventory_write_actions_are_permission_gated():
    assert 'HasPermission("inventory.items.manage")' in UI
    assert 'HasPermission("inventory.warehouses.manage")' in UI
    assert 'إضافة صنف' in UI and 'إضافة مستودع للفرع' in UI


def test_item_creation_uses_company_units_and_core_store():
    assert 'GetUnits(_session.UserId, _ledgerSession.CompanyId)' in UI
    assert 'units.Any(x => x.Id == unitId)' in UI
    assert 'CreateItem(_session.UserId, _ledgerSession.CompanyId' in UI
    assert 'GetUnits(Guid userId, Guid companyId)' in CORE


def test_warehouse_creation_is_bound_to_selected_branch():
    assert 'new Warehouse(Guid.NewGuid(), _ledgerSession.BranchId, code, name)' in UI
    assert 'CreateWarehouse(_session.UserId, _ledgerSession.CompanyId' in UI


def test_deactivation_uses_soft_status_apis_and_confirmation():
    assert 'SetItemActive(_session.UserId, _ledgerSession.CompanyId, id, active)' in UI
    assert 'SetWarehouseActive(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, id, active)' in UI
    assert 'MessageBoxButton.YesNo' in UI
    assert 'DELETE FROM monarch_items' not in CORE
    assert 'DELETE FROM monarch_warehouses' not in CORE


def test_core_permission_check_allows_multiple_authorized_roles():
    assert 'Convert.ToInt64(q.ExecuteScalar())<1' in CORE


def test_item_editor_preserves_existing_financial_and_inventory_attributes():
    assert 'EditSelectedInventoryItem()' in UI
    assert 'UpdateItem(_session.UserId, _ledgerSession.CompanyId, item)' in UI
    for field in ('التكلفة_الافتراضية', 'سعر_البيع', 'حد_إعادة_الطلب_بالألف', 'مجموعة_الصنف', 'السماح_بالسالب'):
        assert field in UI
    assert 'SelectedGridNullableGuid(row, "مجموعة_الصنف")' in UI


def test_warehouse_editor_is_bound_to_current_branch():
    assert 'EditSelectedInventoryWarehouse()' in UI
    assert 'UpdateWarehouse(_session.UserId, _ledgerSession.CompanyId' in UI
    assert 'new Warehouse(id, _ledgerSession.BranchId, code, name, true)' in UI


def test_both_master_data_types_can_be_reactivated_from_ui():
    assert 'تنشيط الصنف المحدد' in UI
    assert 'تنشيط المستودع المحدد' in UI
    assert 'SetSelectedItemActive(true)' in UI
    assert 'SetSelectedWarehouseActive(true)' in UI
