import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MIGRATION = ROOT / "database/migrations/2026-11-11-supplier-ap-alert-delivery.sql"
SOURCE = ROOT / "src/Monarch.Core/Commercial/SupplierPayablesAlertDeliveryPolicy.cs"


def test_delivery_policy_is_advisory_and_allowlisted():
    source = SOURCE.read_text(encoding="utf-8")
    assert '"supplier_ap_heartbeat_failures"' in source
    assert '"supplier_ap_lease_ownership_loss"' in source
    assert '"InApp"' in source
    assert "critical_immediate_escalation" in source
    assert "warning_overdue_escalation" in source
    assert "does not alter worker leases" in source
    assert "HttpClient" not in source and "SendAsync" not in source


def test_delivery_intents_are_tenant_scoped_and_idempotent():
    db = sqlite3.connect(":memory:")
    db.executescript(MIGRATION.read_text(encoding="utf-8"))
    row = ("id1", "c1", "b1", "u1", "supplier_ap_heartbeat_failures",
           "2026-11-11T00:00:00+00:00", "Critical", 2, "InApp",
           "critical_immediate_escalation", "2026-11-11T00:01:00+00:00",
           "2026-11-11T00:01:00+00:00")
    sql = "INSERT INTO monarch_supplier_ap_alert_delivery_intents VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
    db.execute(sql, row)
    db.execute(sql.replace("INSERT INTO", "INSERT OR IGNORE INTO"), ("id2",) + row[1:])
    assert db.execute("SELECT count(*) FROM monarch_supplier_ap_alert_delivery_intents").fetchone()[0] == 1
    db.execute(sql, ("id3", "c2") + row[2:])
    assert db.execute("SELECT count(*) FROM monarch_supplier_ap_alert_delivery_intents").fetchone()[0] == 2


def test_delivery_intents_reject_update_delete_and_invalid_codes():
    db = sqlite3.connect(":memory:")
    db.executescript(MIGRATION.read_text(encoding="utf-8"))
    row = ("id1", "c1", "b1", "u1", "supplier_ap_lease_ownership_loss",
           "2026-11-11T00:00:00+00:00", "Warning", 1, "InApp",
           "warning_initial_delivery", "2026-11-11T00:01:00+00:00",
           "2026-11-11T00:01:00+00:00")
    sql = "INSERT INTO monarch_supplier_ap_alert_delivery_intents VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
    db.execute(sql, row)
    import pytest
    with pytest.raises(sqlite3.IntegrityError):
        db.execute("UPDATE monarch_supplier_ap_alert_delivery_intents SET severity='Critical'")
    with pytest.raises(sqlite3.IntegrityError):
        db.execute("DELETE FROM monarch_supplier_ap_alert_delivery_intents")
    with pytest.raises(sqlite3.IntegrityError):
        db.execute(sql, ("id2", "c1", "b1", "u1", "arbitrary", *row[5:]))
