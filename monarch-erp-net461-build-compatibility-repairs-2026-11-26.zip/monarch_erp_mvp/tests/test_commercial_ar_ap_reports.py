from pathlib import Path
import re, sqlite3, unittest
ROOT=Path(__file__).resolve().parents[1]
CO='00000000-0000-0000-0000-000000000001'; BR='00000000-0000-0000-0000-000000000002'
CS=(ROOT/'src/Monarch.Core/Commercial/CommercialReceivablesPayablesReportStore.cs').read_text()
def sql_block(marker):
    m=re.search(marker+r'\s*\+?\s*@?"(.*?)";',CS,re.S)
    if not m: raise AssertionError('SQL block not found: '+marker)
    return m.group(1).replace('""','"')
class CommercialArApReportTests(unittest.TestCase):
 def setUp(self):
  self.db=sqlite3.connect(':memory:'); self.db.execute('PRAGMA foreign_keys=ON')
  for n in ('ledger-storage.sql','security.sql','tenancy.sql','commercial-data.sql'):
   self.db.executescript((ROOT/'database'/n).read_text())
  self.db.execute("INSERT INTO monarch_users(id,username,display_name,password_salt,password_hash,password_iterations,is_active,created_utc) VALUES('u1','admin','Admin',?,?,210000,1,'now')",(b'a'*16,b'b'*32))
  self.db.execute("INSERT INTO monarch_user_company_access(user_id,company_id,role_code,granted_utc) VALUES('u1',?,'Viewer','now')",(CO,))
  self.db.execute("INSERT INTO monarch_user_branch_access(user_id,company_id,branch_id) VALUES('u1',?,?)",(CO,BR))
  self.db.execute("INSERT INTO monarch_parties(id,company_id,code,party_type,legal_name,display_name,payment_terms_days,created_utc) VALUES('cust',?,'C1','Customer','Customer','Customer',15,'now')",(CO,))
  self.db.execute("INSERT INTO monarch_units(id,company_id,code,name) VALUES('unit',?,'EA','Each')",(CO,))
  self.db.execute("INSERT INTO monarch_items(id,company_id,unit_id,sku,name,item_type,created_utc) VALUES('item',?,'unit','SKU','Item','Service','now')",(CO,))
  self.db.execute("INSERT INTO monarch_warehouses(id,company_id,branch_id,code,name,created_utc) VALUES('wh',?,?,'MAIN','Main','now')",(CO,BR))
  self.db.execute("INSERT INTO monarch_commercial_documents(id,company_id,branch_id,document_type,document_number,party_id,warehouse_id,status,currency_code,currency_scale,total_minor,created_utc,created_by) VALUES('d1',?,?,'Sale','S-1','cust','wh','Posted','SAR',2,10000,'2026-09-01T10:00:00Z','u1')",(CO,BR))
  self.db.execute("INSERT INTO monarch_commercial_documents(id,company_id,branch_id,document_type,document_number,party_id,warehouse_id,status,currency_code,currency_scale,total_minor,created_utc,created_by) VALUES('d2',?,?,'Sale','S-2','cust','wh','Posted','SAR',2,20000,'2026-10-20T10:00:00Z','u1')",(CO,BR))
  self.db.execute("INSERT INTO monarch_commercial_payments(id,company_id,branch_id,payment_type,payment_number,party_id,payment_method,cash_bank_account_code,currency_code,currency_scale,amount_minor,payment_date,status,created_utc,created_by) VALUES('p1',?,?,'CustomerReceipt','R-1','cust','Cash','1000','SAR',2,4000,'2026-10-01','Posted','now','u1')",(CO,BR))
  self.db.execute("INSERT INTO monarch_commercial_payment_allocations(id,company_id,payment_id,document_id,amount_minor) VALUES('a1',?,'p1','d1',4000)",(CO,))
  self.db.execute("INSERT INTO monarch_branches(id,company_id,code,name,is_active,created_utc) VALUES('br2',?,'B2','Other branch',1,'now')",(CO,))
  self.db.execute("INSERT INTO monarch_user_branch_access(user_id,company_id,branch_id) VALUES('u1',?,'br2')",(CO,))
  self.db.execute("INSERT INTO monarch_warehouses(id,company_id,branch_id,code,name,created_utc) VALUES('wh2',?,'br2','OTHER','Other','now')",(CO,))
  self.db.execute("INSERT INTO monarch_commercial_documents(id,company_id,branch_id,document_type,document_number,party_id,warehouse_id,status,currency_code,currency_scale,total_minor,created_utc,created_by) VALUES('d3',?,'br2','Sale','S-3','cust','wh2','Posted','SAR',2,7000,'2026-10-21T10:00:00Z','u1')",(CO,))
  self.db.execute("INSERT INTO monarch_commercial_payments(id,company_id,branch_id,payment_type,payment_number,party_id,payment_method,cash_bank_account_code,currency_code,currency_scale,amount_minor,payment_date,status,created_utc,created_by) VALUES('p2',?,'br2','CustomerReceipt','R-2','cust','Cash','1000','SAR',2,5000,'2026-10-22','Posted','now','u1')",(CO,))
  self.db.execute("INSERT INTO monarch_commercial_payment_allocations(id,company_id,payment_id,document_id,amount_minor) VALUES('a2',?,'p2','d3',5000)",(CO,))
 def tearDown(self): self.db.close()
 def params(self): return {'co':CO,'br':BR,'doctype':'Sale','asof':'2026-11-07','party':None,'from':'2026-10-01','to':'2026-11-07'}
 def test_aging_uses_as_of_date_and_due_date_buckets(self):
  sql=sql_block(r'q\.CommandText\s*=')
  rows=self.db.execute(sql,self.params()).fetchall()
  self.assertEqual(len(rows),2)
  by_num={r[4]:r for r in rows}
  # d1: 100.00 less 40.00 received; due 2026-09-16, 52 days overdue.
  self.assertEqual(by_num['S-1'][11],6000); self.assertEqual(by_num['S-1'][15],6000)
  # d2 due 2026-11-04: 3 days overdue.
  self.assertEqual(by_num['S-2'][14],20000)
 def test_statement_carries_opening_balance_into_requested_period(self):
  sqls=re.findall(r'q\.CommandText\s*=\s*@"(.*?)";',CS,re.S)
  self.assertGreaterEqual(len(sqls),2)
  sql=sqls[1]
  params=self.params(); params['party']='cust'; params['from']='2026-10-01'
  rows=self.db.execute(sql,params).fetchall()
  self.assertEqual([r[1] for r in rows],['R-1','S-2'])
  self.assertEqual(rows[0][7],6000)  # 100 invoice less 40 receipt
  self.assertEqual(rows[1][7],26000)
 def test_report_store_is_read_only_and_tenant_scoped(self):
  self.assertIn('public IReadOnlyList<CommercialAgingRow> GetAging',CS)
  self.assertIn('public IReadOnlyList<CommercialStatementLine> GetStatement',CS)
  self.assertIn('RequireReportAccess(c, tx, userId, companyId, branchId)',CS)
  self.assertIn("rp.permission_code='reports.read'",CS)
  self.assertIn('monarch_users u',CS)
  self.assertIn('monarch_branches b',CS)
  self.assertIn('q.Transaction = tx',CS)
  self.assertIn('tx.Commit()',CS)
  self.assertNotIn('RequireBranch(userId, companyId, branchId)',CS)
  self.assertIn('date(pay.payment_date)<=date($asof)',CS)
  self.assertIn('ROWS UNBOUNDED PRECEDING',CS)
  self.assertIn('pay.branch_id=$br',CS)
  self.assertIn('d.branch_id=$br',CS)
if __name__=='__main__': unittest.main()
