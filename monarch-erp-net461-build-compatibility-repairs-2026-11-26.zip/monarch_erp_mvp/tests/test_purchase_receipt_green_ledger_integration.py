from pathlib import Path
import sqlite3
from contextlib import closing

ROOT = Path(__file__).resolve().parents[1]
STORE = ROOT / 'src/Monarch.Core/Commercial/PurchaseOrderReceiptStore.cs'
MIGRATION = ROOT / 'database/migrations/2026-11-07-z-purchase-receipt-green-ledger-integration.sql'
GREEN_MIGRATION = ROOT / 'database/migrations/2026-11-07-versioned-green-compliance-ledger.sql'


def test_receipt_store_records_carbon_snapshot_or_measurement_gap_in_same_transaction():
    source = STORE.read_text(encoding='utf-8')
    assert 'HasTable(c, tx, "monarch_carbon_factor_versions")' in source
    assert 'using var tx = c.BeginTransaction();' in source
    assert source.index('INSERT INTO monarch_purchase_receipts') < source.index('INSERT INTO monarch_carbon_document_snapshots')
    assert source.index('INSERT INTO monarch_carbon_document_snapshots') < source.index('tx.Commit();')
    assert source.index('INSERT INTO monarch_carbon_measurement_gaps') < source.index('tx.Commit();')
    assert "approval_state='Approved'" in source
    assert 'unit_code=$unit' in source
    assert 'effective_from_utc<=$at' in source
    assert 'effective_to_utc IS NULL OR $at<effective_to_utc' in source


def test_missing_carbon_factor_is_tracked_without_blocking_receipt():
    source = STORE.read_text(encoding='utf-8')
    assert 'CarbonMeasurementGapCreated:' in source
    assert "VALUES($id,$co,$br,'PurchaseReceipt',$receipt,'PURCHASED_GOODS'" in source
    assert 'if (factorId != null)' in source
    assert 'else\n            {\n                using var gap' in source


def test_carbon_measurement_gap_migration_is_tenant_scoped_and_non_deletable():
    with closing(sqlite3.connect(':memory:')) as c:
        c.executescript('''
        CREATE TABLE monarch_companies(id TEXT PRIMARY KEY);
        CREATE TABLE monarch_users(id TEXT PRIMARY KEY);
        CREATE TABLE monarch_branches(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        INSERT INTO monarch_companies VALUES('co');
        INSERT INTO monarch_users VALUES('user');
        INSERT INTO monarch_branches VALUES('co','br');
        ''')
        c.executescript(MIGRATION.read_text(encoding='utf-8'))
        cols = {r[1] for r in c.execute('PRAGMA table_info(monarch_carbon_measurement_gaps)')}
        assert {'company_id','branch_id','document_id','unit_code','status','resolution_reference'} <= cols
        c.execute("INSERT INTO monarch_carbon_measurement_gaps(id,company_id,branch_id,document_type,document_id,activity_code,unit_code,quantity_milli,transaction_utc,status,created_by,created_utc) VALUES('g','co','br','PurchaseReceipt','r','PURCHASED_GOODS','EA',1000,'2026-11-07T00:00:00Z','Pending','user','2026-11-07T00:00:00Z')")
        try:
            c.execute("DELETE FROM monarch_carbon_measurement_gaps WHERE id='g'")
            assert False, 'measurement evidence must not be deleted'
        except sqlite3.IntegrityError as exc:
            assert 'cannot be deleted' in str(exc)

def test_receipt_green_integration_remains_optional_until_explicit_migrations_are_applied():
    source = STORE.read_text(encoding='utf-8')
    assert 'HasTable(c, tx, "monarch_carbon_factor_versions")' in source
    assert 'HasTable(c, tx, "monarch_carbon_measurement_gaps")' in source
    assert 'HasTable(c, tx, "monarch_carbon_document_snapshots")' in source
    migration = GREEN_MIGRATION.read_text(encoding='utf-8')
    assert 'never execute automatically at startup' in migration
