from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_tenant_audit_event_store_is_append_only_hash_chained():
    source = (ROOT / "src/Monarch.Core/Autonomy/TenantAuditEventStore.cs").read_text(encoding="utf-8")
    assert "public static string Append(" in source
    assert "public static bool Verify(" in source
    assert "SHA256.Create()" in source
    assert "GetLastHashOrThrow" in source
    assert "append was blocked" in source


def test_tenant_audit_reads_require_company_and_branch_scope():
    source = (ROOT / "src/Monarch.Core/Autonomy/TenantAuditEventStore.cs").read_text(encoding="utf-8")
    assert "Read(string path, Guid companyId, Guid branchId" in source
    assert "companyId == Guid.Empty || branchId == Guid.Empty" in source
    assert "item.CompanyId != companyId || item.BranchId != branchId" in source


def test_tenant_audit_supports_bounded_time_type_and_result_filters():
    source = (ROOT / "src/Monarch.Core/Autonomy/TenantAuditEventStore.cs").read_text(encoding="utf-8")
    assert "fromUtc" in source and "toUtc" in source
    assert "eventType" in source
    assert "limit > 5000" in source
    assert "Tenant audit event chain is invalid" in source


def test_tenant_audit_is_explicitly_documented_as_foundation_not_central_service():
    report = (ROOT / "docs/IMPLEMENTATION_REPORT_2026-11-08-TENANT-AUDIT-EVENT-STORE.md").read_text(encoding="utf-8")
    assert "not yet wired" in report
    assert "not centralized" in report
