from pathlib import Path
import sqlite3, unittest
ROOT=Path(__file__).resolve().parents[1]
CO='00000000-0000-0000-0000-000000000001'; BR='00000000-0000-0000-0000-000000000002'
class CommercialPaymentTests(unittest.TestCase):
 def setUp(self):
  self.db=sqlite3.connect(':memory:'); self.db.execute('PRAGMA foreign_keys=ON')
  for n in ('ledger-storage.sql','security.sql','tenancy.sql','commercial-data.sql'):
   self.db.executescript((ROOT/'database'/n).read_text())
  self.db.execute("INSERT INTO monarch_users(id,username,display_name,password_salt,password_hash,password_iterations,is_active,created_utc) VALUES('u1','admin','Admin',?,?,210000,1,'now')",(b'a'*16,b'b'*32))
  self.db.execute("INSERT INTO monarch_user_company_access(user_id,company_id,role_code,granted_utc) VALUES('u1',?,'Administrator','now')",(CO,))
  self.db.execute("INSERT INTO monarch_user_branch_access(user_id,company_id,branch_id) VALUES('u1',?,?)",(CO,BR))
  self.db.execute("INSERT INTO monarch_parties(id,company_id,code,party_type,legal_name,display_name,created_utc) VALUES('cust',?,'C1','Customer','Customer','Customer','now')",(CO,))
  self.db.execute("INSERT INTO monarch_units(id,company_id,code,name) VALUES('unit',?,'EA','Each')",(CO,))
  self.db.execute("INSERT INTO monarch_items(id,company_id,unit_id,sku,name,item_type,created_utc) VALUES('item',?,'unit','SKU','Item','Service','now')",(CO,))
  self.db.execute("INSERT INTO monarch_warehouses(id,company_id,branch_id,code,name,created_utc) VALUES('wh',?,?,'MAIN','Main','now')",(CO,BR))
  self.db.execute("INSERT INTO monarch_commercial_documents(id,company_id,branch_id,document_type,document_number,party_id,warehouse_id,status,currency_code,currency_scale,total_minor,created_utc,created_by) VALUES('doc',?,?,'Sale','S-1','cust','wh','Posted','SAR',2,10000,'now','u1')",(CO,BR))
 def tearDown(self): self.db.close()
 def payment(self, ident='pay1', amount=6000):
  self.db.execute("INSERT INTO monarch_commercial_payments(id,company_id,branch_id,payment_type,payment_number,party_id,payment_method,cash_bank_account_code,currency_code,currency_scale,amount_minor,payment_date,status,created_utc,created_by) VALUES(?,?,?,'CustomerReceipt',?,'cust','Cash','1000','SAR',2,?,'2026-11-07','Posted','now','u1')",(ident,CO,BR,ident,amount))
 def allocation(self, ident, amount, payment_id='pay1'):
  self.db.execute("INSERT INTO monarch_commercial_payment_allocations(id,company_id,payment_id,document_id,amount_minor) VALUES(?,?,?,'doc',?)",(ident,CO,payment_id,amount))
 def test_payment_allocation_accepts_partial_amount(self):
  self.payment(); self.allocation('a1',6000)
  self.assertEqual(self.db.execute("SELECT SUM(amount_minor) FROM monarch_commercial_payment_allocations").fetchone()[0],6000)
 def test_document_cannot_be_overallocated(self):
  self.payment('p1',7000); self.allocation('a1',7000,'p1')
  self.payment('p2',4000)
  with self.assertRaises(sqlite3.IntegrityError): self.allocation('a2',4000,'p2')
 def test_payment_cannot_be_overallocated(self):
  self.payment('pay1',5000); self.allocation('a1',4000)
  with self.assertRaises(sqlite3.IntegrityError): self.allocation('a2',2000)
 def test_payment_party_and_document_direction_must_match(self):
  self.payment()
  self.db.execute("INSERT INTO monarch_parties(id,company_id,code,party_type,legal_name,display_name,created_utc) VALUES('supplier',?,'V1','Supplier','Supplier','Supplier','now')",(CO,))
  self.db.execute("INSERT INTO monarch_commercial_payments(id,company_id,branch_id,payment_type,payment_number,party_id,payment_method,cash_bank_account_code,currency_code,currency_scale,amount_minor,payment_date,status,created_utc,created_by) VALUES('bad',?,?, 'SupplierPayment','P-1','supplier','Bank','1100','SAR',2,1000,'2026-11-07','Posted','now','u1')",(CO,BR))
  with self.assertRaises(sqlite3.IntegrityError):
   self.db.execute("INSERT INTO monarch_commercial_payment_allocations(id,company_id,payment_id,document_id,amount_minor) VALUES('badalloc',?,'bad','doc',1000)",(CO,))
 def test_payment_and_allocations_are_immutable(self):
  self.payment(); self.allocation('a1',6000)
  with self.assertRaises(sqlite3.IntegrityError): self.db.execute("UPDATE monarch_commercial_payments SET amount_minor=1 WHERE id='pay1'")
  with self.assertRaises(sqlite3.IntegrityError): self.db.execute("DELETE FROM monarch_commercial_payment_allocations WHERE id='a1'")
 def test_payment_outbox_is_unique(self):
  self.payment()
  self.db.execute("INSERT INTO monarch_payment_accounting_outbox(id,company_id,branch_id,payment_id,event_type,created_utc) VALUES('ob',?,?, 'pay1','CustomerReceiptPosted','now')",(CO,BR))
  with self.assertRaises(sqlite3.IntegrityError):
   self.db.execute("INSERT INTO monarch_payment_accounting_outbox(id,company_id,branch_id,payment_id,event_type,created_utc) VALUES('ob2',?,?, 'pay1','CustomerReceiptPosted','now')",(CO,BR))
 def test_store_validates_full_allocation_and_uses_atomic_outbox(self):
  src=(ROOT/'src/Monarch.Core/Commercial/CommercialPaymentStore.cs').read_text()
  self.assertIn('public void Post(',src); self.assertIn('BeginTransaction()',src)
  self.assertIn('Payment allocations do not reconcile to the payment amount',src)
  self.assertIn('monarch_payment_accounting_outbox',src)
  self.assertIn('outstanding balance',src)
if __name__=='__main__': unittest.main()
