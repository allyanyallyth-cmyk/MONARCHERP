from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'src/Monarch.Core/Commercial/CommercialStore.cs').read_text(encoding='utf-8')


def test_party_write_uses_transaction_and_type_specific_permissions():
    body = SOURCE.split('public void AddParty', 1)[1].split('public void AddUnit', 1)[0]
    assert 'using var tx = c.BeginTransaction();' in body
    assert 'commercial.sales.manage' in body
    assert 'commercial.purchases.manage' in body
    assert 'RequireCompany(userId, companyId, true)' not in body
    assert body.index('RequireCompanyPermission(') < body.index('INSERT INTO monarch_parties')


def test_both_party_type_requires_both_sales_and_purchase_grants():
    body = SOURCE.split('public void AddParty', 1)[1].split('public void AddUnit', 1)[0]
    assert 'p.Type == PartyType.Customer || p.Type == PartyType.Both' in body
    assert 'p.Type == PartyType.Supplier || p.Type == PartyType.Both' in body


def test_party_creation_audit_is_inside_same_transaction_before_commit():
    body = SOURCE.split('public void AddParty', 1)[1].split('public void AddUnit', 1)[0]
    assert 'InsertMasterDataAudit(c, tx, userId, companyId, null' in body
    assert 'CustomerPartyCreated' in body
    assert 'SupplierPartyCreated' in body
    assert body.index('InsertMasterDataAudit(') < body.index('tx.Commit()')


def test_party_type_and_financial_terms_are_validated_before_write():
    body = SOURCE.split('public void AddParty', 1)[1].split('public void AddUnit', 1)[0]
    assert 'Enum.IsDefined(typeof(PartyType), p.Type)' in body
    assert 'p.CreditLimitMinor < 0 || p.PaymentTermsDays < 0' in body
    assert 'ArgumentNullException' in body


def test_party_audit_does_not_log_contact_or_tax_personal_fields():
    body = SOURCE.split('public void AddParty', 1)[1].split('public void AddUnit', 1)[0]
    audit_details = body.split('InsertMasterDataAudit(', 1)[1].split('tx.Commit()', 1)[0]
    assert '"type=" + p.Type + ";code=" + code' in audit_details
    for sensitive in ('TaxNumber', 'Phone', 'Email', 'Address'):
        assert sensitive not in audit_details
