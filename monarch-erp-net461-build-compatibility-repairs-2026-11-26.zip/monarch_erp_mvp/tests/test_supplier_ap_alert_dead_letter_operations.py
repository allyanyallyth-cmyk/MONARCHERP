import sqlite3
from contextlib import closing
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]
INTENTS = ROOT / "database/migrations/2026-11-11-supplier-ap-alert-delivery.sql"
DISPATCH = ROOT / "database/migrations/2026-11-11-supplier-ap-alert-dispatcher.sql"
READ_STATE = ROOT / "database/migrations/2026-11-11-supplier-ap-alert-inbox-read-state.sql"
DEAD = ROOT / "database/migrations/2026-11-11-supplier-ap-alert-dead-letter-operations.sql"
STORE = ROOT / "src/Monarch.Core/Commercial/SupplierPayablesAlertDeadLetterStore.cs"
DISPATCHER = ROOT / "src/Monarch.Core/Commercial/SupplierPayablesAlertDispatcher.cs"
WPF = ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs"


def db_with_dead_letter():
    db = sqlite3.connect(":memory:")
    db.executescript(INTENTS.read_text())
    db.executescript(DISPATCH.read_text())
    db.executescript(READ_STATE.read_text())
    db.execute("INSERT INTO monarch_supplier_ap_alert_delivery_intents VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        ("i1", "c1", "b1", "u1", "supplier_ap_heartbeat_failures", "2026-11-11T00:00:00Z",
         "Critical", 2, "InApp", "critical_immediate_escalation", "2026-11-11T00:00:00Z", "2026-11-11T00:00:00Z"))
    db.execute("UPDATE monarch_supplier_ap_alert_dispatch_state SET status='DeadLetter',attempt_count=8,last_error_code='TIMEOUT' WHERE intent_id='i1'")
    for n in range(1, 9):
        db.execute("INSERT INTO monarch_supplier_ap_alert_dispatch_attempts VALUES(?,?,?,?,?,?,?)",
                   (f"a{n}", "i1", n, "DeadLetter" if n == 8 else "RetryScheduled", "TIMEOUT", f"2026-11-11T00:0{n}:00Z", None))
    db.commit()
    db.executescript(DEAD.read_text())
    return db


def test_migration_preserves_attempt_history_and_makes_sequence_monotonic():
    with closing(db_with_dead_letter()) as db:
        assert db.execute("SELECT count(*) FROM monarch_supplier_ap_alert_dispatch_attempts WHERE intent_id='i1'").fetchone()[0] == 8
        db.execute("INSERT INTO monarch_supplier_ap_alert_dispatch_attempts VALUES('a9','i1',9,'RetryScheduled','TIMEOUT','2026-11-11T01:00:00Z',NULL)")
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("UPDATE monarch_supplier_ap_alert_dispatch_attempts SET outcome='Delivered' WHERE id='a1'")
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("DELETE FROM monarch_supplier_ap_alert_dispatch_attempts WHERE id='a1'")


def test_manual_retry_is_tenant_scoped_and_audited_without_erasing_history():
    with closing(db_with_dead_letter()) as db:
        db.execute("""UPDATE monarch_supplier_ap_alert_dispatch_state SET status='Pending',attempt_count=0,
        next_attempt_utc='2026-11-11T02:00:00Z',last_error_code=NULL,updated_utc='2026-11-11T02:00:00Z'
        WHERE intent_id='i1' AND status='DeadLetter'""")
        db.execute("""INSERT INTO monarch_supplier_ap_alert_dead_letter_actions
        VALUES('r1','i1','c1','b1','operator','ManualRetryQueued',8,'2026-11-11T02:00:00Z','MANUAL_OPERATOR_RETRY')""")
        assert db.execute("SELECT status,attempt_count FROM monarch_supplier_ap_alert_dispatch_state WHERE intent_id='i1'").fetchone() == ('Pending', 0)
        assert db.execute("SELECT count(*) FROM monarch_supplier_ap_alert_dispatch_attempts WHERE intent_id='i1'").fetchone()[0] == 8
        assert db.execute("SELECT actor_user_id,reason_code FROM monarch_supplier_ap_alert_dead_letter_actions").fetchone() == ('operator', 'MANUAL_OPERATOR_RETRY')
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("UPDATE monarch_supplier_ap_alert_dead_letter_actions SET reason_code='changed' WHERE id='r1'")
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("DELETE FROM monarch_supplier_ap_alert_dead_letter_actions WHERE id='r1'")


def test_dead_letter_store_and_wpf_enforce_operator_permission_and_tenant_scope():
    store = STORE.read_text()
    assert 'IdentityStore.Require(actor, "users.manage")' in store
    assert 'i.company_id=$company AND i.branch_id=$branch' in store
    assert "ManualRetryQueued" in store and "previous_attempt_count" in store
    assert "status='DeadLetter'" in store and "status='Pending'" in store
    wpf = WPF.read_text()
    assert 'if (_session.HasPermission("users.manage"))' in wpf
    assert 'QueueSelectedSupplierApDeadLetterRetry' in wpf
    assert 'MessageBoxResult.Yes' in wpf
    dispatcher = DISPATCHER.read_text()
    assert 'MAX(attempt_number),0)+1' in dispatcher
