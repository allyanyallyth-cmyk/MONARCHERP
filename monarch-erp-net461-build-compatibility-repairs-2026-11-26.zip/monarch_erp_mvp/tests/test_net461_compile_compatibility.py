from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CORE = ROOT / "src/Monarch.Core"


def test_net461_date_only_shim_supports_single_format_argument():
    text = (CORE / "Compatibility/NetFrameworkCompat.cs").read_text(encoding="utf-8")
    assert "public static DateOnly FromDateTime(DateTime value)" in text
    assert "public string ToString(string format)" in text
    assert "_value.ToString(format, CultureInfo.CurrentCulture)" in text
    assert "public override string ToString()" in text


def test_enum_parsing_uses_framework_compatible_non_generic_api():
    source = "\\n".join(p.read_text(encoding="utf-8") for p in CORE.rglob("*.cs"))
    assert "Enum.Parse<" not in source
    assert "Enum.Parse(typeof(" in source


def test_alert_delivery_uses_framework_compatible_zip_selector():
    text = (CORE / "Commercial/SupplierPayablesAlertDeliveryStore.cs").read_text(encoding="utf-8")
    assert "alerts.Zip(decisions, (alert, decision) => (First: alert, Second: decision))" in text
    assert "alerts.Zip(decisions)" not in text


def test_procurement_evidence_uses_explicit_row_type_for_eight_fields():
    text = (CORE / "Autonomy/ProcurementApprovalIntelligenceService.cs").read_text(encoding="utf-8")
    assert "ProcurementApprovalLineRow" in text
    assert "line.Item8" not in text
    assert "line.SelectedUnitCostMinor" in text


def test_supplier_outbox_does_not_assign_void_currency_guard_result():
    text = (CORE / "Commercial/SupplierPayablesAccountingOutboxWorker.cs").read_text(encoding="utf-8")
    assert "RequireBaseCurrency(companyId, invoice.CurrencyCode, invoice.CurrencyScale);" in text
    assert "var baseCurrency = RequireBaseCurrency" not in text
