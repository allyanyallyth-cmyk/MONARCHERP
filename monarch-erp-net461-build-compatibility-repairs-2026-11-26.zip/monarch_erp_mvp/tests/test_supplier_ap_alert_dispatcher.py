import sqlite3
from contextlib import closing
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]
INTENTS = ROOT / "database/migrations/2026-11-11-supplier-ap-alert-delivery.sql"
DISPATCH = ROOT / "database/migrations/2026-11-11-supplier-ap-alert-dispatcher.sql"
SOURCE = ROOT / "src/Monarch.Core/Commercial/SupplierPayablesAlertDispatcher.cs"


def database():
    db = sqlite3.connect(":memory:")
    db.executescript(INTENTS.read_text(encoding="utf-8"))
    db.executescript(DISPATCH.read_text(encoding="utf-8"))
    return db


def intent(db, ident="i1", company="c1", branch="b1", user="u1", occurred="2026-11-11T00:00:00.0000000+00:00"):
    db.execute("""INSERT INTO monarch_supplier_ap_alert_delivery_intents
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
    (ident, company, branch, user, "supplier_ap_heartbeat_failures", occurred,
     "Critical", 2, "InApp", "critical_immediate_escalation", occurred,
     occurred))


def test_new_intents_are_enqueued_and_existing_intents_backfilled():
    with closing(sqlite3.connect(":memory:")) as db:
        db.executescript(INTENTS.read_text(encoding="utf-8"))
        intent(db)
        db.executescript(DISPATCH.read_text(encoding="utf-8"))
        assert db.execute("SELECT status,attempt_count FROM monarch_supplier_ap_alert_dispatch_state").fetchone() == ("Pending", 0)
        intent(db, "i2", occurred="2026-11-11T00:01:00.0000000+00:00")
        assert db.execute("SELECT count(*) FROM monarch_supplier_ap_alert_dispatch_state").fetchone()[0] == 2


def test_claim_state_and_attempt_history_constraints():
    with closing(database()) as db:
        intent(db)
        state = db.execute("SELECT status,attempt_count FROM monarch_supplier_ap_alert_dispatch_state WHERE intent_id='i1'").fetchone()
        assert state == ("Pending", 0)
        db.execute("""UPDATE monarch_supplier_ap_alert_dispatch_state SET status='Claimed',lease_token='t',
        lease_expires_utc='2026-11-11T00:01:00.0000000+00:00' WHERE intent_id='i1'""")
        db.execute("""INSERT INTO monarch_supplier_ap_alert_dispatch_attempts
        VALUES('a1','i1',1,'RetryScheduled','timeout','2026-11-11T00:00:30+00:00','2026-11-11T00:01:00+00:00')""")
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("UPDATE monarch_supplier_ap_alert_dispatch_attempts SET outcome='Delivered' WHERE id='a1'")
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("DELETE FROM monarch_supplier_ap_alert_dispatch_attempts WHERE id='a1'")

def test_dispatch_is_tenant_scoped_and_has_bounded_attempts():
    with closing(database()) as db:
        intent(db, "i1", "c1", "b1", "u1"); intent(db, "i2", "c1", "b1", "u2"); intent(db, "i3", "c2", "b1", "u1")
        rows = db.execute("""SELECT i.id FROM monarch_supplier_ap_alert_dispatch_state s
    JOIN monarch_supplier_ap_alert_delivery_intents i ON i.id=s.intent_id
        WHERE i.company_id='c1' AND i.branch_id='b1' AND i.recipient_user_id='u1' AND s.status='Pending'""").fetchall()
        assert rows == [("i1",)]
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("UPDATE monarch_supplier_ap_alert_dispatch_state SET attempt_count=9 WHERE intent_id='i1'")


def test_csharp_dispatcher_uses_lease_fencing_backoff_and_no_external_transport():
    source = SOURCE.read_text(encoding="utf-8")
    for token in ("ClaimDue", "CompleteAttempt", "lease_token", "lease_expires_utc", "LeaseNotOwned",
                  "DeadLetter", "RetryScheduled", "MaxAttempts = 8", "Math.Min(900", "_ledger.GetEntries",
                  "i.recipient_user_id=$user", 'read.Parameters.AddWithValue("$user", userId.ToString())'):
        assert token in source
    assert source.count("i.recipient_user_id=$user") == 4  # scoped SELECT and guarded UPDATE in both methods
    assert "HttpClient" not in source and "SendAsync" not in source
