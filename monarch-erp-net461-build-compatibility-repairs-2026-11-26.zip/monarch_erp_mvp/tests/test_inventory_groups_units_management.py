from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STORE = (ROOT / 'src/Monarch.Core/Commercial/InventoryMasterDataStore.cs').read_text(encoding='utf-8')
MODELS = (ROOT / 'src/Monarch.Core/Commercial/CommercialModels.cs').read_text(encoding='utf-8')
SCHEMA = (ROOT / 'database/commercial-data.sql').read_text(encoding='utf-8')


def test_item_group_management_has_scoped_crud_and_soft_deactivation():
    for method in ('GetItemGroups(', 'CreateItemGroup(', 'UpdateItemGroup(', 'SetItemGroupActive('):
        assert method in STORE
    assert 'UPDATE monarch_item_groups SET is_active=$active' in STORE
    assert 'DELETE FROM monarch_item_groups' not in STORE
    assert 'ItemGroupCreated' in STORE and 'ItemGroupUpdated' in STORE
    assert 'ItemGroupActivated' in STORE and 'ItemGroupDeactivated' in STORE


def test_group_parent_is_validated_and_cycles_are_rejected():
    assert 'ValidateGroupParent(c, tx, companyId, group.ParentId, null)' in STORE
    assert 'ValidateGroupParent(c, tx, companyId, group.ParentId, group.Id)' in STORE
    assert 'WITH RECURSIVE descendants' in STORE
    assert 'لا يمكن نقل المجموعة إلى أحد فروعها التابعة' in STORE
    assert 'FOREIGN KEY(company_id,parent_id) REFERENCES monarch_item_groups(company_id,id)' in SCHEMA


def test_group_deactivation_preserves_referenced_active_items_and_children():
    assert 'SELECT COUNT(*) FROM monarch_items WHERE company_id=$co AND group_id=$id AND is_active=1' in STORE
    assert 'SELECT COUNT(*) FROM monarch_item_groups WHERE company_id=$co AND parent_id=$id AND is_active=1' in STORE
    assert 'لا يمكن تعطيل مجموعة مرتبطة بأصناف نشطة أو مجموعات فرعية نشطة' in STORE


def test_unit_management_validates_precision_and_preserves_historical_quantity_semantics():
    assert 'CreateUnit(' in STORE and 'UpdateUnit(' in STORE
    assert 'u.DecimalPlaces < 0 || u.DecimalPlaces > 6' in STORE
    assert 'لا يمكن تغيير دقة وحدة قياس مستخدمة في أصناف' in STORE
    assert 'UnitCreated' in STORE and 'UnitUpdated' in STORE
    assert 'public sealed record ItemGroup(' in MODELS
    assert 'public sealed record UnitOfMeasure(' in MODELS


def test_all_new_writes_are_permission_checked_audited_and_transactional():
    for method in ('CreateItemGroup(', 'UpdateItemGroup(', 'SetItemGroupActive(', 'CreateUnit(', 'UpdateUnit('):
        start = STORE.index(method)
        end = STORE.find('\n    public ', start + 10)
        body = STORE[start:end if end >= 0 else len(STORE)]
        assert 'BeginTransaction()' in body
        assert 'inventory.items.manage' in body
        assert 'Audit(c, tx' in body
