"""Test-wide SQLite resource guard.

sqlite3.Connection's context manager commits/rolls back but does not close the
connection. Track connections created by tests and close any remaining handles
at the end of each test, including when an assertion raises. Tests that need a
connection beyond one test must manage it explicitly in their own fixture.
"""
from __future__ import annotations

import sqlite3
import pytest


@pytest.fixture(autouse=True)
def close_unreleased_sqlite_connections(monkeypatch):
    original_connect = sqlite3.connect
    opened: list[sqlite3.Connection] = []

    def tracked_connect(*args, **kwargs):
        connection = original_connect(*args, **kwargs)
        opened.append(connection)
        return connection

    monkeypatch.setattr(sqlite3, "connect", tracked_connect)
    try:
        yield
    finally:
        for connection in reversed(opened):
            try:
                connection.close()
            except sqlite3.Error:
                # A test may already have explicitly closed its connection.
                pass
