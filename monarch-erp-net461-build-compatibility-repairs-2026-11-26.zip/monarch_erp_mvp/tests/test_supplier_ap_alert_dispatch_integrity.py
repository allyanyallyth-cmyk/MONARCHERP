import sqlite3
from contextlib import closing
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
MIGRATIONS = ROOT / "database/migrations"
INTENTS = MIGRATIONS / "2026-11-11-supplier-ap-alert-delivery.sql"
DISPATCH = MIGRATIONS / "2026-11-11-supplier-ap-alert-dispatcher.sql"
READ = MIGRATIONS / "2026-11-11-supplier-ap-alert-inbox-read-state.sql"
DEAD = MIGRATIONS / "2026-11-11-supplier-ap-alert-dead-letter-operations.sql"
INTEGRITY = MIGRATIONS / "2026-11-12-supplier-ap-alert-dispatch-integrity.sql"
SOURCE = ROOT / "src/Monarch.Core/Commercial/SupplierPayablesAlertDispatcher.cs"


def db_ready():
    db = sqlite3.connect(":memory:")
    for migration in (INTENTS, DISPATCH, READ, DEAD, INTEGRITY):
        db.executescript(migration.read_text(encoding="utf-8"))
    db.execute("INSERT INTO monarch_supplier_ap_alert_delivery_intents VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        ("i1", "c1", "b1", "u1", "supplier_ap_heartbeat_failures", "2026-11-12T00:00:00Z",
         "Critical", 2, "InApp", "critical_immediate_escalation", "2026-11-12T00:00:00Z", "2026-11-12T00:00:00Z"))
    db.commit()
    return db


def test_unique_attempt_sequence_prevents_duplicate_history_numbers():
    with closing(db_ready()) as db:
        db.execute("INSERT INTO monarch_supplier_ap_alert_dispatch_attempts VALUES('a1','i1',1,'RetryScheduled','TIMEOUT','2026-11-12T00:00:00Z',NULL)")
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("INSERT INTO monarch_supplier_ap_alert_dispatch_attempts VALUES('a2','i1',1,'RetryScheduled','TIMEOUT','2026-11-12T00:00:01Z',NULL)")


def test_two_manual_retry_cycles_preserve_history_and_advance_sequence():
    with closing(db_ready()) as db:
        for cycle in range(2):
            # Model the same guarded DeadLetter -> Pending transition used by the store.
            db.execute("UPDATE monarch_supplier_ap_alert_dispatch_state SET status='DeadLetter',attempt_count=8 WHERE intent_id='i1'")
            changed = db.execute("UPDATE monarch_supplier_ap_alert_dispatch_state SET status='Pending',attempt_count=0,next_attempt_utc='2026-11-12T00:00:00Z',last_error_code=NULL WHERE intent_id='i1' AND status='DeadLetter'").rowcount
            assert changed == 1
            db.execute("INSERT INTO monarch_supplier_ap_alert_dead_letter_actions VALUES(?,?,?,?,?,?,?,?,?)",
                (f'r{cycle+1}', 'i1', 'c1', 'b1', 'operator', 'ManualRetryQueued', 8, f'2026-11-12T00:0{cycle}:00Z', 'MANUAL_OPERATOR_RETRY'))
            first = db.execute("SELECT COALESCE(MAX(attempt_number),0)+1 FROM monarch_supplier_ap_alert_dispatch_attempts WHERE intent_id='i1'").fetchone()[0]
            for offset in range(8):
                n = first + offset
                db.execute("INSERT INTO monarch_supplier_ap_alert_dispatch_attempts VALUES(?,?,?,?,?,?,?)",
                    (f'a{n}', 'i1', n, 'DeadLetter' if offset == 7 else 'RetryScheduled', 'TIMEOUT', f'2026-11-12T00:{cycle}{offset:02}:00Z', None))
        numbers = [r[0] for r in db.execute("SELECT attempt_number FROM monarch_supplier_ap_alert_dispatch_attempts WHERE intent_id='i1' ORDER BY attempt_number")]
        assert numbers == list(range(1, 17))
        assert db.execute("SELECT COUNT(*) FROM monarch_supplier_ap_alert_dead_letter_actions WHERE intent_id='i1'").fetchone()[0] == 2


def test_expired_lease_recovery_and_stale_token_fencing_are_explicit():
    source = SOURCE.read_text(encoding="utf-8")
    assert "s.status='Claimed' AND s.lease_expires_utc<=$now" in source
    assert "lease_expires_utc>$now" in source
    assert "i.company_id=$company AND i.branch_id=$branch AND i.recipient_user_id=$user" in source
    assert "WHERE intent_id=$id AND status='Claimed' AND lease_token=$token AND lease_expires_utc>$now" in source
    assert source.count("i.company_id=$company AND i.branch_id=$branch AND i.recipient_user_id=$user") >= 2


def test_integrity_migration_is_additive_and_documents_duplicate_preflight():
    sql = INTEGRITY.read_text(encoding="utf-8")
    assert "CREATE UNIQUE INDEX IF NOT EXISTS ux_supplier_ap_alert_attempt_sequence" in sql
    assert "rather than silently deleting or renumbering history" in sql
    assert "DROP TABLE" not in sql and "DELETE FROM" not in sql
