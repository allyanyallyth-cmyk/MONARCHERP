import importlib.util, sqlite3, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('migration',ROOT/'tools/migrate_legacy_ledger.py')
M=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(M)
COMPANY='00000000-0000-0000-0000-000000000001'
BRANCH='00000000-0000-0000-0000-000000000002'
A1='10000000-0000-0000-0000-000000000001'
A2='10000000-0000-0000-0000-000000000002'
J1='20000000-0000-0000-0000-000000000001'
J2='20000000-0000-0000-0000-000000000002'

class LegacyTenantMigrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.db=Path(self.tmp.name)/'test.sqlite'
        c=sqlite3.connect(self.db); c.execute('PRAGMA foreign_keys=ON')
        for name in ('ledger-storage.sql','security.sql','tenancy.sql','tenant-accounting.sql'):
            c.executescript((ROOT/'database'/name).read_text(encoding='utf-8'))
        c.execute("INSERT INTO monarch_accounts VALUES('10000000-0000-0000-0000-000000000001','1000','Cash','Asset',1)")
        c.execute("INSERT INTO monarch_accounts VALUES('10000000-0000-0000-0000-000000000002','3000','Capital','Equity',1)")
        c.execute("INSERT INTO monarch_journals(id,number,business_date,description,status,created_utc) VALUES('20000000-0000-0000-0000-000000000001','JV-1','2026-01-01','Opening','Draft','2026-01-01T00:00:00Z')")
        c.executemany("INSERT INTO monarch_journal_lines(journal_id,account_id,debit_minor,credit_minor) VALUES('20000000-0000-0000-0000-000000000001',?,?,?)",[('10000000-0000-0000-0000-000000000001',10000,0),('10000000-0000-0000-0000-000000000002',0,10000)])
        c.execute("UPDATE monarch_journals SET status='Posted' WHERE id='20000000-0000-0000-0000-000000000001'")
        c.execute("INSERT INTO monarch_journals(id,number,business_date,description,status,reversal_of_id,created_utc) VALUES('20000000-0000-0000-0000-000000000002','JV-2','2026-01-02','Reverse','Draft','20000000-0000-0000-0000-000000000001','2026-01-02T00:00:00Z')")
        c.executemany("INSERT INTO monarch_journal_lines(journal_id,account_id,debit_minor,credit_minor) VALUES('20000000-0000-0000-0000-000000000002',?,?,?)",[('10000000-0000-0000-0000-000000000001',0,10000),('10000000-0000-0000-0000-000000000002',10000,0)])
        c.execute("UPDATE monarch_journals SET status='Posted' WHERE id='20000000-0000-0000-0000-000000000002'")
        c.execute("UPDATE monarch_journals SET status='Reversed' WHERE id='20000000-0000-0000-0000-000000000001'")
        c.commit(); c.close()
    def tearDown(self): self.tmp.cleanup()
    def args(self,**kw):
        class A: pass
        a=A(); a.database=str(self.db); a.company_id=COMPANY; a.branch_id=BRANCH; a.dry_run=True; a.backup=None; a.backup_passphrase=None; a.report=None
        for k,v in kw.items(): setattr(a,k,v)
        return a
    def test_dry_run_validates_without_writing(self):
        r=M.run(self.args()); self.assertEqual(r['counts'],{'accounts':2,'journals':2,'lines':4})
        c=sqlite3.connect(self.db); self.assertEqual(c.execute('SELECT COUNT(*) FROM monarch_tenant_accounts').fetchone()[0],0); c.close()
    def test_import_preserves_ids_and_reversal_state(self):
        a=self.args(dry_run=False,backup_passphrase='correct-horse-battery',backup=str(self.db)+'.bak')
        r=M.run(a); self.assertTrue(r['verification']['per_account_posted_balances_match'])
        c=sqlite3.connect(self.db); self.assertEqual(c.execute("SELECT status FROM monarch_tenant_journals WHERE id='20000000-0000-0000-0000-000000000001'").fetchone()[0],'Reversed'); self.assertEqual(c.execute("SELECT status FROM monarch_tenant_journals WHERE id='20000000-0000-0000-0000-000000000002'").fetchone()[0],'Posted'); self.assertEqual(c.execute('SELECT COUNT(*) FROM monarch_tenant_journal_lines').fetchone()[0],4); self.assertTrue(Path(str(self.db)+'.bak').exists()); c.close()
    def test_duplicate_import_is_refused_and_does_not_duplicate(self):
        a=self.args(dry_run=False,backup_passphrase='correct-horse-battery' ,backup=str(self.db)+'.bak'); M.run(a)
        with self.assertRaisesRegex(RuntimeError,'already completed'): M.run(a)
    def test_existing_backup_is_never_overwritten(self):
        backup=Path(str(self.db)+'.bak'); backup.write_bytes(b'keep-me')
        with self.assertRaisesRegex(RuntimeError,'refusing overwrite'):
            M.run(self.args(dry_run=False,backup_passphrase='correct-horse-battery' ,backup=str(backup)))
        self.assertEqual(backup.read_bytes(),b'keep-me')
        c=sqlite3.connect(self.db); self.assertEqual(c.execute('SELECT COUNT(*) FROM monarch_tenant_accounts').fetchone()[0],0); c.close()
    def test_bad_balance_fails_before_any_import(self):
        c=sqlite3.connect(self.db); c.execute("DROP TRIGGER monarch_lines_update_draft_only"); c.execute("UPDATE monarch_journal_lines SET debit_minor=9999 WHERE journal_id='20000000-0000-0000-0000-000000000001' AND account_id='10000000-0000-0000-0000-000000000001'"); c.commit(); c.close()
        with self.assertRaisesRegex(RuntimeError,'Dry-run validation failed'): M.run(self.args(dry_run=False,backup_passphrase='correct-horse-battery' ))
        c=sqlite3.connect(self.db); self.assertEqual(c.execute('SELECT COUNT(*) FROM monarch_tenant_accounts').fetchone()[0],0); c.close()
    def test_global_primary_key_collision_is_rejected_before_import(self):
        c=sqlite3.connect(self.db); c.execute("INSERT INTO monarch_companies(id,code,legal_name,display_name,country_code,base_currency_code,time_zone_id,is_active,created_utc) VALUES('other-company','OTHER','Other','Other','SA','SAR','Asia/Riyadh',1,'now')"); c.execute("INSERT INTO monarch_tenant_accounts(id,company_id,code,name,account_type,is_active,created_utc) VALUES('10000000-0000-0000-0000-000000000001','other-company','1000','Cash','Asset',1,'now')"); c.commit(); c.close()
        with self.assertRaisesRegex(RuntimeError,'collides with an existing tenant account'): M.run(self.args())
    def test_currency_mismatch_is_refused(self):
        c=sqlite3.connect(self.db); c.execute("UPDATE monarch_companies SET base_currency_code='USD' WHERE id=?",(COMPANY,)); c.execute("INSERT OR IGNORE INTO monarch_currencies VALUES('USD','US Dollar',2,1)"); c.commit(); c.close()
        with self.assertRaisesRegex(RuntimeError,'Currency mismatch'): M.run(self.args())
    def test_transaction_rolls_back_all_tenant_rows_on_import_failure(self):
        c=sqlite3.connect(self.db); c.execute("CREATE TRIGGER force_import_failure BEFORE INSERT ON monarch_tenant_journals BEGIN SELECT RAISE(ABORT,'forced test failure'); END"); c.commit(); c.close()
        with self.assertRaisesRegex(sqlite3.IntegrityError,'forced test failure'):
            M.run(self.args(dry_run=False,backup_passphrase='correct-horse-battery' ,backup=str(self.db)+'.bak'))
        c=sqlite3.connect(self.db); self.assertEqual(c.execute('SELECT COUNT(*) FROM monarch_tenant_accounts').fetchone()[0],0); self.assertEqual(c.execute('SELECT COUNT(*) FROM monarch_tenant_journals').fetchone()[0],0); self.assertEqual(c.execute("SELECT COUNT(*) FROM sqlite_master WHERE name='monarch_migration_history'").fetchone()[0],0); c.close()
    def test_reversed_source_without_inverse_fails_validation(self):
        c=sqlite3.connect(self.db); c.execute("DROP TRIGGER monarch_journals_immutable_delete"); c.execute("DROP TRIGGER monarch_lines_delete_draft_only"); c.execute("DELETE FROM monarch_journal_lines WHERE journal_id='20000000-0000-0000-0000-000000000002'"); c.execute("DELETE FROM monarch_journals WHERE id='20000000-0000-0000-0000-000000000002'"); c.commit(); c.close()
        with self.assertRaisesRegex(RuntimeError,'no posted inverse'): M.run(self.args())
    def test_non_guid_legacy_primary_key_is_rejected(self):
        c=sqlite3.connect(self.db); c.execute("INSERT INTO monarch_accounts VALUES('legacy-text-id','9999','Legacy','Asset',1)"); c.commit(); c.close()
        with self.assertRaisesRegex(RuntimeError,'ID is not a GUID'): M.run(self.args())
    def test_wrong_branch_is_refused(self):
        with self.assertRaisesRegex(RuntimeError,'branch'): M.run(self.args(branch_id='not-a-branch'))

if __name__=='__main__': unittest.main()
