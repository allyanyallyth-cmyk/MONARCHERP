from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src/Monarch.Core/Autonomy/ProcurementSupplierIntelligenceAdvisor.cs"


def test_advisor_uses_supplier_store_and_returns_ranked_evidence():
    text = SOURCE.read_text(encoding="utf-8")
    assert "_store.GetItemOptions(userId, companyId, branchId, itemId, asOfDate)" in text
    assert "OrderByDescending(x => x.Score)" in text
    assert "CompletedReceipts" in text and "OnTimeDeliveryRate" in text


def test_advisor_does_not_compare_prices_across_currencies():
    text = SOURCE.read_text(encoding="utf-8")
    assert "CurrencyNotComparableAcrossSuppliers" in text
    assert "ComparableWithinCurrency" in text
    assert "GroupBy(x => x.CurrencyCode + \":\" + x.CurrencyScale)" in text


def test_missing_history_is_neutral_and_risks_are_explicit():
    text = SOURCE.read_text(encoding="utf-8")
    assert "NoVerifiedDeliveryHistory" in text
    assert "reliabilityScore = row.OnTimeDeliveryRate.HasValue" in text
    assert '"High"' in text and '"Moderate"' in text
    assert "Approve(" not in text and "CreateDraft(" not in text
