from pathlib import Path
import sqlite3
import unittest

ROOT = Path(__file__).resolve().parents[1]
ZATCA = ROOT / 'src/Monarch.Core/Zatca'
QR = (ZATCA / 'ZatcaQrCodeEncoder.cs').read_text(encoding='utf-8')
UBL = (ZATCA / 'ZatcaUblInvoiceGenerator.cs').read_text(encoding='utf-8')
HASH = (ZATCA / 'ZatcaInvoiceHashService.cs').read_text(encoding='utf-8')
BUILDER = (ZATCA / 'ZatcaInvoiceBuilder.cs').read_text(encoding='utf-8')
CHAIN = (ZATCA / 'ZatcaInvoiceChainStore.cs').read_text(encoding='utf-8')
API = (ZATCA / 'ZatcaApiClient.cs').read_text(encoding='utf-8')
WORKER = (ZATCA / 'ZatcaSubmissionWorker.cs').read_text(encoding='utf-8')


class ZatcaPhase2FoundationTests(unittest.TestCase):
    def test_tlv_encoder_has_required_fields_and_phase_two_tags(self):
        for tag in ('WriteText(stream, 1', 'WriteText(stream, 2', 'WriteText(stream, 3', 'WriteText(stream, 4', 'WriteText(stream, 5'):
            self.assertIn(tag, QR)
        for tag in ('WriteBinary(stream, 6', 'WriteBinary(stream, 7', 'WriteBinary(stream, 8', 'WriteBinary(stream, 9'):
            self.assertIn(tag, QR)
        self.assertIn('encoded.Length > 700', QR)
        self.assertIn('Encoding.UTF8.GetBytes', QR)

    def test_qr_uses_iso_timestamp_and_saudi_vat_validation(self):
        self.assertIn("yyyy-MM-dd'T'HH:mm:ss'Z'", QR)
        self.assertIn("vat.Length != 15", QR)
        self.assertIn("vat[0] != '3'", QR)
        self.assertIn("vat[14] != '3'", QR)

    def test_ubl_generator_emits_ubl21_and_zatca_references(self):
        for token in ('UBLVersionID', '2.1', 'CustomizationID', 'ProfileID', 'InvoiceTypeCode', 'UUID', 'AdditionalDocumentReference', 'ICV', 'PIH', 'QR', 'TaxTotal', 'TaxSubtotal', 'LegalMonetaryTotal', 'InvoiceLine'):
            self.assertIn(token, UBL)
        self.assertIn('urn:oasis:names:specification:ubl:schema:xsd:Invoice-2', UBL)
        self.assertIn('standard-rated supplies must use 15% VAT', UBL)
        self.assertIn('CurrencyCode != "SAR"', UBL)

    def test_hash_excludes_zatca_excluded_nodes_and_uses_sha256(self):
        self.assertIn('//ext:UBLExtensions', HASH)
        self.assertIn('//cac:Signature', HASH)
        self.assertIn("cbc:ID='QR'", HASH)
        self.assertIn('XmlDsigC14NTransform', HASH)
        self.assertIn('SHA256.Create()', HASH)

    def test_simplified_reporting_requires_real_stamp_and_full_xades_signer(self):
        self.assertIn('IZatcaCryptographicStampProvider', BUILDER)
        self.assertIn('IZatcaInvoiceXmlSigner', BUILDER)
        self.assertIn('complete XAdES XML signer', BUILDER)
        self.assertIn('ApplyCryptographicStamp', BUILDER)

    def test_chain_store_enforces_tenant_chain_and_digest_integrity(self):
        self.assertIn('GetLatestHash', CHAIN)
        self.assertIn('GetNextSequence', CHAIN)
        self.assertIn('zatca.integration.manage', CHAIN)
        self.assertIn('InvoiceCounterValue != sequence', CHAIN)
        self.assertIn('built.PreviousInvoiceHashBase64', CHAIN)
        self.assertIn('ComputeHashBase64(built.Xml)', CHAIN)
        self.assertIn('zatca.integration.manage', CHAIN)
        self.assertIn('ZatcaInvoicePrepared', CHAIN)
        self.assertIn('ListPending', CHAIN)
        self.assertIn('ClaimPending', CHAIN)
        self.assertIn('GetClearedDocument', CHAIN)
        self.assertIn("submission_status='Processing'", CHAIN)

    def test_api_client_has_separate_clearance_and_reporting_routes(self):
        self.assertIn('invoices/clearance/single', API)
        self.assertIn('invoices/reporting/single', API)
        self.assertIn('Clearance-Status', API)
        self.assertIn('connect/token', API)
        self.assertIn('AuthenticationHeaderValue("Basic"', API)
        self.assertIn('AuthenticationHeaderValue("Bearer"', API)

    def test_worker_persists_cleared_xml_and_rejection_or_retry_states(self):
        self.assertIn('CompleteSubmission', WORKER)
        self.assertIn('result.ClearedInvoiceXml', WORKER)
        self.assertIn('result.Status', WORKER)
        self.assertIn('CancellationToken', WORKER)

    def test_zatca_schema_is_append_only_and_tenant_scoped(self):
        schema = (ROOT / 'database/commercial-data.sql').read_text(encoding='utf-8')
        self.assertIn('monarch_zatca_invoice_chain', schema)
        self.assertIn('monarch_zatca_submission_outbox', schema)
        self.assertIn('UNIQUE(company_id,branch_id,egs_unit_id,chain_sequence)', schema)
        self.assertIn('UNIQUE(company_id,uuid)', schema)
        self.assertIn('trg_monarch_zatca_chain_no_delete', schema)
        self.assertIn('trg_monarch_zatca_chain_identity_immutable', schema)

    def test_zatca_permissions_are_explicitly_granted(self):
        security = (ROOT / 'database/security.sql').read_text(encoding='utf-8')
        self.assertIn("'zatca.integration.manage'", security)
        self.assertIn("'commercial.sales.manage'", security)
        self.assertIn("('role-admin','zatca.integration.manage')", security)

    def test_commercial_schema_executes_with_zatca_tables_and_foreign_keys(self):
        db = sqlite3.connect(':memory:')
        db.execute('PRAGMA foreign_keys=ON')
        for name in ('security.sql', 'ledger-storage.sql', 'tenancy.sql', 'commercial-data.sql'):
            db.executescript((ROOT / 'database' / name).read_text(encoding='utf-8'))
        names = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertIn('monarch_zatca_invoice_chain', names)
        self.assertIn('monarch_zatca_submission_outbox', names)
        fk_errors = list(db.execute('PRAGMA foreign_key_check'))
        self.assertEqual([], fk_errors)
        db.close()

    def test_legacy_modules_and_accounting_paths_remain_in_project(self):
        for path in ('src/Monarch.Core/Accounting/TenantAccountingSession.cs',
                     'src/Monarch.Core/Accounting/TenantLedgerStore.cs',
                     'src/Monarch.Core/Commercial/SupplierPayablesAccountingOutboxWorker.cs',
                     'src/Monarch.Desktop/MainWindow.xaml.cs'):
            self.assertTrue((ROOT / path).exists(), path)


if __name__ == '__main__':
    unittest.main()

class ZatcaOperationsDashboardTests(unittest.TestCase):
    def test_dashboard_is_tenant_scoped_and_read_authorized(self):
        store = (ROOT / 'src/Monarch.Core/Zatca/ZatcaInvoiceChainStore.cs').read_text(encoding='utf-8')
        method = store[store.index('public ZatcaSubmissionDashboard GetDashboard'):store.index('public IReadOnlyList<ZatcaSubmissionHistoryItem>')]
        self.assertIn('Require(c, tx, userId, companyId, branchId, "reports.read")', method)
        self.assertIn('WHERE company_id=$co AND branch_id=$br', method)
        for state in ('Pending', 'Processing', 'Failed', 'Rejected', 'Cleared', 'Reported'):
            self.assertIn(f'Count("{state}")', method)

    def test_history_is_bounded_and_tenant_scoped(self):
        store = (ROOT / 'src/Monarch.Core/Zatca/ZatcaInvoiceChainStore.cs').read_text(encoding='utf-8')
        method = store[store.index('public IReadOnlyList<ZatcaSubmissionHistoryItem>'):store.index('public void RetryFailedSubmission')]
        self.assertIn('limit is < 1 or > 500', method)
        self.assertIn('Require(c, tx, userId, companyId, branchId, "reports.read")', method)
        self.assertIn('c.last_response', method)
        self.assertIn('o.attempts', method)

    def test_manual_retry_rejects_non_failed_and_audits(self):
        store = (ROOT / 'src/Monarch.Core/Zatca/ZatcaInvoiceChainStore.cs').read_text(encoding='utf-8')
        method = store[store.index('public void RetryFailedSubmission'):store.index('private static void Require')]
        self.assertIn("submission_status='Failed'", method)
        self.assertIn("submission_status='Pending'", method)
        self.assertIn('o.attempts<$attempts', method)
        self.assertIn('ZatcaSubmissionRetry', method)
        self.assertIn('zatca.integration.manage', method)
        self.assertIn('Rejected invoices require correction', method)

    def test_claim_has_retry_ceiling(self):
        store = (ROOT / 'src/Monarch.Core/Zatca/ZatcaInvoiceChainStore.cs').read_text(encoding='utf-8')
        claim = store[store.index('public IReadOnlyList<ZatcaChainRecord> ClaimPending'):store.index('public IReadOnlyList<ZatcaChainRecord> ListPending')]
        self.assertIn('maxAttempts = 8', claim)
        self.assertIn('o.attempts<$attempts', claim)
        self.assertIn('attempts=attempts+1', claim)

    def test_worker_passes_attempt_ceiling(self):
        worker = (ROOT / 'src/Monarch.Core/Zatca/ZatcaSubmissionWorker.cs').read_text(encoding='utf-8')
        self.assertIn('ProcessWithRetryLimitAsync', worker)
        self.assertIn('int maxAttempts', worker)
        self.assertIn('ClaimPending(userId, companyId, branchId, maxItems, maxAttempts)', worker)


def test_submission_claim_is_gated_by_active_complete_egs_readiness():
    store = (ROOT / 'src/Monarch.Core/Zatca/ZatcaInvoiceChainStore.cs').read_text(encoding='utf-8')
    claim = store[store.index('public IReadOnlyList<ZatcaChainRecord> ClaimPending'):store.index('public IReadOnlyList<ZatcaChainRecord> ListPending')]
    payload = store[store.index('public (string Xml, string Hash, string Kind, Guid EgsUnitId) GetSubmissionPayload'):store.index('public (string Xml, string QrPayloadBase64) GetClearedDocument')]
    for sql in (claim, payload):
        assert 'JOIN monarch_zatca_egs_units e' in sql
        assert "e.lifecycle_state='Active'" in sql
        for field in ('csr_fingerprint','otp_transaction_reference','csid_serial_number','csid_certificate_thumbprint','secret_reference'):
            assert field in sql
    assert 'not ready for submission' in payload


def test_worker_uses_egs_readiness_and_audits_blocked_invoice_reasons():
    worker = (ZATCA / 'ZatcaSubmissionWorker.cs').read_text(encoding='utf-8')
    store = (ZATCA / 'ZatcaInvoiceChainStore.cs').read_text(encoding='utf-8')
    assert 'EvaluateReadiness(userId, companyId, branchId, candidate.EgsUnitId)' in worker
    assert 'readiness.CanSubmitInvoices' in worker
    assert 'AuditEgsReadinessBlocked' in worker
    assert 'BlockingReasons' in worker
    assert "'ZatcaEgsSubmissionBlocked'" in store


def test_unknown_transport_outcome_is_not_blindly_reclaimed_or_marked_failed():
    worker = (ZATCA / 'ZatcaSubmissionWorker.cs').read_text(encoding='utf-8')
    store = (ZATCA / 'ZatcaInvoiceChainStore.cs').read_text(encoding='utf-8')
    claim = store[store.index('public IReadOnlyList<ZatcaChainRecord> ClaimPending'):store.index('public IReadOnlyList<ZatcaChainRecord> ListPending')]
    assert "o.submission_status IN('Pending','Failed')" in claim
    assert "o.submission_status='Processing' AND" not in claim
    assert 'MarkSubmissionOutcomeUnknown' in worker
    assert "'ZatcaSubmissionOutcomeUnknown'" in store
    assert 'CompleteSubmission(userId, companyId, branchId, row.Id, "Failed"' not in worker


def test_outbox_claim_index_exists_in_provisioning_schema():
    schema = (ROOT / 'database/commercial-data.sql').read_text(encoding='utf-8')
    assert 'ix_monarch_zatca_outbox_claim' in schema
