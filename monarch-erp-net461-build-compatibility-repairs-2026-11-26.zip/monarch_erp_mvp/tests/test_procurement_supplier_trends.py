from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
STORE = ROOT / "src/Monarch.Core/Autonomy/ProcurementAnalyticsStore.cs"
COMPAT = ROOT / "src/Monarch.Core/Compatibility/NetFrameworkCompat.cs"


def test_supplier_trends_compare_equal_adjacent_periods_and_require_permission():
    source = STORE.read_text(encoding="utf-8")
    start = source.index("public IReadOnlyList<ProcurementSupplierTrend> GetSupplierPerformanceTrends")
    end = source.index("private static void RequireReportPermission", start)
    method = source[start:end]
    assert "RequireReportPermission(c, tx, userId, companyId, branchId)" in method
    assert "po.company_id=$co AND po.branch_id=$br" in method
    assert "po.status='Received'" in method
    assert "MAX(r.posted_utc) AS completed_utc" in method
    assert "completed_utc >= $previousFrom AND completed_utc < $currentFrom" in method
    assert "completed_utc >= $currentFrom AND completed_utc < $currentUntil" in method
    assert "minimumOrdersPerPeriod" in method


def test_supplier_trend_alerts_use_minimum_sample_and_explicit_thresholds():
    source = STORE.read_text(encoding="utf-8")
    assert "currentCount >= minimumOrdersPerPeriod && previousCount >= minimumOrdersPerPeriod" in source
    assert ">= 0.15" in source
    assert "currentLead.Value >= previousLead.Value * 1.25" in source
    assert '"InsufficientData"' in source and '"Critical"' in source and '"Warning"' in source
    assert "INSERT INTO" not in source and "UPDATE " not in source and "DELETE FROM" not in source


def test_trend_date_window_is_equal_length_and_framework_dateonly_supports_it():
    source = STORE.read_text(encoding="utf-8")
    assert "var days = toDate.DayNumber - fromDate.DayNumber + 1;" in source
    assert "fromDate.AddDays(-days)" in source
    compat = COMPAT.read_text(encoding="utf-8")
    assert "public int DayNumber" in compat and "public DateOnly AddDays(int value)" in compat


def test_alert_classification_threshold_examples():
    # A 20-point on-time decline is a warning; a 30% lead-time increase is also a warning.
    assert (0.90 - 0.70) >= 0.15
    assert 10.0 >= 8.0 * 1.25
    # The service deliberately suppresses alerts when either period has too few orders.
    assert not (2 >= 3 and 5 >= 3)
