import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
UI = (ROOT / 'src/Monarch.Desktop/MainWindow.xaml.cs').read_text(encoding='utf-8')
STORE = (ROOT / 'src/Monarch.Core/Commercial/SupplierInvoiceStore.cs').read_text(encoding='utf-8')


class SupplierInvoiceWpfTests(unittest.TestCase):
    def test_invoice_workspace_is_permission_gated_and_uses_core(self):
        self.assertIn('commercial.purchases.manage', UI)
        self.assertIn('BuildPurchaseOrdersTab()', UI)
        self.assertIn('new SupplierInvoiceStore(_databasePath)', UI)
        self.assertNotIn('INSERT INTO monarch_supplier_invoices', UI)

    def test_invoice_lines_grid_supports_multi_line_draft(self):
        self.assertIn('_supplierInvoiceLinesGrid.IsReadOnly = false', UI)
        self.assertIn('SupplierInvoiceLineInput', UI)
        self.assertIn('selected.Select(x=>new SupplierInvoiceLineInput', UI)
        self.assertIn('CommitEdit(DataGridEditingUnit.Cell,true)', UI)
        self.assertIn('CommitEdit(DataGridEditingUnit.Row,true)', UI)

    def test_post_requires_explicit_confirmation_and_selected_invoice(self):
        self.assertIn('PostSupplierInvoice()', UI)
        self.assertIn('SelectedGridGuid(_supplierInvoicesGrid)', UI)
        self.assertIn('MessageBox.Show("سيتم ترحيل فاتورة المورد نهائياً', UI)
        self.assertIn('.Post(_session.UserId,_ledgerSession.CompanyId,_ledgerSession.BranchId,id)', UI)

    def test_core_read_models_are_scoped_and_hide_fully_invoiced_receipts(self):
        self.assertIn('ListReceiptableLines', STORE)
        self.assertIn("si.status='Posted'", STORE)
        self.assertIn('rr.branch_id=$br', STORE)
        self.assertIn('List(Guid userId', STORE)
        self.assertIn('Require(c, tx, userId, companyId, branchId, "commercial.purchases.manage")', STORE)
        for method in ('ListReceiptableLines', 'List('):
            start = STORE.index('public IReadOnlyList<SupplierInvoice' + ('ReceiptableLine>' if method == 'ListReceiptableLines' else 'Summary>') + ' ' + method)
            end = STORE.find('\n    }', start)
            self.assertIn('commercial.purchases.manage', STORE[start:end])
            self.assertNotIn('reports.read', STORE[start:end])

    def test_ui_explains_accounting_handoff_is_not_a_gl_posting(self):
        self.assertIn('لم يُنشأ قيد أستاذ عام أو رصيد ذمم دائنة', UI)


if __name__ == '__main__':
    unittest.main()
