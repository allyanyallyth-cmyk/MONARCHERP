import pathlib
import sqlite3
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SCHEMA = (ROOT / 'database/commercial-data.sql').read_text(encoding='utf-8')
STORE = (ROOT / 'src/Monarch.Core/Commercial/SupplierInvoiceStore.cs').read_text(encoding='utf-8')


class SupplierInvoiceThreeWayMatchTests(unittest.TestCase):
    def test_invoice_is_separate_from_goods_receipt(self):
        self.assertIn('CREATE TABLE IF NOT EXISTS monarch_supplier_invoices', SCHEMA)
        self.assertIn('CREATE TABLE IF NOT EXISTS monarch_supplier_invoice_lines', SCHEMA)
        self.assertIn('purchase_order_id TEXT NOT NULL', SCHEMA)
        self.assertIn('receipt_line_id TEXT NOT NULL', SCHEMA)
        self.assertIn('UNIQUE(company_id,branch_id,supplier_id,invoice_number)', SCHEMA)

    def test_core_enforces_three_way_relationship_and_exact_po_price_tax(self):
        self.assertIn('JOIN monarch_purchase_receipts rr', STORE)
        self.assertIn('rr.purchase_order_id=$po', STORE)
        self.assertIn('pl.unit_cost_minor', STORE)
        self.assertIn('pl.tax_rate_bps', STORE)
        self.assertIn('current_qty+prior_qty>rl.quantity_milli', STORE)
        self.assertIn('current_qty+prior_qty>rl.quantity_milli', STORE)

    def test_posting_is_transactional_permissioned_and_idempotency_guarded(self):
        self.assertIn('using var tx = c.BeginTransaction()', STORE)
        self.assertIn('commercial.purchases.manage', STORE)
        self.assertIn('tx.Commit()', STORE)
        self.assertIn('UNIQUE(company_id,invoice_id,event_type)', SCHEMA)
        self.assertIn("'SupplierInvoicePosted'", STORE)

    def test_posted_invoice_and_lines_are_immutable(self):
        for trigger in ('trg_supplier_invoice_posted_immutable', 'trg_supplier_invoice_posted_no_delete',
                        'trg_supplier_invoice_line_no_update', 'trg_supplier_invoice_line_no_delete'):
            self.assertIn(trigger, SCHEMA)

    def test_schema_enforces_company_scope_invoice_number_and_append_only(self):
        db = sqlite3.connect(':memory:')
        db.executescript('''
        PRAGMA foreign_keys=ON;
        CREATE TABLE monarch_branches(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_parties(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_purchase_orders(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_users(id TEXT PRIMARY KEY);
        CREATE TABLE monarch_items(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_purchase_order_lines(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_purchase_receipt_lines(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        ''')
        marker = '-- Supplier invoices are separate liabilities documents'
        db.executescript(SCHEMA[SCHEMA.index(marker):])
        db.execute("INSERT INTO monarch_branches VALUES('co','br')")
        db.execute("INSERT INTO monarch_parties VALUES('co','supplier')")
        db.execute("INSERT INTO monarch_purchase_orders VALUES('co','po')")
        db.execute("INSERT INTO monarch_users VALUES('u')")
        db.execute("INSERT INTO monarch_supplier_invoices(id,company_id,branch_id,supplier_id,purchase_order_id,invoice_number,supplier_invoice_date,currency_code,currency_scale,status,created_utc,created_by) VALUES('i','co','br','supplier','po','INV-1','2026-11-07','SAR',2,'Draft','now','u')")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("INSERT INTO monarch_supplier_invoices(id,company_id,branch_id,supplier_id,purchase_order_id,invoice_number,supplier_invoice_date,currency_code,currency_scale,status,created_utc,created_by) VALUES('i2','co','br','supplier','po','inv-1','2026-11-07','SAR',2,'Draft','now','u')")
        db.execute("UPDATE monarch_supplier_invoices SET status='Posted',posted_utc='now',posted_by='u' WHERE company_id='co' AND id='i'")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("UPDATE monarch_supplier_invoices SET total_minor=1 WHERE company_id='co' AND id='i'")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("DELETE FROM monarch_supplier_invoices WHERE company_id='co' AND id='i'")

    def test_invoice_lines_can_only_be_added_to_drafts(self):
        self.assertIn('trg_supplier_invoice_line_draft_insert', SCHEMA)
        self.assertIn("<>'Draft'", SCHEMA[SCHEMA.index('trg_supplier_invoice_line_draft_insert'):])


    def test_operational_invoice_reads_require_purchase_domain_permission(self):
        for signature in ('ListReceiptableLines', 'List(Guid userId'):
            start = STORE.index(signature)
            end = STORE.find('\n    }', start)
            body = STORE[start:end]
            self.assertIn('commercial.purchases.manage', body)
            self.assertNotIn('reports.read', body)
            self.assertIn('using var tx = c.BeginTransaction()', body)


if __name__ == '__main__':
    unittest.main()
