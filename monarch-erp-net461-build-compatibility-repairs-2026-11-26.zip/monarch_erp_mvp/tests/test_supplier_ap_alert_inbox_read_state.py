import sqlite3
from contextlib import closing
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]
MIGRATIONS = [
    ROOT / 'database/migrations/2026-11-11-supplier-ap-alert-delivery.sql',
    ROOT / 'database/migrations/2026-11-11-supplier-ap-alert-dispatcher.sql',
    ROOT / 'database/migrations/2026-11-11-supplier-ap-alert-inbox-read-state.sql',
]
SOURCE = ROOT / 'src/Monarch.Core/Commercial/SupplierPayablesAlertInboxStore.cs'


def database():
    db = sqlite3.connect(':memory:')
    for migration in MIGRATIONS:
        db.executescript(migration.read_text(encoding='utf-8'))
    return db


def add_intent(db, intent_id='i1', company='c1', branch='b1', user='u1'):
    stamp = '2026-11-11T00:00:00.0000000+00:00'
    db.execute('''INSERT INTO monarch_supplier_ap_alert_delivery_intents
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''', (intent_id, company, branch, user,
        'supplier_ap_heartbeat_failures', stamp, 'Critical', 2, 'InApp',
        'critical_immediate_escalation', stamp, stamp))
    db.execute("UPDATE monarch_supplier_ap_alert_dispatch_state SET status='Delivered',updated_utc=? WHERE intent_id=?", (stamp, intent_id))


def event(db, intent_id='i1', company='c1', branch='b1', user='u1', action='Viewed'):
    db.execute('''INSERT INTO monarch_supplier_ap_alert_inbox_events
    VALUES(lower(hex(randomblob(16))),?,?,?,?,?,?)''', (intent_id, company, branch, user, action, '2026-11-11T00:01:00+00:00'))


def test_read_state_is_recipient_company_and_branch_scoped():
    with closing(database()) as db:
        add_intent(db)
        event(db)
        rows = db.execute('''SELECT action FROM monarch_supplier_ap_alert_inbox_events
          WHERE intent_id=? AND company_id=? AND branch_id=? AND recipient_user_id=?''', ('i1','c1','b1','u1')).fetchall()
        assert rows == [('Viewed',)]
        assert db.execute("SELECT COUNT(*) FROM monarch_supplier_ap_alert_inbox_events WHERE recipient_user_id='u2'").fetchone()[0] == 0


def test_view_and_acknowledgement_are_distinct_and_idempotent():
    with closing(database()) as db:
        add_intent(db)
        event(db, action='Viewed')
        event(db, action='Acknowledged')
        with pytest.raises(sqlite3.IntegrityError):
            event(db, action='Viewed')
        assert {r[0] for r in db.execute('SELECT action FROM monarch_supplier_ap_alert_inbox_events')} == {'Viewed','Acknowledged'}


def test_only_delivered_intents_are_eligible_for_read_markers():
    with closing(database()) as db:
        add_intent(db)
        stamp = '2026-11-11T00:00:00.0000000+00:00'
        db.execute('''INSERT INTO monarch_supplier_ap_alert_delivery_intents VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
            ('i2','c1','b1','u1','supplier_ap_heartbeat_failures','2026-11-11T00:02:00.0000000+00:00','Critical',2,'InApp','reason',stamp,stamp))
        # Store's INSERT..SELECT is constrained by Delivered state; a pending row yields no inserted event.
        sql = SOURCE.read_text(encoding='utf-8')
        assert "AND s.status='Delivered'" in sql
        assert db.execute("SELECT status FROM monarch_supplier_ap_alert_dispatch_state WHERE intent_id='i2'").fetchone()[0] == 'Pending'


def test_read_events_are_append_only_and_have_durable_scope_index():
    with closing(database()) as db:
        add_intent(db)
        event(db)
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("UPDATE monarch_supplier_ap_alert_inbox_events SET action='Acknowledged'")
        with pytest.raises(sqlite3.IntegrityError):
            db.execute('DELETE FROM monarch_supplier_ap_alert_inbox_events')
        indexes = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='index'")}
        assert 'ix_supplier_ap_alert_inbox_recipient' in indexes


def test_csharp_store_authorizes_before_reads_and_writes_and_never_retries_dispatch():
    source = SOURCE.read_text(encoding='utf-8')
    assert source.count('_ledger.GetEntries(userId, companyId, branchId);') == 2
    assert 's.status=\'Delivered\'' in source
    assert 'recipient_user_id=$user' in source
    assert 'INSERT OR IGNORE' in source
    assert 'ClaimDue' not in source and 'CompleteAttempt' not in source
    assert 'journal_entries' not in source and 'accounting_outbox' not in source
