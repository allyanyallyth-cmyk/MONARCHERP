from contextlib import closing
from pathlib import Path
import re
import sqlite3
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "src/Monarch.Core/Commercial/InventoryMovementLineageStore.cs").read_text(encoding="utf-8")


def query_after(marker: str) -> str:
    start = SOURCE.index(marker)
    match = re.search(r'CommandText\s*=\s*@"(.*?)";', SOURCE[start:], re.S)
    if not match:
        raise AssertionError(f"SQL not found after {marker}")
    return match.group(1)


class InventoryMovementLineageTests(unittest.TestCase):
    def test_read_only_and_authorized_inside_same_transaction(self):
        self.assertIn("using var transaction = connection.BeginTransaction();", SOURCE)
        self.assertIn("RequireBranchAccess(connection, transaction, userId, companyId, branchId);", SOURCE)
        self.assertIn("transaction.Commit();", SOURCE)
        self.assertNotRegex(SOURCE, r"(?i)\b(INSERT\s+INTO|UPDATE\s+|DELETE\s+FROM)\s+monarch_")

    def test_lineage_query_scopes_company_branch_and_cutoff(self):
        sql = query_after("command.CommandText = @\"SELECT")
        self.assertIn("m.company_id=$company AND m.branch_id=$branch", sql)
        self.assertIn("m.occurred_utc <= $cutoff", sql)
        self.assertIn("w.branch_id=m.branch_id", sql)
        self.assertIn("ORDER BY m.occurred_utc,m.ledger_sequence,m.id", sql)

    def test_statuses_cover_missing_links_and_transfers(self):
        for state in ("MissingCostAllocation", "MissingReturnCostAllocation", "MissingAccountingOutbox",
                      "OutboxFailed", "OutboxPending", "MissingJournal", "JournalNotPosted",
                      "TransferPairIncomplete", "TransferPaired"):
            self.assertIn(state, SOURCE)

    def test_sqlite_lineage_links_sale_and_return_and_transfer_pair(self):
        sql = query_after("command.CommandText = @\"SELECT")
        with closing(sqlite3.connect(":memory:")) as db:
            db.executescript("""
            CREATE TABLE monarch_users(id TEXT,is_active INTEGER);
            CREATE TABLE monarch_user_company_access(user_id TEXT,company_id TEXT,is_active INTEGER);
            CREATE TABLE monarch_user_branch_access(user_id TEXT,company_id TEXT,branch_id TEXT,is_active INTEGER);
            CREATE TABLE monarch_companies(id TEXT,is_active INTEGER);
            CREATE TABLE monarch_branches(company_id TEXT,id TEXT,is_active INTEGER);
            CREATE TABLE monarch_warehouses(id TEXT,company_id TEXT,branch_id TEXT,code TEXT);
            CREATE TABLE monarch_items(id TEXT,company_id TEXT,sku TEXT,name TEXT);
            CREATE TABLE monarch_stock_movements(id TEXT,company_id TEXT,branch_id TEXT,warehouse_id TEXT,item_id TEXT,
              occurred_utc TEXT,ledger_sequence INTEGER,movement_type TEXT,quantity_milli INTEGER,unit_cost_minor INTEGER,
              source_type TEXT,source_id TEXT);
            CREATE TABLE monarch_inventory_cost_allocations(id TEXT,company_id TEXT,movement_id TEXT,document_id TEXT,allocation_type TEXT,total_cost_minor INTEGER);
            CREATE TABLE monarch_commercial_documents(id TEXT,company_id TEXT,document_number TEXT,document_type TEXT);
            CREATE TABLE monarch_accounting_posting_outbox(company_id TEXT,document_id TEXT,status TEXT,event_type TEXT);
            CREATE TABLE monarch_commercial_returns(id TEXT,company_id TEXT,source_document_id TEXT,return_number TEXT,return_type TEXT);
            CREATE TABLE monarch_inventory_return_cost_allocations(id TEXT,company_id TEXT,movement_id TEXT,return_id TEXT,allocation_type TEXT,total_cost_minor INTEGER);
            CREATE TABLE monarch_return_accounting_outbox(company_id TEXT,return_id TEXT,status TEXT,event_type TEXT);
            CREATE TABLE monarch_tenant_journals(company_id TEXT,id TEXT,branch_id TEXT,number TEXT,status TEXT);
            INSERT INTO monarch_users VALUES('U',1);
            INSERT INTO monarch_user_company_access VALUES('U','C',1);
            INSERT INTO monarch_user_branch_access VALUES('U','C','B',1);
            INSERT INTO monarch_companies VALUES('C',1);
            INSERT INTO monarch_branches VALUES('C','B',1);
            INSERT INTO monarch_warehouses VALUES('W','C','B','MAIN');
            INSERT INTO monarch_warehouses VALUES('W2','C','B','SECOND');
            INSERT INTO monarch_items VALUES('I','C','SKU-1','Test item');
            INSERT INTO monarch_commercial_documents VALUES('11111111-1111-1111-1111-111111111111','C','INV-1','Sale');
            INSERT INTO monarch_inventory_cost_allocations VALUES('A1','C','M1','11111111-1111-1111-1111-111111111111','SalesIssue',2500);
            INSERT INTO monarch_accounting_posting_outbox VALUES('C','11111111-1111-1111-1111-111111111111','Processed','SalePosted');
            INSERT INTO monarch_tenant_journals VALUES('C','J1','B','AUTO-COM-11111111111111111111111111111111','Posted');
            INSERT INTO monarch_commercial_returns VALUES('22222222-2222-2222-2222-222222222222','C','11111111-1111-1111-1111-111111111111','RET-1','SalesReturn');
            INSERT INTO monarch_inventory_return_cost_allocations VALUES('RA1','C','M2','22222222-2222-2222-2222-222222222222','SalesReturnReversal',500);
            INSERT INTO monarch_return_accounting_outbox VALUES('C','22222222-2222-2222-2222-222222222222','Processed','SalesReturnPosted');
            INSERT INTO monarch_tenant_journals VALUES('C','J2','B','AUTO-RET-22222222222222222222222222222222','Posted');
            INSERT INTO monarch_stock_movements VALUES
              ('M1','C','B','W','I','2026-01-01T00:00:00.0000000+00:00',1,'Issue',1000,2500,'CommercialDocument','11111111111111111111111111111111:0'),
              ('M2','C','B','W','I','2026-01-02T00:00:00.0000000+00:00',2,'SalesReturn',200,2500,'CommercialReturn','22222222222222222222222222222222:0'),
              ('T1','C','B','W','I','2026-01-03T00:00:00.0000000+00:00',3,'TransferOut',100,2500,'WarehouseTransfer','transfer-key'),
              ('T2','C','B','W2','I','2026-01-03T00:00:00.0000000+00:00',4,'TransferIn',100,2500,'WarehouseTransfer','transfer-key');
            """)
            rows = db.execute(sql, {"company": "C", "branch": "B", "cutoff": "2026-12-31T23:59:59.0000000+00:00"}).fetchall()
            by_id = {row[0]: row for row in rows}
            self.assertEqual(len(rows), 4)
            self.assertEqual(by_id["M1"][24], "AUTO-COM-11111111111111111111111111111111")
            self.assertEqual(by_id["M1"][25], "Posted")
            self.assertEqual(by_id["M2"][24], "AUTO-RET-22222222222222222222222222222222")
            self.assertEqual(by_id["M2"][25], "Posted")
            self.assertEqual(by_id["T1"][26], 2)
            self.assertEqual(by_id["T2"][26], 2)

    def test_query_excludes_other_company_branch_and_future_movements(self):
        sql = query_after("command.CommandText = @\"SELECT")
        self.assertIn("WHERE m.company_id=$company AND m.branch_id=$branch AND m.occurred_utc <= $cutoff", sql)

    def test_core_read_requires_reports_permission_not_only_branch_membership(self):
        access_sql = SOURCE[SOURCE.index('private static void RequireBranchAccess'):]
        self.assertIn("rp.permission_code='reports.read'", access_sql)
        self.assertIn('FROM monarch_user_roles ur', access_sql)
        self.assertIn('JOIN monarch_role_permissions rp', access_sql)
        self.assertIn('RequireBranchAccess(connection, transaction, userId, companyId, branchId);', SOURCE)
        query = re.search(r'CommandText\s*=\s*@"(SELECT 1 FROM monarch_users.*?);";', access_sql, re.S).group(1)
        with closing(sqlite3.connect(':memory:')) as db:
            db.executescript("""
            CREATE TABLE monarch_users(id TEXT,is_active INTEGER);
            CREATE TABLE monarch_user_company_access(user_id TEXT,company_id TEXT,is_active INTEGER);
            CREATE TABLE monarch_user_branch_access(user_id TEXT,company_id TEXT,branch_id TEXT,is_active INTEGER);
            CREATE TABLE monarch_companies(id TEXT,is_active INTEGER);
            CREATE TABLE monarch_branches(company_id TEXT,id TEXT,is_active INTEGER);
            CREATE TABLE monarch_user_roles(user_id TEXT,role_id TEXT);
            CREATE TABLE monarch_role_permissions(role_id TEXT,permission_code TEXT);
            INSERT INTO monarch_users VALUES('U',1);
            INSERT INTO monarch_user_company_access VALUES('U','C',1);
            INSERT INTO monarch_user_branch_access VALUES('U','C','B',1);
            INSERT INTO monarch_companies VALUES('C',1);
            INSERT INTO monarch_branches VALUES('C','B',1);
            INSERT INTO monarch_user_roles VALUES('U','R');
            INSERT INTO monarch_role_permissions VALUES('R','reports.read');
            """)
            args = {'user':'U','company':'C','branch':'B'}
            self.assertIsNotNone(db.execute(query, args).fetchone())
            db.execute("DELETE FROM monarch_role_permissions WHERE permission_code='reports.read'")
            self.assertIsNone(db.execute(query, args).fetchone())


if __name__ == "__main__":
    unittest.main()
