from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def source(path):
    return (ROOT / path).read_text(encoding="utf-8")


def test_direct_stock_movement_audit_is_inside_transaction():
    text = source("src/Monarch.Core/Commercial/CommercialStore.cs")
    body = text.split("public void RecordMovement(", 1)[1].split("public void TransferStock(", 1)[0]
    assert "InsertInventoryAudit(c, tx" in body
    assert body.index("InsertInventoryAudit(c, tx") < body.index("tx.Commit()")
    assert "monarch_company_audit_log" in text


def test_transfer_records_both_legs_in_their_branch_scopes():
    text = source("src/Monarch.Core/Commercial/CommercialStore.cs")
    body = text.split("public void TransferStock(", 1)[1].split("private static void InsertInventoryAudit", 1)[0]
    assert "StockTransferOut" in body and "StockTransferIn" in body
    assert "sourceBranchId" in body and "targetBranchId" in body
    assert body.count("InsertInventoryAudit(c, tx") == 2
    assert body.index("InsertInventoryAudit(c, tx") < body.index("tx.Commit()")


def test_sales_purchase_document_posting_is_audited_atomically():
    text = source("src/Monarch.Core/Commercial/CommercialDocumentStore.cs")
    body = text.split("public void Post(", 1)[1].split("private static void ValidatePartyAndWarehouse", 1)[0]
    assert "CommercialDocument" in body and "monarch_company_audit_log" in body
    assert body.index("monarch_company_audit_log") < body.index("tx.Commit()")


def test_sales_purchase_return_posting_is_audited_atomically():
    text = source("src/Monarch.Core/Commercial/CommercialReturnStore.cs")
    body = text.split("public void Post(", 1)[1].split("private static SourceDocument LoadSource", 1)[0]
    assert "CommercialReturn" in body and "monarch_company_audit_log" in body
    assert body.index("monarch_company_audit_log") < body.index("tx.Commit()")


def test_audit_sql_is_parameterized_and_uses_existing_tenant_scope():
    text = source("src/Monarch.Core/Commercial/CommercialStore.cs")
    helper = text.split("private static void InsertInventoryAudit", 1)[1].split("private static long CalculateCurrentMovingAverageCost", 1)[0]
    for parameter in ("$co", "$br", "$actor", "$action", "$id", "$details", "$now"):
        assert parameter in helper
    assert "VALUES($co,$br,$actor,$action,'StockMovement',$id,$details,$now)" in helper
