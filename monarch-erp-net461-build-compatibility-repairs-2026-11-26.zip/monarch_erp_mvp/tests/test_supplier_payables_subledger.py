import pathlib
import sqlite3
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SCHEMA = (ROOT / 'database/commercial-data.sql').read_text(encoding='utf-8')
INVOICE_STORE = (ROOT / 'src/Monarch.Core/Commercial/SupplierInvoiceStore.cs').read_text(encoding='utf-8')
AP_STORE = (ROOT / 'src/Monarch.Core/Commercial/SupplierPayablesStore.cs').read_text(encoding='utf-8')


class SupplierPayablesSubledgerTests(unittest.TestCase):
    def test_posted_invoice_creates_payable_in_same_core_transaction(self):
        self.assertIn('INSERT INTO monarch_supplier_payables', INVOICE_STORE)
        self.assertLess(INVOICE_STORE.index('INSERT INTO monarch_supplier_payables'), INVOICE_STORE.index('tx.Commit();', INVOICE_STORE.index('public void Post')))
        self.assertIn("'Open'", INVOICE_STORE)
        self.assertIn('payment_terms_days', INVOICE_STORE)

    def test_ap_schema_supports_invoice_due_balance_and_allocated_payments(self):
        for table in ('monarch_supplier_payables', 'monarch_supplier_payments',
                      'monarch_supplier_payment_allocations', 'monarch_supplier_payment_accounting_outbox'):
            self.assertIn(f'CREATE TABLE IF NOT EXISTS {table}', SCHEMA)
        self.assertIn('UNIQUE(company_id,branch_id,supplier_id,payment_number)', SCHEMA)
        self.assertIn('UNIQUE(company_id,payment_id,invoice_id)', SCHEMA)
        self.assertIn('trg_supplier_payable_insert_posted_invoice', SCHEMA)
        self.assertIn('trg_supplier_payable_financial_fields_immutable', SCHEMA)

    def test_payment_core_validates_supplier_branch_currency_and_outstanding(self):
        self.assertIn('commercial.purchases.manage', AP_STORE)
        self.assertIn('ap.supplier_id', AP_STORE)
        self.assertIn('ap.branch_id', AP_STORE)
        self.assertIn('ap.currency_code', AP_STORE)
        self.assertIn('allocation.AmountMinor > outstanding', AP_STORE)
        self.assertIn('SUM(amount_minor)', AP_STORE)
        self.assertIn('SupplierPaymentPosted', AP_STORE)

    def test_aging_uses_only_posted_payments_on_or_before_the_as_of_date(self):
        aging = AP_STORE[AP_STORE.index('public IReadOnlyList<SupplierPayableAgingRow> GetAging'):]
        self.assertIn('LEFT JOIN monarch_supplier_payments pay', aging)
        self.assertIn('pay.branch_id=ap.branch_id', aging)
        self.assertIn("pay.status='Posted'", aging)
        self.assertIn('date(pay.payment_date)<=date($asof)', aging)
        self.assertIn('CASE WHEN pay.id IS NOT NULL THEN a.amount_minor ELSE 0 END', aging)

    def test_partial_and_full_payment_status_transitions_are_explicit(self):
        self.assertIn("THEN 'Paid' ELSE 'PartiallyPaid' END", AP_STORE)
        self.assertIn("status<>'Paid'", AP_STORE)
        self.assertIn('GetAging', AP_STORE)
        self.assertIn('Days61To90Minor', AP_STORE)

    def test_payment_and_allocations_are_append_only(self):
        for trigger in ('trg_supplier_payment_no_update', 'trg_supplier_payment_no_delete',
                        'trg_supplier_payment_allocation_no_update', 'trg_supplier_payment_allocation_no_delete'):
            self.assertIn(trigger, SCHEMA)

    def test_schema_enforces_allocation_uniqueness_and_immutability(self):
        db = sqlite3.connect(':memory:')
        db.execute('PRAGMA foreign_keys=ON')
        db.executescript('''
        CREATE TABLE monarch_branches(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_parties(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_purchase_orders(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_users(id TEXT PRIMARY KEY);
        CREATE TABLE monarch_items(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_purchase_order_lines(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        CREATE TABLE monarch_purchase_receipt_lines(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
        ''')
        marker = '-- Supplier invoices are separate liabilities documents'
        db.executescript(SCHEMA[SCHEMA.index(marker):])
        db.execute("INSERT INTO monarch_branches VALUES('co','br')")
        db.execute("INSERT INTO monarch_parties VALUES('co','supplier')")
        db.execute("INSERT INTO monarch_purchase_orders VALUES('co','po')")
        db.execute("INSERT INTO monarch_users VALUES('u')")
        db.execute("INSERT INTO monarch_supplier_invoices(id,company_id,branch_id,supplier_id,purchase_order_id,invoice_number,supplier_invoice_date,currency_code,currency_scale,status,created_utc,created_by,total_minor) VALUES('i','co','br','supplier','po','INV-1','2026-11-01','SAR',2,'Draft','now','u',10000)")
        db.execute("UPDATE monarch_supplier_invoices SET status='Posted',posted_utc='now',posted_by='u' WHERE company_id='co' AND id='i'")
        db.execute("INSERT INTO monarch_supplier_payables(company_id,invoice_id,branch_id,supplier_id,invoice_number,invoice_date,due_date,currency_code,currency_scale,original_minor,status,created_utc) VALUES('co','i','br','supplier','INV-1','2026-11-01','2026-12-01','SAR',2,10000,'Open','now')")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("UPDATE monarch_supplier_payables SET original_minor=1 WHERE company_id='co' AND invoice_id='i'")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("DELETE FROM monarch_supplier_payables WHERE company_id='co' AND invoice_id='i'")
        db.execute("INSERT INTO monarch_supplier_payments(id,company_id,branch_id,supplier_id,payment_number,payment_date,payment_method,cash_bank_account_code,currency_code,currency_scale,amount_minor,status,created_utc,created_by) VALUES('p','co','br','supplier','PAY-1','2026-11-07','Bank','1010','SAR',2,4000,'Posted','now','u')")
        db.execute("INSERT INTO monarch_supplier_payment_allocations VALUES('a','co','p','i',4000)")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("INSERT INTO monarch_supplier_payment_allocations VALUES('a2','co','p','i',1)")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("UPDATE monarch_supplier_payments SET amount_minor=1 WHERE company_id='co' AND id='p'")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("DELETE FROM monarch_supplier_payment_allocations WHERE company_id='co' AND id='a'")
        self.assertEqual(db.execute("SELECT original_minor-SUM(amount_minor) FROM monarch_supplier_payables ap JOIN monarch_supplier_payment_allocations a USING(company_id,invoice_id) WHERE ap.invoice_id='i'").fetchone()[0], 6000)


if __name__ == '__main__':
    unittest.main()
