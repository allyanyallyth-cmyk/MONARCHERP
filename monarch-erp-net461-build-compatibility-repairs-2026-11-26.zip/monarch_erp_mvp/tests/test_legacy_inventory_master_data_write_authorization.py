from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
STORE = (ROOT / "src/Monarch.Core/Commercial/CommercialStore.cs").read_text(encoding="utf-8")


class LegacyInventoryMasterDataWriteAuthorizationTests(unittest.TestCase):
    def test_legacy_unit_and_item_writes_use_transactional_item_permission_and_audit(self):
        for method, next_method, action in (
            ("AddUnit", "AddItem", "UnitCreated"),
            ("AddItem", "AddWarehouse", "InventoryItemCreated"),
        ):
            body = STORE.split(f"public void {method}(", 1)[1].split(f"public void {next_method}(", 1)[0]
            self.assertIn("using var tx = c.BeginTransaction();", body)
            self.assertIn('RequireCompanyPermission(c, tx, userId, companyId, "inventory.items.manage");', body)
            self.assertIn("cmd.Transaction = tx;", body)
            self.assertIn(action, body)
            self.assertLess(body.index("RequireCompanyPermission"), body.index("cmd.ExecuteNonQuery()"))
            self.assertLess(body.index("InsertMasterDataAudit"), body.index("tx.Commit()"))

    def test_legacy_warehouse_write_is_branch_scoped_and_audited_atomically(self):
        body = STORE.split("public void AddWarehouse(", 1)[1].split("/// <summary>Lists company-scoped", 1)[0]
        self.assertIn("using var tx = c.BeginTransaction();", body)
        self.assertIn('RequireBranchPermission(c, tx, userId, companyId, warehouse.BranchId, "inventory.warehouses.manage");', body)
        self.assertIn("cmd.Transaction = tx;", body)
        self.assertIn('"WarehouseCreated"', body)
        self.assertLess(body.index("RequireBranchPermission"), body.index("cmd.ExecuteNonQuery()"))
        self.assertLess(body.index("InsertMasterDataAudit"), body.index("tx.Commit()"))

    def test_company_permission_checks_active_identity_membership_and_role_grant(self):
        helper = STORE.split("private static void RequireCompanyPermission", 1)[1].split("private static void RequireBranchPermission", 1)[0]
        for term in ("monarch_users", "u.is_active=1", "monarch_user_company_access", "ca.is_active=1", "monarch_companies", "co.is_active=1", "monarch_user_roles", "monarch_role_permissions", "$permission"):
            self.assertIn(term, helper)

    def test_branch_permission_checks_active_branch_membership_and_role_grant(self):
        helper = STORE.split("private static void RequireBranchPermission", 1)[1].split("private static void InsertMasterDataAudit", 1)[0]
        for term in ("monarch_users", "u.is_active=1", "ca.is_active=1", "ba.is_active=1", "monarch_branches", "b.is_active=1", "monarch_user_roles", "monarch_role_permissions", "$permission"):
            self.assertIn(term, helper)

    def test_audit_insert_is_parameterized_and_part_of_caller_transaction(self):
        helper = STORE.split("private static void InsertMasterDataAudit", 1)[1].split("private void RequireCompany", 1)[0]
        self.assertIn("a.Transaction = tx", helper)
        self.assertIn("INSERT INTO monarch_company_audit_log", helper)
        for parameter in ("$co", "$branch", "$user", "$action", "$entity", "$id", "$details", "$now"):
            self.assertIn(parameter, helper)


if __name__ == "__main__":
    unittest.main()
