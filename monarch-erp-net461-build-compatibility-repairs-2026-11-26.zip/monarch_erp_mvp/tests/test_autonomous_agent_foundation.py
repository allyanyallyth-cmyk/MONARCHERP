from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CORE = ROOT / "src/Monarch.Core/Autonomy"


def test_autonomous_engine_contains_tenant_scoped_cash_forecast_and_30_day_capability():
    source = (CORE / "AutonomousAgentEngine.cs").read_text(encoding="utf-8")
    assert "ForecastCash" in source
    assert "CompanyId == companyId && x.BranchId == branchId" in source
    assert "horizonDays > 90" in source
    assert "FirstNegativeDateUtc" in source


def test_predictive_procurement_uses_lead_time_safety_stock_and_on_order():
    source = (CORE / "AutonomousAgentEngine.cs").read_text(encoding="utf-8")
    assert "AverageDailyUsage * x.LeadTimeDays + x.SafetyStock" in source
    assert "x.OnHand + x.OnOrder <= reorderPoint" in source
    assert "purchase order requires authorized approval" in source


def test_anomaly_detection_and_month_close_are_advisory_not_automatic_posting():
    source = (CORE / "AutonomousAgentEngine.cs").read_text(encoding="utf-8")
    assert "DetectAnomalies" in source and "sigmaThreshold" in source
    assert "fraud determination" in source
    assert "AssessMonthClose" in source and "authorized controller may approve close" in source


def test_natural_language_interface_is_allowlisted_and_never_executes_actions():
    source = (CORE / "AutonomousAgentEngine.cs").read_text(encoding="utf-8")
    assert '"SalesReport"' in source
    assert '"ZatcaPendingInvoices"' in source
    assert '"InventoryReorderPreview"' in source
    assert '"MonthCloseAssessment"' in source
    assert "IsExecutable" in source and "false" in source


def test_circuit_breaker_and_green_ledger_require_explicit_approved_inputs():
    source = (CORE / "ResiliencePrimitives.cs").read_text(encoding="utf-8")
    assert "CircuitBreaker" in source and "HalfOpen" in source
    assert "TryEnter" in source and "RecordFailure" in source and "RecordSuccess" in source
    assert "if (!factor.IsApproved)" in source
    assert "never changes legal/tax rules" in source
