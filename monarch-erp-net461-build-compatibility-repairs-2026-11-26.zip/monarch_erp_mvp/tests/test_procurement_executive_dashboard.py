from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_executive_dashboard_is_registered_only_for_report_read_users():
    source = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
    assert 'if (_session.HasPermission("reports.read"))' in source
    assert 'tabs.Items.Add(BuildProcurementAnalyticsDashboardTab());' in source
    assert 'IdentityStore.Require(_session, "reports.read")' in source


def test_dashboard_uses_tenant_scoped_analytics_store_and_date_filters():
    source = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
    assert 'new ProcurementAnalyticsStore(_databasePath).GetSnapshot(' in source
    assert '_ledgerSession.CompanyId, _ledgerSession.BranchId, from, to' in source
    assert 'DateOnly.FromDateTime(_procurementAnalyticsFrom.SelectedDate.Value.Date)' in source
    assert 'DateOnly.FromDateTime(_procurementAnalyticsTo.SelectedDate.Value.Date)' in source


def test_dashboard_surfaces_decisions_suppliers_consumption_and_forecast_accuracy():
    source = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
    for token in ('RejectionRate', 'AverageDecisionHours', 'SupplierPerformance',
                  'snapshot.Consumption', 'WeightedAbsolutePercentageError', 'ForecastAccuracyNote'):
        assert token in source


def test_dashboard_is_read_only_and_does_not_add_procurement_mutations():
    source = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
    start = source.index('private TabItem BuildProcurementAnalyticsDashboardTab()')
    end = source.index('private TabItem BuildSupplierPayablesTab()', start)
    block = source[start:end]
    assert 'GetSnapshot(' in block
    assert '.Approve(' not in block and '.Post(' not in block and '.CreateDraft(' not in block
