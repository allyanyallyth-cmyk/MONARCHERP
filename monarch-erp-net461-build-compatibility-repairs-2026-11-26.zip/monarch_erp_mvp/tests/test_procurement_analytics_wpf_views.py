from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs"


def test_procurement_dashboard_exposes_supplier_item_trend_and_forecast_history_views():
    source = UI.read_text(encoding="utf-8")
    for field in (
        "_procurementSupplierItemGrid", "_procurementSupplierTrendsGrid",
        "_procurementForecastHistoryGrid",
    ):
        assert field in source
    assert 'Heading("أداء المورد حسب الصنف والعملـة")' in source
    assert 'Heading("اتجاهات أداء الموردين والتنبيهات")' in source
    assert 'Heading("السجل التاريخي لدقة التوقعات")' in source


def test_dashboard_calls_existing_core_analytics_services_with_current_tenant_context():
    source = UI.read_text(encoding="utf-8")
    for method in ("GetSupplierItemPerformance", "GetSupplierPerformanceTrends", "GetForecastHistory"):
        assert f"analytics.{method}(" in source
    assert source.count("_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, from, to") >= 3
    assert 'IdentityStore.Require(_session, "reports.read")' in source


def test_analytics_dashboard_remains_read_only_and_clears_stale_results_on_failure():
    source = UI.read_text(encoding="utf-8")
    assert "_procurementSupplierItemGrid.ItemsSource = null" in source
    assert "_procurementSupplierTrendsGrid.ItemsSource = null" in source
    assert "_procurementForecastHistoryGrid.ItemsSource = null" in source
    # UI only invokes read-model methods; no purchasing approval or posting actions are added here.
    block = source[source.index("private void RefreshProcurementAnalytics()"):source.index("private TabItem BuildSupplierPayablesTab()") ]
    assert "DecideProcurementApproval(" not in block
    assert "PostPayment(" not in block and "Decide(" not in block
    assert "INSERT INTO" not in block and "UPDATE " not in block and "DELETE FROM" not in block
