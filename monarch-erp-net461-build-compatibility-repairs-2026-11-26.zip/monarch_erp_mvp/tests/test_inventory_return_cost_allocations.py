from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
STORE = (ROOT / 'src/Monarch.Core/Commercial/CommercialReturnStore.cs').read_text()
SCHEMA = (ROOT / 'database/commercial-data.sql').read_text()

class InventoryReturnCostAllocationTests(unittest.TestCase):
    def test_sales_and_purchase_returns_resolve_original_allocation(self):
        self.assertIn('returnType == "SalesReturn" ? "SalesIssue" : "PurchaseReceipt"', STORE)
        self.assertIn('LoadOriginalCostAllocation(c, tx, companyId, sourceLine, type)', STORE)

    def test_return_cost_is_based_on_cumulative_original_allocation(self):
        self.assertIn('allocation.TotalCostMinor * cumulativeQty / allocation.QuantityMilli', STORE)
        self.assertIn('cumulativeCost - priorReturnedCost', STORE)
        self.assertIn('var unitCost = allocation.UnitCostMinor', STORE)
        self.assertIn('cumulativeQty > allocation.QuantityMilli', STORE)

    def test_return_cost_allocations_are_immutable_and_tenant_scoped(self):
        self.assertIn('monarch_inventory_return_cost_allocations', SCHEMA)
        self.assertIn('FOREIGN KEY(company_id,return_id)', SCHEMA)
        self.assertIn('FOREIGN KEY(company_id,return_id,return_line_id)', SCHEMA)
        self.assertIn('FOREIGN KEY(company_id,source_allocation_id)', SCHEMA)
        self.assertIn('trg_inventory_return_cost_no_update', SCHEMA)
        self.assertIn('trg_inventory_return_cost_no_delete', SCHEMA)

    def test_return_stock_movements_receive_per_warehouse_item_sequence(self):
        self.assertIn('ledger_sequence,movement_type,quantity_milli', STORE)
        self.assertIn('MAX(ledger_sequence),0)+1 FROM monarch_stock_movements', STORE)

    def test_return_movement_and_cost_trace_share_posting_transaction(self):
        self.assertIn('InsertReturnCostAllocation(c, tx', STORE)
        self.assertIn('using var c = Open(); using var tx = c.BeginTransaction();', STORE)
        self.assertIn('tx.Commit();', STORE)

if __name__ == '__main__':
    unittest.main()
