from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
DESKTOP = ROOT / 'src/Monarch.Desktop/MainWindow.xaml.cs'

class CommercialSchemaUpgradeUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = DESKTOP.read_text(encoding='utf-8')

    def test_upgrade_tab_is_restricted_to_system_administrator(self):
        self.assertIn('tabs.Items.Add(BuildCommercialSchemaUpgradeTab())', self.source)
        gate = self.source.split('if (_session.HasPermission("users.manage") && string.Equals(_session.RoleCode, "Administrator"', 1)[1].split('root.Children.Add(tabs)', 1)[0]
        self.assertIn('BuildCommercialSchemaUpgradeTab()', gate)

    def test_inspection_precedes_apply_and_is_explicit(self):
        self.assertIn('new CommercialSchemaUpgradeService(_databasePath).Inspect(schema)', self.source)
        self.assertIn('if (_pendingSchemaUpgradePlan == null)', self.source)
        self.assertIn('Apply(CommercialSchemaPath(), backupDialog.FileName, true)', self.source)

    def test_ui_requires_backup_dialog_and_final_confirmation(self):
        apply = self.source.split('private void ApplyCommercialSchemaUpgrade()', 1)[1].split('private void LoadMasterData()', 1)[0]
        self.assertIn('new SaveFileDialog', apply)
        self.assertIn('MessageBoxResult.Yes', apply)
        self.assertIn('أغلق جميع نسخ MONARCH الأخرى', apply)

    def test_schema_file_is_resolved_from_installed_database_folder(self):
        self.assertIn('Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "database", "commercial-data.sql")', self.source)

if __name__ == '__main__':
    unittest.main()
