import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CENTER = (ROOT / 'src/Monarch.Core/Commercial/SupplierPayablesOperationalAlertCenter.cs').read_text(encoding='utf-8')
WORKER = (ROOT / 'src/Monarch.Core/Commercial/SupplierPayablesAccountingOutboxWorker.cs').read_text(encoding='utf-8')


class SupplierApOperationalAlertCenterTests(unittest.TestCase):
    def test_alerts_are_derived_from_known_durable_event_codes_only(self):
        self.assertIn('x.EventCode == "heartbeat_failed"', CENTER)
        self.assertIn('x.EventCode == "lease_ownership_lost"', CENTER)
        self.assertIn('supplier_ap_heartbeat_failures', CENTER)
        self.assertIn('supplier_ap_lease_ownership_loss', CENTER)

    def test_heartbeat_threshold_and_windows_are_explicit(self):
        self.assertIn('HeartbeatWindow = TimeSpan.FromMinutes(15)', CENTER)
        self.assertIn('LeaseLossWindow = TimeSpan.FromHours(24)', CENTER)
        self.assertIn('DefaultHeartbeatCriticalThreshold = 3', CENTER)
        self.assertIn('heartbeat.Length >= heartbeatCriticalThreshold', CENTER)

    def test_alert_query_authorizes_before_scoped_read(self):
        method = WORKER.split('public IReadOnlyList<SupplierPayablesOperationalAlert> GetOperationalAlerts', 1)[1].split('private void RecordDiagnostic', 1)[0]
        self.assertIn('GetRecentDiagnostics(userId, companyId, branchId, 500)', method)
        diagnostics = WORKER.split('public IReadOnlyList<SupplierPayablesWorkerDiagnostic> GetRecentDiagnostics', 1)[1].split('public IReadOnlyList<SupplierPayablesOperationalAlert>', 1)[0]
        self.assertIn('_ledger.GetEntries(userId, companyId, branchId)', diagnostics)
        self.assertIn('WHERE company_id=$co AND branch_id=$br', diagnostics)

    def test_result_and_threshold_inputs_are_bounded(self):
        self.assertIn('limit is < 1 or > 500', CENTER)
        self.assertIn('heartbeatCriticalThreshold < 2', CENTER)
        self.assertIn('.Take(limit).ToArray()', CENTER)

    def test_read_only_center_does_not_mutate_accounting_or_leases(self):
        self.assertIn('read-only, tenant-scoped operational view', CENTER)
        self.assertIn('does not retry work, mutate leases, or change accounting state', CENTER)
        self.assertNotIn('UPDATE monarch_supplier_ap_', CENTER)
        self.assertNotIn('INSERT INTO monarch_supplier_ap_', CENTER)

    def test_alert_order_is_deterministic(self):
        self.assertIn('.OrderByDescending(x => x.Severity == "Critical")', CENTER)
        self.assertIn('.ThenByDescending(x => x.LastOccurredUtc)', CENTER)
        self.assertIn('.ThenBy(x => x.Code, StringComparer.Ordinal)', CENTER)


if __name__ == '__main__':
    unittest.main()
