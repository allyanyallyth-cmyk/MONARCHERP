import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MIGRATION = ROOT / 'database/migrations/2026-11-07-versioned-green-compliance-ledger.sql'


def database():
    c = sqlite3.connect(':memory:')
    c.executescript('''
    CREATE TABLE monarch_companies(id TEXT PRIMARY KEY);
    CREATE TABLE monarch_users(id TEXT PRIMARY KEY);
    CREATE TABLE monarch_branches(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
    CREATE TABLE monarch_company_audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,company_id TEXT,branch_id TEXT,actor_user_id TEXT,action TEXT,entity_type TEXT,entity_id TEXT,details TEXT,occurred_utc TEXT);
    INSERT INTO monarch_companies VALUES('co');
    INSERT INTO monarch_users VALUES('user');
    INSERT INTO monarch_branches VALUES('co','br');
    ''')
    c.executescript(MIGRATION.read_text(encoding='utf-8'))
    return c


def test_green_ledger_schema_has_tenant_scope_and_temporal_versions():
    c = database()
    factor_cols = {r[1] for r in c.execute('PRAGMA table_info(monarch_carbon_factor_versions)')}
    snapshot_cols = {r[1] for r in c.execute('PRAGMA table_info(monarch_carbon_document_snapshots)')}
    assert {'company_id','version_code','effective_from_utc','effective_to_utc','approval_state'} <= factor_cols
    assert {'factor_version_id','transaction_utc','kg_co2e','document_id'} <= snapshot_cols


def test_approved_factor_is_immutable_and_cannot_be_deleted():
    c = database()
    c.execute("INSERT INTO monarch_carbon_factor_versions(id,company_id,activity_code,unit_code,kg_co2e_per_unit,source_reference,version_code,effective_from_utc,approval_state,created_by,created_utc) VALUES('f','co','freight','tonne','2.5','official','v1','2026-01-01T00:00:00+00:00','Approved','user','2026-01-01T00:00:00+00:00')")
    try:
        c.execute("UPDATE monarch_carbon_factor_versions SET kg_co2e_per_unit='9' WHERE id='f'")
        assert False, 'approved factors must be immutable'
    except sqlite3.IntegrityError as e:
        assert 'immutable' in str(e)
    try:
        c.execute("DELETE FROM monarch_carbon_factor_versions WHERE id='f'")
        assert False, 'factor history must be retained'
    except sqlite3.IntegrityError as e:
        assert 'cannot be deleted' in str(e)


def test_document_snapshot_cannot_be_changed_or_deleted():
    c = database()
    c.execute("INSERT INTO monarch_carbon_factor_versions(id,company_id,activity_code,unit_code,kg_co2e_per_unit,source_reference,version_code,effective_from_utc,approval_state,created_by,created_utc) VALUES('f','co','freight','tonne','2.5','official','v1','2026-01-01T00:00:00+00:00','Approved','user','2026-01-01T00:00:00+00:00')")
    c.execute("INSERT INTO monarch_carbon_document_snapshots VALUES('s','co','br','SupplierInvoice','inv-1','freight','3','7.5','f','2026-02-01T00:00:00+00:00','user','2026-02-01T00:00:00+00:00')")
    for sql in ["UPDATE monarch_carbon_document_snapshots SET kg_co2e='0' WHERE id='s'", "DELETE FROM monarch_carbon_document_snapshots WHERE id='s'"]:
        try:
            c.execute(sql)
            assert False, 'snapshot must be append-only'
        except sqlite3.IntegrityError as e:
            assert 'immutable' in str(e) or 'cannot be deleted' in str(e)


def test_tax_rule_versions_are_effective_dated_and_approved_rows_immutable():
    c = database()
    cols = {r[1] for r in c.execute('PRAGMA table_info(monarch_tax_rule_versions)')}
    assert {'jurisdiction_code','rule_code','version_code','effective_from_utc','effective_to_utc','official_source'} <= cols
    c.execute("INSERT INTO monarch_tax_rule_versions(id,jurisdiction_code,rule_code,version_code,rate,official_source,effective_from_utc,approval_state,created_by,created_utc) VALUES('t','SA','VAT','v1','0.15','official','2026-01-01T00:00:00+00:00','Approved','user','2026-01-01T00:00:00+00:00')")
    try:
        c.execute("UPDATE monarch_tax_rule_versions SET rate='0.20' WHERE id='t'")
        assert False, 'approved tax rules must be immutable'
    except sqlite3.IntegrityError as e:
        assert 'immutable' in str(e)
