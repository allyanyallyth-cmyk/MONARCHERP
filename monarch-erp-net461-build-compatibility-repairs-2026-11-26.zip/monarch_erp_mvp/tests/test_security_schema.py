import pathlib
import sqlite3
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "database" / "security.sql"


class SecuritySchemaTests(unittest.TestCase):
    def setUp(self):
        self.connection = sqlite3.connect(":memory:")
        self.connection.execute("PRAGMA foreign_keys=ON")
        self.connection.executescript(SCHEMA.read_text(encoding="utf-8"))

    def tearDown(self):
        self.connection.close()

    def test_seeded_roles_and_permissions_exist(self):
        roles = {row[0] for row in self.connection.execute("SELECT code FROM monarch_roles")}
        self.assertEqual(roles, {"Administrator", "Accountant", "Viewer"})
        permissions = {row[0] for row in self.connection.execute("SELECT code FROM monarch_permissions")}
        self.assertIn("users.manage", permissions)
        self.assertIn("journals.post", permissions)

    def test_administrator_receives_all_permissions(self):
        all_permissions = self.connection.execute("SELECT COUNT(*) FROM monarch_permissions").fetchone()[0]
        admin_permissions = self.connection.execute("""
            SELECT COUNT(*) FROM monarch_role_permissions rp
            JOIN monarch_roles r ON r.id=rp.role_id WHERE r.code='Administrator'
        """).fetchone()[0]
        self.assertEqual(admin_permissions, all_permissions)

    def test_viewer_cannot_create_or_post_journals(self):
        granted = {row[0] for row in self.connection.execute("""
            SELECT rp.permission_code FROM monarch_role_permissions rp
            JOIN monarch_roles r ON r.id=rp.role_id WHERE r.code='Viewer'
        """)}
        self.assertNotIn("journals.create", granted)
        self.assertNotIn("journals.post", granted)
        self.assertIn("reports.read", granted)

    def test_username_is_unique_case_insensitively(self):
        values = ("u1", "Admin", "Manager", b"s" * 16, b"h" * 32, 210000, 1, "2026-01-01T00:00:00Z")
        self.connection.execute("INSERT INTO monarch_users(id,username,display_name,password_salt,password_hash,password_iterations,is_active,created_utc) VALUES(?,?,?,?,?,?,?,?)", values)
        with self.assertRaises(sqlite3.IntegrityError):
            self.connection.execute("INSERT INTO monarch_users(id,username,display_name,password_salt,password_hash,password_iterations,is_active,created_utc) VALUES(?,?,?,?,?,?,?,?)", ("u2", "ADMIN", "Second", b"s" * 16, b"h" * 32, 210000, 1, "2026-01-01T00:00:00Z"))

    def test_password_iteration_floor_is_enforced(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.connection.execute("INSERT INTO monarch_users(id,username,display_name,password_salt,password_hash,password_iterations,is_active,created_utc) VALUES(?,?,?,?,?,?,?,?)", ("u1", "alice", "Alice", b"s" * 16, b"h" * 32, 1000, 1, "2026-01-01T00:00:00Z"))

    def test_role_user_relationship_enforces_foreign_keys(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.connection.execute("INSERT INTO monarch_user_roles(user_id,role_id) VALUES('missing','role-admin')")

    def test_audit_log_records_are_timestamped(self):
        columns = {row[1] for row in self.connection.execute("PRAGMA table_info(monarch_audit_log)")}
        self.assertTrue({"user_id", "action", "entity_type", "occurred_utc"}.issubset(columns))

    def test_identity_uses_salted_pbkdf2_sha256_and_lockout(self):
        source = (ROOT / "src/Monarch.Core/Security/IdentityStore.cs").read_text(encoding="utf-8")
        self.assertIn("HMACSHA256", source)
        self.assertIn("Iterations = 210000", source)
        self.assertIn("MaxFailedAttempts = 5", source)
        self.assertIn("LockoutDuration = TimeSpan.FromMinutes(15)", source)
        self.assertIn("FixedTimeEquals", source)

    def test_desktop_requires_login_and_bootstraps_admin(self):
        source = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
        gate = (ROOT / "src/Monarch.Desktop/SecurityGateWindow.cs").read_text(encoding="utf-8")
        self.assertIn("SecurityGateWindow.Run(_identity)", source)
        self.assertIn("CreateFirstAdministrator", gate)
        self.assertIn("Authenticate", gate)
        self.assertIn("BuildUsersTab", source)


if __name__ == "__main__":
    unittest.main()
