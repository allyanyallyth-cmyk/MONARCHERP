import pathlib
import sqlite3
from contextlib import closing
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SCHEMA = (ROOT / 'database/commercial-data.sql').read_text(encoding='utf-8')
SECURITY = (ROOT / 'database/security.sql').read_text(encoding='utf-8')
STORE = (ROOT / 'src/Monarch.Core/Commercial/PurchaseOrderStore.cs').read_text(encoding='utf-8')

class PurchaseOrderWorkflowTests(unittest.TestCase):
    def test_schema_has_separate_order_header_and_lines(self):
        self.assertIn('CREATE TABLE IF NOT EXISTS monarch_purchase_orders', SCHEMA)
        self.assertIn('CREATE TABLE IF NOT EXISTS monarch_purchase_order_lines', SCHEMA)
        self.assertIn("CHECK(status IN('Draft','Approved','Cancelled','PartiallyReceived','Received'))", SCHEMA)

    def test_schema_enforces_company_branch_and_document_uniqueness(self):
        self.assertIn('UNIQUE(company_id,branch_id,order_number)', SCHEMA)
        self.assertIn('FOREIGN KEY(company_id,branch_id) REFERENCES monarch_branches(company_id,id)', SCHEMA)
        self.assertIn('FOREIGN KEY(company_id,warehouse_id) REFERENCES monarch_warehouses(company_id,id)', SCHEMA)

    def test_approved_lines_are_immutable(self):
        self.assertIn('trg_purchase_order_lines_insert_draft', SCHEMA)
        self.assertIn('trg_purchase_order_lines_update_draft', SCHEMA)
        self.assertIn('trg_purchase_order_lines_delete_draft', SCHEMA)

    def test_dedicated_permission_seeded_for_admin(self):
        self.assertIn("'commercial.purchases.manage'", SECURITY)
        self.assertIn("('role-admin','commercial.purchases.manage')", SECURITY)

    def test_store_has_create_approve_cancel_list_and_audit(self):
        for token in ('CreateDraft(', 'Approve(', 'Cancel(', 'List(', 'PurchaseOrderCreated', 'PurchaseOrderApproved', 'PurchaseOrderCancelled'):
            self.assertIn(token, STORE)

    def test_authorization_is_scoped_inside_transaction(self):
        self.assertIn('BeginTransaction()', STORE)
        self.assertIn('JOIN monarch_user_branch_access', STORE)
        self.assertIn('JOIN monarch_role_permissions', STORE)
        self.assertIn('commercial.purchases.manage', STORE)
        self.assertIn('reports.read', STORE)

    def test_supplier_lookup_is_scoped_and_authorized(self):
        self.assertIn('ListActiveSuppliers(', STORE)
        self.assertIn('Require(c, tx, userId, companyId, branchId, \"reports.read\")', STORE)
        self.assertIn("party_type IN('Supplier','Both')", STORE)

    def test_create_validates_supplier_and_branch_warehouse(self):
        self.assertIn("type is not (\"Supplier\" or \"Both\")", STORE)
        self.assertIn('branch_id=$br AND id=$id AND is_active=1', STORE)

    def test_sqlite_order_tables_accept_draft_and_enforce_constraints(self):
        with closing(sqlite3.connect(':memory:')) as db:
            db.executescript('''
            PRAGMA foreign_keys=ON;
            CREATE TABLE monarch_branches(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
            CREATE TABLE monarch_parties(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
            CREATE TABLE monarch_warehouses(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
            CREATE TABLE monarch_users(id TEXT PRIMARY KEY);
            CREATE TABLE monarch_items(company_id TEXT,id TEXT,PRIMARY KEY(company_id,id));
            CREATE TABLE monarch_company_audit_log(company_id TEXT,branch_id TEXT,actor_user_id TEXT,action TEXT,entity_type TEXT,entity_id TEXT,details TEXT,occurred_utc TEXT);
            ''')
            marker = '-- Purchase-order workflow.'
            db.executescript(SCHEMA[SCHEMA.index(marker):])
            db.execute("INSERT INTO monarch_branches VALUES('c','b')")
            db.execute("INSERT INTO monarch_parties VALUES('c','s')")
            db.execute("INSERT INTO monarch_warehouses VALUES('c','w')")
            db.execute("INSERT INTO monarch_users VALUES('u')")
            db.execute("INSERT INTO monarch_items VALUES('c','i')")
            db.execute("INSERT INTO monarch_purchase_orders(id,company_id,branch_id,order_number,supplier_id,warehouse_id,currency_code,currency_scale,created_utc,created_by) VALUES('o','c','b','PO-1','s','w','SAR',2,'now','u')")
            with self.assertRaises(sqlite3.IntegrityError):
                db.execute("UPDATE monarch_purchase_orders SET status='Unknown' WHERE id='o'")
            with self.assertRaises(sqlite3.IntegrityError):
                db.execute("INSERT INTO monarch_purchase_orders(id,company_id,branch_id,order_number,supplier_id,warehouse_id,currency_code,currency_scale,created_utc,created_by) VALUES('o2','c','b','po-1','s','w','SAR',2,'now','u')")
            db.execute("INSERT INTO monarch_purchase_order_lines(id,company_id,order_id,line_number,item_id,item_sku_snapshot,item_name_snapshot,quantity_milli,unit_cost_minor,tax_rate_bps,net_minor,tax_minor,total_minor) VALUES('l','c','o',1,'i','SKU','Item',1000,100,1500,100,15,115)")
            db.execute("UPDATE monarch_purchase_orders SET status='Approved' WHERE company_id='c' AND id='o'")
            with self.assertRaises(sqlite3.IntegrityError):
                db.execute("UPDATE monarch_purchase_order_lines SET unit_cost_minor=200 WHERE company_id='c' AND id='l'")

if __name__ == '__main__':
    unittest.main()
