from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'src/Monarch.Desktop/MainWindow.xaml.cs'


def section(start, end):
    source = SOURCE.read_text(encoding='utf-8')
    return source[source.index(start):source.index(end, source.index(start))]


def test_inbox_ui_exposes_persistent_refresh_and_separate_lifecycle_actions():
    source = SOURCE.read_text(encoding='utf-8')
    assert 'تحديث الصندوق المحفوظ' in source
    assert 'تسجيل مشاهدة الإشعار المحدد' in source
    assert 'الإقرار بالإشعار المحدد' in source
    assert 'LoadSupplierApPersistentInbox();' in source
    assert 'RecordSupplierApInboxLifecycle(false)' in source
    assert 'RecordSupplierApInboxLifecycle(true)' in source


def test_persistent_inbox_load_is_scoped_and_uses_durable_store():
    body = section('private void LoadSupplierApPersistentInbox()', 'private void RecordSupplierApInboxLifecycle')
    assert 'IdentityStore.Require(_session, "reports.read")' in body
    assert 'GetDelivered(_session.UserId, _ledgerSession.CompanyId' in body
    assert '_ledgerSession.BranchId' in body
    assert 'SupplierPayablesAlertInboxStore' in body
    assert 'item.Viewed' in body and 'item.Acknowledged' in body


def test_lifecycle_actions_use_selected_intent_and_do_not_touch_accounting():
    body = section('private void RecordSupplierApInboxLifecycle(bool acknowledge)', 'private void LoadSupplierApOperationalAlerts()')
    assert 'IdentityStore.Require(_session, "reports.read")' in body
    assert 'store.MarkViewed' in body and 'store.Acknowledge' in body
    assert 'journal_entries' not in body and 'PostPayment' not in body
    assert 'accounting_outbox' not in body


def test_inbox_selection_is_single_and_read_only():
    source = SOURCE.read_text(encoding='utf-8')
    assert '_supplierApInboxGrid.IsReadOnly = true;' in source
    assert '_supplierApInboxGrid.SelectionMode = DataGridSelectionMode.Single;' in source
