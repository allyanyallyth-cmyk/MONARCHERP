from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
CS = (ROOT / 'src/Monarch.Core/Commercial/InventoryValuationEngine.cs').read_text()

class InventoryValuationEngineContractTests(unittest.TestCase):
    def test_both_methods_and_result_contract_exist(self):
        self.assertIn('Fifo', CS)
        self.assertIn('MovingWeightedAverage', CS)
        self.assertIn('InventoryValuationResult', CS)
        self.assertIn('RemainingFifoLayers', CS)

    def test_deterministic_order_and_integer_minor_units(self):
        self.assertIn('OrderBy(x => x.Sequence).ThenBy(x => x.Id)', CS)
        self.assertIn('MidpointRounding.AwayFromZero', CS)
        self.assertIn('checked(', CS)

    def test_fifo_consumes_oldest_layer_first(self):
        self.assertIn('layers.First', CS)
        self.assertIn('layers.RemoveFirst()', CS)
        self.assertIn('ConsumeFifo(layers, m.QuantityMilli)', CS)

    def test_weighted_average_recalculates_after_receipt_and_issue(self):
        self.assertIn('Average(value, quantity)', CS)
        self.assertIn('Average(value, nextQty)', CS)
        self.assertIn('layers.Clear()', CS)

    def test_outbound_cannot_exceed_available_quantity(self):
        self.assertIn('m.QuantityMilli > quantity', CS)
        self.assertIn('Inventory valuation cannot issue more than the available quantity', CS)

    def test_movement_directions_are_explicit(self):
        self.assertIn('StockMovementType.SalesReturn', CS)
        self.assertIn('StockMovementType.PurchaseReturn', CS)
        self.assertIn('StockMovementType.TransferIn', CS)
        self.assertIn('StockMovementType.TransferOut', CS)

if __name__ == '__main__': unittest.main()
