from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPORTER = ROOT / "src/Monarch.Core/Autonomy/ProcurementAnalyticsHtmlReportExporter.cs"
UI = ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs"


def test_print_report_is_arabic_rtl_self_contained_and_print_friendly():
    source = EXPORTER.read_text(encoding="utf-8")
    assert 'lang=\\\"ar\\\" dir=\\\"rtl\\\"' in source
    assert "@page{size:A4 landscape" in source
    assert "@media print" in source
    assert "new UTF8Encoding(true)" in source
    assert "WebUtility.HtmlEncode" in source


def test_print_report_contains_all_three_procurement_analytics_datasets():
    source = EXPORTER.read_text(encoding="utf-8")
    for token in ("ProcurementSupplierItemPerformance", "ProcurementSupplierTrend", "ProcurementForecastHistoryRow"):
        assert token in source
    for label in ("أداء المورد حسب الصنف", "اتجاهات أداء الموردين", "السجل التاريخي لدقة التوقع"):
        assert label in source
    assert "Company:" in source and "Branch:" in source


def test_wpf_print_report_export_rechecks_permission_and_tenant_scope():
    source = UI.read_text(encoding="utf-8")
    assert "ExportProcurementAnalyticsPrintReport()" in source
    block = source[source.index("private void ExportProcurementAnalyticsPrintReport()"):source.index("private TabItem BuildSupplierPayablesTab()")]
    assert 'IdentityStore.Require(_session, "reports.read")' in block
    assert "_ledgerSession.CompanyId, _ledgerSession.BranchId" in block
    assert 'DefaultExt = ".html"' in block
    assert "ProcurementAnalyticsHtmlReportExporter.Export" in block


def test_report_supports_tenant_branding_and_embedded_png_jpeg_logo():
    source = EXPORTER.read_text(encoding="utf-8")
    assert 'string branchName = ""' in source
    assert "byte[]? logoImage = null" in source
    assert "BuildLogoDataUri(logoImage)" in source
    assert '"image/png"' in source and '"image/jpeg"' in source
    assert "2 * 1024 * 1024" in source
    assert "WebUtility.HtmlEncode(value ?? string.Empty)" in source
    assert 'class=\\"brand\\"' in source
    assert 'class=\\"report-footer\\"' in source
    assert "generatedAtUtc ?? DateTime.UtcNow" in source


def test_wpf_report_export_uses_active_company_branch_names_and_optional_logo():
    source = UI.read_text(encoding="utf-8")
    block = source[source.index("private void ExportProcurementAnalyticsPrintReport()"):source.index("private TabItem BuildSupplierPayablesTab()")]
    assert "OpenFileDialog" in block
    assert "MessageBoxButton.YesNoCancel" in block
    assert "_ledgerSession.CompanyName, _ledgerSession.BranchName, logoImage, DateTime.UtcNow" in block
    assert "logoInfo.Length > 2 * 1024 * 1024" in block
    assert "IdentityStore.Require(_session, \"reports.read\")" in block


def test_print_report_summarizes_alerts_and_avoids_fixed_footer_overlap():
    source = EXPORTER.read_text(encoding="utf-8")
    assert "reliableTrends" in source
    assert "criticalAlerts" in source and "warningAlerts" in source
    assert "مقارنات موثوقة" in source
    assert "ملخص التنبيهات" in source
    assert ".report-footer{position:static}" in source
    assert "page-break-inside:avoid" in source
