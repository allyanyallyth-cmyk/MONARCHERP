from pathlib import Path
import unittest
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'src/Monarch.Core/Commercial/SupplierPayablesAccountingOutboxWorker.cs').read_text(encoding='utf-8')
RECEIPT_WORKER = (ROOT / 'src/Monarch.Core/Commercial/CommercialAccountingOutboxWorker.cs').read_text(encoding='utf-8')
RETURN_STORE = (ROOT / 'src/Monarch.Core/Commercial/CommercialReturnStore.cs').read_text(encoding='utf-8')
RETURN_WORKER = (ROOT / 'src/Monarch.Core/Commercial/CommercialReturnAccountingOutboxWorker.cs').read_text(encoding='utf-8')


class SupplierPayablesAccountingWorkerTests(unittest.TestCase):
    def test_worker_consumes_both_dedicated_supplier_outboxes(self):
        self.assertIn('monarch_supplier_invoice_accounting_outbox', SOURCE)
        self.assertIn('monarch_supplier_payment_accounting_outbox', SOURCE)
        self.assertIn('processed_utc IS NULL', SOURCE)
        self.assertIn('attempts=attempts+1,last_error=$error', SOURCE)

    def test_invoice_journal_is_deterministic_and_posts_inventory_expense_tax_and_payables(self):
        self.assertIn('AUTO-SUP-INV-', SOURCE)
        self.assertIn('invoice.Subtotal', SOURCE)
        self.assertIn('GoodsReceivedNotInvoicedCode', SOURCE)
        self.assertIn('invoice.Tax', SOURCE)
        self.assertIn('invoice.Total', SOURCE)
        self.assertIn('GoodsReceivedNotInvoicedCode', RECEIPT_WORKER)
        self.assertIn('GoodsReceivedNotInvoicedCode', RETURN_WORKER)
        self.assertIn('AccountType.Asset', SOURCE)
        self.assertIn('AccountType.Liability', SOURCE)
        self.assertIn('AccountType.Liability', SOURCE)

    def test_payment_journal_debits_payables_and_credits_cash_or_bank(self):
        self.assertIn('AUTO-SUP-PAY-', SOURCE)
        self.assertIn('JournalLine.Debit(Require(map.PayablesCode, AccountType.Liability).Id, payment.AmountMinor)', SOURCE)
        self.assertIn('JournalLine.Credit(Require(payment.CashBankAccountCode, AccountType.Asset).Id, payment.AmountMinor)', SOURCE)
        self.assertIn('r.GetInt64(7) != r.GetInt64(4)', SOURCE)

    def test_worker_checks_posted_documents_and_line_reconciliation(self):
        self.assertIn('r.GetString(11) != "Posted"', SOURCE)
        self.assertIn('Supplier invoice header does not match its lines.', SOURCE)
        self.assertIn('Supplier payment allocations do not reconcile to its amount.', SOURCE)

    def test_payment_allocations_are_validated_against_supplier_branch_currency_and_posted_invoice(self):
        self.assertIn('LEFT JOIN monarch_supplier_payables ap', SOURCE)
        self.assertIn('ap.branch_id=p.branch_id AND i.branch_id=p.branch_id', SOURCE)
        self.assertIn('ap.supplier_id=p.supplier_id', SOURCE)
        self.assertIn('ap.currency_code=p.currency_code AND ap.currency_scale=p.currency_scale', SOURCE)
        self.assertIn("i.status='Posted'", SOURCE)
        self.assertIn('r.GetInt64(8) != r.GetInt64(9)', SOURCE)
        self.assertIn('allocation outside its supplier, branch, currency, or posted-invoice scope', SOURCE)

    def test_post_invoice_receipt_return_is_blocked_until_credit_note_workflow_exists(self):
        self.assertIn('monarch_supplier_invoice_lines', RETURN_STORE)
        self.assertIn('لا يمكن ترحيل مرتجع شراء بعد فوترة سند الاستلام', RETURN_STORE)

    def test_worker_blocks_foreign_currency_without_fx_policy(self):
        self.assertIn('RequireBaseCurrency', SOURCE)
        self.assertIn('minor_unit_exponent', SOURCE)
        self.assertIn('FX accounting is not enabled', SOURCE)

    def test_deterministic_journals_are_idempotent_and_authorized(self):
        self.assertIn('GetEntries(userId, companyId, branchId)', SOURCE)
        self.assertIn('existing.Status == JournalStatus.Posted', SOURCE)
        self.assertIn('EnsureJournalMatches(existing', SOURCE)
        self.assertIn('existing.Lines.SequenceEqual(expectedLines)', SOURCE)
        self.assertIn('_ledger.CreateDraft', SOURCE)
        self.assertIn('_ledger.Post', SOURCE)

    def test_worker_serializes_same_database_company_branch_within_process(self):
        self.assertIn('ConcurrentDictionary<string, SemaphoreSlim> ProcessingGates', SOURCE)
        self.assertIn('_databasePath, companyId.ToString("N"), branchId.ToString("N")', SOURCE)
        self.assertIn('gate.Wait();', SOURCE)
        self.assertIn('finally { gate.Release(); }', SOURCE)

    def test_cross_process_duplicate_guard_uses_deterministic_company_unique_journal_number(self):
        self.assertIn('AUTO-SUP-INV-', SOURCE)
        self.assertIn('AUTO-SUP-PAY-', SOURCE)
        schema = (ROOT / 'database/tenant-accounting.sql').read_text(encoding='utf-8')
        self.assertIn('UNIQUE(company_id,number)', schema)
        self.assertIn('EnsureJournalMatches(existing', SOURCE)

    def test_outbox_acknowledgement_remains_retry_safe_after_journal_commit(self):
        self.assertIn('AcknowledgeInvoice(item.Id, companyId, branchId, item.LeaseToken)', SOURCE)
        self.assertIn('AcknowledgePayment(item.Id, companyId, branchId, item.LeaseToken)', SOURCE)
        self.assertIn('if (existing.Status == JournalStatus.Posted) return;', SOURCE)
        self.assertIn('processed_utc IS NULL', SOURCE)


    def test_supplier_ap_outbox_uses_durable_claims_and_token_fenced_acknowledgement(self):
        self.assertIn('ClaimPendingInvoices(companyId, branchId, maxItems, leaseOwner)', SOURCE)
        self.assertIn('ClaimPendingPayments(companyId, branchId, maxItems, leaseOwner)', SOURCE)
        self.assertIn('lease_expires_utc<=$now', SOURCE)
        self.assertIn('lease_token=$token', SOURCE)
        self.assertIn('processed_utc IS NULL AND lease_token=$token AND lease_expires_utc>$now', SOURCE)
        self.assertIn('lease_token=NULL,lease_expires_utc=NULL', SOURCE)
        self.assertIn('now.AddMinutes(5)', SOURCE)
        self.assertGreaterEqual(SOURCE.count('var changed = q.ExecuteNonQuery();'), 2)
        self.assertIn('if (changed != 1)', SOURCE)

    def test_supplier_ap_outbox_lease_heartbeat_renews_invoice_and_payment_claims(self):
        self.assertIn('using var heartbeat = new Timer(', SOURCE)
        self.assertIn('TimeSpan.FromMinutes(1), TimeSpan.FromMinutes(1)', SOURCE)
        self.assertIn('RenewLeases(companyId, branchId, invoices, payments)', SOURCE)
        self.assertIn('lease_expires_utc=CASE WHEN lease_expires_utc<$until THEN $until ELSE lease_expires_utc END', SOURCE)

    def test_supplier_ap_heartbeat_is_fenced_and_never_resurrects_expired_or_stale_claims(self):
        self.assertGreaterEqual(SOURCE.count('processed_utc IS NULL AND lease_token=$token AND lease_expires_utc>$now'), 2)
        self.assertIn('catch (Exception ex)', SOURCE)
        self.assertIn('RecordDiagnostic(companyId, branchId, "heartbeat_failed"', SOURCE)

    def test_supplier_ap_outbox_lease_migration_is_explicit_and_additive(self):
        migration = (ROOT / 'database/migrations/2026-11-10-supplier-ap-outbox-leases.sql').read_text(encoding='utf-8')
        self.assertIn('ALTER TABLE monarch_supplier_invoice_accounting_outbox ADD COLUMN lease_token', migration)
        self.assertIn('ALTER TABLE monarch_supplier_payment_accounting_outbox ADD COLUMN lease_expires_utc', migration)
        self.assertIn('CREATE INDEX IF NOT EXISTS', migration)
        self.assertIn('Never execute automatically at application startup', migration)

    def test_fresh_commercial_schema_contains_supplier_ap_lease_fields(self):
        schema = (ROOT / 'database/commercial-data.sql').read_text(encoding='utf-8')
        self.assertGreaterEqual(schema.count('lease_token TEXT NULL'), 2)
        self.assertGreaterEqual(schema.count('lease_expires_utc TEXT NULL'), 2)
    def test_supplier_ap_lease_migration_executes_on_existing_outbox_tables(self):
        migration = (ROOT / 'database/migrations/2026-11-10-supplier-ap-outbox-leases.sql').read_text(encoding='utf-8')
        db = sqlite3.connect(':memory:')
        db.executescript('CREATE TABLE monarch_supplier_invoice_accounting_outbox(id TEXT,company_id TEXT,branch_id TEXT,processed_utc TEXT,created_utc TEXT); CREATE TABLE monarch_supplier_payment_accounting_outbox(id TEXT,company_id TEXT,branch_id TEXT,processed_utc TEXT,created_utc TEXT);')
        db.executescript(migration)
        for table in ('monarch_supplier_invoice_accounting_outbox','monarch_supplier_payment_accounting_outbox'):
            columns = {row[1] for row in db.execute(f'PRAGMA table_info({table})')}
            self.assertIn('lease_token', columns)
            self.assertIn('lease_expires_utc', columns)
        db.close()



class SupplierApLeaseCrashRecoveryIntegrationTests(unittest.TestCase):
    """SQLite execution tests for the SQL lease contract; not C# worker runtime tests."""

    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        self.db.execute('CREATE TABLE outbox(id TEXT PRIMARY KEY, company_id TEXT, branch_id TEXT, processed_utc TEXT, lease_token TEXT, lease_expires_utc TEXT, attempts INTEGER DEFAULT 0, last_error TEXT)')
        self.db.execute("INSERT INTO outbox(id,company_id,branch_id,processed_utc) VALUES('evt-1','co-1','br-1',NULL)")

    def tearDown(self):
        self.db.close()

    def claim(self, token, now, until):
        return self.db.execute("UPDATE outbox SET lease_token=?,lease_expires_utc=? WHERE id='evt-1' AND company_id='co-1' AND branch_id='br-1' AND processed_utc IS NULL AND (lease_expires_utc IS NULL OR lease_expires_utc<=?)", (token, until, now)).rowcount

    def renew(self, token, now, until):
        return self.db.execute("UPDATE outbox SET lease_expires_utc=CASE WHEN lease_expires_utc<? THEN ? ELSE lease_expires_utc END WHERE id='evt-1' AND company_id='co-1' AND branch_id='br-1' AND processed_utc IS NULL AND lease_token=? AND lease_expires_utc>?", (until, until, token, now)).rowcount

    def finish(self, token, now, success=True):
        if success:
            sql = "UPDATE outbox SET processed_utc=?,lease_token=NULL,lease_expires_utc=NULL WHERE id='evt-1' AND company_id='co-1' AND branch_id='br-1' AND processed_utc IS NULL AND lease_token=? AND lease_expires_utc>?"
            args = (now, token, now)
        else:
            sql = "UPDATE outbox SET attempts=attempts+1,last_error='failed',lease_token=NULL,lease_expires_utc=NULL WHERE id='evt-1' AND company_id='co-1' AND branch_id='br-1' AND processed_utc IS NULL AND lease_token=? AND lease_expires_utc>?"
            args = (token, now)
        return self.db.execute(sql, args).rowcount

    def row(self):
        return self.db.execute('SELECT processed_utc,lease_token,lease_expires_utc,attempts,last_error FROM outbox').fetchone()

    def test_worker_b_cannot_claim_before_expiry_then_takes_over_after_expiry(self):
        self.assertEqual(self.claim('worker-A', '2026-11-10T10:00:00Z', '2026-11-10T10:05:00Z'), 1)
        self.assertEqual(self.claim('worker-B', '2026-11-10T10:04:59Z', '2026-11-10T10:09:59Z'), 0)
        self.assertEqual(self.claim('worker-B', '2026-11-10T10:05:00Z', '2026-11-10T10:10:00Z'), 1)
        self.assertEqual(self.row()[1], 'worker-B')

    def test_stale_worker_a_cannot_renew_acknowledge_or_fail_after_takeover(self):
        self.claim('worker-A', '2026-11-10T10:00:00Z', '2026-11-10T10:05:00Z')
        self.claim('worker-B', '2026-11-10T10:05:00Z', '2026-11-10T10:10:00Z')
        self.assertEqual(self.renew('worker-A', '2026-11-10T10:05:01Z', '2026-11-10T10:10:01Z'), 0)
        self.assertEqual(self.finish('worker-A', '2026-11-10T10:05:01Z', True), 0)
        self.assertEqual(self.finish('worker-A', '2026-11-10T10:05:01Z', False), 0)
        self.assertEqual(self.row()[1], 'worker-B')

    def test_expired_owner_cannot_ack_or_fail_even_before_another_worker_claims(self):
        self.claim('worker-A', '2026-11-10T10:00:00Z', '2026-11-10T10:05:00Z')
        self.assertEqual(self.finish('worker-A', '2026-11-10T10:05:01Z', True), 0)
        self.assertEqual(self.finish('worker-A', '2026-11-10T10:05:01Z', False), 0)
        self.assertIsNone(self.row()[0])
        self.assertEqual(self.row()[1], 'worker-A')

    def test_current_owner_can_renew_and_acknowledge(self):
        self.claim('worker-B', '2026-11-10T10:00:00Z', '2026-11-10T10:05:00Z')
        self.assertEqual(self.renew('worker-B', '2026-11-10T10:02:00Z', '2026-11-10T10:07:00Z'), 1)
        self.assertEqual(self.finish('worker-B', '2026-11-10T10:06:00Z', True), 1)
        self.assertIsNotNone(self.row()[0])

    def test_late_heartbeat_cannot_shorten_a_newer_expiry(self):
        self.claim('worker-A', '2026-11-10T10:00:00Z', '2026-11-10T10:05:00Z')
        self.assertEqual(self.renew('worker-A', '2026-11-10T10:02:00Z', '2026-11-10T10:07:00Z'), 1)
        self.assertEqual(self.renew('worker-A', '2026-11-10T10:01:00Z', '2026-11-10T10:06:00Z'), 1)
        self.assertEqual(self.row()[2], '2026-11-10T10:07:00Z')

class SupplierApWorkerHealthTelemetryTests(unittest.TestCase):
    def test_worker_exposes_process_local_thread_safe_health_snapshot(self):
        self.assertIn('SupplierPayablesWorkerHealthSnapshot', SOURCE)
        self.assertIn('GetHealthSnapshot()', SOURCE)
        self.assertIn('Interlocked.Read(ref _heartbeatFailures)', SOURCE)
        self.assertIn('Interlocked.Read(ref _leaseOwnershipLosses)', SOURCE)

    def test_worker_counts_claims_heartbeat_failures_renewals_and_finalization(self):
        for counter in ('_invoiceClaims', '_paymentClaims', '_heartbeatTicks', '_heartbeatFailures',
                        '_leaseRenewals', '_leaseOwnershipLosses', '_acknowledgements', '_failureUpdates'):
            self.assertIn(counter, SOURCE)
        self.assertIn('Interlocked.Increment(ref _heartbeatFailures)', SOURCE)
        self.assertIn('Interlocked.Increment(ref _leaseRenewals)', SOURCE)
        self.assertGreaterEqual(SOURCE.count('Interlocked.Increment(ref _leaseOwnershipLosses)'), 2)

    def test_health_metrics_are_diagnostic_only_and_do_not_change_lease_authority(self):
        self.assertIn('lease_token=$token AND lease_expires_utc>$now', SOURCE)
        self.assertIn('GetHealthSnapshot()', SOURCE)
        self.assertIn('deterministic', SOURCE.lower())
