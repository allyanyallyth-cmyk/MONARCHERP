from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPORTER = ROOT / "src/Monarch.Core/Autonomy/ProcurementAnalyticsCsvExporter.cs"
UI = ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs"


def test_csv_exporter_covers_all_three_procurement_analytics_reports():
    source = EXPORTER.read_text(encoding="utf-8")
    for method in (
        "ExportSupplierItemPerformance", "ExportSupplierTrends", "ExportForecastHistory"
    ):
        assert f"byte[] {method}(" in source
    assert "SupplierItemPerformance" in source
    assert "ProcurementSupplierTrend" in source
    assert "ProcurementForecastHistoryRow" in source


def test_csv_export_is_excel_friendly_and_uses_invariant_numeric_formatting():
    source = EXPORTER.read_text(encoding="utf-8")
    assert "new UTF8Encoding(true)" in source
    assert 'output.Append("\\r\\n")' in source
    assert "CultureInfo.InvariantCulture" in source
    assert 'value.Replace("\\\"", "\\\"\\\"")' in source


def test_csv_export_neutralizes_spreadsheet_formula_injection_in_text_cells():
    source = EXPORTER.read_text(encoding="utf-8")
    for marker in ("first[0] == '='", "first[0] == '+'", "first[0] == '-'", "first[0] == '@'"):
        assert marker in source
    assert 'value = "\'" + value' in source
    assert "trustedNumeric" in source
    assert '"\\u0001" + value.ToString(CultureInfo.InvariantCulture)' in source


def test_wpf_exposes_csv_exports_and_rechecks_report_permission_and_tenant_scope():
    source = UI.read_text(encoding="utf-8")
    for report in ("supplier-items", "supplier-trends", "forecast-history"):
        assert f'ExportProcurementAnalyticsCsv("{report}")' in source
    block = source[source.index("private void ExportProcurementAnalyticsCsv("):source.index("private TabItem BuildSupplierPayablesTab()")]
    assert 'IdentityStore.Require(_session, "reports.read")' in block
    assert "_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, from, to" in block
    assert "File.WriteAllBytes(dialog.FileName, content)" in block
    assert "SaveFileDialog" in block
