from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")


def test_in_app_inbox_is_permission_gated_and_uses_active_user_scope():
    section = SOURCE[SOURCE.index("private void LoadSupplierApInbox()"):SOURCE.index("private void LoadSupplierApOperationalAlerts()")]
    assert 'IdentityStore.Require(_session, "reports.read")' in section
    assert "ClaimDue(_session.UserId, _ledgerSession.CompanyId" in section
    assert "_ledgerSession.BranchId" in section
    assert "limit: 50" in section


def test_inbox_confirms_delivery_only_after_binding_and_keeps_read_state_distinct():
    section = SOURCE[SOURCE.index("private void LoadSupplierApInbox()"):SOURCE.index("private void LoadSupplierApOperationalAlerts()")]
    assert section.index("_supplierApInboxGrid.ItemsSource = rows") < section.index("CompleteAttempt")
    assert 'delivered: true' in section
    assert "لا يمثل إثبات قراءة" in section


def test_failed_ui_presentation_schedules_bounded_retry_and_does_not_drop_claims():
    section = SOURCE[SOURCE.index("private void LoadSupplierApInbox()"):SOURCE.index("private void LoadSupplierApOperationalAlerts()")]
    assert 'delivered: false, errorCode: "UI_PRESENTATION_FAILED"' in section
    assert "LeaseExpiresUtc" not in section  # lease expiry remains authoritative recovery


def test_inbox_does_not_run_accounting_or_outbox_workers():
    section = SOURCE[SOURCE.index("private void LoadSupplierApInbox()"):SOURCE.index("private void LoadSupplierApOperationalAlerts()")]
    assert ".Process(" not in section
    assert "PostPayment(" not in section
    assert "PostJournal" not in section
