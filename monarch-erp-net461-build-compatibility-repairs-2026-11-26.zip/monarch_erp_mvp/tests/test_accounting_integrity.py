"""SQLite integration tests for MONARCH journal safeguards (Python stdlib only)."""
from pathlib import Path
import sqlite3
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "database" / "schema.sql"


class JournalIntegrityTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.db.executescript(SCHEMA.read_text(encoding="utf-8"))
        self.db.executemany(
            "INSERT INTO accounts(id, code, name_ar, account_type, is_active) VALUES (?, ?, ?, ?, ?)",
            [
                ("cash", "1000", "الصندوق", "Asset", 1),
                ("sales", "4000", "المبيعات", "Revenue", 1),
                ("inactive", "1999", "حساب غير نشط", "Asset", 0),
            ],
        )

    def tearDown(self):
        self.db.close()

    def entry(self, entry_id="J1", reversal_of_id=None, status="Draft"):
        self.db.execute(
            """INSERT INTO journal_entries
               (id, entry_number, business_date, description, status, reversal_of_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (entry_id, entry_id, "2026-11-05", "اختبار", status, reversal_of_id, "2026-11-05T10:00:00Z"),
        )

    def line(self, entry_id, line_id, account, debit, credit):
        self.db.execute(
            """INSERT INTO journal_entry_lines
               (id, journal_entry_id, account_id, debit, credit)
               VALUES (?, ?, ?, ?, ?)""",
            (line_id, entry_id, account, debit, credit),
        )

    def standard_entry(self, entry_id="J1"):
        self.entry(entry_id)
        self.line(entry_id, f"{entry_id}-L1", "cash", 100, 0)
        self.line(entry_id, f"{entry_id}-L2", "sales", 0, 100)

    def post(self, entry_id):
        self.db.execute("UPDATE journal_entries SET status='Posted' WHERE id=?", (entry_id,))

    def test_balanced_entry_can_be_posted(self):
        self.standard_entry()
        self.post("J1")
        self.assertEqual(self.db.execute("SELECT status FROM journal_entries WHERE id='J1'").fetchone()[0], "Posted")

    def test_unbalanced_entry_is_rejected(self):
        self.entry()
        self.line("J1", "L1", "cash", 100, 0)
        self.line("J1", "L2", "sales", 0, 90)
        with self.assertRaisesRegex(sqlite3.IntegrityError, "not balanced"):
            self.post("J1")

    def test_single_line_entry_is_rejected(self):
        self.entry()
        self.line("J1", "L1", "cash", 100, 0)
        with self.assertRaisesRegex(sqlite3.IntegrityError, "at least two lines"):
            self.post("J1")

    def test_zero_value_line_is_rejected(self):
        self.entry()
        with self.assertRaisesRegex(sqlite3.IntegrityError, "CHECK constraint failed"):
            self.line("J1", "L0", "cash", 0, 0)

    def test_inactive_account_is_rejected(self):
        self.entry()
        self.line("J1", "L1", "inactive", 100, 0)
        self.line("J1", "L2", "sales", 0, 100)
        with self.assertRaisesRegex(sqlite3.IntegrityError, "Inactive account"):
            self.post("J1")

    def test_non_draft_entry_cannot_be_inserted(self):
        with self.assertRaisesRegex(sqlite3.IntegrityError, "created as Draft"):
            self.entry(status="Posted")

    def test_invalid_status_transition_is_rejected(self):
        self.entry()
        with self.assertRaisesRegex(sqlite3.IntegrityError, "Invalid journal status transition"):
            self.db.execute("UPDATE journal_entries SET status='Reversed' WHERE id='J1'")

    def test_posted_entry_cannot_be_marked_reversed_without_inverse(self):
        self.standard_entry()
        self.post("J1")
        with self.assertRaisesRegex(sqlite3.IntegrityError, "Post a matching reversal"):
            self.db.execute("UPDATE journal_entries SET status='Reversed' WHERE id='J1'")

    def test_reversal_must_reference_a_posted_journal(self):
        self.entry("DRAFT-ORIGINAL")
        with self.assertRaisesRegex(sqlite3.IntegrityError, "Only a posted journal"):
            self.entry("REV-1", reversal_of_id="DRAFT-ORIGINAL")

    def test_reversal_must_match_original_by_account(self):
        self.standard_entry()
        self.post("J1")
        self.entry("REV-1", reversal_of_id="J1")
        self.line("REV-1", "R1", "cash", 0, 90)
        self.line("REV-1", "R2", "sales", 90, 0)
        with self.assertRaisesRegex(sqlite3.IntegrityError, "exactly invert"):
            self.post("REV-1")

    def test_valid_reversal_posts_before_original_is_marked_reversed(self):
        self.standard_entry()
        self.post("J1")
        self.entry("REV-1", reversal_of_id="J1")
        self.line("REV-1", "R1", "cash", 0, 100)
        self.line("REV-1", "R2", "sales", 100, 0)
        self.post("REV-1")
        self.db.execute("UPDATE journal_entries SET status='Reversed' WHERE id='J1'")
        states = dict(self.db.execute("SELECT id, status FROM journal_entries"))
        self.assertEqual(states, {"J1": "Reversed", "REV-1": "Posted"})

    def test_only_one_reversal_can_be_created(self):
        self.standard_entry()
        self.post("J1")
        self.entry("REV-1", reversal_of_id="J1")
        with self.assertRaises(sqlite3.IntegrityError):
            self.entry("REV-2", reversal_of_id="J1")

    def test_posted_lines_and_header_are_immutable_and_entry_cannot_be_deleted(self):
        self.standard_entry()
        self.post("J1")
        with self.assertRaisesRegex(sqlite3.IntegrityError, "only be added to draft"):
            self.line("J1", "L3", "cash", 1, 0)
        with self.assertRaisesRegex(sqlite3.IntegrityError, "Only draft journal lines"):
            self.db.execute("UPDATE journal_entry_lines SET debit=99 WHERE id='J1-L1'")
        with self.assertRaisesRegex(sqlite3.IntegrityError, "immutable"):
            self.db.execute("UPDATE journal_entries SET description='تعديل' WHERE id='J1'")
        with self.assertRaisesRegex(sqlite3.IntegrityError, "cannot be deleted"):
            self.db.execute("DELETE FROM journal_entries WHERE id='J1'")


if __name__ == "__main__":
    unittest.main(verbosity=2)
