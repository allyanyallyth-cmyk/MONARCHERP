from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_export_audit_store_is_hash_chained_and_verifiable():
    source = (ROOT / "src/Monarch.Core/Autonomy/ProcurementReportExportAuditStore.cs").read_text(encoding="utf-8")
    assert "public static string Append(" in source
    assert "public static bool Verify(" in source
    assert "SHA256.Create()" in source
    assert "GetLastHashOrThrow" in source
    assert "append was blocked" in source
    assert "content.Length" in source


def test_all_procurement_export_formats_record_successful_exports():
    source = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
    assert 'RecordProcurementReportExport(report, "CSV"' in source
    assert 'RecordProcurementReportExport("procurement-analytics", "XLSX"' in source
    assert 'RecordProcurementReportExport("procurement-analytics", "HTML"' in source
    assert '"MONARCH ERP", "Audit", "procurement-report-exports.log"' in source


def test_export_audit_is_tenant_branch_and_user_scoped():
    source = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
    assert "_session.UserId, _ledgerSession.CompanyId" in source
    assert "_ledgerSession.BranchId, reportType, format" in source


def test_export_audit_reader_parses_verified_entries_and_filters_tenant_branch():
    source = (ROOT / "src/Monarch.Core/Autonomy/ProcurementReportExportAuditStore.cs").read_text(encoding="utf-8")
    assert "ReadEntries(" in source
    assert "companyId.HasValue" in source and "branchId.HasValue" in source
    assert "DateOnly.ParseExact" in source
    assert "Verify(auditPath, out _)" in source


def test_export_audit_verified_csv_export_protects_spreadsheet_formulas():
    source = (ROOT / "src/Monarch.Core/Autonomy/ProcurementReportExportAuditStore.cs").read_text(encoding="utf-8")
    assert "ExportVerifiedCsv(" in source
    assert "IndexOf(safe[0])" in source
    assert "safe = \"'\" + safe" in source
    assert "ContentSha256" in source and "ChainHash" in source


def test_export_audit_center_is_permission_gated_and_tenant_branch_scoped():
    source = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
    assert 'tabs.Items.Add(BuildProcurementExportAuditTab())' in source
    assert 'IdentityStore.Require(_session, "reports.read")' in source
    assert 'ReadEntries(path, _ledgerSession.CompanyId, _ledgerSession.BranchId' in source
    assert 'ExportVerifiedCsv(path, dialog.FileName, _ledgerSession.CompanyId, _ledgerSession.BranchId' in source
