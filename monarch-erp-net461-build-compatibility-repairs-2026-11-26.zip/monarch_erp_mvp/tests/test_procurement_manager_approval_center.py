import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
UI = (ROOT / 'src/Monarch.Desktop/MainWindow.xaml.cs').read_text(encoding='utf-8')
STORE = (ROOT / 'src/Monarch.Core/Autonomy/ProcurementApprovalQueueStore.cs').read_text(encoding='utf-8')


def test_manager_approval_tab_is_permission_gated_and_tenant_scoped():
    assert 'HasPermission("commercial.purchases.approve")' in UI
    assert 'BuildProcurementApprovalTab()' in UI
    assert 'ListPending(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId)' in UI


def test_manager_center_displays_commercial_context_and_rationale():
    for token in ('OrderNumber', 'SupplierName', 'CurrencyCode', 'TotalMinor', 'ExpectedAt', 'Rationale'):
        assert token in STORE
        assert token in UI
    assert 'JOIN monarch_parties p' in STORE
    assert 'po.branch_id=q.branch_id' in STORE


def test_manager_decisions_use_authorized_atomic_queue_store():
    assert 'new ProcurementApprovalQueueStore(_databasePath).Decide' in UI
    assert 'commercial.purchases.approve' in STORE
    assert 'BeginTransaction()' in STORE
    assert 'AutonomousPurchaseOrderApproved' in STORE
    assert 'AutonomousPurchaseOrderRejected' in STORE
    assert 'يجب تسجيل سبب الرفض' in UI


def test_manager_center_does_not_auto_apply_schema_migrations():
    start = UI.index('private TabItem BuildProcurementApprovalTab()')
    end = UI.index('private TabItem BuildSupplierPayablesTab()', start)
    assert '.Initialize(' not in UI[start:end]
    assert 'CommercialSchemaUpgradeService' not in UI[start:end]
