from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
SERVICE = ROOT / 'src/Monarch.Core/Commercial/CommercialSchemaUpgradeService.cs'
STORE = ROOT / 'src/Monarch.Core/Commercial/CommercialStore.cs'
DESKTOP = ROOT / 'src/Monarch.Desktop/MainWindow.xaml.cs'

class CommercialSchemaUpgradeServiceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = SERVICE.read_text(encoding='utf-8')
        cls.store = STORE.read_text(encoding='utf-8')
        cls.desktop = DESKTOP.read_text(encoding='utf-8')

    def test_inspect_uses_read_only_database_connection(self):
        inspect = self.source.split('public CommercialSchemaUpgradePlan Inspect', 1)[1].split('public CommercialSchemaUpgradeResult Apply', 1)[0]
        self.assertIn('Open(_databasePath, true)', inspect)
        self.assertNotRegex(inspect, r'ExecuteNonQuery\s*\(')

    def test_apply_requires_explicit_confirmation_and_backup_path(self):
        apply = self.source.split('public CommercialSchemaUpgradeResult Apply', 1)[1]
        self.assertIn('if (!confirmApply) throw', apply)
        self.assertIn('A safety backup path is required', apply)
        self.assertIn('if (File.Exists(backup)) throw', apply)

    def test_backup_is_created_and_verified_before_initialize(self):
        apply = self.source.split('public CommercialSchemaUpgradeResult Apply', 1)[1]
        self.assertLess(apply.index('CopyDatabase(_databasePath, backup)'), apply.index('new CommercialStore(_databasePath).Initialize(schemaPath)'))
        self.assertLess(apply.index('Integrity(backup)'), apply.index('new CommercialStore(_databasePath).Initialize(schemaPath)'))

    def test_failure_path_restores_from_backup(self):
        self.assertRegex(self.source, r'catch\s*\{\s*RestoreDatabase\(backup, _databasePath\);\s*throw;')
        self.assertIn('Automatic rollback copy did not pass SQLite integrity_check', self.source)

    def test_startup_does_not_run_commercial_initializer(self):
        self.assertNotRegex(self.desktop, r'new CommercialStore\([^)]*\)\s*\.Initialize')
        self.assertIn('store.GetItems(', self.desktop)
        self.assertIn('store.GetWarehouses(', self.desktop)

    def test_schema_inspection_counts_required_tables_from_schema_file(self):
        self.assertIn('CREATE\\s+TABLE\\s+IF\\s+NOT\\s+EXISTS', self.source)
        self.assertIn('MissingTables', self.source)
        self.assertIn('NeedsMovementSequenceUpgrade', self.source)

if __name__ == '__main__':
    unittest.main()
