from pathlib import Path
import re
import sqlite3
import unittest

ROOT = Path(__file__).resolve().parents[1]
STORE = (ROOT / "src/Monarch.Core/Commercial/CommercialStore.cs").read_text(encoding="utf-8")
SECURITY = (ROOT / "database/security.sql").read_text(encoding="utf-8")
MIGRATION = (ROOT / "database/migrations/2026-11-08-inventory-operation-permissions.sql").read_text(encoding="utf-8")


class InventoryOperationAuthorizationTests(unittest.TestCase):
    def test_direct_movement_authorization_runs_inside_mutation_transaction(self):
        body = STORE.split("public void RecordMovement(", 1)[1].split("public void TransferStock(", 1)[0]
        self.assertIn("using var tx=c.BeginTransaction();", body)
        self.assertIn("RequireBranch(c, tx, userId, companyId, branchId, true);", body)
        self.assertLess(body.index("RequireBranch(c, tx"), body.index("INSERT INTO monarch_stock_movements"))
        self.assertLess(body.index("InsertInventoryAudit(c, tx"), body.index("tx.Commit()"))

    def test_transfer_requires_explicit_permission_for_both_branches(self):
        body = STORE.split("public void TransferStock(", 1)[1].split("private static long CalculateCurrentMovingAverageCost", 1)[0]
        self.assertEqual(body.count("RequireBranch(c, tx, userId, companyId,"), 2)
        self.assertIn("sourceBranchId, true", body)
        self.assertIn("targetBranchId, true", body)

    def test_permission_query_checks_active_identity_membership_and_scope(self):
        helper = STORE.split("private static void RequireBranch(", 1)[1].split("private static long NextMovementSequence", 1)[0]
        for term in ("u.is_active=1", "ca.is_active=1", "ba.is_active=1", "co.is_active=1", "b.is_active=1", "monarch_user_roles", "monarch_role_permissions", "$permission"):
            self.assertIn(term, helper)
        self.assertIn('write ? "inventory.movements.manage" : "inventory.read"', helper)

    def test_permissions_are_seeded_for_new_databases_and_existing_database_migration(self):
        for source in (SECURITY, MIGRATION):
            self.assertIn("inventory.read", source)
            self.assertIn("inventory.movements.manage", source)
            self.assertIn("role-admin", source)
            self.assertIn("role-accountant", source)
            self.assertIn("role-viewer", source)
        self.assertIn("INSERT OR IGNORE", MIGRATION)

    def test_permission_grants_default_to_admin_only_for_stock_mutations(self):
        grants = re.findall(r"\('([^']+)','inventory\.movements\.manage'\)", MIGRATION)
        self.assertEqual(grants, ["role-admin"])
        reads = re.findall(r"\('([^']+)','inventory\.read'\)", MIGRATION)
        self.assertEqual(set(reads), {"role-admin", "role-accountant", "role-viewer"})

    def test_migration_is_explicit_and_not_auto_applied(self):
        self.assertIn("Apply explicitly", MIGRATION)
        self.assertNotIn("2026-11-08-inventory-operation-permissions.sql", (ROOT / "src/Monarch.Core/Commercial/CommercialStore.cs").read_text())


if __name__ == "__main__":
    unittest.main()
