from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src/Monarch.Core/Autonomy/SqliteAuthorizedErpQueryExecutor.cs"


def test_executor_rechecks_permission_inside_query_transaction():
    text = SOURCE.read_text(encoding="utf-8")
    assert "connection.BeginTransaction()" in text
    assert "RequirePermission(connection, transaction, scope" in text
    assert "JOIN monarch_user_company_access" in text
    assert "JOIN monarch_user_branch_access" in text
    assert "JOIN monarch_role_permissions" in text


def test_executor_fails_closed_on_unsupported_intents_and_scope_mismatch():
    text = SOURCE.read_text(encoding="utf-8")
    assert "request.CompanyId != scope.CompanyId" in text
    assert "request.BranchId != scope.BranchId" in text
    assert "This intent is not yet backed by a tenant-safe SQLite query" in text


def test_zatca_query_is_parameterized_and_tenant_filtered():
    text = SOURCE.read_text(encoding="utf-8")
    assert "WHERE o.company_id=$company AND o.branch_id=$branch" in text
    assert 'command.Parameters.AddWithValue("$company"' in text
    assert 'command.Parameters.AddWithValue("$branch"' in text
    assert "LIMIT 500" in text
    assert "request.IntentCode != \"ZatcaPendingInvoices\"" in text


def test_executor_is_read_only_and_returns_structured_rows():
    text = SOURCE.read_text(encoding="utf-8")
    assert "ErpQueryResult(request.IntentCode, \"Success\"" in text
    assert '["invoiceNumber"]' in text
    assert '["submissionStatus"]' in text
    assert "UPDATE " not in text
    assert "DELETE " not in text
