import pathlib
import sqlite3

ROOT = pathlib.Path(__file__).resolve().parents[1]
MIGRATION = ROOT / "database/migrations/2026-11-07-autonomous-procurement-approval.sql"
STORE = ROOT / "src/Monarch.Core/Autonomy/ProcurementApprovalQueueStore.cs"


def database():
    c = sqlite3.connect(":memory:")
    c.executescript("""
    PRAGMA foreign_keys=ON;
    CREATE TABLE monarch_permissions(code TEXT PRIMARY KEY, description TEXT NOT NULL);
    CREATE TABLE monarch_roles(id TEXT PRIMARY KEY, code TEXT UNIQUE, name TEXT);
    CREATE TABLE monarch_role_permissions(role_id TEXT, permission_code TEXT, PRIMARY KEY(role_id,permission_code));
    CREATE TABLE monarch_users(id TEXT PRIMARY KEY);
    CREATE TABLE monarch_branches(company_id TEXT,id TEXT,is_active INTEGER,PRIMARY KEY(company_id,id));
    CREATE TABLE monarch_purchase_orders(id TEXT,company_id TEXT,branch_id TEXT,status TEXT,approved_by TEXT,PRIMARY KEY(company_id,id));
    CREATE TABLE monarch_user_company_access(user_id TEXT,company_id TEXT,is_active INTEGER);
    CREATE TABLE monarch_user_branch_access(user_id TEXT,company_id TEXT,branch_id TEXT,is_active INTEGER);
    CREATE TABLE monarch_user_roles(user_id TEXT,role_id TEXT);
    CREATE TABLE monarch_company_audit_log(company_id TEXT,branch_id TEXT,actor_user_id TEXT,action TEXT,entity_type TEXT,entity_id TEXT,details TEXT,occurred_utc TEXT);
    CREATE TABLE monarch_companies(id TEXT,is_active INTEGER);
    CREATE TABLE monarch_purchase_order_lines(company_id TEXT,order_id TEXT);
    INSERT INTO monarch_roles VALUES('role-admin','Administrator','Admin');
    INSERT INTO monarch_users VALUES('creator'),('manager'),('unauthorized');
    INSERT INTO monarch_companies VALUES('co',1);
    INSERT INTO monarch_branches VALUES('co','br',1);
    INSERT INTO monarch_purchase_orders VALUES('po','co','br','Draft',NULL);
    INSERT INTO monarch_purchase_order_lines VALUES('co','po');
    INSERT INTO monarch_user_company_access VALUES('creator','co',1),('manager','co',1),('unauthorized','co',1);
    INSERT INTO monarch_user_branch_access VALUES('creator','co','br',1),('manager','co','br',1),('unauthorized','co','br',1);
    INSERT INTO monarch_user_roles VALUES('manager','role-admin');
    """)
    c.executescript(MIGRATION.read_text(encoding="utf-8"))
    return c


def test_migration_creates_dedicated_manager_permission_and_queue():
    c = database()
    assert c.execute("SELECT 1 FROM monarch_permissions WHERE code='commercial.purchases.approve'").fetchone()
    assert c.execute("SELECT 1 FROM monarch_role_permissions WHERE role_id='role-admin' AND permission_code='commercial.purchases.approve'").fetchone()
    cols = {row[1] for row in c.execute("PRAGMA table_info(monarch_procurement_approval_queue)")}
    assert {'assigned_permission_code', 'status', 'rationale', 'decided_by', 'decided_utc'} <= cols


def test_autonomous_draft_cannot_be_approved_outside_queue_decision():
    c = database()
    c.execute("INSERT INTO monarch_procurement_approval_queue(id,company_id,branch_id,purchase_order_id,rationale,created_by,created_utc) VALUES('q','co','br','po','forecast reorder','creator','2026-11-07T00:00:00Z')")
    try:
        c.execute("UPDATE monarch_purchase_orders SET status='Approved',approved_by='manager' WHERE company_id='co' AND id='po'")
        assert False, 'direct approval must be blocked'
    except sqlite3.IntegrityError as exc:
        assert 'requires an authorized approval-queue decision' in str(exc)


def test_queue_decision_is_required_and_must_match_approver():
    c = database()
    c.execute("INSERT INTO monarch_procurement_approval_queue(id,company_id,branch_id,purchase_order_id,rationale,created_by,created_utc) VALUES('q','co','br','po','forecast reorder','creator','2026-11-07T00:00:00Z')")
    c.execute("UPDATE monarch_procurement_approval_queue SET status='Approved',decided_by='manager',decided_utc='2026-11-07T00:01:00Z' WHERE id='q'")
    c.execute("UPDATE monarch_purchase_orders SET status='Approved',approved_by='manager' WHERE company_id='co' AND id='po'")
    assert c.execute("SELECT status FROM monarch_purchase_orders WHERE id='po'").fetchone()[0] == 'Approved'


def test_final_queue_decision_is_immutable():
    c = database()
    c.execute("INSERT INTO monarch_procurement_approval_queue(id,company_id,branch_id,purchase_order_id,rationale,created_by,created_utc,status,decided_by,decided_utc) VALUES('q','co','br','po','forecast reorder','creator','2026-11-07T00:00:00Z','Rejected','manager','2026-11-07T00:01:00Z')")
    try:
        c.execute("UPDATE monarch_procurement_approval_queue SET status='Approved' WHERE id='q'")
        assert False, 'terminal decision must be immutable'
    except sqlite3.IntegrityError as exc:
        assert 'decision is immutable' in str(exc)


def test_csharp_store_uses_permission_scope_and_single_transaction_for_decision():
    source = STORE.read_text(encoding='utf-8')
    assert 'commercial.purchases.approve' in source
    assert 'BeginTransaction()' in source
    assert 'AutonomousPurchaseOrderQueued' in source
    assert 'AutonomousPurchaseOrderApproved' in source
    assert "status='Draft'" in source and "status='Pending'" in source
    assert 'monarch_user_company_access' in source and 'monarch_user_branch_access' in source
