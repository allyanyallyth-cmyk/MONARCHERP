from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
STORE = ROOT / "src/Monarch.Core/Autonomy/ProcurementAnalyticsStore.cs"
MIGRATION = ROOT / "database/migrations/2026-11-08-procurement-analytics-indexes.sql"


def test_analytics_store_is_read_only_tenant_scoped_and_permission_gated():
    source = STORE.read_text(encoding="utf-8")
    assert "RequireReportPermission(c, tx, userId, companyId, branchId)" in source
    assert "rp.permission_code='reports.read'" in source
    assert "d.company_id=$co AND d.branch_id=$br" in source
    assert "po.company_id=$co AND po.branch_id=$br" in source
    assert "m.company_id=$co AND m.branch_id=$br" in source
    assert "INSERT INTO" not in source and "UPDATE " not in source and "DELETE FROM" not in source


def test_analytics_exposes_decision_delivery_and_consumption_metrics_without_fabricating_forecast_accuracy():
    source = STORE.read_text(encoding="utf-8")
    assert "AverageDecisionHours" in source
    assert "RejectionRate" in source
    assert "AverageCompletionLeadTimeDays" in source
    assert "OnTimeRate" in source
    assert "IssuedQuantityMilli" in source
    assert "ForecastAccuracyAvailable" in source
    assert "forecastAccuracy != null" in source
    assert "WAPE" in source
    assert "movement_type IN('Issue','TransferOut','PurchaseReturn')" in source


def test_analytics_index_migration_is_additive_and_idempotent():
    c = sqlite3.connect(":memory:")
    c.executescript("""
    CREATE TABLE monarch_procurement_decision_history(company_id TEXT,branch_id TEXT,decided_utc TEXT,decision TEXT,purchase_order_id TEXT);
    CREATE TABLE monarch_purchase_receipts(company_id TEXT,branch_id TEXT,posted_utc TEXT,purchase_order_id TEXT);
    CREATE TABLE monarch_stock_movements(company_id TEXT,branch_id TEXT,occurred_utc TEXT,movement_type TEXT,item_id TEXT);
    CREATE TABLE monarch_purchase_receipt_lines(company_id TEXT,receipt_id TEXT,item_id TEXT,quantity_milli INTEGER,unit_cost_minor INTEGER);
    """)
    script = MIGRATION.read_text(encoding="utf-8")
    c.executescript(script)
    c.executescript(script)
    names = {r[1] for r in c.execute("PRAGMA index_list(monarch_procurement_decision_history)")}
    assert "ix_procurement_decisions_analytics" in names
    names = {r[1] for r in c.execute("PRAGMA index_list(monarch_purchase_receipts)")}
    assert "ix_purchase_receipts_analytics" in names
    names = {r[1] for r in c.execute("PRAGMA index_list(monarch_stock_movements)")}
    assert "ix_stock_movements_procurement_analytics" in names


def test_decision_and_supplier_delivery_aggregates_keep_currency_values_out_of_cross_supplier_totals():
    source = STORE.read_text(encoding="utf-8")
    assert "AVG((julianday(d.decided_utc)-julianday(p.created_utc))*24.0)" in source
    assert "po.status='Received'" in source
    assert "MAX(r.posted_utc) AS completed_utc" in source
    assert "SUM(CASE WHEN x.expected_utc IS NOT NULL" in source
    assert "total_minor" not in source


def test_supplier_item_performance_is_receipt_backed_currency_safe_and_read_only():
    source = STORE.read_text(encoding="utf-8")
    assert "GetSupplierItemPerformance" in source
    assert "ProcurementSupplierItemPerformance" in source
    assert "rr.status='Posted'" in source
    assert "rr.posted_utc >= $from AND rr.posted_utc < $until" in source
    assert "GROUP BY p.id,p.code,p.display_name,i.id,i.sku,i.name,po.currency_code" in source
    assert "SUM(CAST(rl.quantity_milli AS REAL) * rl.unit_cost_minor)" in source
    assert "RequireReportPermission(c, tx, userId, companyId, branchId)" in source
    assert "INSERT INTO" not in source and "UPDATE " not in source and "DELETE FROM" not in source


def test_supplier_item_analytics_index_migration_is_additive_and_idempotent():
    c = sqlite3.connect(":memory:")
    c.executescript("""CREATE TABLE monarch_procurement_decision_history(company_id TEXT,branch_id TEXT,decided_utc TEXT,decision TEXT,purchase_order_id TEXT);
    CREATE TABLE monarch_purchase_receipts(company_id TEXT,branch_id TEXT,posted_utc TEXT,purchase_order_id TEXT);
    CREATE TABLE monarch_stock_movements(company_id TEXT,branch_id TEXT,occurred_utc TEXT,movement_type TEXT,item_id TEXT);
    CREATE TABLE monarch_purchase_receipt_lines(company_id TEXT,receipt_id TEXT,item_id TEXT,quantity_milli INTEGER,unit_cost_minor INTEGER);""")
    script = MIGRATION.read_text(encoding="utf-8")
    c.executescript(script)
    c.executescript(script)
    names = {r[1] for r in c.execute("PRAGMA index_list(monarch_purchase_receipt_lines)")}
    assert "ix_purchase_receipt_lines_supplier_item" in names
