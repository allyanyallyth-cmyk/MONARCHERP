import pathlib, sqlite3, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class CommercialSchemaTests(unittest.TestCase):
 def setUp(self):
  self.db=sqlite3.connect(':memory:'); self.db.execute('PRAGMA foreign_keys=ON')
  for n in ('ledger-storage.sql','security.sql','tenancy.sql','commercial-data.sql'):
   self.db.executescript((ROOT/'database'/n).read_text())
  self.db.execute("INSERT INTO monarch_users(id,username,display_name,password_salt,password_hash,password_iterations,is_active,created_utc) VALUES('u1','admin','Admin',?,?,210000,1,'now')",(b'a'*16,b'b'*32))
  co='00000000-0000-0000-0000-000000000001'; br='00000000-0000-0000-0000-000000000002'
  self.db.execute("INSERT INTO monarch_user_company_access(user_id,company_id,role_code,granted_utc) VALUES('u1',?,'Administrator','now')",(co,))
  self.db.execute("INSERT INTO monarch_user_branch_access(user_id,company_id,branch_id) VALUES('u1',?,?)",(co,br))
  self.db.execute("INSERT INTO monarch_units(id,company_id,code,name,decimal_places) VALUES('unit',?,'EA','Each',0)",(co,))
  self.db.execute("INSERT INTO monarch_items(id,company_id,unit_id,sku,name,item_type,created_utc) VALUES('item',?,'unit','SKU1','Item','Stock','now')",(co,))
  self.db.execute("INSERT INTO monarch_warehouses(id,company_id,branch_id,code,name,created_utc) VALUES('wh',?,?,'MAIN','Main','now')",(co,br))
 def tearDown(self): self.db.close()
 def move(self,typ,qty,key):
  self.db.execute("INSERT INTO monarch_stock_movements(id,company_id,branch_id,warehouse_id,item_id,movement_type,quantity_milli,unit_cost_minor,idempotency_key,occurred_utc,actor_user_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(key,'00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002','wh','item',typ,qty,100,key,'now','u1'))
 def test_company_scoped_party_uniqueness(self):
  self.db.execute("INSERT INTO monarch_parties(id,company_id,code,party_type,legal_name,display_name,created_utc) VALUES('p1',?,'C1','Customer','A','A','now')",('00000000-0000-0000-0000-000000000001',))
  with self.assertRaises(sqlite3.IntegrityError): self.db.execute("INSERT INTO monarch_parties(id,company_id,code,party_type,legal_name,display_name,created_utc) VALUES('p2',?,'c1','Supplier','B','B','now')",('00000000-0000-0000-0000-000000000001',))
 def test_stock_receipt_and_issue_balance(self):
  self.move('Opening',1000,'m1'); self.move('Issue',250,'m2')
  self.assertEqual(self.db.execute("SELECT quantity_milli FROM monarch_stock_balances WHERE item_id='item'").fetchone()[0],750)
 def test_negative_stock_rejected_by_database(self):
  with self.assertRaises(sqlite3.IntegrityError): self.move('Issue',1,'out')
 def test_stock_movement_immutable(self):
  self.move('Opening',100,'m1')
  with self.assertRaises(sqlite3.IntegrityError): self.db.execute("UPDATE monarch_stock_movements SET quantity_milli=1 WHERE id='m1'")
  with self.assertRaises(sqlite3.IntegrityError): self.db.execute("DELETE FROM monarch_stock_movements WHERE id='m1'")
 def test_idempotency_key_unique_per_company(self):
  self.move('Opening',100,'same')
  with self.assertRaises(sqlite3.IntegrityError): self.move('Receipt',100,'same')
 def test_cross_company_references_rejected(self):
  with self.assertRaises(sqlite3.IntegrityError): self.db.execute("INSERT INTO monarch_warehouses(id,company_id,branch_id,code,name,created_utc) VALUES('bad',?,'bad-branch','B','Bad','now')",('00000000-0000-0000-0000-000000000001',))
 def test_transfer_legs_preserve_company_total(self):
  self.db.execute("INSERT INTO monarch_warehouses(id,company_id,branch_id,code,name,created_utc) VALUES('wh2','00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002','SECOND','Second','now')")
  self.move('Opening',1000,'seed')
  self.db.execute("INSERT INTO monarch_stock_movements(id,company_id,branch_id,warehouse_id,item_id,movement_type,quantity_milli,unit_cost_minor,idempotency_key,occurred_utc,actor_user_id) VALUES('tout','00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002','wh','item','TransferOut',300,100,'tr:OUT','now','u1')")
  self.db.execute("INSERT INTO monarch_stock_movements(id,company_id,branch_id,warehouse_id,item_id,movement_type,quantity_milli,unit_cost_minor,idempotency_key,occurred_utc,actor_user_id) VALUES('tin','00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002','wh2','item','TransferIn',300,100,'tr:IN','now','u1')")
  balances=dict(self.db.execute("SELECT warehouse_id,quantity_milli FROM monarch_stock_balances WHERE item_id='item'"))
  self.assertEqual(balances, {'wh':700,'wh2':300})
  self.assertEqual(sum(balances.values()),1000)
 def test_transfer_source_leg_cannot_overdraw(self):
  with self.assertRaises(sqlite3.IntegrityError): self.move('TransferOut',1,'overdraw')
 def test_store_exposes_atomic_transfer_contract(self):
  src=(ROOT/'src/Monarch.Core/Commercial/CommercialStore.cs').read_text()
  self.assertIn('public void TransferStock(',src)
  self.assertIn('StockMovementType.TransferOut',src)
  self.assertIn('StockMovementType.TransferIn',src)
  self.assertIn('tx.Commit()',src)
 def test_document_schema_and_accounting_outbox(self):
  self.db.execute("INSERT INTO monarch_parties(id,company_id,code,party_type,legal_name,display_name,created_utc) VALUES('cust','00000000-0000-0000-0000-000000000001','C1','Customer','Customer','Customer','now')")
  self.db.execute("INSERT INTO monarch_commercial_documents(id,company_id,branch_id,document_type,document_number,party_id,warehouse_id,status,currency_code,currency_scale,created_utc,created_by) VALUES('doc','00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002','Sale','S-1','cust','wh','Draft','SAR',2,'now','u1')")
  self.db.execute("INSERT INTO monarch_commercial_document_lines(id,company_id,document_id,line_number,item_id,item_sku_snapshot,item_name_snapshot,quantity_milli,unit_price_minor,tax_rate_bps,net_minor,tax_minor,total_minor) VALUES('ln','00000000-0000-0000-0000-000000000001','doc',1,'item','SKU1','Item',1000,1000,1500,1000,150,1150)")
  self.db.execute("UPDATE monarch_commercial_documents SET subtotal_minor=1000,tax_minor=150,total_minor=1150,status='Posted',posted_utc='now',posted_by='u1' WHERE id='doc'")
  self.db.execute("INSERT INTO monarch_accounting_posting_outbox(id,company_id,branch_id,document_id,event_type,created_utc) VALUES('ob','00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002','doc','SalePosted','now')")
  with self.assertRaises(sqlite3.IntegrityError): self.db.execute("UPDATE monarch_commercial_documents SET total_minor=1 WHERE id='doc'")
  with self.assertRaises(sqlite3.IntegrityError): self.db.execute("DELETE FROM monarch_commercial_document_lines WHERE id='ln'")
  with self.assertRaises(sqlite3.IntegrityError): self.db.execute("INSERT INTO monarch_accounting_posting_outbox(id,company_id,branch_id,document_id,event_type,created_utc) VALUES('ob2','00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002','doc','SalePosted','now')")
 def test_document_rejects_invalid_tax_and_cross_company_item(self):
  self.db.execute("INSERT INTO monarch_parties(id,company_id,code,party_type,legal_name,display_name,created_utc) VALUES('cust','00000000-0000-0000-0000-000000000001','C1','Customer','Customer','Customer','now')")
  self.db.execute("INSERT INTO monarch_commercial_documents(id,company_id,branch_id,document_type,document_number,party_id,warehouse_id,status,currency_code,currency_scale,created_utc,created_by) VALUES('doc','00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002','Sale','S-1','cust','wh','Draft','SAR',2,'now','u1')")
  with self.assertRaises(sqlite3.IntegrityError):
   self.db.execute("INSERT INTO monarch_commercial_document_lines(id,company_id,document_id,line_number,item_id,item_sku_snapshot,item_name_snapshot,quantity_milli,unit_price_minor,tax_rate_bps,net_minor,tax_minor,total_minor) VALUES('ln','00000000-0000-0000-0000-000000000001','doc',1,'missing','X','X',1000,100,10001,100,100,200)")
 def test_commercial_document_store_uses_atomic_outbox_and_stock(self):
  src=(ROOT/'src/Monarch.Core/Commercial/CommercialDocumentStore.cs').read_text()
  self.assertIn('public CommercialDocumentTotals CreateDraft(',src)
  self.assertIn('public void Post(',src)
  self.assertIn('BeginTransaction()',src)
  self.assertIn('monarch_accounting_posting_outbox',src)
  self.assertIn("type == \"Purchase\" ? StockMovementType.Receipt : StockMovementType.Issue",src)
  self.assertIn('MidpointRounding.AwayFromZero',src)
 def test_store_checks_branch_and_immutable_ledger(self):
  src=(ROOT/'src/Monarch.Core/Commercial/CommercialStore.cs').read_text()
  self.assertIn('RequireBranch(c, tx, userId, companyId, branchId, true)',src)
  self.assertIn('BEGIN',src.upper())
  schema=(ROOT/'database/commercial-data.sql').read_text()
  self.assertIn('trg_stock_movement_no_update',schema); self.assertIn('trg_stock_prevent_negative',schema)
if __name__=='__main__': unittest.main()

class WarehouseTransferCostingContractTests(unittest.TestCase):
 def test_transfer_cost_is_derived_from_source_ledger_not_caller_input(self):
  src=(ROOT/'src/Monarch.Core/Commercial/CommercialStore.cs').read_text()
  transfer=src.split('public void TransferStock(',1)[1].split('private static long CalculateCurrentMovingAverageCost',1)[0]
  self.assertNotIn('unitCostMinor',transfer)
  self.assertIn('CalculateCurrentMovingAverageCost(c, tx, companyId',transfer)
  self.assertIn('InventoryCostMethod.MovingWeightedAverage',src)
  self.assertIn('transferUnitCost, idempotencyKey + ":OUT"',transfer)
  self.assertIn('transferUnitCost, idempotencyKey + ":IN"',transfer)

 def test_transfer_authorizes_both_branches_inside_write_transaction(self):
  src=(ROOT/'src/Monarch.Core/Commercial/CommercialStore.cs').read_text()
  transfer=src.split('public void TransferStock(',1)[1].split('private static long CalculateCurrentMovingAverageCost',1)[0]
  self.assertIn('using var tx = c.BeginTransaction();',transfer)
  self.assertIn('RequireBranch(c, tx, userId, companyId, sourceBranchId, true);',transfer)
  self.assertIn('RequireBranch(c, tx, userId, companyId, targetBranchId, true);',transfer)
  self.assertIn('u.is_active=1',src)
  self.assertIn('ValidateWarehouse(c, tx, companyId, sourceBranchId, sourceWarehouseId);',transfer)
  self.assertIn('ValidateWarehouse(c, tx, companyId, targetBranchId, targetWarehouseId);',transfer)

 def test_transfer_cost_replay_uses_persisted_sequence(self):
  src=(ROOT/'src/Monarch.Core/Commercial/CommercialStore.cs').read_text()
  calc=src.split('private static long CalculateCurrentMovingAverageCost',1)[1].split('private static void RequireBranch',1)[0]
  self.assertIn('ORDER BY ledger_sequence',calc)
  self.assertIn('InventoryValuationEngine.Calculate(movements, InventoryCostMethod.MovingWeightedAverage)',calc)
  self.assertIn('valuation.AverageUnitCostMinor',calc)
