from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src/Monarch.Core/Autonomy/PredictiveProcurementDraftOrchestrator.cs"


def test_predictive_orchestrator_bridges_analyzer_to_existing_draft_workflow():
    text = SOURCE.read_text(encoding="utf-8")
    assert "_analyzer.Analyze(companyId, branchId, warehouseId, asOf, policy)" in text
    assert "_workflow.CreateDraft" in text
    assert "new ProcurementDraftLine(candidate.ItemId, candidate.SuggestedQuantityMilli" in text
    assert '"Draft"' in text and "ApprovalQueueId" in text


def test_orchestrator_requires_explicit_approved_commercial_terms():
    text = SOURCE.read_text(encoding="utf-8")
    assert "approvedTerms.TryGetValue(candidate.ItemId" in text
    assert "CommercialTermsRequired" in text
    assert "No draft was created" in text
    assert "UnitCostMinor" in text and "TaxRateBasisPoints" in text


def test_orchestrator_has_no_approval_or_posting_capability_and_isolates_item_failures():
    text = SOURCE.read_text(encoding="utf-8")
    assert "Approve(" not in text and "Post(" not in text
    assert "catch (Exception ex)" in text
    assert "DraftCreationFailed" in text
    assert "AutonomousProcurementWorkflow" in text
