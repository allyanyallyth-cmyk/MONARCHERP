import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MIGRATION = ROOT / 'database/migrations/2026-11-11-supplier-ap-alert-lifecycle.sql'
SOURCE = ROOT / 'src/Monarch.Core/Commercial/SupplierPayablesOperationalAlertLifecycleStore.cs'


def database():
    con = sqlite3.connect(':memory:')
    con.executescript(MIGRATION.read_text(encoding='utf-8'))
    return con


def insert(con, company='c1', branch='b1', user='u1', code='supplier_ap_heartbeat_failures',
           source='2026-11-11T00:00:00+00:00', action='Viewed', occurred='2026-11-11T00:01:00+00:00'):
    con.execute('''INSERT INTO monarch_supplier_ap_alert_lifecycle
        (id,company_id,branch_id,user_id,alert_code,source_last_occurred_utc,action,occurred_utc)
        VALUES (lower(hex(randomblob(16))),?,?,?,?,?,?,?)
        ON CONFLICT(company_id,branch_id,user_id,alert_code,source_last_occurred_utc,action) DO NOTHING''',
        (company, branch, user, code, source, action, occurred))


def test_migration_creates_scoped_lifecycle_table_and_indexes():
    con = database()
    names = {r[0] for r in con.execute("SELECT name FROM sqlite_master")}
    assert 'monarch_supplier_ap_alert_lifecycle' in names
    assert 'ux_supplier_ap_alert_lifecycle_once' in names
    assert 'ix_supplier_ap_alert_lifecycle_scope' in names


def test_same_user_scope_reads_only_own_company_branch_and_alert():
    con = database()
    insert(con)
    insert(con, company='c2')
    insert(con, branch='b2')
    insert(con, user='u2')
    rows = con.execute('''SELECT action FROM monarch_supplier_ap_alert_lifecycle
      WHERE company_id=? AND branch_id=? AND user_id=?''', ('c1','b1','u1')).fetchall()
    assert rows == [('Viewed',)]


def test_different_source_timestamp_is_new_recurrence():
    con = database()
    insert(con)
    insert(con, source='2026-11-11T00:05:00+00:00')
    assert con.execute('SELECT COUNT(*) FROM monarch_supplier_ap_alert_lifecycle').fetchone()[0] == 2


def test_same_lifecycle_action_is_idempotent():
    con = database()
    insert(con)
    insert(con, occurred='2026-11-11T00:02:00+00:00')
    assert con.execute('SELECT COUNT(*) FROM monarch_supplier_ap_alert_lifecycle').fetchone()[0] == 1


def test_acknowledgement_and_view_are_distinct_events():
    con = database()
    insert(con, action='Viewed')
    insert(con, action='Acknowledged')
    assert {r[0] for r in con.execute('SELECT action FROM monarch_supplier_ap_alert_lifecycle')} == {'Viewed','Acknowledged'}


def test_unapproved_alert_code_rejected_by_database():
    con = database()
    try:
        insert(con, code='arbitrary_code')
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError('unapproved alert code accepted')


def test_unapproved_action_rejected_by_database():
    con = database()
    try:
        insert(con, action='Deleted')
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError('unapproved action accepted')


def test_update_and_delete_are_blocked():
    con = database()
    insert(con)
    for sql in ("UPDATE monarch_supplier_ap_alert_lifecycle SET action='Acknowledged'",
                "DELETE FROM monarch_supplier_ap_alert_lifecycle"):
        try:
            con.execute(sql)
        except sqlite3.IntegrityError as exc:
            assert 'append-only' in str(exc)
        else:
            raise AssertionError('append-only trigger did not reject mutation')


def test_csharp_store_authorizes_before_database_access_and_bounds_reads():
    text = SOURCE.read_text(encoding='utf-8')
    assert text.index('_ledger.GetEntries(userId, companyId, branchId); // authorization before lifecycle read') < text.index('connection.Open();', text.index('public IReadOnlyList'))
    assert text.index('_ledger.GetEntries(userId, companyId, branchId); // authorization before lifecycle write') < text.index('connection.Open();', text.index('private void Append'))
    assert 'alerts.Count > 500' in text
    assert 'AllowedCodes.Contains(alert.Code)' in text
    assert 'INSERT OR IGNORE' in text


def test_store_does_not_mutate_accounting_or_worker_state():
    text = SOURCE.read_text(encoding='utf-8')
    forbidden = ('UPDATE monarch_supplier_ap_worker_diagnostics', 'DELETE FROM monarch_supplier_ap_worker_diagnostics',
                 'UPDATE monarch_supplier_ap_worker_leases', 'UPDATE journal_entries', 'UPDATE accounting_outbox')
    assert not any(fragment in text for fragment in forbidden)
