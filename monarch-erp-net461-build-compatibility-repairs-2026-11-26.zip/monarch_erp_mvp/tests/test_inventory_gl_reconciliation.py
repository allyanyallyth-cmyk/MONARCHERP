from contextlib import closing
from pathlib import Path
import re
import sqlite3
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "src/Monarch.Core/Commercial/InventoryGlReconciliationStore.cs").read_text(encoding="utf-8")


def raw_sql_after(marker: str) -> str:
    start = SOURCE.index(marker)
    match = re.search(r'CommandText\s*=\s*@"(.*?)";', SOURCE[start:], re.S)
    if not match:
        raise AssertionError(f"Could not locate SQL after {marker}")
    return match.group(1)


class InventoryGlReconciliationTests(unittest.TestCase):
    def test_reconciliation_is_read_only_and_uses_authorized_transaction(self):
        self.assertIn("using var transaction = connection.BeginTransaction();", SOURCE)
        self.assertIn("RequireBranchAccess(connection, transaction, userId, companyId, branchId);", SOURCE)
        self.assertIn("transaction.Commit();", SOURCE)
        self.assertNotRegex(SOURCE, r"(?i)\b(UPDATE\s+|DELETE\s+FROM)\s+monarch_")
        inserts = re.findall(r"(?i)INSERT\s+INTO\s+(monarch_[a-z0-9_]+)", SOURCE)
        self.assertEqual(inserts, ["monarch_company_audit_log"])
        self.assertIn("This service never", SOURCE)

    def test_stock_movements_are_company_branch_warehouse_item_scoped(self):
        sql = raw_sql_after("private static List<InventoryGlItemValuation> LoadStockValuations")
        self.assertIn("m.company_id=$company AND m.branch_id=$branch", sql)
        self.assertIn("w.branch_id=$branch", sql)
        self.assertIn("i.item_type='Stock'", sql)
        self.assertIn("ORDER BY ledger_sequence,id", SOURCE)
        self.assertIn("InventoryValuationEngine.Calculate(movements, method)", SOURCE)

    def test_fifo_reconciliation_fails_closed_until_transfer_layer_lineage_exists(self):
        self.assertIn("costMethod != InventoryCostMethod.MovingWeightedAverage", SOURCE)
        self.assertIn("FIFO reconciliation is blocked until FIFO layer lineage is preserved", SOURCE)

    def test_inventory_account_must_be_active_asset_in_same_company(self):
        sql = raw_sql_after("private static string ResolveInventoryAccount")
        self.assertIn("company_id=$company", sql)
        self.assertIn("is_active=1 AND account_type='Asset'", sql)

    def test_gl_balance_query_excludes_unposted_and_other_branches_or_companies(self):
        sql = raw_sql_after("private static long LoadPostedInventoryBalance")
        self.assertIn("j.status IN ('Posted','Reversed')", sql)
        self.assertIn("j.branch_id=$branch", sql)
        self.assertIn("l.company_id=$company", sql)
        self.assertIn("SUM(l.debit_minor-l.credit_minor)", sql)

    def test_gl_balance_sql_behavior_is_tenant_and_branch_isolated(self):
        sql = raw_sql_after("private static long LoadPostedInventoryBalance")
        with closing(sqlite3.connect(":memory:")) as db:
            db.executescript("""
                CREATE TABLE monarch_tenant_journals(company_id TEXT,id TEXT,branch_id TEXT,status TEXT,posted_at_utc TEXT);
                CREATE TABLE monarch_tenant_journal_lines(company_id TEXT,journal_id TEXT,account_id TEXT,debit_minor INTEGER,credit_minor INTEGER);
                INSERT INTO monarch_tenant_journals VALUES
                  ('A','ja1','A1','Posted','2026-01-01T10:00:00.0000000+00:00'),('A','ja2','A1','Draft',NULL),('A','ja3','A2','Posted','2026-01-01T10:00:00.0000000+00:00'),('B','jb1','A1','Posted','2026-01-01T10:00:00.0000000+00:00');
                INSERT INTO monarch_tenant_journal_lines VALUES
                  ('A','ja1','inv',10000,0),('A','ja2','inv',9000,0),('A','ja3','inv',0,2000),('B','jb1','inv',7000,0);
            """)
            result = db.execute(sql, {"company": "A", "branch": "A1", "account": "inv",
                                      "cutoff": "2026-12-31T23:59:59.0000000+00:00"}).fetchone()[0]
            self.assertEqual(result, 10000)

    def test_variance_is_general_ledger_minus_inventory_subledger(self):
        self.assertIn("var variance = checked(ledgerValue - subledgerValue);", SOURCE)
        self.assertIn("variance == 0", SOURCE)
        self.assertIn("subledgerValue, ledgerValue, variance, variance == 0", SOURCE)

    def test_reconciliation_requires_explicit_utc_cutoff_for_both_ledgers(self):
        self.assertIn("DateTimeOffset asOfUtc", SOURCE)
        self.assertIn("asOfUtc.ToUniversalTime()", SOURCE)
        stock_sql = raw_sql_after("private static List<InventoryGlItemValuation> LoadStockValuations")
        gl_sql = raw_sql_after("private static long LoadPostedInventoryBalance")
        self.assertIn("m.occurred_utc <= $cutoff", stock_sql)
        self.assertIn("occurred_utc <= $cutoff", SOURCE)
        self.assertIn("j.posted_at_utc <= $cutoff", gl_sql)
        self.assertIn("j.status IN ('Posted','Reversed')", gl_sql)
        self.assertIn("AsOfUtc", SOURCE)

    def test_cutoff_balance_includes_only_posted_before_cutoff_and_keeps_reversals_historical(self):
        sql = raw_sql_after("private static long LoadPostedInventoryBalance")
        with closing(sqlite3.connect(":memory:")) as db:
            db.executescript("""
                CREATE TABLE monarch_tenant_journals(company_id TEXT,id TEXT,branch_id TEXT,status TEXT,posted_at_utc TEXT);
                CREATE TABLE monarch_tenant_journal_lines(company_id TEXT,journal_id TEXT,account_id TEXT,debit_minor INTEGER,credit_minor INTEGER);
                INSERT INTO monarch_tenant_journals VALUES
                  ('A','old','A1','Posted','2026-01-01T10:00:00.0000000+00:00'),
                  ('A','future','A1','Posted','2026-02-01T10:00:00.0000000+00:00'),
                  ('A','reversed-old','A1','Reversed','2026-01-02T10:00:00.0000000+00:00'),
                  ('A','draft','A1','Draft',NULL);
                INSERT INTO monarch_tenant_journal_lines VALUES
                  ('A','old','inv',10000,0),('A','future','inv',5000,0),
                  ('A','reversed-old','inv',2000,0),('A','draft','inv',9000,0);
            """)
            result = db.execute(sql, {"company":"A", "branch":"A1", "account":"inv",
                                      "cutoff":"2026-01-31T23:59:59.0000000+00:00"}).fetchone()[0]
            self.assertEqual(result, 12000)

if __name__ == "__main__":
    unittest.main()


class InventoryGlReconciliationAuditTests(unittest.TestCase):
    def test_audit_is_inserted_inside_same_transaction_before_commit(self):
        audit = SOURCE.index("InventoryGlReconciled")
        commit = SOURCE.index("transaction.Commit();", audit)
        self.assertLess(audit, commit)
        self.assertIn("monarch_company_audit_log", SOURCE)
        self.assertIn("InventoryGlReconciliation", SOURCE)
        for parameter in ("$co", "$br", "$actor", "$id", "$details", "$now"):
            self.assertIn(parameter, SOURCE[audit:commit])

    def test_audit_captures_account_method_cutoff_totals_and_balance_state(self):
        for field in ("account=", "method=", "asOfUtc=", "itemWarehouseCount=",
                      "quantityMilli=", "subledgerValueMinor=", "generalLedgerValueMinor=",
                      "varianceMinor=", "isBalanced="):
            self.assertIn(field, SOURCE)

    def test_reports_read_permission_is_required_in_tenant_branch_scope(self):
        access = SOURCE[SOURCE.index("private static void RequireBranchAccess"):SOURCE.index("private static string ResolveInventoryAccount")]
        self.assertIn("monarch_user_roles", access)
        self.assertIn("monarch_role_permissions", access)
        self.assertIn("rp.permission_code='reports.read'", access)

    def test_reconciliation_audit_does_not_create_or_modify_journals(self):
        audit = SOURCE.index("INSERT INTO monarch_company_audit_log")
        commit = SOURCE.index("transaction.Commit();", audit)
        block = SOURCE[audit:commit]
        self.assertNotIn("monarch_tenant_journals", block)
        self.assertNotIn("monarch_tenant_journal_lines", block)
        self.assertIn("INSERT INTO monarch_company_audit_log", block)
