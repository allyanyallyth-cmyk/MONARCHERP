from pathlib import Path
import sqlite3, unittest
ROOT=Path(__file__).resolve().parents[1]
CO='00000000-0000-0000-0000-000000000001'; BR='00000000-0000-0000-0000-000000000002'
CS=(ROOT/'src/Monarch.Core/Commercial/CommercialReturnStore.cs').read_text()
class CommercialReturnTests(unittest.TestCase):
 def setUp(self):
  self.db=sqlite3.connect(':memory:'); self.db.execute('PRAGMA foreign_keys=ON')
  for n in ('ledger-storage.sql','security.sql','tenancy.sql','commercial-data.sql'):
   self.db.executescript((ROOT/'database'/n).read_text())
  self.db.execute("INSERT INTO monarch_users(id,username,display_name,password_salt,password_hash,password_iterations,is_active,created_utc) VALUES('u1','admin','Admin',?,?,210000,1,'now')",(b'a'*16,b'b'*32))
  self.db.execute("INSERT INTO monarch_user_company_access(user_id,company_id,role_code,granted_utc) VALUES('u1',?,'Administrator','now')",(CO,))
  self.db.execute("INSERT INTO monarch_user_branch_access(user_id,company_id,branch_id) VALUES('u1',?,?)",(CO,BR))
  self.db.execute("INSERT INTO monarch_parties(id,company_id,code,party_type,legal_name,display_name,created_utc) VALUES('cust',?,'C1','Customer','Customer','Customer','now')",(CO,))
  self.db.execute("INSERT INTO monarch_units(id,company_id,code,name) VALUES('unit',?,'EA','Each')",(CO,))
  self.db.execute("INSERT INTO monarch_items(id,company_id,unit_id,sku,name,item_type,created_utc) VALUES('item',?,'unit','SKU','Item','Stock','now')",(CO,))
  self.db.execute("INSERT INTO monarch_warehouses(id,company_id,branch_id,code,name,created_utc) VALUES('wh',?,?,'MAIN','Main','now')",(CO,BR))
  self.db.execute("INSERT INTO monarch_commercial_documents(id,company_id,branch_id,document_type,document_number,party_id,warehouse_id,status,currency_code,currency_scale,subtotal_minor,total_minor,created_utc,created_by) VALUES('sale',?,?,'Sale','S-1','cust','wh','Draft','SAR',2,10000,11500,'now','u1')",(CO,BR))
  self.db.execute("INSERT INTO monarch_commercial_document_lines(id,company_id,document_id,line_number,item_id,item_sku_snapshot,item_name_snapshot,quantity_milli,unit_price_minor,tax_rate_bps,net_minor,tax_minor,total_minor) VALUES('sl1',?,'sale',1,'item','SKU','Item',5000,2000,1500,10000,1500,11500)",(CO,))
  self.db.execute("UPDATE monarch_commercial_documents SET status='Posted' WHERE id='sale'")
  self.db.execute("INSERT INTO monarch_stock_movements(id,company_id,branch_id,warehouse_id,item_id,movement_type,quantity_milli,unit_cost_minor,idempotency_key,occurred_utc,actor_user_id) VALUES('m0',?,?, 'wh','item','Opening',5000,1000,'opening-stock','now','u1')",(CO,BR))
  self.db.execute("INSERT INTO monarch_stock_movements(id,company_id,branch_id,warehouse_id,item_id,movement_type,quantity_milli,unit_cost_minor,idempotency_key,occurred_utc,actor_user_id) VALUES('m1',?,?, 'wh','item','Issue',5000,1000,'sale-stock','now','u1')",(CO,BR))
 def tearDown(self): self.db.close()
 def add_return(self, rid='r1', qty=2000, rtype='SalesReturn', source='sale', source_line='sl1', party='cust'):
  self.db.execute("INSERT INTO monarch_commercial_returns(id,company_id,branch_id,return_type,return_number,source_document_id,party_id,warehouse_id,status,currency_code,currency_scale,subtotal_minor,tax_minor,total_minor,created_utc,created_by) VALUES(?,?,?, ?,?,?, ?, 'wh','Draft','SAR',2,4000,600,4600,'now','u1')",(rid,CO,BR,rtype,'RET-'+rid,source,party))
  self.db.execute("INSERT INTO monarch_commercial_return_lines(id,company_id,return_id,source_line_id,line_number,item_id,item_sku_snapshot,item_name_snapshot,quantity_milli,unit_price_minor,tax_rate_bps,net_minor,tax_minor,total_minor) VALUES(?,?,?, ?,1,'item','SKU','Item',?,2000,1500,4000,600,4600)",(rid+'l',CO,rid,source_line,qty))
 def test_return_source_must_be_posted_and_match_type_branch_party(self):
  with self.assertRaises(sqlite3.IntegrityError):
   self.db.execute("INSERT INTO monarch_commercial_returns(id,company_id,branch_id,return_type,return_number,source_document_id,party_id,warehouse_id,status,currency_code,currency_scale,created_utc,created_by) VALUES('bad',?,?, 'PurchaseReturn','R-BAD','sale','cust','wh','Draft','SAR',2,'now','u1')",(CO,BR))
 def test_sales_return_posts_positive_stock_and_outbox_atomically_in_schema(self):
  self.add_return()
  self.db.execute("INSERT INTO monarch_stock_movements(id,company_id,branch_id,warehouse_id,item_id,movement_type,quantity_milli,unit_cost_minor,source_type,source_id,idempotency_key,occurred_utc,actor_user_id) VALUES('mr',?,?, 'wh','item','SalesReturn',2000,1000,'CommercialReturn','r1','r1:0','now','u1')",(CO,BR))
  self.db.execute("UPDATE monarch_commercial_returns SET status='Posted',posted_utc='now',posted_by='u1' WHERE id='r1'")
  self.db.execute("INSERT INTO monarch_return_accounting_outbox(id,company_id,branch_id,return_id,event_type,created_utc) VALUES('ob',?,?,'r1','SalesReturnPosted','now')",(CO,BR))
  balance=self.db.execute("SELECT quantity_milli FROM monarch_stock_balances WHERE company_id=? AND warehouse_id='wh' AND item_id='item'",(CO,)).fetchone()[0]
  self.assertEqual(balance,2000)
  with self.assertRaises(sqlite3.IntegrityError): self.db.execute("UPDATE monarch_commercial_returns SET total_minor=1 WHERE id='r1'")
 def test_purchase_return_is_outbound_stock_movement(self):
  self.db.execute("INSERT INTO monarch_parties(id,company_id,code,party_type,legal_name,display_name,created_utc) VALUES('supp',?,'S1','Supplier','Supplier','Supplier','now')",(CO,))
  self.db.execute("INSERT INTO monarch_commercial_documents(id,company_id,branch_id,document_type,document_number,party_id,warehouse_id,status,currency_code,currency_scale,subtotal_minor,total_minor,created_utc,created_by) VALUES('purchase',?,?,'Purchase','P-1','supp','wh','Draft','SAR',2,10000,11500,'now','u1')",(CO,BR))
  self.db.execute("INSERT INTO monarch_commercial_document_lines(id,company_id,document_id,line_number,item_id,item_sku_snapshot,item_name_snapshot,quantity_milli,unit_price_minor,tax_rate_bps,net_minor,tax_minor,total_minor) VALUES('pl1',?,'purchase',1,'item','SKU','Item',5000,2000,1500,10000,1500,11500)",(CO,))
  self.db.execute("UPDATE monarch_commercial_documents SET status='Posted' WHERE id='purchase'")
  self.db.execute("INSERT INTO monarch_stock_movements(id,company_id,branch_id,warehouse_id,item_id,movement_type,quantity_milli,unit_cost_minor,idempotency_key,occurred_utc,actor_user_id) VALUES('mp',?,?, 'wh','item','Receipt',5000,1000,'purchase-stock','now','u1')",(CO,BR))
  self.add_return(rtype='PurchaseReturn',source='purchase',source_line='pl1',party='supp')
  self.db.execute("INSERT INTO monarch_stock_movements(id,company_id,branch_id,warehouse_id,item_id,movement_type,quantity_milli,unit_cost_minor,source_type,source_id,idempotency_key,occurred_utc,actor_user_id) VALUES('mr',?,?, 'wh','item','PurchaseReturn',2000,1000,'CommercialReturn','r1','r1:0','now','u1')",(CO,BR))
  balance=self.db.execute("SELECT quantity_milli FROM monarch_stock_balances WHERE company_id=? AND warehouse_id='wh' AND item_id='item'",(CO,)).fetchone()[0]
  self.assertEqual(balance,3000)
 def test_database_blocks_cumulative_overreturn_at_post_time(self):
  self.add_return(rid='r1',qty=4000)
  self.add_return(rid='r2',qty=2000)
  self.db.execute("UPDATE monarch_commercial_returns SET status='Posted',posted_utc='now',posted_by='u1' WHERE id='r1'")
  with self.assertRaises(sqlite3.IntegrityError):
   self.db.execute("UPDATE monarch_commercial_returns SET status='Posted',posted_utc='now',posted_by='u1' WHERE id='r2'")
 def test_cancelled_return_cannot_be_reopened(self):
  self.add_return()
  self.db.execute("UPDATE monarch_commercial_returns SET status='Cancelled' WHERE id='r1'")
  with self.assertRaises(sqlite3.IntegrityError):
   self.db.execute("UPDATE monarch_commercial_returns SET status='Posted' WHERE id='r1'")
 def test_return_line_cannot_point_to_another_invoice_item_line(self):
  self.add_return()
  with self.assertRaises(sqlite3.IntegrityError):
   self.db.execute("INSERT INTO monarch_commercial_return_lines(id,company_id,return_id,source_line_id,line_number,item_id,item_sku_snapshot,item_name_snapshot,quantity_milli,unit_price_minor,tax_rate_bps,net_minor,tax_minor,total_minor) VALUES('badline',?,'r1','missing',2,'item','SKU','Item',1000,2000,1500,2000,300,2300)",(CO,))
 def test_return_outbox_is_unique_and_tenant_scoped(self):
  self.add_return()
  self.db.execute("INSERT INTO monarch_return_accounting_outbox(id,company_id,branch_id,return_id,event_type,created_utc) VALUES('ob',?,?,'r1','SalesReturnPosted','now')",(CO,BR))
  with self.assertRaises(sqlite3.IntegrityError):
   self.db.execute("INSERT INTO monarch_return_accounting_outbox(id,company_id,branch_id,return_id,event_type,created_utc) VALUES('ob2',?,?,'r1','SalesReturnPosted','now')",(CO,BR))
 def test_return_cost_trace_is_linked_to_original_allocation_and_movement(self):
  self.add_return()
  self.db.execute("INSERT INTO monarch_inventory_cost_allocations(id,company_id,branch_id,document_id,document_line_id,movement_id,allocation_type,quantity_milli,unit_cost_minor,total_cost_minor,cost_method,created_utc) VALUES('a1',?,?,'sale','sl1','m1','SalesIssue',5000,1000,5000,'MovingWeightedAverage','now')",(CO,BR))
  self.db.execute("INSERT INTO monarch_stock_movements(id,company_id,branch_id,warehouse_id,item_id,ledger_sequence,movement_type,quantity_milli,unit_cost_minor,source_type,source_id,idempotency_key,occurred_utc,actor_user_id) VALUES('mr',?,?,'wh','item',2,'SalesReturn',2000,1000,'CommercialReturn','r1','r1:0','now','u1')",(CO,BR))
  self.db.execute("INSERT INTO monarch_inventory_return_cost_allocations(id,company_id,branch_id,return_id,return_line_id,source_allocation_id,movement_id,allocation_type,quantity_milli,unit_cost_minor,total_cost_minor,created_utc) VALUES('ra1',?,?,'r1','r1l','a1','mr','SalesReturnReversal',2000,1000,2000,'now')",(CO,BR))
  self.assertEqual(self.db.execute("SELECT total_cost_minor FROM monarch_inventory_return_cost_allocations WHERE id='ra1'").fetchone()[0],2000)
  with self.assertRaises(sqlite3.IntegrityError):
   self.db.execute("UPDATE monarch_inventory_return_cost_allocations SET total_cost_minor=1 WHERE id='ra1'")

 def test_store_rechecks_returned_quantity_and_uses_transactional_outbox(self):
  self.assertIn('EnsureRemaining(c, tx, companyId, sourceLine, qty, returnId)',CS)
  self.assertIn('BeginTransaction()',CS)
  self.assertIn('InsertMovement(c, tx',CS)
  self.assertIn('monarch_return_accounting_outbox',CS)
  self.assertIn('No access to selected branch',CS)
if __name__=='__main__': unittest.main()
