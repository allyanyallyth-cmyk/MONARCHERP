from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
CS = (ROOT / 'src/Monarch.Core/Commercial/CommercialReturnAccountingOutboxWorker.cs').read_text()
class CommercialReturnAccountingWorkerTests(unittest.TestCase):
    def test_worker_reads_only_pending_failed_tenant_scoped_events(self):
        self.assertIn("status IN('Pending','Failed')", CS)
        self.assertIn('company_id=$co AND branch_id=$br', CS)
        self.assertIn('_ledger.GetEntries(userId, companyId, branchId)', CS)
    def test_sales_return_reverses_receivable_and_output_tax(self):
        self.assertIn('SalesReturnsCode, AccountType.Expense', CS)
        self.assertIn('OutputTaxCode, AccountType.Liability', CS)
        self.assertIn('ReceivablesCode, AccountType.Asset', CS)
    def test_purchase_return_reverses_payable_purchase_expense_and_input_tax(self):
        self.assertIn('GoodsReceivedNotInvoicedCode, AccountType.Liability', CS)
        self.assertIn('PurchasesExpenseCode, AccountType.Expense', CS)
        self.assertIn('InputTaxCode, AccountType.Asset', CS)
    def test_deterministic_journal_and_retry_acknowledgement(self):
        self.assertIn('AUTO-RET-', CS)
        self.assertIn("status='Processed'", CS)
        self.assertIn("status='Failed',attempts=attempts+1", CS)
        self.assertIn('JournalStatus.Posted', CS)
    def test_sales_return_restores_inventory_and_reverses_cogs_at_original_cost(self):
        self.assertIn('InventoryCode, AccountType.Asset', CS)
        self.assertIn('CostOfGoodsSoldCode, AccountType.Expense', CS)
        self.assertIn('data.StockCost', CS)
        self.assertIn('monarch_inventory_return_cost_allocations', CS)

    def test_purchase_return_credits_inventory_and_reconciles_cost_variance(self):
        self.assertIn('PurchasePriceVarianceCode', CS)
        self.assertIn('data.StockCost', CS)
        self.assertIn('data.NonStockSubtotal', CS)
if __name__ == '__main__': unittest.main()
