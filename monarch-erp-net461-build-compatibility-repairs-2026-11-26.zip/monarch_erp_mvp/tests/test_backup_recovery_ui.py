from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class BackupRecoveryUiTests(unittest.TestCase):
    def test_backup_permission_is_seeded_for_admin(self):
        sql = (ROOT / "database/security.sql").read_text(encoding="utf-8")
        self.assertIn("('backups.manage','إنشاء النسخ الاحتياطية والتحقق منها')", sql)
        self.assertIn("SELECT 'role-admin',code FROM monarch_permissions", sql)

    def test_backup_tab_is_permission_gated(self):
        code = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
        self.assertIn('if (_session.HasPermission("backups.manage")) tabs.Items.Add(BuildBackupsTab());', code)
        self.assertIn('IdentityStore.Require(_session, "backups.manage")', code)

    def test_backup_create_and_verify_use_recovery_service(self):
        code = (ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs").read_text(encoding="utf-8")
        self.assertIn("CreateEncryptedBackup(path, password, 20)", code)
        self.assertIn("VerifyEncryptedBackup(dialog.FileName, password)", code)
        self.assertIn('"MONARCH", "Backups"', code)

    def test_restore_tool_targets_legacy_framework_and_requires_confirmation(self):
        project = (ROOT / "src/Monarch.Recovery/Monarch.Recovery.csproj").read_text(encoding="utf-8")
        code = (ROOT / "src/Monarch.Recovery/Program.cs").read_text(encoding="utf-8")
        self.assertIn("<TargetFramework>net461</TargetFramework>", project)
        self.assertIn('"RESTORE"', code)
        self.assertIn("VerifyEncryptedBackup", code)
        self.assertIn("RestoreEncryptedBackup", code)

    def test_recovery_project_is_in_solution(self):
        sln = (ROOT / "MonarchERP.sln").read_text(encoding="utf-8-sig")
        self.assertIn('"Monarch.Recovery"', sln)


if __name__ == "__main__":
    unittest.main()
