from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
MIGRATION = ROOT / "database/migrations/2026-11-08-procurement-forecast-snapshots.sql"
GATEWAY = ROOT / "src/Monarch.Core/Autonomy/SqliteAutonomousProcurementDraftGateway.cs"
WORKFLOW = ROOT / "src/Monarch.Core/Autonomy/AutonomousProcurementWorkflow.cs"
ORCHESTRATOR = ROOT / "src/Monarch.Core/Autonomy/PredictiveProcurementDraftOrchestrator.cs"
ANALYTICS = ROOT / "src/Monarch.Core/Autonomy/ProcurementAnalyticsStore.cs"


def test_forecast_snapshot_migration_is_additive_repeatable_and_scoped():
    c = sqlite3.connect(":memory:")
    c.executescript("""
    CREATE TABLE monarch_procurement_recommendation_runs(
      company_id TEXT, branch_id TEXT, warehouse_id TEXT, recommendation_key TEXT,
      UNIQUE(company_id,branch_id,warehouse_id,recommendation_key));
    """)
    sql = MIGRATION.read_text(encoding="utf-8")
    c.executescript(sql)
    c.executescript(sql)
    cols = {r[1] for r in c.execute("PRAGMA table_info(monarch_procurement_forecast_snapshots)")}
    assert {"forecast_demand_milli", "horizon_days", "window_start_utc", "window_end_utc", "policy_version"} <= cols
    c.execute("INSERT INTO monarch_procurement_recommendation_runs VALUES('co','br','wh','key')")
    c.execute("""INSERT INTO monarch_procurement_forecast_snapshots
    VALUES('co','br','wh','item','key','po',12000,30,'2026-01-01T00:00:00Z','2026-01-31T00:00:00Z','demand-average-v1','2026-01-01T00:00:00Z')""")
    try:
        c.execute("""INSERT INTO monarch_procurement_forecast_snapshots
        VALUES('co','br','wh','item','key','po2',12000,30,'2026-01-01T00:00:00Z','2026-01-31T00:00:00Z','demand-average-v1','2026-01-01T00:00:00Z')""")
        assert False, "duplicate forecast snapshot must be rejected"
    except sqlite3.IntegrityError:
        pass


def test_forecast_is_frozen_in_same_gateway_transaction_as_recommendation():
    gateway = GATEWAY.read_text(encoding="utf-8")
    assert "INSERT INTO monarch_procurement_forecast_snapshots" in gateway
    assert "forecast.Transaction = tx" in gateway
    assert gateway.index("INSERT INTO monarch_procurement_forecast_snapshots") < gateway.rindex("tx.Commit();")
    workflow = WORKFLOW.read_text(encoding="utf-8")
    assert "ProcurementForecastSnapshot? ForecastSnapshot = null" in workflow
    orchestrator = ORCHESTRATOR.read_text(encoding="utf-8")
    assert "new ProcurementForecastSnapshot" in orchestrator
    assert '"demand-average-v1"' in orchestrator


def test_analytics_computes_wape_only_for_matured_tenant_branch_forecasts():
    source = ANALYTICS.read_text(encoding="utf-8")
    assert "ProcurementForecastAccuracy" in source
    assert "monarch_procurement_forecast_snapshots f" in source
    assert "f.company_id=$co AND f.branch_id=$br" in source
    assert "f.window_end_utc <= $until" in source
    assert "ABS(f.forecast_demand_milli" in source
    assert "(double)absoluteError / actual" in source
    assert "zero actual demand yields no percentage" in source
