# Restore-journal dangling symbolic-link cleanup — 2026-11-14

## Change
Added regression coverage for a matching GUID-N abandoned restore-journal temp represented by a dangling symbolic link. The test injects the enumerated directory entry, removes the link with file-entry unlink semantics, confirms its missing target remains absent, and repeats cleanup to verify idempotence. Added a C# source guard for direct `File.Delete(path)` semantics without a `File.Exists` preflight or recursive directory fallback.

## Scope
Test and documentation only. No production C# logic, database schema, WPF view, or ERP module changed.

## Validation boundary
The Python test exercises the host filesystem model and injected enumeration/deletion behavior. The source guard inspects C# text; it does not compile or execute the service. Windows/NTFS reparse-point, ACL, and sharing-violation behavior remains to be tested on Windows.
