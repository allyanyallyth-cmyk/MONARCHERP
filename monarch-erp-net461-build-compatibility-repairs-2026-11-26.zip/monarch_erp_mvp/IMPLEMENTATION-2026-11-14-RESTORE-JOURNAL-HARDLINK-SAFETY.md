# Restore-journal temporary hard-link safety — 2026-11-14

Added a filesystem regression test for a matching GUID-N abandoned journal-temp entry that is a hard link to a separately retained file. The test verifies cleanup removes only the temporary directory entry and preserves the retained file's bytes. This complements the existing symbolic-link target-preservation test.

Scope: Python filesystem-model test and documentation only. No production C#, database schema, WPF UI, or ERP module was changed. The test ran successfully on the current host; behavior of the compiled C# service on Windows remains unverified.

Validation: `pytest -q` — 740 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 tests OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. No .NET build, WPF runtime, or Windows filesystem/SQLite integration was run.
