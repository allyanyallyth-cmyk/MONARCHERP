# Restore journal strict UTF-8 corruption boundary

## Change

Added regression coverage for malformed byte sequences in the durable restore journal: an invalid leading byte, an invalid continuation byte, and a truncated multibyte sequence. The tests verify strict UTF-8 decoding rejects these inputs and that the modeled live database and rollback artifact remain byte-for-byte unchanged.

Added a source-structure assertion that `RecoverInterruptedRestore` uses `UTF8Encoding(false, true)` when reading the journal and performs that read before destructive recovery operations.

## Production scope

No production C# code was changed. No database schema, ERP module, or WPF UI was changed. The existing strict decoder was already present; this increment adds explicit regression coverage for its malformed-input boundary.

## Validation

- `pytest -q`: 697 passed.
- `python -m unittest discover -s tests -p 'test_*.py'`: 365 passed.
- XML/XAML/project/config parsing: 7 parsed, 0 errors.
- See `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-STRICT-UTF8.log` for scope and limitations.

C# compilation, WPF runtime, Windows filesystem behavior, and SQLite provider integration remain unverified because the .NET SDK and Windows runtime are unavailable in this environment.
