# MONARCH local identity and security baseline

## Implemented in this stage

- First-run administrator enrollment; no built-in/default password.
- PBKDF2-HMAC-SHA256 password derivation, per-user cryptographically random 16-byte salt, 32-byte derived key, and 210,000 iterations.
- Password minimum length of 12 characters.
- Five failed password attempts trigger a 15-minute temporary lockout.
- Seeded roles: Administrator, Accountant, Viewer.
- Permission checks in the desktop event handlers for account creation, journal creation/posting, and user administration.
- Audit records for successful/failed login, blocked login, user creation, and activation/deactivation.
- Last active Administrator cannot be deactivated.

## Current limitations

- The active WPF accounting path is tenant-scoped through `TenantAccountingSession`; company access and branch access are enforced by `TenantLedgerStore` and SQLite composite foreign keys. Every public ledger read/write requires user, company and branch identifiers; branch authorization is checked in the same SQLite transaction as the operation. The company-level chart of accounts is not exposed through company-only APIs. The legacy `monarch_accounts`/`monarch_journals` tables remain as a preserved migration source and are blocked from active WPF use when they contain data without a completed migration record.
- Password reset, password change, user reactivation UI, and audit browsing/export UI are not implemented.
- A user session is validated at login; disabling a user does not revoke an already-open desktop session until it is closed.
- The audit log is local and does not yet have tamper-evident chaining or external forwarding.
- SQLite database file protection relies on Windows account/file-system permissions. No database encryption is configured in this stage.
- This is a baseline for development and controlled testing, not a security certification or production deployment approval.

## Operational recommendations

- Use a unique administrator password and keep it in an approved password manager.
- Limit Windows access to the MONARCH data folder.
- Back up the full database while the application is closed, and verify restoration before relying on backups.
- Do not share a SQLite database file over a network share; use a future authenticated LAN service for multi-user network access.

## Backup and recovery baseline

- Backup artifacts use AES-256-CBC encryption with HMAC-SHA256 authentication (encrypt-then-MAC), using independent encryption and authentication keys derived from a random salt with PBKDF2-HMAC-SHA1 (310,000 iterations) for .NET Framework 4.6.1 compatibility.
- The HMAC is verified before decryption; restored plaintext is checked with SQLite `PRAGMA integrity_check` before replacement.
- Restore creates an encrypted pre-restore safety copy and retains a rollback file until the replacement database passes integrity verification.
- Restore is an offline maintenance operation: close MONARCH and all other processes connected to the database first.
- WPF `.mbackup` backups contain the entire shared database. Per-company selective restore is not implemented. The legacy-to-tenant migration tool creates a separate AES-256-GCM `.monarchbak` pre-import backup, decryptable only with `tools/decrypt_migration_backup.py`.
- The live SQLite database is not encrypted by this feature. Restrict its directory using Windows ACLs; backup encryption does not protect the live file.
- Losing the backup password makes the backup unrecoverable. Store it separately from backup files.
- C# smoke tests are present but must be run on Windows with the required .NET SDK/runtime before production use.


## Commercial document write authorization — 2026-11-07
`CommercialDocumentStore.CreateDraft` and `Post` authorize the active company role and active branch membership through the same SQLite connection/transaction used by the write. This closes the prior preflight gap for these two operations. Viewer is read-only. This hardening is scoped to this store; audit the remaining commercial, inventory, backup and administration write paths separately.
