# Supplier AP in-app WPF delivery adapter — 2026-11-11

## Scope

Added a user-facing in-app inbox to the existing Supplier AP operational alert tab. The adapter consumes the durable dispatch queue; it does not call external transports and does not mutate accounting or supplier-payables records.

## Behavior

- The inbox is available only through the existing `reports.read`-gated tab.
- Claims are requested with the active `UserId`, `CompanyId`, and `BranchId`; the dispatcher additionally constrains each claim to `recipient_user_id`.
- The bounded UI batch is 50 claims with a 60-second lease.
- The grid is bound before a successful delivery outcome is recorded.
- A successful delivery receipt means the in-app UI batch was prepared for display; it is explicitly not a read receipt.
- If UI preparation fails after claiming, the adapter records the bounded `UI_PRESENTATION_FAILED` outcome, allowing the dispatcher's existing retry/backoff policy to recover the intent. If completion itself cannot be persisted, lease expiry remains the recovery mechanism.
- The adapter does not run the accounting outbox worker, post journals, or record supplier payments.

## Validation

Python structural regression tests cover permission gating, active user/company/branch scope, binding-before-completion order, failure retry, and separation from accounting operations. These tests do not compile or execute the C# WPF application.

## Remaining

- Build Core and Desktop projects on a .NET-enabled Windows CI agent.
- Exercise actual WPF rendering, user switching, and lease-expiry recovery on Windows.
- Add UI-level duplicate presentation suppression across refreshes if product semantics require a persistent inbox history distinct from the immutable delivery-attempt log.
