# Implementation report — Backup/restore cross-process serialization

**Date:** 2026-11-12  
**Scope:** `src/Monarch.Core/Backup/BackupRecoveryService.cs` and regression tests.

## Change

- Added a named operating-system mutex keyed by SHA-256 of the normalized database path.
- Encrypted backup creation and restore acquire the same mutex before touching the database workflow.
- The wait is bounded to 30 seconds. A timeout raises `TimeoutException`; the operation does not continue without the lock.
- `AbandonedMutexException` is treated as successful ownership transfer, and mutex release is guaranteed by `finally`.
- Restore's call to create its safety backup is re-entrant on the owning thread.

## Safety boundary

The mutex coordinates only MONARCH processes that use this service implementation and the same path-normalization/naming scheme. It does not lock out unrelated SQLite clients or older MONARCH builds. Restore still requires other database users to be closed, especially clients that may hold WAL/SHM sidecars or active transactions.

## Validation

Python regression coverage asserts that backup and restore share the path-scoped mutex and that timeout, abandoned-owner, and release paths are present in source. Existing SQLite competing-worker tests remain in place. These checks are structural and do not demonstrate actual .NET named-mutex behavior.

C# build and Windows runtime tests were not executed in this environment because the .NET SDK/Windows runtime is unavailable. Required follow-up includes multi-process contention, abandoned-owner recovery, timeout behavior, nested safety-copy reentrancy, and WAL-sidecar tests on supported Windows targets.
