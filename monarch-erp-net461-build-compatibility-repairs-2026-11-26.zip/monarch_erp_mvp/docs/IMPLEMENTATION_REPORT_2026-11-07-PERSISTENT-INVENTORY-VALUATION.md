# Implementation report — persistent inventory valuation snapshots

Date: 2026-11-07

## Delivered

- Added `database/inventory-valuation.sql` with append-only valuation run, movement-entry, and remaining FIFO-layer tables.
- Added `InventoryValuationStore` to load the immutable stock ledger for one authorized company/branch/warehouse/item scope, run FIFO or moving weighted average through `InventoryValuationEngine`, and persist the complete snapshot in one SQLite transaction.
- The store rejects inactive/mismatched warehouses and non-stock/inactive items; company/branch write access and Viewer read-only restrictions are enforced.
- Added the schema to desktop output content and seven Python/SQLite contract tests.

## Verification

- `python -m unittest discover -s tests -q`: 162 tests passed.
- XML/XAML parse: 7/7 files passed.
- SQLite valuation schema initialization: passed in tests.
- .NET SDK unavailable in this environment; C# compilation, WPF execution, Windows CI, and installer build were not run.

## Important limitations

- The snapshot store is not yet called by sales/purchase/return posting transactions. A snapshot can therefore become stale after a later stock movement; rerun it to obtain a newer snapshot.
- No atomic cost allocation rows are yet attached to source document lines. FIFO return-cost reversal and transfer cost carry-forward are not complete.
- No COGS/Inventory accounting outbox integration or GL reconciliation is complete.
- This stage is not production-ready and must not be used as an approved financial valuation until the remaining integrations and Windows tests pass.
