# البنية المعمارية المقترحة

## المبدأ
MONARCH ERP منتج Desktop مستقل Offline-first. لا يحتاج المستخدم إلى اشتراك سحابي كي ينشئ القيود أو يدير عملياته المحلية. الاتصال بالهاتف أو الفروع ميزة اختيارية تُفعّل عبر خدمة API.

## الطبقات
1. **Monarch.Core**: نماذج الأعمال وقواعد الحسابات والتنبيهات؛ لا يعتمد على WPF أو قاعدة بيانات بعينها.
2. **Monarch.Infrastructure (المرحلة التالية)**: مستودعات البيانات، SQLite، الترحيلات، النسخ الاحتياطي والتشفير.
3. **Monarch.Desktop**: واجهة Windows عربية WPF.
4. **Monarch.Api**: بوابة اختيارية لاتصال LAN والهاتف؛ لا تتصل التطبيقات مباشرة بملف SQLite.
5. **Mobile**: تطبيق Android/iOS لاحقاً يستهلك API بصلاحيات المستخدم.
6. **Modules/Plugins**: وحدات مستقلة بعقود واضحة وإصدارات متوافقة.

## الذكاء الاصطناعي بأمان محاسبي
- الحسابات المالية، الأرصدة، الضرائب، الكميات، وإجماليات التقارير تُحسب برمجياً من سجلات مرحّلة.
- محرك القواعد يصدر تنبيهات محددة مثل حد إعادة الطلب، تاريخ الاستحقاق، فرق الصندوق، أو تغير غير اعتيادي.
- نموذج AI يشرح النتائج ويقارنها ويلخصها ويقترح أسئلة/إجراءات؛ لا يُسمح له بتوليد أرقام أو ترحيل قيد أو تعديل مخزون مباشرة.
- أي إجراء مؤثر يحتاج موافقة مستخدم مخول، مع سجل تدقيق.
- في الوضع المحلي يمكن تشغيل قواعد التنبيه دون إنترنت؛ ميزات النماذج السحابية اختيارية وتحتاج موافقة صريحة على مشاركة البيانات.

## التزامن والعمل متعدد الأجهزة
- جهاز واحد: قاعدة SQLite محلية.
- LAN: API تعمل على جهاز خادم داخل الشبكة وقاعدة بيانات خادمية مناسبة؛ لا تتم مشاركة ملف SQLite عبر SMB.
- الوصول الخارجي: HTTPS/VPN، مصادقة قوية، صلاحيات دقيقة، تدوير الجلسات، وسجل تدقيق.
- نحتاج سياسة تعارض مزامنة واضحة قبل السماح بتحرير نفس السجل من أكثر من جهاز.

## ضمانات دفتر القيود في المخطط الحالي
- الإدخال يبدأ كمسودة؛ الترحيل مشروط بوجود سطرين على الأقل وتوازن المدين والدائن وعدم استخدام حساب غير نشط.
- بعد الترحيل لا تتغير بيانات الرأس أو السطور ولا يُحذف القيد.
- القيد العكسي سجل مستقل مرتبط بالأصل، ويُتحقق من عكس إجمالي كل حساب قبل ترحيله.
- هذه ضمانات على مستوى SQLite في المخطط التأسيسي، وليست بعد خدمة تطبيقية متكاملة أو نظام ترحيلات قواعد بيانات.

## ملاحظة محاسبية
قبل الاستخدام التجاري يجب تنفيذ دورة محاسبية متكاملة: دليل حسابات، قيود مزدوجة متوازنة، ترحيل واعتماد، فترات مالية، عكس القيود بدلاً من حذفها، تسويات، ضرائب، تقارير، اختبارات إقفال، ونسخ احتياطي واستعادة مجرّبة.


## Accounting persistence boundary
`SqliteLedgerStore` is the infrastructure adapter for the deterministic `LedgerBook` domain. It loads a consistent ledger snapshot inside a SQLite transaction, applies the domain operation, and persists the delta before commit. Monetary values in `monarch_journal_lines` are signed-direction integer minor units (`debit_minor` / `credit_minor`). The desktop application must use this store rather than opening the database file directly from another device.


## Windows compatibility strategy
The desktop WPF host targets .NET Framework 4.6.1 for legacy Windows coverage (Windows 7 SP1, Windows 8/8.1, and newer Windows releases with a compatible .NET 4.x runtime); `Monarch.Core` multi-targets `net461` and `net8.0`. The ASP.NET Core API remains `net8.0` and is optional for offline single-PC use. A small `DateOnly`/`IsExternalInit` compatibility shim is compiled only for `net461`. This strategy is not a verified compatibility certification: build and runtime tests are still required on clean Windows 7 SP1, Windows 8/8.1, Windows 10, and Windows 11 machines.

## Local identity boundary (current stage)

The desktop process performs local authentication against the same SQLite file using `IdentityStore`. The first launch enrolls an administrator; subsequent launches require login. Roles are stored in tables and resolved into a permission set for the current session. The desktop event handlers check permissions again before mutating account/journal data. Authentication uses PBKDF2-HMAC-SHA256 with a random per-user salt and a temporary lockout policy. Audit events are persisted locally.

The identity layer is combined with company-scoped roles and branch access in `CompanyDirectoryStore`. The active WPF accounting path opens `TenantAccountingSession` after explicit company/branch selection. The account chart is stored at company scope, but every chart read/write is gated by access to the selected branch; journals and reports are branch-scoped. Posting and reversal require the journal to match the selected branch. Legacy single-company tables remain only as a migration source and are not the active WPF accounting path.


## Organization directory foundation
`Monarch.Core.Organizations.CompanyDirectoryStore` and `database/tenancy.sql` define companies, branches, company-scoped user roles, branch access and organization audit records. Composite foreign keys ensure a branch assignment belongs to the same company as the user's company membership.

The tenant ledger boundary is implemented in `TenantLedgerStore` and `database/tenant-accounting.sql`: accounts belong to a company, journals belong to a company and branch, and composite foreign keys prevent cross-company account/journal/branch references. Every operational ledger API requires `userId`, `companyId`, and `branchId`; even company-level chart reads/writes are gated by active access to the selected branch. Authorization and the associated ledger operation share one SQLite transaction. The WPF entry point now uses `TenantAccountingSession` and refuses to open when legacy ledger data has not been migrated. Legacy tables remain preserved for rollback and audit. See the latest tenant migration implementation report for the exact validation and remaining Windows verification gates.
