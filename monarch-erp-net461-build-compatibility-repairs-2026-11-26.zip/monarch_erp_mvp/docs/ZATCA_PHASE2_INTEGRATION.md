# دليل تكامل MONARCH مع ZATCA — Phase 2

## الفروق التنظيمية المهمة

- الفاتورة الضريبية القياسية (عادة B2B): تُرسل إلى FATOORA عبر Clearance قبل مشاركتها مع المشتري؛ تعيد المنصة XML بعد الختم ورمز QR.
- الفاتورة الضريبية المبسطة (عادة B2C): تُصدر وتُختم من حل EGS، ثم تُرسل عبر Reporting خلال 24 ساعة.
- الفاتورة القياسية لا تستخدم مسار Reporting، والمبسطة لا تستخدم Clearance.
- تطبيق Phase 2 تدريجي حسب المجموعات وإشعار الهيئة، لذلك يجب التحقق من موجة المنشأة وموعد إلزامها.

## إعداد التطوير

1. أكمل تسجيل/تهيئة وحدة EGS في بوابة FATOORA.
2. احتفظ بمعلومات CSID والسر في موفر أسرار خارجي يطبق `IZatcaCredentialProvider`؛ لا تحفظ السر في قاعدة البيانات التجارية أو ملفات README أو السجلات.
3. حقق `IZatcaCryptographicStampProvider` لتوقيع SHA-256 باستخدام ECDSA P-256 وإرجاع المفتاح العام وتوقيع CA المناسب.
4. حقق `IZatcaInvoiceXmlSigner` لتوليد توقيع XAdES كاملاً وفق متطلبات الهيئة، وليس مجرد تضمين قيمة التوقيع.
5. استخدم `ZatcaInvoicePreparationService.Prepare` لإنتاج ICV/PIH/QR وإضافة الفاتورة إلى السلسلة والـ Outbox.
6. شغّل `ZatcaSubmissionWorker.ProcessAsync` بعملية مجدولة/مراقبة بعد إعداد API client وموفر الأسرار.
7. خزّن XML المعاد من Clearance، وشارك المستند الذي أعادته الهيئة، لا نسخة الطلب غير المختومة.
8. نفّذ التحقق عبر ZATCA SDK والـ Sandbox قبل تفعيل الإنتاج.

## عناوين API الافتراضية

- Sandbox Base URI: `https://gw-fatoora.zatca.gov.sa/e-invoicing/developer-portal/`
- Production Base URI: `https://gw-fatoora.zatca.gov.sa/e-invoicing/core/`
- OAuth token: `connect/token`
- Clearance: `invoices/clearance/single`
- Reporting: `invoices/reporting/single`

العناوين والإصدارات قد تتغير؛ راجع دليل مطوري الهيئة الحالي قبل الإنتاج.

## قواعد QR TLV

- Tag 1: اسم البائع UTF-8.
- Tag 2: رقم تسجيل VAT للبائع.
- Tag 3: تاريخ/وقت ISO 8601 UTC.
- Tag 4: الإجمالي شامل الضريبة.
- Tag 5: إجمالي ضريبة القيمة المضافة.
- Tag 6: بصمة XML SHA-256 الثنائية.
- Tag 7: توقيع ECDSA.
- Tag 8: المفتاح العام.
- Tag 9: توقيع CA لمفتاح الختم للفواتير المبسطة.

تُخزن حقول 1–5 كنص UTF-8، والحقول 6–9 كبايتات ثنائية؛ كل TLV يتكون من Tag ثم Length كبايت ثم Value، ثم Base64. حد طول رمز QR حسب المواصفة 700 محرف Base64.

## القيود الحالية

هذا الإصدار لا يمثل شهادة امتثال ZATCA. التحقق البنيوي داخل Monarch لا يستبدل SDK الهيئة. مولّد XML لا يغطي بعد جميع قواعد البيانات/الحقول؛ وحساب البصمة يحتاج مطابقة دقيقة مع C14N 1.1 في SDK. كذلك لم يتم بعد بناء CSR/OTP/CSID، أو تنفيذ توقيع XAdES، أو ربط بيانات المبيعات الحالية تلقائياً، أو واجهة WPF للإعدادات.
