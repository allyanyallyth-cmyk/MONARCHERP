# Commercial payment RBAC and atomic audit

Date: 2026-11-08

## Changes

- `CommercialPaymentStore.Post` no longer performs a pre-transaction, broad role-name check.
- Customer receipts require `commercial.sales.manage`; supplier payments require `commercial.purchases.manage`.
- The permission query runs on the same SQLite connection and transaction as the payment. It verifies an active user, active company, active company membership, active branch membership, active branch, and an explicit role-permission grant.
- The payment operation writes `CustomerReceiptPosted` or `SupplierPaymentPosted` to `monarch_company_audit_log` before commit. The audit row is transaction-bound, so an audit insert failure rolls back the payment, all allocations, and the accounting outbox event.
- Audit details include party ID, payment type, amount in minor units, currency, payment method, cash/bank account code, and allocation count. No credentials or payment instrument secrets are recorded.
- Undefined payment type or method enum values are rejected.
- Public API signatures and database schema are unchanged. No migration is required.

## Preserved behavior

- Existing party validation and company-scoped document lookup remain in place.
- Allocation type, party, currency, scale, branch, status, outstanding-balance, and total-reconciliation checks remain in place.
- Payment, allocations, and accounting outbox remain atomic; GL posting remains delegated to its existing worker.

## Validation boundary

Python structural tests verify that permission and audit code are transaction-bound and that the expected authorization/audit fields are present. They do not execute the C# implementation or prove runtime rollback behavior. C# compilation and WPF runtime testing were not performed in this environment; do not treat this package as a verified Windows installer.
