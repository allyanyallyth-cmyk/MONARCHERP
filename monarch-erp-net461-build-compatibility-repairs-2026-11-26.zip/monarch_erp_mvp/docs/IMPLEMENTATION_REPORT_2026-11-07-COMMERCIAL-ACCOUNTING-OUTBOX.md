# MONARCH ERP — Commercial Accounting Outbox Worker

Date: 2026-11-07

## Delivered
- Added `CommercialAccountingOutboxWorker` to consume posted sales and purchase outbox events for an explicitly selected company and branch.
- Enforces ledger branch authorization even when no events are queued.
- Uses deterministic `AUTO-COM-{document-guid}` journal numbers. If the ledger journal was committed but the outbox acknowledgement was interrupted, a retry finds the existing journal and does not create a duplicate.
- Sales posting: debit receivables; credit sales revenue and output tax.
- Purchase posting: debit inventory for stock lines, purchases expense for service/non-stock lines, input tax, and credit payables.
- Validates configured account codes and account types before creating the journal.
- Uses integer minor-unit amounts, omits zero lines, posts only balanced journal entries through `TenantLedgerStore`, and records outbox attempts/errors for retry.

## Verification
- `python -m unittest discover -s tests -q`: 122 tests passed.
- Python tests include structural checks for tenant scoping, deterministic retry identity, account type validation, stock/non-stock purchase mapping, and failure retry tracking.
- C# build and runtime integration tests were not executed because this environment has no .NET SDK/compiler or Windows runtime.

## Important limitations
- Account-code defaults are illustrative; each company must configure codes matching its chart of accounts. There is no mapping UI yet.
- Ledger posting and outbox acknowledgement are separate transactions. Deterministic journal identity makes retries safe across a crash between them, but does not make the two commits one atomic transaction.
- No returns/credit notes, payment allocation, VAT filing, FIFO/weighted-average valuation, or WPF commercial screens yet.
- Not production-ready until C# integration tests, Windows build/acceptance, company account mapping, and accounting review are complete.
