# Commercial party read RBAC — 2026-11-08

## Scope
Added `CommercialStore.GetParties(Guid userId, Guid companyId, PartyType? type = null, bool activeOnly = true)` as a tenant-scoped read API.

## Authorization
- `Customer` queries require `commercial.sales.manage`.
- `Supplier` queries require `commercial.purchases.manage`.
- Unfiltered queries and explicit `Both` queries require both grants because they can expose both commercial domains.
- Customer and supplier views include records classified as `Both`.
- Authorization and parameterized company-scoped selection execute in the same SQLite transaction.

## Compatibility and safety
- No schema change or migration was added.
- The read method does not call initialization or migration code.
- Existing APIs and data model remain unchanged.
- `activeOnly` defaults to true; callers may explicitly request inactive records but must still hold the corresponding permission.

## Validation limits
Python structural tests validate the intended source structure only. They do not execute C# or prove SQLite behavior. .NET SDK/MSBuild and WPF runtime validation were not performed in this environment.
