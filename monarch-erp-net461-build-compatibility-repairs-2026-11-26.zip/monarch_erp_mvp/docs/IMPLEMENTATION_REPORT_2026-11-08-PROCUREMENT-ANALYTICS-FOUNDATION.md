# Procurement Analytics Foundation — 2026-11-08

## Delivered

- Added `ProcurementAnalyticsStore` as a read-only Core reporting service.
- Enforced `reports.read`, active user, active company, and active branch membership in the same SQLite transaction used for report queries.
- Added approval KPIs based on immutable decision history and purchase-order creation timestamps: total decisions, approved, rejected, average elapsed hours, and rejection rate.
- Added supplier delivery performance based on completed (`Received`) purchase orders and posted receipt timestamps. On-time rate is null when no expected timestamp exists; partial receipts are not treated as completed deliveries.
- Added item consumption ranking from `Issue`, `TransferOut`, and `PurchaseReturn` stock movements in the requested branch/date range.
- Added bounded date-range and top-N inputs, plus optional query indexes in `2026-11-08-procurement-analytics-indexes.sql`.
- Explicitly reports forecast accuracy as unavailable. The existing durable recommendation ledger stores identity and PO linkage, not a frozen forecast quantity, so deriving forecast accuracy would be misleading.
- No cross-currency money totals are calculated.

## Validation

- `python3 -m pytest -q`: 405 passed.
- `python3 -m unittest discover -s tests -p 'test_*.py' -q`: 308 tests OK. Existing ResourceWarnings about unclosed SQLite connections were emitted by other test paths.
- Analytics index migration applied twice in an in-memory SQLite test; all indexes were present and the migration remained idempotent.
- C# build and WPF runtime were not executed because .NET SDK/MSBuild are unavailable in this environment.

## Explicit limitations

- This is a Core analytics foundation, not yet a WPF dashboard.
- Forecast-versus-actual accuracy requires immutable forecast quantity snapshots, policy/version, and a defined measurement horizon. Those are not persisted today.
- Supplier delivery completion uses the latest posted receipt timestamp for fully `Received` orders; operational reconciliation and partial-delivery analytics need broader integration tests against a fully migrated tenant database.
- Apply the additive index migration manually after a verified backup. No startup auto-migration was introduced.
