# Implementation report — durable procurement approval gate

Date: 2026-11-07

## Delivered

- Added explicit additive SQL migration `database/migrations/2026-11-07-autonomous-procurement-approval.sql`.
- Added dedicated `commercial.purchases.approve` permission (granted to the seeded Administrator role only).
- Added tenant/branch-scoped durable approval queue with a unique queue item per purchase order, rationale, decision actor/time/note, and inbox index.
- Added database trigger that blocks direct approval of any purchase order already present in the autonomous approval queue unless the queue is approved by the same user recorded as `approved_by`.
- Added immutable terminal queue decisions.
- Added `ProcurementApprovalQueueStore`: enqueue an existing draft, list pending items for a user with the approval permission, and approve/reject in one SQLite transaction. Approval updates queue state, PO state, and audit log atomically; any failure rolls back all three.
- Added SQLite integration tests for migration shape, bypass prevention, matching approver, and terminal-decision immutability.

## Deliberate boundaries

- Migration is not executed automatically at startup. Back up and explicitly apply it after verifying the database baseline.
- The current queue store enqueues an already-created Draft PO. The `IProcurementDraftGateway` adapter that creates the PO and its queue row in one transaction is not yet implemented; therefore the autonomous forecast-to-draft end-to-end workflow is not declared production complete.
- The existing general-purpose `PurchaseOrderStore.Approve` path is not changed. The database trigger specifically protects POs that have entered this new approval queue.
- No .NET compilation was performed because `dotnet`, `msbuild`, and `csc` are unavailable in this environment.

## Validation

- Pytest: 356 passed.
- Unittest discovery: 308 tests, OK. Existing SQLite ResourceWarnings about unclosed connections remain visible.
- XML/XAML/CSProj parsing: 7/7 OK.
- ZIP integrity: validated separately at packaging time.
