# MONARCH ERP — Restore integrity result cardinality guard

Date: 2026-11-13  
Baseline: `monarch-erp-restore-integrity-result-completeness.zip`

## Change

`BackupRecoveryService.CheckIntegrity` now accepts SQLite `PRAGMA integrity_check` as successful only when exactly one row is returned and its value is `ok`. An empty result set and anomalous multiple rows that all say `ok` are rejected. Error rows continue to be recorded as integrity failures.

This follows SQLite's success result shape and prevents a malformed/unexpected provider result from being interpreted as proof of integrity.

## Regression coverage

- Added a Python source-structure assertion for the exact-one-`ok` rule.
- This is not an execution test of the C# method or SQLite provider.

## Scope and limitations

- No schema, migration, backup format, WPF, or module changes.
- C# build, provider integration, and Windows runtime: NOT RUN (`dotnet` unavailable).
