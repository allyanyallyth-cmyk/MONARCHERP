# Tenant Identity Administration Audit — 2026-11-08

## Delivered

Added `TenantIdentityAuditStore` in Core. It writes user-administration events to the existing `monarch_company_audit_log` table and reads them by explicit company and branch. Both operations require `users.manage`; the actor must also have active company and branch access. Reads support bounded time/action filters and a maximum page size of 5,000. Writes use a SQLite transaction and parameterized SQL. No schema migration or external dependency was added.

## Scope and integration boundary

This is an explicit audit API for tenant-scoped identity administration. It is **not automatically emitted** by legacy `IdentityStore.CreateUser`, `SetUserActive`, or global role operations because those APIs do not receive company/branch context. Callers must invoke this API after the corresponding tenant-scoped administration action. Therefore it does not yet guarantee atomic coupling between a separate identity mutation and its audit event. The existing global `monarch_audit_log` remains intact.

The new API relies on `monarch_user_company_access`, `monarch_user_branch_access`, `monarch_branches`, and `monarch_company_audit_log`, which are created by the existing tenancy schema. The application must initialize the existing security and tenancy schemas before using it.

## Security notes

- Company and branch are mandatory and are checked against active membership records.
- The actor must carry `users.manage` in the authenticated `UserSession`.
- SQL values are parameterized; output is bounded and ordered newest first.
- This store uses the SQLite company audit table; it does not claim cryptographic tamper evidence or central multi-device replication.

## Validation limits

Python source-contract tests validate the intended guards and query shape. .NET SDK/MSBuild were not available in the environment, so C# compilation and SQLite runtime integration were not executed. Existing modules and prior tests were retained.
