# MONARCH ERP — Restore integrity-check result completeness

Date: 2026-11-13  
Baseline: `monarch-erp-committed-recovery-integrity-guard.zip`

## Change

`BackupRecoveryService.CheckIntegrity` now counts rows returned by SQLite `PRAGMA integrity_check`. If the provider returns no rows, the check reports an explicit integrity issue. Previously, a zero-row result could leave the issue list empty and be interpreted as `ok`. This change makes the integrity gate fail closed for that anomalous provider/result state.

## Regression coverage

- Added a source-structure assertion that the result count is initialized, incremented for each returned row, and checked for zero before success is returned.
- This assertion does not execute C# or simulate a provider returning no rows.

## Scope and limitations

- No schema, migration, backup format, WPF, or module changes.
- C# build and runtime: NOT RUN (`dotnet` unavailable).
- Windows SQLite provider integration: NOT RUN.
