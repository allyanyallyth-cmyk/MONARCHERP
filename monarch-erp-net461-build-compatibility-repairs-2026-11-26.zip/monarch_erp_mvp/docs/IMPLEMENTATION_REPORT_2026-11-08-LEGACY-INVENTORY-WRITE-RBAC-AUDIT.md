# MONARCH ERP — Legacy Inventory Write-Path RBAC and Audit Hardening

Date: 2026-11-08

## Scope
Hardened the compatibility write APIs in `CommercialStore` without removing or renaming public methods:

- `AddUnit` now requires `inventory.items.manage`.
- `AddItem` now requires `inventory.items.manage`.
- `AddWarehouse` now requires `inventory.warehouses.manage` and active access to the specified company branch.
- Each authorization check runs inside the same SQLite transaction as its write.
- Each successful write appends a parameterized `monarch_company_audit_log` event before commit. An audit failure therefore rolls back the associated write.
- Existing signatures and data behavior are retained for compatibility with existing callers. No schema migration was added.

## Security properties
The new checks validate active user identity, active company membership, active company, assigned role permission, and (for warehouses) active branch membership and branch. The write and audit use the same `SqliteTransaction`.

## Verification
- `python3 -m pytest -q`: **493 passed**.
- `python3 -m unittest discover -s tests -p 'test_*.py' -q`: **327 tests OK**. Existing SQLite `ResourceWarning` messages about unclosed connections were emitted by tests; they did not fail the suite.
- XML/XAML/CSProj parse: **7/7 passed**.
- Archive integrity: verified after packaging.
- C# compilation and WPF runtime: **NOT RUN**. `dotnet`, `msbuild`, and `csc` are not available in this environment.

## Cumulative integrity
This package is based on `monarch-erp-inventory-master-data-read-rbac-stage.zip`. All prior file paths are retained. This stage adds the implementation report and one structural test, modifies `CommercialStore.cs`, `README.md`, and `ROADMAP.md`, and deletes no files.

## Remaining work
Continue auditing legacy commercial write APIs outside inventory (for example party/customer/supplier writes) for granular RBAC and atomic audit. Validate the complete solution with a Windows/.NET build and WPF integration run before claiming install-ready status.
