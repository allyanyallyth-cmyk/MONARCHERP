# MONARCH ERP Implementation Report — Restore Journal Path Hardening

Date: 2026-11-12

## Scope

Hardened `BackupRecoveryService.RecoverInterruptedRestore` so a journal-supplied rollback path is accepted only when it is in the live database directory, has the exact live database filename followed by `.pre-restore-`, and ends in a 32-character GUID token in `N` format.

## Rationale

A simple string-prefix check on the full path can accept sibling names sharing a textual prefix. Recovery later moves or deletes files at the journal path, so validating the exact filename shape and directory before touching artifacts narrows the set of paths the recovery journal can direct the service to use.

## Changes

- Replaced the broad full-path prefix test with directory equality, exact database-specific filename prefix, token-length validation, and `Guid.TryParseExact(..., "N", ...)`.
- Added regression assertions for malformed suffixes, invalid GUID tokens, prefix-sibling filenames, and a valid GUID suffix.
- Updated README and ROADMAP while retaining all prior modules and work.

## Validation

- `python -W error::ResourceWarning -m pytest -q`: **621 passed**.
- `python -m unittest discover -s tests -p 'test_*.py' -q`: **365 passed**.
- XML/XAML/C# project parsing: **7 files parsed successfully**.
- .NET SDK/build: not available; no C# compilation or WPF runtime test is claimed.
- Windows crash-injection and filesystem durability tests: not run.

## Security boundary

This validation is defense-in-depth against malformed or unexpected journal paths. It does not cryptographically authenticate the journal against a privileged local writer. Filesystem permissions and a future explicit journal-authentication design remain relevant to the threat model.
