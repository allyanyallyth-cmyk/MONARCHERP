# Supplier AP Alert Dispatcher — Implementation Report

## Scope

This stage adds a durable, tenant-scoped work queue for the in-app delivery intents created by the preceding alert-delivery stage. It does not send email, SMS, push notifications, or network requests. A trusted in-app adapter is still required to consume a claim and report its result.

## Implementation

- `SupplierPayablesAlertDispatcher.ClaimDue` authorizes the user through `TenantLedgerStore.GetEntries` before reading or claiming rows and filters the claim query by `recipient_user_id=$user`.
- Claims are bounded to 1–100 rows and leases to 10–600 seconds.
- Claim ownership is represented by a random token and UTC expiry. Completion requires matching company, branch, intent, token, and an unexpired lease.
- Expired claims can be reclaimed. Reclaiming a claim does not count as a completed delivery attempt.
- `CompleteAttempt` records only allow-listed, bounded error codes; it never persists raw exception text or transport payloads.
- Attempt outcomes are append-only. Failed delivery is rescheduled with exponential backoff starting at 15 seconds and capped at 15 minutes. The eighth completed failure moves the item to `DeadLetter`.
- Successful adapter confirmation moves the item to `Delivered`.
- Migration backfills existing intents and automatically enqueues subsequently inserted intents.

## Safety boundaries

The dispatcher does not mutate the immutable source intent, alert diagnostics, supplier AP worker leases, outbox accounting events, journal entries, balances, or invoice/payment state. It performs no external transport. The caller must not report `Delivered` until the in-app adapter has actually accepted/rendered the notification according to its own contract.

## Migration

Apply `database/migrations/2026-11-11-supplier-ap-alert-dispatcher.sql` after the preceding alert-delivery migration and after taking a database backup. No automatic migration is performed.

## Verification limits

Python/SQLite tests validate schema constraints, enqueue/backfill behavior, company/branch/recipient scoping, bounded attempts, and source-level dispatcher contracts. Final results: pytest 577 passed with `ResourceWarning` promoted to errors; unittest discover 365 passed with `PYTHONTRACEMALLOC=1` and no ResourceWarnings. A regression case creates two recipients in one branch and verifies that only the matching recipient sees the intent. They do not compile or execute the C# implementation. .NET SDK/MSBuild and live WPF runtime validation remain outstanding in this environment.

## Follow-up security correction — 2026-11-11

The initial dispatcher query scoped work by company and branch but did not restrict the recipient. Both `ClaimDue` and `CompleteAttempt` now include the authenticated `userId` in the recipient predicate. The regression suite explicitly distinguishes two users in the same branch. The ledger authorization preflight remains required on both operations; the recipient predicate is an additional data-level boundary.
