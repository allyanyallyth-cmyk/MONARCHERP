# MONARCH ERP — Backup restore failure-safety regression coverage

Date: 2026-11-12

## Scope

This cumulative stage adds regression coverage for the restore safety contract without changing the production backup format, database schema, or migration sequence.

## Coverage added

- Wrong password and modified authenticated payload are rejected while the live database bytes remain unchanged.
- An authenticated but invalid SQLite payload is rejected during preflight; the live database remains unchanged and no safety copy is created.
- A successful modeled restore retains the original live database as a safety copy and validates the restored database.
- Structural assertions check that `BackupRecoveryService.RestoreEncryptedBackup` authenticates before candidate-file creation, performs SQLite integrity/foreign-key preflight before safety backup and replacement, retains rollback logic, and checks the replaced database.

## Important test boundary

The Python test uses a deliberately test-only HMAC envelope and a Python SQLite restore model. It is not the MONARCH encrypted-backup format and does not execute the C# service. Source-order checks are structural only. Windows file replacement behavior, WAL/SHM sidecar handling, injected post-replacement failures, C# compilation, and WPF runtime behavior remain unverified.

## Production impact

No production C# code, backup format, migration, or schema was changed in this stage. This avoids claiming runtime safety based only on a Python simulation. The next required validation is a Windows/.NET integration suite that invokes the real C# service against file-backed databases and fault-injects each restore boundary.
