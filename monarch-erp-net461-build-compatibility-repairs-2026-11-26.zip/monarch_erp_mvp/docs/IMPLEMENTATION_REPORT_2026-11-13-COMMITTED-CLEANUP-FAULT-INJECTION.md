# MONARCH ERP — Committed cleanup fault-injection

Date: 2026-11-13
Baseline: `monarch-erp-prepared-recovery-fault-injection.zip`

## Change
Added a deterministic Python filesystem-model regression that injects process termination after each of the three committed-phase rollback-artifact deletions (previous database, previous WAL, previous SHM). Each interrupted state is then passed through a fresh recovery attempt. The assertions require the already-verified live database to remain unchanged and all remaining rollback artifacts to be cleaned.

No production C# code, database schema, module, or UI behavior was changed.

## Validation
- pytest: 644 passed.
- unittest: 365 passed.
- XML/XAML/project/config parsing: see accompanying test log.
- .NET SDK: unavailable; C# build and WPF runtime not run.
- Windows SQLite provider and real process-termination tests: not run.

The new tests exercise a Python filesystem model, not the compiled `BackupRecoveryService`; they are not evidence of Windows runtime durability.
