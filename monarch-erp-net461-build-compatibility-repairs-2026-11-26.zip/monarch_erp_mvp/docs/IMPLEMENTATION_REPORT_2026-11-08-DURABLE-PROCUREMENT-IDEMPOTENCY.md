# Implementation report — durable predictive procurement idempotency

## Delivered

- Added `database/migrations/2026-11-08-durable-procurement-recommendation-idempotency.sql`, an explicit additive migration creating a durable recommendation-run table with a unique key over company, branch, warehouse and recommendation key.
- Added an optional recommendation key to `ProcurementDraftRequest` and propagated it through the existing draft-only workflow. Requests without a key remain compatible with the manual-draft path.
- Added deterministic SHA-256 recommendation identity based on company, branch, warehouse, item, UTC analysis day and policy parameters.
- Updated the SQLite draft gateway to check an existing key, verify its item binding and return the existing PO/approval queue on replay. For a new key, it inserts the claim before the PO header, within the same SQLite transaction as PO lines/totals, manager approval queue and audit. A failed transaction rolls the claim back with the rest of the draft.
- Added Python tests that execute the migration against SQLite, prove scoped uniqueness, and verify the source-level transaction/replay contracts.

## Operational requirements and boundaries

1. Back up the database and explicitly apply the migration before enabling predictive draft requests with a recommendation key. Startup does not apply it.
2. The key is a daily analysis/policy identity, not a permanent lock on an item. A new UTC analysis day or policy creates a new identity.
3. SQLite uniqueness prevents two committed claims for the same scope/key. A simultaneous losing first writer may receive a SQLite uniqueness/locking error; retrying the same request then reads and returns the committed existing PO. Automatic retry/backoff is not yet implemented.
4. Manual drafts without a recommendation key do not query the new table.
5. Supplier-item lead-time/price master data, manager WPF approval center, notifications, and provider-backed concurrent integration tests remain pending.
6. The C# solution was not built in this environment because .NET SDK/MSBuild/C# compiler tools are unavailable. Python tests do not substitute for a C# build or Windows runtime validation.

## Validation

- `python3 -m pytest -q`: 381 passed.
- `python3 -m unittest discover -s tests -p 'test_*.py' -q`: 308 tests OK.
- The migration's uniqueness and scope behavior was executed against Python SQLite.
