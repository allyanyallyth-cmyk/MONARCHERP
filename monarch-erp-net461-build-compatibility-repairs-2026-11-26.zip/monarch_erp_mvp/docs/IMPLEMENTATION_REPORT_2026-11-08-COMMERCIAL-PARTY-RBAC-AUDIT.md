# Commercial party RBAC and atomic audit — 2026-11-08

## Scope
Hardened the legacy `CommercialStore.AddParty` write path while preserving its public signature and the existing commercial schema.

## Changes
- Customer creation requires the explicit `commercial.sales.manage` grant.
- Supplier creation requires the explicit `commercial.purchases.manage` grant.
- A `Both` party requires both grants; neither permission implies the other.
- Authorization uses the existing `RequireCompanyPermission` query inside the same SQLite transaction as the insert. The query checks active user, active company, active company membership, and an explicit role-permission grant.
- The party insert and `CustomerPartyCreated`, `SupplierPartyCreated`, or `CommercialPartyCreated` audit event commit atomically. Audit failure rolls back the party insert.
- Undefined party types and negative credit limits/payment terms are rejected before persistence.
- Audit details contain only party type and code; contact and tax fields are not copied into the audit detail string.
- Existing API signature, tables, and schema are unchanged; no migration is required.

## Validation limits
Python tests verify source structure and invariants only. They do not execute the C# implementation. .NET Core/Desktop compilation and WPF runtime validation were not performed in this environment.
