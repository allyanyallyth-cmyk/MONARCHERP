# MONARCH ERP — Tenant migration and desktop wiring report

Date: 2026-11-06

## Implemented

1. Added `tools/migrate_legacy_ledger.py` with explicit database/company/branch arguments.
2. Dry-run validates SQLite integrity and foreign keys, required schemas, active company/branch, matching currency, account/journal references, posted journal balance, and exact account-level reversal lines.
3. Import creates a consistent SQLite online backup and encrypts it using AES-256-GCM with PBKDF2-HMAC-SHA256 (600,000 iterations). Existing backup destinations are never overwritten.
4. Import uses one `BEGIN IMMEDIATE` transaction, preserves account and journal IDs, imports line amounts in minor units, resolves reversal dependencies, verifies row counts, each journal's status/branch/totals, and posted per-account balances. A migration history row prevents a second import. Legacy tables are not deleted or modified.
5. Added `tools/decrypt_migration_backup.py` to decrypt and run SQLite integrity validation on the migration-specific backup format.
6. Added tenant-aware currency metadata to `TenantAccountingSession`.
7. WPF now initializes shared schemas, bootstraps the first global Administrator's default-company membership only when no company memberships exist, blocks legacy-data launch until migration history exists, prompts for an authorized company and branch, opens `TenantAccountingSession`, and routes accounting reads/writes/reports through that session.
8. Monetary display/input uses the selected company's currency exponent. Newly created users receive access to the current company and branch according to their selected role.

## Verification performed

- `python -m unittest discover -s tests -v`: 92/92 passed.
- `.csproj` and XAML XML parsing: 7/7 passed.
- Migration integration tests exercised successful import, dry-run non-mutation, exact reversal state, idempotency, currency mismatch rejection, invalid branch and non-GUID ID rejection, no-inverse rejection, backup overwrite protection, global ID collision rejection, and transactional rollback.
- ZIP integrity is verified at packaging time (see release checksum file).

## Not verified

- `dotnet`, `csc`, and `msbuild` are unavailable in this environment. No C# compilation, WPF execution, or C# smoke test was performed.
- No Windows 7/8.1/10/11 runtime compatibility test was performed.
- No MSI/Setup installer was produced.
- No live customer database was migrated. The migration tests use temporary SQLite databases with controlled fixtures.

## Operational migration

The user must close MONARCH, install `tools/requirements.txt`, run Dry-run, inspect its report, then run import and preserve the encrypted backup and passphrase. The default seeded target is company `00000000-0000-0000-0000-000000000001`, branch `00000000-0000-0000-0000-000000000002`. Currency mismatches are refused rather than converted.
