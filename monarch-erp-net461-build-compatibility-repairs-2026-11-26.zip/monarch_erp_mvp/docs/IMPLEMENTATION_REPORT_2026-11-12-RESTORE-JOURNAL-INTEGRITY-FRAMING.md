# Implementation Report — Restore Journal Integrity Framing

Date: 2026-11-12

## Scope

Hardened the SQLite restore recovery journal while preserving compatibility with previously written three-line V1 journals.

## Changes

- New writes use the `MONARCH-RESTORE-JOURNAL-V2` marker and include a SHA-256 checksum over the four preceding fields.
- Recovery uses strict UTF-8 decoding and validates the checksum before consuming V2 journal fields or acting on a rollback path.
- V1 three-line journals remain supported for interrupted operations created by earlier cumulative packages.
- Invalid format, truncated records, invalid phases, and checksum mismatches fail closed and preserve recovery artifacts.

## Security boundary

The checksum is unkeyed. It detects accidental corruption and inconsistent edits but does not authenticate the journal against a local actor able to rewrite both content and checksum. A keyed mechanism requires a separately validated Windows-compatible key-protection design and is not claimed by this change.

## Validation

- `python -W error::ResourceWarning -m pytest -q`: 630 passed.
- `python -m unittest discover -s tests -p 'test_*.py' -q`: 365 passed.
- C# compilation and WPF runtime tests: not run; .NET SDK availability was not established in this environment.
- Windows process-termination / power-loss integration tests: pending.
