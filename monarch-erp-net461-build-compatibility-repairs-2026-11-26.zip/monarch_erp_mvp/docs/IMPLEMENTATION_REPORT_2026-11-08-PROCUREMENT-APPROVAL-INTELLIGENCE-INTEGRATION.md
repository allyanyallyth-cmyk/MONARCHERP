# MONARCH ERP — Procurement Approval Intelligence Integration

Date: 2026-11-08

## Delivered

- Added `ProcurementApprovalIntelligenceService` in Core.
- The service requires the selected approval queue item to remain pending for the supplied manager/company/branch, using the existing permission-checked queue query.
- Reads only the associated Draft purchase order and its persisted lines in the same company/branch scope.
- Calls the existing `ProcurementSupplierIntelligenceAdvisor` for each item and returns ranked, evidence-backed supplier alternatives alongside the supplier and price actually stored on the draft.
- Added a read-only supplier comparison panel to the WPF procurement manager approval tab. It shows the selected supplier, alternatives, currency, unit cost, tax rate, contractual lead time, verified receipt count, observed on-time rate, score and risk flags.
- No migration was added. No supplier, price, tax, purchase order, approval status, inventory, or ledger data is changed by this comparison.

## Security and operational boundaries

- The queue lookup enforces `commercial.purchases.approve` and active company/branch access.
- Supplier comparison uses `SupplierIntelligenceStore`, which independently enforces `reports.read` and the same tenant/branch scope.
- Consequently, users viewing this combined panel need both permissions.
- A missing supplier term or missing receipt history remains absent; the panel does not invent prices or performance.
- Mixed currencies remain explicitly non-comparable through the advisor's existing flags.
- The panel is decision support only. It does not select a new supplier or silently amend a queued order. Any future commercial change should create a reviewed revision with audit history.

## Validation

Python contract tests and repository-wide checks are recorded in the delivery summary. C# compilation and WPF runtime validation require a Windows environment with the relevant .NET SDK/MSBuild and have not been claimed as completed in this environment.
