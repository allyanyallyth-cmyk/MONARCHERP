# MONARCH ERP — Warehouse transfer costing and authorization

Date: 2026-11-07

## Delivered

- Removed caller-provided `unitCostMinor` from `CommercialStore.TransferStock`; the service now derives carrying cost from the source warehouse/item movement stream.
- Replays source movements in persisted `ledger_sequence` order through `InventoryValuationEngine` using `MovingWeightedAverage`.
- Uses the derived unit cost for both transfer legs and persists both legs in the same SQLite transaction.
- Moved source and target branch authorization into that same transaction and validates active user status, active company/branch memberships plus both active warehouse mappings.
- Rejects transfer when the source quantity is non-positive, even if the item permits negative stock, because no reliable positive carrying value can be derived.
- Added structural regression tests for no caller-supplied cost, persisted-sequence costing, and transaction-bound authorization.

## Verification

- Python tests: run result recorded in the release status for this stage.
- XML/XAML/project parse: not modified in this stage; validation run separately.
- C# compilation, WPF execution, and Windows compatibility: not run in this Linux environment; .NET SDK/MSBuild are unavailable.

## Limitations

- The transfer costing policy is currently Moving Weighted Average; company/item-level costing policy selection is not implemented.
- Transfer cost is carried in stock movement rows but is not yet reconciled to general-ledger Inventory/COGS control accounts.
- End-to-end C# tests and Windows runtime acceptance remain mandatory before production use.
