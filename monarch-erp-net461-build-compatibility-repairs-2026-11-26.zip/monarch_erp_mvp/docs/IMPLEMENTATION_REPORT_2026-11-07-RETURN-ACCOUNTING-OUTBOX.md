# Implementation report — return accounting outbox worker

Date: 2026-11-07

## Delivered

- Added `CommercialReturnAccountingOutboxWorker` to process posted sales/purchase return events for an authorized company and branch.
- Sales return journal: debit sales returns (expense/contra-revenue), debit output-tax liability, credit accounts receivable.
- Purchase return journal: debit accounts payable, credit purchases expense, credit input-tax asset.
- Validates posted return state, exact event type, active ledger accounts and account types.
- Uses deterministic `AUTO-RET-<return-guid>` journal numbers to make retries idempotent after a ledger commit/outbox-acknowledgement interruption.
- Persists failed status, attempt count and bounded error detail; successful events are acknowledged only after the journal is posted.
- Added five structural regression tests for tenant scoping, mappings, retry behavior and valuation guardrails.

## Accounting boundary

This worker reverses trade value and tax only. It does not reverse sales COGS or adjust perpetual inventory valuation because source cost layers are not yet persisted. Purchase returns credit the purchases expense account (periodic-inventory treatment); they are intentionally not credited to the inventory asset account at sales price or invoice price. FIFO/weighted-average cost layers, COGS reversal and VAT-report integration remain outstanding.

Ledger posting and outbox acknowledgement are separate transactions. Deterministic journal identity protects retries; this is not a distributed atomic transaction.

## Verification

- Python/SQLite suite: **149/149 tests passed**.
- XML/XAML parse check: **7/7 files passed**.
- `dotnet` is unavailable in this environment; C# compilation, WPF execution, Windows CI and installer generation were not performed.
