# Procurement report export audit center

## Delivered
- Added a verified audit reader that refuses to return entries if the hash chain is invalid.
- Added structured entry parsing for timestamp, user, tenant, branch, report type, format, date range, output path, byte count, content SHA-256 and chain hash.
- Added optional company, branch, user and format filters.
- Added UTF-8 BOM CSV export of verified audit entries, with spreadsheet-formula injection protection for textual fields.
- Added a WPF audit-center tab gated by `reports.read`, scoped to the active company and branch, with format filter, chain verification, and CSV export.

## Limitations
The log remains a per-user/per-device local file. The UI scopes visible/exported rows to the active company and branch, but the underlying file can contain multiple tenants if the same Windows profile hosts them. There is no centralized aggregation, cross-process file lock, digital signature, remote tamper-proof storage, or .NET/WPF runtime validation in this environment. `reports.read` is the existing permission reused; no new RBAC permission was introduced.
