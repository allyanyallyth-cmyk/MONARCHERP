# MONARCH ERP — Supplier AP persistent inbox read state

Date: 2026-11-11

## Scope

This additive stage establishes durable, recipient-specific read state for supplier AP in-app delivery intents. It deliberately separates `Delivered` (dispatcher outcome) from `Viewed` and `Acknowledged` (user actions).

## Changes

- Added `database/migrations/2026-11-11-supplier-ap-alert-inbox-read-state.sql`.
- Added `SupplierPayablesAlertInboxStore` and `SupplierPayablesAlertInboxItem` in `src/Monarch.Core/Commercial/SupplierPayablesAlertInboxStore.cs`.
- Added Python regression coverage in `tests/test_supplier_ap_alert_inbox_read_state.py`.
- The store authorizes company/branch access through `TenantLedgerStore` before reads and writes; all queries additionally fence by recipient user, company, and branch.
- The delivered inbox projection is bounded to 1–500 records. Read markers are append-only, idempotent, and can be recorded only for an intent already delivered to that exact recipient scope.
- The service does not claim work, schedule retries, mutate dispatcher state, run workers, or post accounting entries.

## Migration order

Back up the database, then apply the existing supplier AP alert delivery migration, dispatcher migration, and finally the new inbox read-state migration. No automatic migration is performed.

## Explicit limitations

This stage provides the durable Core persistence service; the existing WPF inbox has not yet been rewired to render historical delivered items or expose read/acknowledgement actions. Operator-facing dead-letter inspection/manual retry remains pending and will require an audited retry-cycle design that preserves immutable attempt history. No C# build or WPF runtime claim is made because the current environment does not provide the .NET SDK.
