# MONARCH ERP — Commercial Document RBAC & Draft Audit

## Delivered
- `CommercialDocumentStore.CreateDraft` now requires `commercial.sales.manage` for Sale and `commercial.purchases.manage` for Purchase.
- `CommercialDocumentStore.Post` reads the tenant/branch-scoped draft type, then requires the matching dedicated permission before mutating inventory/document/outbox state.
- Authorization is evaluated inside the same SQLite transaction as the operation and checks active user, active company, active branch, active company membership, active branch membership, and explicit role permission.
- Draft creation appends `CommercialDocumentDraftCreated` to `monarch_company_audit_log` before transaction commit. If the audit insert fails, the draft and its lines are rolled back.
- Existing posting audit, stock movement/cost allocation, and accounting outbox behavior are preserved.
- Existing public method signatures and database schema are unchanged. No migration is required.

## Scope and constraints
- This stage does not add customer/supplier CRUD APIs.
- `commercial.purchases.manage` remains granted according to the existing security seed (Administrator by default); no implicit role grants were added.
- This does not establish that all payment, return, party, or other commercial APIs have been fully reviewed.
- No automatic journal posting behavior was introduced.

## Verification
- Python structural tests verify type-specific permissions, tenant/branch/RBAC predicates, draft audit-before-commit, and transaction binding.
- Python test suite and XML/XAML/project parsing results are recorded in the package test log.
- C# compilation and WPF runtime were not executed in this environment; Windows/.NET integration validation remains required.
