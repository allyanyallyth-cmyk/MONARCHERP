# Procurement Report Export Audit

## Delivered
- Added `ProcurementReportExportAuditStore`, a local append-only audit log for successfully saved procurement reports.
- Each entry records UTC time, user/company/branch IDs, report type, format, date range, encoded output path, byte count, and SHA-256 content digest.
- Entries are linked with a SHA-256 hash chain. `Verify` validates the complete chain; appending is blocked when existing history fails verification.
- CSV, XLSX, and HTML report save flows record an audit entry after writing the output file.
- Audit file location: `%LOCALAPPDATA%/MONARCH ERP/Audit/procurement-report-exports.log`.

## Boundaries
- The log is local to the Windows user profile and is not synchronized between workstations.
- The hash chain detects accidental or unsophisticated edits; it is not a digital signature and does not prevent an administrator from rewriting the entire file.
- The append lock is process-local. Concurrent writes from multiple MONARCH processes to the same audit file require a future cross-process lock or centralized audit store.
- Audit failure is surfaced to the operator; the report file may already have been written before the audit append fails.
- No commercial database migration or external package was added. The feature does not alter accounting or procurement records.

## Validation
- Python regression tests cover the presence of hash-chain verification and all three export integrations.
- A .NET SDK/MSBuild environment is required to compile the Core multi-target project and run the WPF application; this environment does not provide those tools.
