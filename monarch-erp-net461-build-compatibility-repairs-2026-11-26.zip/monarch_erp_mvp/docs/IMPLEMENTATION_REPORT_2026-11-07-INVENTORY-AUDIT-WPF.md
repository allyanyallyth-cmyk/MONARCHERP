# Implementation report — WPF Inventory Movement Audit

Date: 2026-11-07

## Scope

Integrated the existing read-only inventory movement lineage service into the WPF desktop interface. The new tab is available only to authenticated sessions carrying `reports.read` and inspects the currently selected company and branch through `TenantAccountingSession`.

## Changes

- `src/Monarch.Desktop/MainWindow.xaml.cs`
  - Added an Arabic read-only audit tab.
  - Added a local cutoff-date picker interpreted through the workstation timezone and converted to UTC.
  - Passes authenticated `userId`, active `companyId`, active `branchId`, and cutoff to `InventoryMovementLineageStore.Inspect`.
  - Displays movement identity, date, sequence, type, warehouse, item, source document, cost allocation, outbox, journal and Arabic lineage state.
  - Displays counts for total movements, fully linked movements and exceptions.
  - Catches missing-schema/inspection errors and clears stale rows; no automatic schema migration is attempted.
- `src/Monarch.Core/Commercial/InventoryMovementLineageStore.cs`
  - Authorization now additionally requires the database-backed `reports.read` role permission inside the same SQLite read transaction as the scoped query.
  - Retains active user/company/branch membership checks and exact company/branch/cutoff filters.
- Tests
  - Added UI wiring/permission-scope assertions.
  - Added SQLite execution test proving an authorized report reader passes and removal of `reports.read` denies access.

## Verification

- Full Python suite: **217/217 passed**.
- New structural and SQLite authorization checks: passed as part of the full suite.
- XML/XAML/project parsing: **7/7 passed**.
- C# build: NOT RUN; `dotnet` is not installed in this environment.
- WPF runtime: NOT RUN.
- Windows 7 SP1/8.1/10/11 compatibility: NOT verified by runtime tests.

## Safety and known limits

- The screen is read-only; it never repairs inventory, creates accounting journals, or mutates outbox state.
- The commercial schema is not initialized automatically from the screen because the existing initializer also performs stock movement sequence migration/backfill. Missing schema is reported to the user; a separately reviewed explicit migration step remains required for legacy databases.
- Date cutoff is end-of-selected-day in the workstation local timezone, then converted to UTC.
- No production readiness or Windows compatibility claim is made.
