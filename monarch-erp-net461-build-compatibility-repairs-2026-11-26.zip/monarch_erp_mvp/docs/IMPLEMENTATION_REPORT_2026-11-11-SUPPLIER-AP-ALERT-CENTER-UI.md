# Implementation report — Supplier AP alert center UI

## Scope
Integrated the existing operational alert projection and append-only lifecycle store into the WPF desktop application.

## Delivered
- New Arabic UI tab, available only to users with `reports.read`.
- Company/branch-scoped alert loading through `SupplierPayablesAccountingOutboxWorker.GetOperationalAlerts`.
- User-specific lifecycle state loading through `SupplierPayablesOperationalAlertLifecycleStore.GetStates`.
- Explicit `MarkViewed` and `Acknowledge` actions for the selected alert.
- Visible severity, code, summary, event count, latest event time, and lifecycle flags.
- Clear migration prerequisite message when the lifecycle table is not present.

## Safety boundaries
The UI does not invoke worker processing, payment posting, journal posting, lease renewal, or outbox mutation. The lifecycle store checks tenant access through `TenantLedgerStore` before reads and writes. The feature remains reporting-permission gated.

## Migration
Apply `database/migrations/2026-11-11-supplier-ap-alert-lifecycle.sql` before using lifecycle state/actions.

## Validation limitations
Python structural tests can verify wiring and authorization arguments, but cannot prove C# compilation, WPF rendering, or runtime interaction. .NET SDK/MSBuild is unavailable in the packaging environment; these remain required on Windows CI.
