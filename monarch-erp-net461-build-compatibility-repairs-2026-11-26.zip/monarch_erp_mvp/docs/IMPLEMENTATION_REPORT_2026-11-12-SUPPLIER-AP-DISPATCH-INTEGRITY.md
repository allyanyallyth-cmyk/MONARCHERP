# Supplier AP dispatch integrity hardening — 2026-11-12

## Scope

This cumulative increment hardens the existing supplier-payables alert dispatch lifecycle without replacing its delivery-intent, dispatcher, inbox, read-state, or dead-letter features.

## Changes

- Added `database/migrations/2026-11-12-supplier-ap-alert-dispatch-integrity.sql` after the 2026-11-11 dead-letter migration.
- Added a unique index on `(intent_id, attempt_number)` so each immutable attempt-history sequence number is unique per delivery intent, including across operator-triggered retry cycles.
- Added an intent/time index for dead-letter operator-action history.
- Hardened `ClaimDue`'s state transition with a second company/branch/recipient scope predicate in the guarded update, not only in the preceding selection.
- Hardened `CompleteAttempt`'s guarded update with company/branch/recipient scope, the current lease token, and an unexpired lease predicate.
- Added regression tests for duplicate sequence rejection, two manual retry cycles preserving globally increasing attempt numbers, stale-lease fencing, and additive migration behavior.

## Migration safety

Apply after:
1. `2026-11-11-supplier-ap-alert-delivery.sql`
2. `2026-11-11-supplier-ap-alert-dispatcher.sql`
3. `2026-11-11-supplier-ap-alert-inbox-read-state.sql`
4. `2026-11-11-supplier-ap-alert-dead-letter-operations.sql`

Back up the database first. Unique-index creation intentionally fails if duplicate `(intent_id, attempt_number)` rows already exist; inspect and reconcile such corruption explicitly. The migration does not delete, renumber, or rewrite historical attempts.

## Verification

- `python -W error::ResourceWarning -m pytest -q`: **597 passed**.
- `python -m unittest discover -s tests -p 'test_*.py' -q`: **365 passed**.
- XML/XAML parsing: recorded in the accompanying test log.
- C# build and WPF runtime: **not run**; the environment does not have the .NET SDK (`dotnet` command unavailable).

Python/SQLite tests verify schema and SQL-level invariants; they do not substitute for compiling or executing the C# dispatcher on Windows.
