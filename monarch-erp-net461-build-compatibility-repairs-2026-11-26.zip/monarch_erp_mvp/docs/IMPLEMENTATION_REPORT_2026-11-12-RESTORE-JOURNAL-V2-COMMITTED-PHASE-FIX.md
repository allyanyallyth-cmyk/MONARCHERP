# Restore Journal V2 Committed-Phase Recovery Regression Fix

Date: 2026-11-12

## Problem

The restore journal reader supports both legacy V1 (three fields) and V2 (five fields). It normalized the parsed phase into `phase`, but the committed-state branch compared `lines[2]` directly with `committed`. In V2, `lines[2]` is the `hadPrevious` flag and `lines[3]` is the phase. Consequently, a valid V2 committed journal could incorrectly enter the prepared-recovery path.

## Change

Changed the dispatch condition to `phase == "committed"`, so both V1 and V2 use the normalized parsed value. Added regression coverage for V2 field layout and a source assertion preventing reintroduction of the version-specific index comparison.

## Validation

- `python -W error::ResourceWarning -m pytest -q`: 632 passed.
- `python -m unittest discover -s tests -p 'test_*.py' -q`: 365 passed.
- XML/XAML/project-file parsing: recorded in the accompanying test log.
- C# build and WPF runtime: not run; .NET SDK availability must be checked separately and is not inferred from Python tests.

## Scope

No database schema, backup encryption format, ERP module, or existing project file was removed. This correction fixes recovery dispatch only; it does not claim keyed journal authenticity or Windows crash-durability verification.
