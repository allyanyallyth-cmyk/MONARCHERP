# MONARCH ERP — Release status snapshot

Date: 2026-11-07

## Latest delivered source stage — Inventory/GL reconciliation (2026-11-07)

The cumulative source now includes sales COGS posting and a read-only `InventoryGlReconciliationStore`. It recalculates inventory value per warehouse/item from the persisted movement ledger (Moving Weighted Average only; FIFO is blocked until transfer layer lineage is complete), then compares the branch inventory asset balance from posted tenant journals. Reconciliation is authorized by `userId + companyId + branchId` inside the same SQLite read transaction. The service reports variances and never creates adjustment journals.

## Automated checks in this workspace

- Python/SQLite tests: **208 passed** (201 from the prior sales COGS stage plus 7 reconciliation tests).
- XML/XAML/project files parsed: **7/7 passed**.
- Tests cover accounting integrity, tenant isolation and authorization, migration dry-run/import/rollback/idempotency, commercial documents/payments/returns, cost allocations, inventory sequence, COGS posting, and reconciliation SQL isolation.
- The standalone multi-line journals package from 2026-11-06 17:21 UTC is older; its functionality is included in the cumulative source.

## Not verified / remaining work

- No `dotnet`, `msbuild`, or `csc` executable is installed. C# compilation, C# smoke-test execution, WPF launch, installer generation, and Windows 7 SP1/8.1/10/11 runtime compatibility are not verified.
- FIFO issue-layer consumption and warehouse transfer cost lineage are not complete.
- Minor-unit rounding reconciliation and full Inventory/COGS-to-GL reconciliation remain incomplete.
- VAT filing workflow, unapplied advances/refunds/voids, FX, and commercial WPF screens remain incomplete.
- AR/AP subledger-to-GL reconciliation is not yet a completed acceptance workflow.

## Release gate

This remains a development/foundation build. Do not use it as the authoritative system for live accounting, inventory valuation, tax filing, or customer balances until Windows builds and integration tests pass, return/payment/document accounting reconciles to GL, backup/restore is validated, and operational acceptance is complete.


## Latest verification update — persistent movement sequence

- Python/SQLite tests: **169 passed**.
- Persisted `ledger_sequence` now orders valuation movements; old database migration and warehouse-transfer sequence assignment are implemented.
- C# compilation, WPF execution, installer creation, and Windows compatibility remain unverified because this environment has no .NET SDK/compiler or Windows runtime.
- This does not complete perpetual inventory costing: per-document FIFO/weighted-average allocations, original-cost return reversals, transfer cost carry-forward, COGS/Inventory journal posting, and GL reconciliation remain release blockers.

## Latest verification update — persistent return cost reversals

- Python/SQLite tests: **185 passed**.
- Added immutable return cost reversal allocations tied to original sales-issue or purchase-receipt allocations, return lines and stock movements.
- Sales returns now generate Inventory/COGS reversals using historical cost; purchase returns credit inventory at original carrying cost and post carrying-cost differences to purchase price variance.
- Return movements receive permanent warehouse/item ledger sequence numbers. Composite unique indexes support tenant-scoped foreign keys on both fresh and pre-existing databases.
- C# compilation and WPF execution remain unverified because no .NET SDK/compiler or Windows runtime is available here. No installer or Windows compatibility run is claimed.
- FIFO issue-layer consumption, transfer cost lineage, minor-unit rounding reconciliation, full inventory-to-GL reconciliation, and commercial WPF screens remain outstanding. This is not a production release.


## Latest verification update — WPF tenant authorization hardening (2026-11-07)

- Python/SQLite suite: **190 passed** after branch-scoping all TenantLedgerStore operations.
- Every operational tenant ledger API now requires user, company and branch IDs. Chart-of-accounts reads/writes require active access to the selected branch even though the chart itself is company-level.
- Authorization checks and ledger reads/writes share one SQLite transaction; commercial Outbox workers pass the selected branch for chart reads.
- C# smoke tests were extended for cross-company chart isolation, branch denial, Viewer write denial, wrong-branch posting/reversal and permission revocation. They were not run in this environment.
- No `dotnet`, `msbuild`, or `csc` executable is installed. C# compilation, WPF launch, GitHub Actions, installer generation, and Windows 7 SP1/8.1/10/11 runtime compatibility remain unverified.
- The desktop source has a migration gate before the tenant selector: if legacy ledger rows exist and the default-company migration marker is absent, the accounting workspace is not opened.

**Release decision:** development-only. Do not use as the authoritative system for live accounting, inventory valuation, tax filing or customer balances until Windows build/runtime acceptance, migration/recovery drills, and full Inventory/COGS-to-GL reconciliation pass.


## Follow-up package — commercial write authorization (2026-11-07)
- Hardened `CommercialDocumentStore.CreateDraft` and `Post`: active company role and branch membership are checked inside the same SQLite transaction as the write.
- Added 3 structural tests; complete Python/SQLite suite now passes **193/193**. XML/XAML parse **7/7**.
- C# build/smoke tests, WPF execution and Windows CI remain unrun because `dotnet`, `msbuild` and `csc` are unavailable in the packaging environment.
- This patch is scoped to commercial document draft/post authorization; remaining write paths still require a transaction-bound authorization audit.

## تحديث 2026-11-07 — تحصين تفويض تقييم المخزون

- نقل تحقق صلاحيات المستخدم والمنشأة والفرع لتقييم المخزون إلى معاملة SQLite نفسها المستخدمة لقراءة الحركات وحفظ لقطة التقييم.
- أصبح المستخدم مطالباً بأن يكون نشطاً، وأن تكون عضويتا المنشأة والفرع نشطتين.
- صلاحية حفظ لقطة التقييم محصورة صراحة في `Administrator` و`Accountant`.
- اختبارات Python/SQLite: **196/196 ناجحة**.
- بناء C# وWPF واختبارات C# وWindows CI: **لم تُنفذ** لعدم توفر .NET SDK/Windows runtime في بيئة إعداد الحزمة.
- تقييم المخزون لا يزال غير مربوط ذرياً بترحيل المستند التجاري؛ ولا تزال قيود Inventory/COGS ومطابقة الأستاذ العام ضمن الأعمال المتبقية.

## Latest verification update — warehouse transfer cost lineage (2026-11-07)

- Python/SQLite and structural suite: **199/199 passed**.
- XML/XAML/project parse: **7/7 passed**.
- `CommercialStore.TransferStock` no longer accepts a caller-supplied unit cost. It derives source carrying cost by replaying persisted movement sequence with Moving Weighted Average and applies it to both transfer legs.
- Source and target branch permissions, active user, active company/branch memberships, and warehouse mappings are checked in the same transaction as the paired transfer write.
- A transfer is rejected if the source balance is not positive, even when negative inventory is configured, because carrying cost cannot safely be derived.
- C# compilation, C# smoke tests, WPF execution, installer creation, Windows CI, and Windows compatibility were **not run**; `dotnet`, `msbuild`, and `csc` are unavailable in this workspace.
- FIFO layer depletion at sales issue, configurable company/item costing policy, cost rounding reconciliation, transfer/return-to-GL reconciliation, and production acceptance remain open.

**Release decision remains development-only.** No claim of Windows 7 SP1 or later compatibility is made without actual clean-machine testing.


## Latest verification update — sales COGS posting (2026-11-07)

- Python/SQLite and structural tests: **201 passed**. Two new tests assert that sale COGS is sourced from immutable `SalesIssue` cost allocations, scoped by company/branch/document, and never derived from sales price.
- `CommercialAccountingOutboxWorker` now posts debit COGS / credit Inventory using the persisted historical stock issue cost. A stock sale with positive stock-line value but no persisted cost allocation is rejected and remains retryable/failed in the outbox rather than being posted incompletely.
- Added configurable `CostOfGoodsSoldCode`, default `5000` (Expense).
- This affects new sales journals created by the updated worker. Existing posted deterministic journals are idempotently skipped; historical sales already marked processed are **not** auto-adjusted. A controlled historical reconciliation/adjustment workflow is still required.
- C# compilation, C# smoke tests, WPF execution, Windows CI, installer generation and Windows compatibility were not run.

**Release decision remains development-only.** Full Inventory/COGS-to-GL reconciliation, historical adjustment, FIFO layer depletion, cost rounding policy, Windows build/runtime acceptance and recovery drills remain release gates.


## Latest verification update — Inventory/GL reconciliation (2026-11-07)

- Added read-only branch-scoped comparison of inventory movement valuation to the posted balance of a configured active Asset account.
- Current inventory value is recalculated from movement sequence per warehouse/item using Moving Weighted Average only; FIFO is blocked until layer lineage is preserved across transfers. GL balance includes only Posted journals in the same company and branch.
- Added 7 Python structural/SQLite tests; total suite: **208/208 passed**. XML/XAML/project parse: **7/7 passed**.
- C# build, C# smoke tests, WPF execution, Windows CI, installer generation, and Windows 7 SP1/8.1/10/11 runtime tests remain **not run**; this environment has no `dotnet`, `msbuild`, or `csc`.
- This is current-balance diagnostic reconciliation only. Moving Weighted Average is the only currently permitted method; FIFO fails closed until layer lineage is preserved across transfers. Opening stock movements must be complete and the inventory GL account must not contain unrelated postings. No automatic adjustment is made; historical cut-off reconciliation and source-document lineage checks remain open.

**Release decision remains development-only.** No production accounting or Windows compatibility claim is made.


## Latest verification update — inventory/GL as-of reconciliation (2026-11-07)

- `InventoryGlReconciliationStore.Reconcile` now requires an explicit `DateTimeOffset asOfUtc`; both stock movements (`occurred_utc`) and GL journals (`posted_at_utc`) are cut off at the same normalized UTC instant.
- Historical GL query includes journals currently marked `Reversed` when they were posted by the cutoff, and includes the reversal journal only when its own posting timestamp is within the cutoff. Draft and future-posted journals are excluded.
- Result exposes `AsOfUtc` separately from report generation time.
- Python/SQLite suite: **210/210 passed**. XML/XAML/project parse: **7/7 passed**. Two additional tests cover explicit cut-off and historical reversal semantics.
- `dotnet`, `msbuild`, `csc`, and `mono` are unavailable; C# build/smoke tests, WPF execution, Windows CI, installer, and Windows 7 SP1/8.1/10/11 runtime checks were **not run**.
- This is historical-by-posting-time read-only reconciliation, not business-date/period-close reconciliation. FIFO remains blocked; no automatic adjustments are created.

**Release decision remains development-only.** No production accounting or Windows compatibility claim is made.

## Latest verification update — Inventory Movement Lineage Audit (2026-11-07)

- Added read-only `InventoryMovementLineageStore` to trace stock movement → commercial document/return → immutable cost allocation → accounting outbox → deterministic tenant-ledger journal.
- The inspection API requires user/company/branch and an explicit UTC cutoff. Authorization is checked inside the same SQLite read transaction; records are restricted to the selected company and branch.
- Return lineage exposes both the return record and its original invoice. Transfer pairs are considered valid only when there are exactly two opposite movement types, two distinct warehouses, and matching item, quantity, and unit cost.
- Added 5 Python/SQLite tests that execute the actual lineage SQL against test fixtures and cover sale, return, transfer pairing, tenant/branch/cutoff scoping, and read-only behavior.
- Full Python suite: **215/215 passed**. XML/XAML/project parse: **7/7 passed**.
- C# build, C# runtime tests, WPF execution, Windows CI, installer creation, and Windows 7 SP1/8.1/10/11 compatibility tests: **NOT RUN**; `dotnet`, `msbuild`, `csc`, and `mono` are unavailable.
- The audit is not wired to WPF yet and does not repair missing links or post adjustments. Internal warehouse transfers are shown as paired movements, without a separate GL journal in the current design.

**Release decision remains development-only.** No production accounting or Windows compatibility claim is made.

## تحديث لاحق — 2026-11-07: أوامر الشراء
- تمت إضافة نواة أوامر الشراء (مسودة/اعتماد/إلغاء/قائمة) وصلاحية مستقلة وتدقيق ذري.
- اختبارات البيئة: 264 pytest و241 unittest ناجحة.
- لا تزال واجهة WPF، استلام المشتريات، فاتورة المورد، وبناء Windows غير مكتملة/غير متحققة. هذا الإصدار غير معتمد للاستخدام المالي الإنتاجي.

## Latest verification update — ZATCA Phase 2 foundation (2026-11-07)

- Added `Monarch.Core.Zatca`: TLV/Base64 QR, UBL 2.1 invoice generator, SHA-256 hash/PIH/ICV chain, immutable SQLite chain + claimable submission outbox, OAuth2 Basic API client, and explicit Clearance/Reporting worker.
- Added 12 structural/SQLite tests. Full Python suite: **326/326 passed**; unittest: **303/303 passed**. The commercial schema scripts executed in-memory with `PRAGMA foreign_key_check` returning no errors.
- `System.Security.Cryptography.Xml` dependency added for XML canonicalization.
- No `dotnet`, `msbuild`, or `csc` is installed. C# build, C# tests, WPF execution, and ZATCA Sandbox/Production requests were **not run**.
- Not yet compliant/production-ready: C14N 1.1 must be verified byte-for-byte against ZATCA SDK; no CSR/OTP/CSID onboarding or secure credential/key vault; no built-in ECDSA/XAdES signer (simplified Phase-2 path fails closed until injected); UBL business-rule coverage incomplete; no mapping from existing sales documents; no WPF EGS setup; no credit/debit notes or FX.

**Release decision:** Development foundation only. Do not issue legally operative invoices or transmit real taxpayer data until official SDK validation, sandbox acceptance, secure onboarding/key custody, and tax/legal review are complete.
