# Implementation report — Purchase receipt Green Ledger integration

## Delivered

- Extended `PurchaseOrderReceiptStore.Receive` to retrieve each received item's base-unit code.
- In the existing receipt transaction, aggregates receipt quantities by base unit and resolves the approved `PURCHASED_GOODS` factor effective at the receipt timestamp.
- Persists immutable `PurchaseReceipt` carbon snapshots with the selected factor-version ID and calculated kg CO2e.
- When no valid approved factor exists, persists a `Pending` carbon measurement gap and audit event. It does not fabricate zero emissions and does not block normal receipt posting.
- Added `2026-11-07-z-purchase-receipt-green-ledger-integration.sql` with tenant/branch-scoped measurement gaps, a queue index and a no-delete trigger.
- Integration is conditional on the explicit Green Ledger and measurement-gap migrations being applied. Existing deployments without those tables retain their prior receipt behavior.

## Transaction boundary

The carbon snapshot or measurement-gap record is committed or rolled back together with the purchase receipt, stock movements, cost allocations, accounting posting outbox, order received quantities and receipt audit event. No network or external service call is made inside this transaction.

## Limitations

- The activity taxonomy currently uses `PURCHASED_GOODS` and item base-unit codes. Organizations must approve factor versions with matching units and reliable source references.
- Measurement gaps are durable but require a future authorized review/resolution workflow.
- This change is source- and schema-tested in the current environment; .NET compilation and WPF execution require a Windows/.NET SDK build environment.
- The new migration is explicit and must be applied after `2026-11-07-versioned-green-compliance-ledger.sql`; it is never applied automatically at startup.

## Verification

- `python3 -m pytest -q`: 372 passed.
- `python3 -m unittest discover -s tests -p 'test_*.py' -q`: 308 tests, OK (pre-existing ResourceWarnings from unclosed SQLite test fixtures).
- XML/XAML/CSProj parse: 7/7 OK.
- No .NET compiler/build tools are installed in this environment; no C# build is claimed.
