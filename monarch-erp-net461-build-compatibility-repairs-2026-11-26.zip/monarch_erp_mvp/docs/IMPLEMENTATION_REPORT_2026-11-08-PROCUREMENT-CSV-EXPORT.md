# MONARCH ERP — Procurement Analytics CSV Export

## Scope

Added a dependency-free CSV export path for three existing read-only procurement analytics reports:

- Supplier/item performance, preserving currency code and minor-unit cost values.
- Supplier performance trends, including comparison reliability and alert classification.
- Matured procurement forecast history, including policy version, horizon, forecast/actual quantities and error metrics.

## Implementation

- Added `ProcurementAnalyticsCsvExporter` in Core with typed input contracts and UTF-8 BOM output for spreadsheet compatibility.
- Uses invariant-culture numeric serialization, RFC-style quoted cells, doubled embedded quotes, and CRLF row endings.
- Neutralizes spreadsheet formula-leading untrusted text (`=`, `+`, `-`, `@`, tab and carriage return) by prefixing an apostrophe.
- Added three WPF export actions using `Microsoft.Win32.SaveFileDialog` and the existing `reports.read` permission.
- Each export re-queries the existing read models using the active user, company and branch context. No user-supplied SQL, posting, approval, or database mutation is introduced.
- No package dependency or database migration was added.

## Verification

Python source-contract tests cover report coverage, encoding, numeric culture, CSV quoting, formula-injection mitigation, permission checks and tenant/branch context. These tests do not compile C# or prove WPF runtime behavior.

A full .NET Framework 4.6.1 build and interactive Windows validation remain required in a Windows environment with the supported .NET toolchain.
