# Implementation report — persistent stock movement sequence

Date: 2026-11-07

## Delivered

- Added `ledger_sequence` to `monarch_stock_movements`, scoped by company, warehouse and item.
- `CommercialStore.RecordMovement` allocates the next sequence inside the same SQLite transaction as the immutable movement insert.
- Both legs of `TransferStock` receive independent monotonically increasing sequences in their respective warehouse/item streams while remaining in the same transfer transaction.
- `CommercialStore.Initialize` performs an idempotent schema upgrade for existing databases: it detects the column, adds it when absent, backfills old rows by `occurred_utc` and `rowid`, and creates a partial unique index.
- The migration temporarily drops and then recreates only the stock-movement update guard inside the migration transaction, because legacy movement rows are otherwise immutable. The delete guard remains active.
- `InventoryValuationStore` now reads and passes the persisted sequence; `InventoryValuationEngine` orders by sequence, not by event timestamp or UUID. This means a late-posted/backdated movement remains in its actual ledger posting order rather than silently rewriting prior cost flow.
- Added tests for sequence allocation, migration shape, backfill order, per-warehouse/item scope, and valuation sequence consumption.

## Verification

- Python/SQLite tests: 169 passed.
- XML/XAML/project XML parsing: passed (7 XAML and project files checked during this stage).
- .NET build and WPF runtime: not executed; this environment does not provide `dotnet`, `msbuild`, `csc`, or Windows.

## Scope limits

This stage establishes durable ordering only. It does not yet implement persistent FIFO layer consumption/allocation at invoice posting, weighted-average cost capture on each issue, original-cost sales return reversals, source-cost warehouse transfer integration, COGS/Inventory journal events, or stock-to-GL reconciliation. Existing posted documents are not retroactively re-costed. The upgrade should be backed up before running against a customer database.
