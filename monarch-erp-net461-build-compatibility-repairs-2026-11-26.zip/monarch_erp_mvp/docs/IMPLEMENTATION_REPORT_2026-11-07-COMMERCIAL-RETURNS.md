# Implementation report — commercial returns foundation

Date: 2026-11-07

## Delivered

- Added `CommercialReturnStore` with SalesReturn and PurchaseReturn draft/post workflows.
- Every return references a posted source invoice in the same company, branch, party, warehouse, and currency.
- Return lines reference the exact source invoice line and preserve item, SKU, name, unit-price, tax-rate and amount snapshots.
- Return quantities cannot exceed the source invoice line's remaining quantity. The limit is rechecked during posting and enforced again by a SQLite status-transition trigger, protecting against competing drafts and direct SQL writes.
- Sales returns add stock (`SalesReturn`); purchase returns remove stock (`PurchaseReturn`). Service/non-stock lines do not create inventory movements.
- Posting commits immutable stock movements, return status and a unique `monarch_return_accounting_outbox` event in one SQLite transaction.
- Posted returns and their lines are immutable. Branch/company authorization is checked by the store.
- Added composite uniqueness for `(company_id,id)` on document lines to support valid tenant-scoped foreign keys from return lines.

## Verification

- Python/SQLite suite: 144 tests passed.
- New tests cover source-document type/context validation, source-line matching, sales-return stock direction, purchase-return stock direction, immutable posted returns, unique outbox events, and cumulative over-return rejection at posting.
- ZIP integrity and XML/XAML parsing: 6/6 files passed.
- C# compilation and WPF execution are not claimed; this environment has no .NET SDK or Windows runtime.

## Explicit limitations

- The return accounting outbox is created but no return-specific GL worker has been implemented yet.
- Sales cost-of-goods-sold accounting and inventory valuation are not yet implemented; stock quantities are updated, but this is not a complete perpetual inventory valuation model.
- Credit/debit note presentation, tax-report integration, refunds, write-offs, multi-currency exchange differences and WPF return screens remain outstanding.
- Amounts for partial returns are allocated proportionally from the source line and rounded to minor units; a full production release needs an explicit residual-rounding policy for multiple partial returns.
