# MONARCH ERP — Commercial Payments Foundation

Date: 2026-11-07

## Implemented

- Added `monarch_commercial_payments`, `monarch_commercial_payment_allocations`, and `monarch_payment_accounting_outbox`.
- Added immutable posted-payment and allocation guards.
- Added SQLite allocation validation: posted document only, matching company/branch/party/document direction/currency, and no over-allocation of either payment or invoice.
- Added `CommercialPaymentStore.Post` for customer receipts and supplier payments. It checks company/branch write access, validates the party role, requires positive allocations, computes the payment total with checked integer arithmetic, verifies invoice outstanding balances, and commits the payment, all allocations, and outbox event atomically.
- Supports multiple invoice allocations per payment. Unapplied advances and partial payment of the payment instrument are intentionally excluded; each payment must be fully allocated.

## Verification

- Python/SQLite test suite: 129 tests passed.
- SQL schema initializes with foreign-key enforcement in the test harness.
- .NET/C# compilation and WPF execution were not run: the current build environment has no .NET SDK or Windows runtime. These results are not a substitute for C# compilation.

## Known limitations

- The payment outbox consumer and automatic GL posting are implemented in `CommercialPaymentAccountingOutboxWorker`; see `IMPLEMENTATION_REPORT_2026-11-07-PAYMENT-ACCOUNTING-OUTBOX.md`.
- Cash/bank account code is stored as a mapping key but is not yet validated against a configured cash/bank account registry.
- No payment void/reversal, refunds, unapplied advances, bank reconciliation, or WPF payment screens.
- The workflow is a foundation and must not be used for production accounting until C# build, integration tests, and accounting review pass.
