# MONARCH ERP — Restore recovery code review and regression checks

Date: 2026-11-13  
Baseline: `monarch-erp-restore-recovery-restartability.zip`

## Scope

Reviewed `src/Monarch.Core/Backup/BackupRecoveryService.cs` across encrypted backup validation, per-database named mutex acquisition, V1/V2 journal parsing, rollback-path validation, prepared rollback, committed cleanup, and SQLite WAL/SHM quarantine restoration.

No production C# defect was established by this source review that justified changing runtime logic without a .NET/Windows execution environment. Production C# was therefore left unchanged. Two additional structural regression checks assert that prepared recovery restores both sidecars before deleting the journal and that committed recovery verifies the live database before deleting rollback artifacts.

## Validation results

- Full pytest suite: **638 passed**.
- unittest discovery: **365 passed**.
- XML/XAML/project/config parsing: **7 files parsed, 0 errors**.
- ZIP source baseline integrity was verified before extraction; this package is rebuilt and checked separately.
- .NET SDK: unavailable (`dotnet` not found).
- C# build: **not run**.
- WPF runtime: **not run**.
- Windows process-termination, power-loss, filesystem durability, live WAL/SHM, and cross-process integration: **not run**.

## Review findings and limits

- MONARCH backup/restore operations using this service share a path-derived named mutex with a 30-second bounded wait. Unrelated SQLite clients do not participate in that lock.
- Journal V2 SHA-256 is an unkeyed checksum. It detects corruption/inconsistent edits but is not authentication against a local writer able to change both the journal and checksum.
- Recovery remains fail-closed for malformed journal data and ambiguous main-file states; manual recovery may be required rather than deleting uncertain artifacts.
- Source assertions and Python crash-state models are not execution evidence for the C# implementation or Windows filesystem semantics.

## Cumulative integrity

This update retains the complete prior project tree and adds only this report and its test log. The manifest comparison against the immediately preceding package is recorded in the companion log. No production C# file or module was removed.
