# MONARCH ERP — Autonomous Workflows and Governance

## Delivered in this stage

- Added `AutonomousProcurementWorkflow` as a draft-only orchestration contract. It requires tenant/branch/user scope, supplier, warehouse, non-empty lines and a traceable rationale. Its gateway contract explicitly requires atomic persistence of the Draft PO and assignment to the purchasing-manager approval queue. It rejects any gateway result that is not `Draft` or lacks an approval queue identifier. The workflow exposes no approval or posting method.
- Added `ConversationalErpRouter`. It accepts only an authenticated user/company/branch scope, maps supported intents to a fixed permission allowlist, and delegates to an executor that must re-check RBAC in the same database transaction as the tenant-filtered query. User text is never interpolated into SQL.
- Added `VersionedComplianceLedger` with effective-dated, approved carbon factors and tax rules. It resolves the rule effective on the transaction timestamp and records carbon-document snapshots with the exact factor version. Duplicate versions are rejected. This is a domain implementation in memory; persistent immutable database tables and a WPF audit screen remain future work.
- Integrated an optional process-local circuit breaker into `ZatcaSubmissionWorker`. An open circuit prevents outbox claiming and alerts through an injected callback; successful/rejected responses reset the breaker, transport ambiguity increments failures and remains quarantined via the existing unknown-outcome handling. Local accounting and document creation are not blocked.

## Security and operational boundaries

- The procurement gateway is an explicit integration contract, not yet a concrete SQLite adapter. A production adapter must insert the PO, approval-queue assignment and audit event in one SQLite transaction and use a dedicated purchasing-manager role/permission check.
- The conversational query executor is an integration contract. It must enforce `reports.read` and company/branch membership in the same transaction as each query; no generic SQL execution endpoint is provided.
- Carbon/tax rule version selection is implemented as a domain component, but persistence, tamper-evident audit storage and UI are not yet wired to the commercial database. Legal rule updates must be reviewed and approved before activation.
- Circuit breaker state is process-local. It protects the worker instance, not multiple Windows processes or machines. The alert callback must be connected to the system notification/audit service by the host application.
- This stage does not claim zero downtime, production AI, voice transcription, automatic PO approval, automatic GL posting, or legal auto-updates.

## Validation

Python source-contract tests cover draft-only procurement, RBAC routing, effective-dated version selection and ZATCA circuit isolation. They do not replace .NET compilation or end-to-end integration tests.
