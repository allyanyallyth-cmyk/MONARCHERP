# Inventory operation audit integration — 2026-11-08

## Scope delivered
- `CommercialStore.RecordMovement` now writes a tenant/branch audit row for each direct stock movement inside the same SQLite transaction as the immutable movement row.
- `CommercialStore.TransferStock` writes distinct outbound and inbound audit events scoped to the source and target branches, in the same transaction as both movement legs.
- `CommercialDocumentStore.Post` records the stock-affecting purchase/sales document posting in the same transaction as movement/cost allocation/status/outbox writes.
- `CommercialReturnStore.Post` records sales/purchase return posting in the same transaction as movement/return-cost allocation/status/outbox writes.
- Audit details include warehouse, item or source document, quantity/cost context where available, and the operation type. SQL values are parameterized.
- Existing `monarch_company_audit_log` schema is reused; no migration or package dependency added.

## Boundaries
- The audit rows are transactional SQLite records, not a cryptographically chained or remotely replicated journal.
- This stage does not add audit coverage to every inventory master-data edit or valuation/reconciliation background worker.
- Cross-device centralization, tamper-evident signatures, and retention/archival policies remain future work.
- Python tests are structural source checks; they do not execute the C# methods.
- .NET SDK/MSBuild/C# compiler are unavailable in this environment, so C# build and WPF runtime validation were not performed.
