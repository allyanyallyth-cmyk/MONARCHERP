# MONARCH ERP — Restore recovery restartability regression coverage

Date: 2026-11-13
Baseline: `monarch-erp-restore-journal-v2-committed-phase-fix.zip`

## Scope

This cumulative update extends the Python crash-state model for restore-journal recovery. It does not change production C# restore logic. The new cases cover: (1) restart after the previous main database has already been restored but before sidecars are restored; (2) restart after WAL restoration but before SHM restoration; (3) retry of committed cleanup after partial rollback-artifact deletion; and (4) a structural guard that C# sidecar recovery requires the quarantined file to exist.

## Validation

- `python -W error::ResourceWarning -m pytest -q -p no:cacheprovider`: **636 passed**.
- `python -m unittest discover -s tests -p 'test_*.py' -q`: **365 passed**.
- XML/XAML/project-file parsing: see the companion test log.
- .NET SDK: not available (`dotnet` not found).
- C# build: not run.
- WPF runtime: not run.
- Windows process-termination, power-loss, filesystem durability, and live SQLite WAL/SHM integration tests: not run.

## Interpretation

The new Python tests establish idempotence in the modeled recovery states and structural consistency of the C# helper. They are not evidence that the C# implementation has executed successfully on Windows. SHA-256 in the journal remains an unkeyed corruption checksum, not authentication against a local writer able to alter both journal and checksum.
