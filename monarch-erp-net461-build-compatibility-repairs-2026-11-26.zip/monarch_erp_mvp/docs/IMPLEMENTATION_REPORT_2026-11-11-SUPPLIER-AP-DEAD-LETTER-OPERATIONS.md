# Supplier AP dead-letter operator controls — 2026-11-11

## Scope delivered

- Added `SupplierPayablesAlertDeadLetterStore` for bounded dead-letter inspection and operator-authorized manual requeue.
- Enforced `users.manage` at the service boundary and retained the active company/branch scope through `TenantLedgerStore.GetEntries` plus tenant predicates in SQL.
- Added WPF dead-letter grid and explicit confirmation before requeue. The UI is shown only to sessions holding `users.manage`.
- Manual requeue changes only the dispatch state to `Pending`; it does not claim or deliver the message. Delivery remains the dispatcher’s responsibility.
- Added append-only audit rows containing actor, tenant scope, prior retry-cycle attempt count, UTC timestamp, and bounded reason code.
- Added an additive migration that rebuilds the attempt-history table while preserving all existing rows and removing the per-intent attempt-number uniqueness constraint. New attempt numbers are globally monotonic per intent, so retry cycles do not overwrite or collide with prior history.

## Safety and accounting boundaries

- A dead-letter can be requeued only while it is still in `DeadLetter` and belongs to the active company and branch.
- Retry is not automatic; an authorized operator must select the row and confirm.
- Each retry cycle remains capped by the existing dispatcher maximum of eight attempts. Historical attempt records remain append-only.
- No journal, payment, supplier balance, or accounting outbox operation is invoked.

## Validation

- `python -W error::ResourceWarning -m pytest -q`: 593 passed.
- `python -m unittest discover -s tests -p 'test_*.py' -q`: 365 passed.
- SQLite migration regression checks preserve existing attempt rows and reject update/delete of attempt and manual-retry audit records.
- C# build and WPF runtime tests were not run: `dotnet` is unavailable in this environment. Python tests are structural/database checks and are not a substitute for compiling the .NET Framework 4.6.1 WPF application.

## Required migration order

After backup, apply the existing Supplier AP delivery, dispatcher, and inbox-read-state migrations, then `2026-11-11-supplier-ap-alert-dead-letter-operations.sql`. No automatic migration was introduced.

## Remaining

- Build Core for `net8.0` and `net461`, and Desktop for `net461`, on a Windows/.NET-enabled agent.
- Exercise operator permission denial, confirmation cancellation, successful requeue, repeated retry cycles, and concurrent lease recovery against a live migrated database.
