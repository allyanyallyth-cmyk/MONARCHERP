# تقرير تنفيذ — أساس تكامل الفوترة الإلكترونية ZATCA Phase 2

التاريخ: 2026-11-07

## النطاق المنفذ

أضيفت مساحة أسماء `Monarch.Core.Zatca` دون تعديل أو حذف وحدات المحاسبة والمشتريات والذمم الدائنة السابقة.

### 1) QR TLV / Base64
- الحقول 1–5: اسم البائع، الرقم الضريبي، الوقت UTC بصيغة ISO 8601، إجمالي الفاتورة شامل الضريبة، وإجمالي VAT.
- دعم الحقول الثنائية 6–9: SHA-256، توقيع ECDSA، المفتاح العام، وتوقيع CA الخاص بمفتاح الختم للفواتير المبسطة.
- ترميز UTF-8 وطول TLV كبايت واحد، وحد أقصى 700 محرف Base64.
- التحقق من رقم VAT السعودي (15 رقماً يبدأ وينتهي بـ3) ومن مبالغ الفاتورة.

### 2) UBL 2.1
- مولّد XML يتضمن namespaces القياسية، UUID، ICV، PIH، QR، نوع الفاتورة، أطراف البيع، تفاصيل البنود، مجاميع الضريبة والإجماليات.
- يفرض SAR في هذا الإصدار، و15% على فئة Standard Rated، مع طلب سبب/رمز للإعفاء أو الصفرية أو خارج النطاق.
- الفواتير الدائنة والمدينة مؤجلة حتى إضافة مراجع المستند الأصلي وأسباب الإشعار والحقول الإلزامية.

### 3) Hash chain
- تسلسل مستقل لكل شركة/فرع/وحدة EGS.
- ICV متزايد، وPIH يشير إلى بصمة المستند السابق، مع قيمة البداية المحددة في مواصفات ZATCA.
- حفظ XML والبصمات وQR في سجل دائم غير قابل للحذف أو تعديل حمولة الفاتورة.
- Outbox ذري مع claim للعملية، واستعادة المطالبة العالقة بعد 10 دقائق، ومحاولات قابلة للتتبع.

### 4) API / Worker
- OAuth 2.0 Basic Authentication للحصول على Bearer token.
- Clearance للفواتير القياسية والإشعارات، وReporting للفواتير المبسطة.
- دعم Sandbox وProduction عبر خيارات Base URI قابلة للضبط، دون إرسال أي طلب أثناء الاختبارات.
- حفظ XML المعاد من Clearance ورمز QR ورسائل التحقق، وتصنيف النجاح والرفض والفشل وإعادة المحاولة.
- واجهة `IZatcaCredentialProvider` تفصل الأسرار عن كود النواة.

## الملفات المضافة
- `src/Monarch.Core/Zatca/ZatcaModels.cs`
- `src/Monarch.Core/Zatca/ZatcaQrCodeEncoder.cs`
- `src/Monarch.Core/Zatca/ZatcaUblInvoiceGenerator.cs`
- `src/Monarch.Core/Zatca/ZatcaInvoiceHashService.cs`
- `src/Monarch.Core/Zatca/ZatcaInvoiceBuilder.cs`
- `src/Monarch.Core/Zatca/ZatcaInvoiceChainStore.cs`
- `src/Monarch.Core/Zatca/ZatcaInvoicePreparationService.cs`
- `src/Monarch.Core/Zatca/ZatcaApiClient.cs`
- `src/Monarch.Core/Zatca/ZatcaSubmissionWorker.cs`
- `tests/test_zatca_phase2_foundation.py`

## التعديلات
- إضافة جداول سلسلة الفواتير وOutbox ومحفزات منع الحذف/تعديل الهوية في `database/commercial-data.sql`.
- إضافة صلاحيات `commercial.sales.manage` و`zatca.integration.manage` في `database/security.sql`.
- إضافة اعتماد `System.Security.Cryptography.Xml` إلى `Monarch.Core.csproj`.
- تحديث README وROADMAP وحالة الإصدار.

## التحقق
- Pytest: **326 passed**.
- Unittest: **303 tests, OK**.
- مخططات SQLite: نفّذ اختبار التكامل ملفات الأمن والدفتر والـ tenancy والتجارة، وتحقق من عدم وجود أخطاء Foreign Key.
- لم يُشغّل dotnet build أو اختبارات C# أو اتصال Sandbox؛ أدوات .NET SDK/MSBuild غير متوفرة في بيئة إعداد الحزمة.

## قيود مهمة — لا يُعلن التوافق الرسمي بعد
1. مولّد UBL أساس أولي وليس اعتماداً كاملاً لكل Business Rules/validation rules أو جميع سيناريوهات VAT.
2. `ZatcaInvoiceHashService` يستخدم تحويل C14N المتاح في .NET؛ مواصفة الهيئة تشير إلى C14N 1.1. يجب مقارنة البصمة باختبارات ZATCA SDK/SDK الرسمي byte-for-byte قبل الإنتاج.
3. لم يُضمّن مزوّد مفاتيح ECDSA/شهادة CSID أو منشئ XAdES كامل. الفاتورة المبسطة Phase 2 تُرفض محلياً ما لم يحقن التطبيق `IZatcaCryptographicStampProvider` و`IZatcaInvoiceXmlSigner` حقيقيين يتبعان ملف الهيئة. واجهات التعاقد موجودة فقط.
4. لا يوجد بعد onboarding CSR/OTP/Compliance CSID/Production CSID أو تخزين أسرار داخل Windows Credential Manager/DPAPI/HSM.
5. API client لم يُختبر ضد Sandbox/Production، ويجب التحقق من أحدث endpoints والـ headers وعقود الاستجابة قبل اعتماد الإرسال.
6. لا يوجد بعد ربط مباشر بمستندات المبيعات الحالية `monarch_commercial_documents`; التحضير يقبل DTO موحداً ويتطلب استكمال mapping للبيانات القانونية والعناوين والضرائب.
7. لا يوجد WPF setup screen لإعداد وحدة EGS أو مراقبة/إعادة إرسال Outbox.
8. لا يوجد توليد صورة QR matrix؛ النواة تنتج TLV Base64 payload الجاهز لتغذيته إلى QR renderer.
9. العملات الأجنبية والإشعارات الدائنة/المدينة والفواتير المقدمة وسيناريوهات الخصم/البدلات ليست ضمن هذا التسليم.

**قرار الإصدار:** مرحلة تأسيسية هندسية فقط. لا تستخدم لإصدار فواتير ضريبية ملزمة أو إرسال معاملات حقيقية قبل تنفيذ النواقص أعلاه، واجتياز ZATCA SDK وSandbox والاختبارات القانونية/الضريبية.

## تحديث 2026-11-07 — مركز متابعة إرسال ZATCA وضبط إعادة المحاولة

### ما أضيف
- إضافة `ZatcaSubmissionDashboard` لملخص حالات Pending/Processing/Failed/Rejected/Cleared/Reported حسب الشركة والفرع.
- إضافة `ListSubmissionHistory` لعرض آخر 1–500 عملية مع نوع الفاتورة، وحدة EGS، عدد المحاولات، آخر رد، وتوقيت الإنشاء/المعالجة.
- إضافة `RetryFailedSubmission` لإعادة إدراج حالة Failed فقط بعد تحقق الصلاحية والنطاق والحد الأقصى للمحاولات، مع تسجيل تدقيق `ZatcaSubmissionRetry`.
- رفض إعادة المحاولة اليدوية للفواتير Rejected؛ يجب تصحيح سبب الرفض وإصدار مستند جديد متوافق بدلاً من إعادة إرسال XML مرفوض كما هو.
- إضافة سقف افتراضي 8 محاولات لعامل الإرسال، قابل للضبط ضمن 1–50، لمنع الدوران غير المحدود في الأعطال الدائمة.
- لا تُعرض حمولة XML أو بيانات اعتماد API ضمن سجل لوحة المتابعة.

### الاختبارات
- Pytest: **331 passed**.
- Unittest: **308 tests, OK**.
- XML/XAML/CSProj parse: **6/6 OK**.
- ظهرت ResourceWarning لاتصالات SQLite غير مغلقة في اختبارات سابقة؛ لم تفشل الاختبارات.
- لم يتوفر `dotnet` أو `msbuild` أو `csc`، ولم يتم بناء C# أو تشغيل WPF أو الاتصال بـ Sandbox.

### الحدود
- هذه واجهات Core للقراءة والإدارة وليست شاشة WPF مكتملة.
- حالات الرفض نهائية في السجل الحالي؛ إعادة الإصدار بعد تصحيح البيانات تتطلب مستنداً جديداً وربط مرجع الفاتورة الأصلية عند تطبيق قواعد الإشعارات.
- حد المحاولات يحمي من التكرار غير المحدود لكنه لا يثبت نتيجة طلب HTTP انتهت مهلته بعد وصوله إلى الهيئة؛ يلزم مسار مصالحة/استعلام حالة من مزود الخدمة قبل إعادة الإرسال في حالات النتيجة غير المعروفة.
