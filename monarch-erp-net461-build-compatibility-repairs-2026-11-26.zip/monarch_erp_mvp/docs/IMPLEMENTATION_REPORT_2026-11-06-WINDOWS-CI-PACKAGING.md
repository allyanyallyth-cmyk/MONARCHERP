# MONARCH ERP — Windows CI and portable packaging stage

Date: 2026-11-06

## Implemented

1. Added `.github/workflows/windows-build.yml` targeting `windows-2022` with .NET 8 SDK and Python 3.12.
2. The workflow installs migration dependencies, runs Python/SQLite tests, restores and builds the solution, runs the C# smoke-test executable, publishes the WPF desktop and recovery utility, then uploads a portable ZIP and SHA-256 file as a GitHub Actions artifact.
3. Updated `scripts/build-windows.ps1` to run Python integration tests before .NET restore/build, execute the C# smoke tests, publish both Windows applications, and verify expected executable outputs.
4. Added `scripts/package-release.ps1` to assemble the desktop app, recovery utility, migration tools, schemas, README and security notes into a portable release ZIP with SHA-256.
5. Added Python structural tests for the CI workflow and release scripts.

## Verification performed in this environment

- `python -m unittest discover -s tests -v`: 95/95 passed.
- XML parsing for project and XAML files: 7/7 passed.
- Source archive extraction and prior stage contents verified.
- `.NET SDK`, `MSBuild`, `C# compiler`, and PowerShell are not installed in this Linux environment. Consequently, the Windows workflow, PowerShell scripts, C# compilation, WPF execution, and release packaging script were not executed here.

## Release status

This stage adds reproducible Windows CI and packaging definitions; it does not claim a successful Windows build. A repository owner must push this project to GitHub and run the `MONARCH Windows build` workflow. Only after a successful Windows runner result should the generated artifact be treated as a compiled Windows package. It remains unsigned and portable; no MSI installer is produced.

## Outstanding acceptance work

- Run the Windows workflow and resolve any compiler or packaging errors it reports.
- Perform interactive Windows 11 acceptance tests for first-run administrator setup, login, tenant/branch selection, account creation, multi-line journal draft/post/reversal, reports, backup and recovery.
- Test actual migration against a copied legacy database and compare the dry-run and post-import reconciliation reports.
- Validate Windows 10, 8.1 and Windows 7 SP1 runtime requirements and dependencies; do not infer compatibility solely from the `net461` target.
- Produce and sign an MSI/Setup package, then test install, upgrade, repair and uninstall.

## Installer definition added

An Inno Setup definition is now included at `installer/monarch.iss`. The Windows CI workflow installs Inno Setup, compiles a versioned Setup executable after publishing, and generates its SHA-256 sidecar. The installer checks for .NET Framework 4.6.1 or later, installs application/recovery/migration files, and does not package or overwrite a user's database. The installer has not been compiled or tested in this Linux environment and will remain unsigned unless a signing certificate and signing stage are configured.
