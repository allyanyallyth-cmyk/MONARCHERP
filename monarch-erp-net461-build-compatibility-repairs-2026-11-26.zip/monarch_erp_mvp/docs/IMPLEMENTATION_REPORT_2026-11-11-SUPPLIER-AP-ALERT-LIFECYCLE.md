# Supplier AP Operational Alert Lifecycle

## Delivered

- `SupplierPayablesOperationalAlertLifecycleStore` persists `Viewed` and `Acknowledged` events for allowlisted operational alert summaries.
- Events are isolated by company, branch, user, alert code, and source alert's latest occurrence timestamp.
- A repeated action for the same alert lifecycle is idempotent; a later recurrence is a separate lifecycle.
- `GetStates` returns lifecycle state for up to 500 alerts and checks tenant authorization before opening the lifecycle database.
- SQLite migration enforces allowed codes/actions, uniqueness, indexes, and append-only update/delete triggers.

## Safety boundaries

This feature does not edit or delete original diagnostics, acquire or release worker leases, retry jobs, mutate outbox records, or post/change accounting entries. The current authorization check reuses the ledger's tenant-scoped read permission; a dedicated alert-acknowledgement permission and WPF interface remain future work.

## Validation boundary

Python SQLite tests exercise the migration and its constraints. Structural tests inspect authorization ordering and bounded reads. They do not constitute C# compilation, provider integration, or WPF runtime validation.
