# Supplier invoice operational-read RBAC alignment — 2026-11-10

## Change
- `SupplierInvoiceStore.ListReceiptableLines` now requires `commercial.purchases.manage`.
- `SupplierInvoiceStore.List` now requires `commercial.purchases.manage`.
- Both methods continue to run `Require` and their parameterized, company/branch-scoped query in the same SQLite transaction.
- This aligns the Core read boundary with the purchase workspace's existing WPF permission gate and the store's existing `CreateDraft`/`Post` permission.

## Security rationale
`reports.read` is intentionally used by financial reporting stores such as AP aging. Supplier invoice lists and un-invoiced receipt details are operational purchasing data, so granting them to every report reader was broader than the WPF screen's intended access boundary. The change closes that mismatch at the Core API rather than relying on UI visibility alone.

## Compatibility and scope
- No public method signatures changed.
- No schema or migration changed.
- No automatic migration or startup behavior added.
- Supplier payment and AP aging permissions remain unchanged.
- Existing company/branch filters and transactional behavior are preserved.

## Verification
- Python structural regression tests: recorded in `docs/TEST_RESULTS_2026-11-10-SUPPLIER-INVOICE-READ-RBAC.log`.
- Python test suite: see test log.
- C# build and WPF runtime: not executed; do not treat this package as a verified Windows build.
