# Tenant Audit Event Store — 2026-11-08

## Delivered
- Added `TenantAuditEventStore` as a generic append-only event-journal foundation.
- Events carry UTC timestamp, actor, company, branch, event/entity identifiers, summary, and opaque metadata.
- Each line is linked to the preceding SHA-256 hash; append verifies the existing chain before writing.
- `Verify` validates sequence/hash integrity and payload shape.
- `Read` requires explicit company and branch IDs and supports UTC time bounds, event-type filtering, and a bounded result count (1–5000).
- No database migration or package dependency was introduced.

## Scope and limitations
- This stage adds a reusable Core foundation only. It is **not yet wired** to login, user administration, accounting, inventory, purchasing, or permission-change workflows.
- The journal is a local file; it is not centralized, replicated, digitally signed, or protected against a privileged operator rewriting the entire file and recomputing the chain.
- The lock is process-local. Concurrent separate MONARCH processes can still race on the same file; cross-process locking or transactional storage is required before multi-process deployment.
- `Read` verifies the full journal before returning tenant/branch-filtered events. This protects integrity but can become expensive for large logs.
- The opaque metadata field is caller-supplied text; callers must avoid secrets and apply their own data-minimization rules.
- C# compilation and Windows runtime execution were not available in this environment. Python tests check source-level contracts, not runtime behavior.

## Next
Integrate explicit audit events into selected high-value workflows one at a time, beginning with user/role administration and accounting posting, with atomicity guarantees appropriate to each storage boundary. Then introduce inter-process coordination and a central replication design.
