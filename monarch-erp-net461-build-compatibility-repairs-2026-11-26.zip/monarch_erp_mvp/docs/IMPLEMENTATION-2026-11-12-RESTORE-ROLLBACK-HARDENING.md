# MONARCH ERP — Restore rollback hardening

Date: 2026-11-12

## Change

`BackupRecoveryService.RestoreEncryptedBackup` now removes the newly placed live database when post-replacement verification fails and there was no database before the restore. When a database existed before restore, the rollback path continues to restore that exact file and does not delete the rollback copy before the move-back succeeds.

## Safety boundary

Authentication and candidate SQLite integrity checks remain preconditions before touching the live database. The change addresses the separate failure window after the candidate has been moved into the live path.

## Validation scope

Python tests model the restore contract and source assertions inspect the C# branch. They are not execution of the C# implementation. A .NET build, WPF launch, and Windows restore integration test are not claimed.
