# Implementation report — inventory operation authorization (2026-11-08)

## Scope
Closed the legacy authorization gap for direct stock movement and paired warehouse transfer operations in `CommercialStore`.

## Changes
- Moved `RecordMovement` authorization into the same SQLite transaction as its stock-ledger write and audit insert, eliminating the prior check-before-transaction window.
- Both direct movements and both legs of a transfer now require explicit `inventory.movements.manage` permission.
- Authorization validates active global user, active company membership, active branch membership, active company and branch records, and a role grant in `monarch_user_roles` / `monarch_role_permissions`.
- Added `inventory.read` for standard Administrator, Accountant, and Viewer roles.
- Added `inventory.movements.manage` with an Administrator-only default grant. New databases receive grants from `database/security.sql`; existing databases require the explicit migration `database/migrations/2026-11-08-inventory-operation-permissions.sql`.
- No business tables, stock valuation rules, audit event formats, or journal behavior were changed. No migration is run automatically at startup.

## Security behavior
Existing custom roles receive no implicit stock-mutation grant. An administrator must explicitly assign the permission to any authorized inventory operator. This is intentionally fail-closed. The change does not claim that all legacy commercial CRUD APIs have been migrated to RBAC; the scope is the direct stock-movement and transfer write paths.

## Validation
Python structural and SQLite-oriented tests validate transaction ordering, both-branch authorization, tenant/branch active-state checks, permission seed/migration coverage, and default grants. C# compilation and WPF runtime tests were not run in this environment.

## Executed checks for this package
- `python3 -m pytest -q`: 484 passed.
- `python3 -m unittest discover -s tests -p 'test_*.py' -q`: 318 tests passed; existing SQLite `ResourceWarning` messages were emitted by older tests.
- XML/XAML/CSProj parse: 7/7 passed.
- Explicit permission migration executed successfully against an in-memory SQLite schema assembled from the project's security, tenancy, ledger, and commercial schema scripts.
- ZIP integrity: passed; previous archive entries retained with zero missing files.
