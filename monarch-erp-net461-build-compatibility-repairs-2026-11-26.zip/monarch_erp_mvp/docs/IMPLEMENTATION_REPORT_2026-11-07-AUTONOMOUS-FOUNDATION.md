# MONARCH ERP — Autonomous Agent Foundation

## Scope delivered

This increment adds deterministic, tenant-scoped decision-support primitives under `Monarch.Core/Autonomy`:

- 30-day-capable cash-flow projection (configurable horizon up to 90 days), with earliest projected negative-balance date.
- Predictive inventory reorder recommendations using average daily usage, supplier lead time, review period, safety stock, on-hand and on-order quantities.
- Statistical financial outlier detection (minimum sample size, absolute floor and sigma threshold). Results are alerts for investigation, not fraud findings.
- Month-close control assessment. It does not post journals or close periods.
- Arabic/English allowlisted natural-language intent classification for sales reports, pending ZATCA invoices, inventory reorder previews and month-close assessment. It emits non-executable intents only; tenant authorization and query planning remain mandatory downstream.
- Process-local circuit breaker primitive with Closed/Open/HalfOpen states.
- Green Ledger calculation from explicitly approved, versioned emission factors.

## Safety and architecture boundaries

No autonomous bank payment, journal posting, purchase-order issuance, fraud accusation, tax-rule mutation, legal interpretation or ZATCA submission is performed by this increment. These operations require tenant-scoped permissions, human approval, immutable audit evidence and idempotent transactional workflows. The circuit breaker is process-local and does not claim cross-process coordination or zero downtime. The natural-language classifier is a narrow deterministic prototype, not a multilingual speech/LLM system and does not yet support all dialects.

A 30-day forecast is only as reliable as the cash, receivable, payable, payroll, tax and scheduled-payment feeds supplied to it. This increment exposes the forecasting primitive; it does not yet connect all source subledgers or schedule automatic alerts.

## Green Ledger and regulatory updates

Emission factors are versioned and must be approved before calculation. This release does not automatically adopt government tax/zakat/customs changes. Regulatory updates must be sourced from authoritative publications, reviewed by compliance, versioned, tested in a sandbox and explicitly approved before activation. Blind automatic legal-rule changes are unsafe.

## Validation

Python tests in `tests/test_autonomous_agent_foundation.py` verify the presence of tenant scoping, formulas, guardrails and non-executable intent behavior. These are source-contract tests, not C# runtime tests. C# build and runtime tests were not run because the current environment does not contain the .NET SDK/MSBuild/compiler.
