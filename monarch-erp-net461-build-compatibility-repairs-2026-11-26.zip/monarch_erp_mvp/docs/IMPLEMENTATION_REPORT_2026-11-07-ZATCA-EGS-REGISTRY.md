# MONARCH ERP — ZATCA EGS Registry Implementation Report

Date: 2026-11-07

## Delivered
- Added `ZatcaEgsRegistry` for EGS unit creation, tenant/branch-scoped listing, lifecycle history, and validated lifecycle transitions.
- Added lifecycle states: Draft, CsrGenerated, CompliancePending, CompliancePassed, ProductionPending, Active, Suspended, Revoked.
- Added immutable lifecycle event records and management-permission enforcement inside SQLite transactions.
- Added metadata fields for OTP transaction reference, CSR fingerprint, CSID serial, certificate thumbprint, and external secret reference.
- Added `IZatcaSecretStore` boundary. No plaintext OTP, private key, or API client secret is written to the commercial schema.
- Added EGS tables, indexes, constraints, and immutable lifecycle-history triggers to `database/commercial-data.sql`.

## Security and scope
- All reads and writes are scoped by company and branch and require `zatca.integration.manage`.
- EGS activation requires CSID metadata and an external secret reference.
- Revoked registrations are terminal. Suspended registrations may be reactivated only through an explicit transition.
- The OTP field is a transaction reference only, not an OTP value.
- Schema migration remains explicit; startup migration is not introduced.

## Not yet production-complete
- No CSR generation, private-key generation, DPAPI/Credential Manager provider, FATOORA OTP exchange, compliance API call, production CSID issuance, or live ZATCA onboarding was implemented in this stage.
- `IZatcaSecretStore` is an abstraction only; production activation must be gated on a reviewed OS-backed provider and live integration tests.
- No .NET build or WPF runtime test is claimed because the current environment lacks the .NET SDK/compiler toolchain.
