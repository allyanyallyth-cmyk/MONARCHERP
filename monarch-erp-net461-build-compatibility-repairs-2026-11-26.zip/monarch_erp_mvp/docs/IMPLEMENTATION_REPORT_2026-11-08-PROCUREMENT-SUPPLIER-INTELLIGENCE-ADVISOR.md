# Procurement Supplier Intelligence Advisor — 2026-11-08

## Scope
Added `ProcurementSupplierIntelligenceAdvisor` as a read-only decision-support service over `SupplierIntelligenceStore`.

## Behavior
- Reads currently effective supplier/item terms and posted receipt evidence through the existing tenant/branch permission-checked store.
- Produces an explainable score: 40% relative price, 25% contractual lead-time, 35% observed on-time delivery.
- Normalizes price and lead-time only within suppliers sharing the same currency code and currency scale. Mixed currencies are explicitly flagged and must not be treated as a direct price comparison.
- Missing delivery history receives a neutral reliability score and a `NoVerifiedDeliveryHistory` flag; it is not interpreted as 100% on-time performance.
- Flags low on-time delivery and actual lead time exceeding the contractual lead time.
- Does not create or approve purchase orders and does not post accounting entries.

## Constraints
The score is an initial transparent heuristic, not a validated procurement policy or a foreign-exchange conversion. It currently uses receipt/order timestamps available in the supplier store and therefore should be reviewed for partial receipts and split deliveries before operational use. The advisor is not yet wired into a verified Windows manager presentation. No C# build or Windows runtime test is claimed in this environment.

## Next work
Integrate ranked options and risk flags into the manager approval presentation, preserve explicit human selection of supplier terms, and add production-provider SQLite integration tests on Windows.
