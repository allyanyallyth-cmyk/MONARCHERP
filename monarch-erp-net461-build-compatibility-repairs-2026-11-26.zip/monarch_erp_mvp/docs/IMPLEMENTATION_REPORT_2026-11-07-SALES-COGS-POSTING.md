# MONARCH ERP — Sales COGS general-ledger posting

Date: 2026-11-07

## Delivered

- Added `CostOfGoodsSoldCode` (default `5000`) to `CommercialPostingAccounts`.
- Extended the commercial document loader to sum immutable `SalesIssue` cost allocations for the exact company, branch and document.
- For `SalePosted`, the deterministic sales journal now includes debit COGS and credit Inventory for the persisted historical issue cost. Revenue continues to use the sales subtotal; COGS never uses the sales price.
- A stock sale with positive stock subtotal but no persisted issue allocation is blocked rather than silently posted without perpetual inventory cost. The outbox records the failure for retry/inspection.
- Added two structural regression tests.

## Verification

- Python/SQLite tests: **201/201 passed** (`python -m unittest discover -s tests -v`).
- C# build and C# smoke tests: **not run**; no .NET SDK/compiler available in this environment.
- WPF execution and Windows 7 SP1/8.1/10/11 runtime tests: **not run**.
- This patch changed C# and documentation only; no XML/XAML files were changed.

## Limitations and next step

- Deterministic journals already posted by an older build are skipped on retry. Historical sales marked processed therefore need a separate audited reconciliation/adjustment workflow; this patch does not rewrite posted journals.
- A complete inventory subledger-to-GL reconciliation report is still required, including opening balances, receipts, issues, returns, transfers, adjustments and rounding differences.
- The current stock purchase posting still uses the purchase stock-line net value. Landed-cost allocation and purchase price variance policy require further work.
- C# integration tests against SQLite/TenantLedgerStore and Windows acceptance remain mandatory.
