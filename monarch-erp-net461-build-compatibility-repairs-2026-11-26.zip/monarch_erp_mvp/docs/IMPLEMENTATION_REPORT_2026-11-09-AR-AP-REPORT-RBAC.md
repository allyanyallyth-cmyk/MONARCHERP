# AR/AP report authorization and branch-isolation hardening — 2026-11-09

## Scope
Reviewed `CommercialReceivablesPayablesReportStore` for authorization, tenant/branch isolation, and consistency of its read transaction.

## Changes
- Replaced the previous company/branch-membership-only check with explicit `reports.read` RBAC.
- The authorization query now validates an active user, active company membership, active branch membership, active branch, active company, and an assigned role carrying `reports.read`.
- Both aging and statement reads now run authorization and report SQL on the same SQLite connection and transaction.
- Aging allocations are restricted to posted payments in the selected company and branch, preventing another branch's payment from reducing this branch's receivable/payable balance.
- Statement allocation rows now require matching company and branch on both payment and document, and matching party on payment and document.
- Invalid `CommercialBalanceSide` enum values are rejected instead of silently falling through to supplier-side reporting.
- Preserved public method signatures, read-only connection mode, existing schema, and migration behavior. No migration was added or run.

## Validation boundary
Python tests validate SQL behavior and source structure; they do not compile or execute the C# store. .NET SDK/MSBuild and Windows WPF runtime validation were not performed in this environment.
