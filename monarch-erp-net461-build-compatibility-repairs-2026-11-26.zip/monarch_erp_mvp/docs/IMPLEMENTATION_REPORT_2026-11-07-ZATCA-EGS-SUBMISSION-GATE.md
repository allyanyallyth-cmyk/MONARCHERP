# ZATCA EGS submission readiness enforcement — 2026-11-07

## Scope
The EGS readiness assessment is now enforced at two independent persistence boundaries. `ClaimPending` joins the invoice/outbox records to the EGS unit by EGS id, company id, and branch id, then requires lifecycle state `Active` and non-empty CSR fingerprint, OTP transaction reference, CSID serial, certificate thumbprint, and external secret reference. `GetSubmissionPayload` repeats the same gate, so direct payload retrieval cannot bypass the queue filter.

## Operational behavior
Unready EGS submissions remain unclaimed in the outbox; they do not increment the attempt counter and are not passed to the HTTP client. Existing APIs and the prior worker constructor/signatures are unchanged. No schema migration was added.

## Security boundary
This is metadata readiness enforcement only. The current code does not prove that the external secret reference resolves, that a private key is available, or that credentials are valid. No OTP, private key, or client secret is retrieved or persisted by this change.

## Remaining work
- Implement and test an OS-backed Windows secret-store provider and credential resolver.
- Add explicit EGS/environment selection for API credentials.
- Implement safe timeout/unknown-outcome reconciliation before retrying potentially accepted invoices.
- Complete XAdES/ECDSA and C14N 1.1 verification against official SDK test vectors and Sandbox.
- Build and run Core/WPF on supported Windows versions.

## Verification
- `python3 -m pytest -q`: 338 passed.
- `python3 -m unittest discover -s tests -p 'test_*.py' -q`: 308 tests, OK (existing SQLite ResourceWarnings remain).
- XML/XAML/CSProj parsing: pending in packaging validation.
- .NET build/WPF/Sandbox: not run; .NET SDK/MSBuild are unavailable in this environment.
