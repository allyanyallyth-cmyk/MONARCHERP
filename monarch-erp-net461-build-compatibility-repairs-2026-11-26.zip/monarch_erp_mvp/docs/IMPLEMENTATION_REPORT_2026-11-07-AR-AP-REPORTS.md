# Implementation report — AR/AP statements and aging

Date: 2026-11-07

## Delivered

- Added `CommercialReceivablesPayablesReportStore` with read-only tenant/branch-scoped queries.
- Added customer receivables and supplier payables aging as of a caller-selected date.
- Aging buckets are current/not yet overdue, 1–30, 31–60, 61–90, and over 90 days overdue.
- Payments reduce balances only when posted and allocated to the relevant posted invoice, and only on/before the as-of date.
- Added date-range customer/vendor statements with invoice/debit and allocation/credit lines.
- Statement running balances include all earlier posted activity through the report end date, even when the requested display period starts later.
- Viewer role can read reports when company and branch access are active; this store performs no writes.
- Used `DateOnly.ParseExact` to remain compatible with the project's .NET Framework 4.6.1 compatibility shim.

## Verification

- Added executable SQLite tests for aging bucket math, payment reduction, and statement opening/running balance behavior.
- Python/SQLite full suite: result recorded in release package report.
- C# compilation and Windows execution are not claimed because the environment does not provide the .NET SDK or Windows runtime.

## Accounting boundary

These reports are subledger views derived from posted commercial documents and payment allocations. They are not yet reconciled automatically to GL control accounts, and they do not include unallocated advances, credit notes/returns, write-offs, foreign-exchange revaluation, or period-close adjustments. Those workflows remain gated for later stages.
