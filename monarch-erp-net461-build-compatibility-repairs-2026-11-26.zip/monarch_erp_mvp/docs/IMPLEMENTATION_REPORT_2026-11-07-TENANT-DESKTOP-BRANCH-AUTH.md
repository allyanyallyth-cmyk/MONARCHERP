# Implementation report — Tenant desktop authorization hardening

Date: 2026-11-07

## Reviewed baseline

- Latest cumulative package reviewed: `monarch-erp-return-cost-reversals-stage.zip` (uploaded 2026-11-06 23:29 UTC; SHA-256 `68913a54aef40a8dc685fcbaf990b9835f4ac5ec8d4427d1305b3ab6066df5f2`).
- `README.md`, `docs/ROADMAP.md`, architecture/security notes, `TenantLedgerStore`, `TenantAccountingSession`, WPF startup/selector, migration tool, and C# smoke tests were inspected.
- The standalone `monarch-erp-multiline-journals-stage.zip` is older (2026-11-06 17:21 UTC; SHA-256 `c7d7561131bb2d44221e92d29bb2c226160d3514b39c91c35fee133d07576e03`); its multi-line journal UI is present in the later cumulative package. No newer standalone package with that exact stage name was found.

## Changes

1. `TenantLedgerStore` now requires `userId + companyId + branchId` for every operational read/write API. Company-only `GetAccounts` and `AddAccount` overloads were removed.
2. Company-level chart data remains company-scoped, but every chart read/write is authorized against the selected active branch.
3. Active user, company, branch, company role, and branch membership are checked inside the same SQLite transaction as the ledger read/write. This reduces time-of-check/time-of-use gaps.
4. Posting and reversal require the target journal to match the selected branch inside that transaction.
5. All three commercial accounting Outbox workers now pass `branchId` when reading account mappings.
6. `TenantAccountingSession` passes the explicit user/company/branch tuple for account operations as well as journal/report operations. WPF startup comments now make explicit that `SqliteLedgerStore` is used only to bootstrap preserved legacy tables, and that the migration gate must pass before the tenant selector or accounting UI appears.
7. C# smoke tests were expanded for cross-company chart isolation, unauthorized branch reads, Viewer write denial, wrong-branch post/reversal, and permission revocation after a session was opened.
8. README, ROADMAP, architecture/security notes, and release status were updated.

## Validation

- Python/SQLite test suite: **190/190 passed** (`python3 -m unittest discover -s tests -q`).
- XML/XAML parse: **7/7 passed** (five `.csproj` files and two WPF XAML files).
- Existing tests include SQLite schema integrity, accounting constraints, migration dry-run/import/rollback/idempotency, inventory/returns/outbox behavior, and source-level WPF/Core checks.
- C# smoke tests were updated but **not executed**.
- `dotnet`, `msbuild`, and `csc` are not installed; WPF cannot run in this Linux environment.
- No Windows CI run, installer, or runtime compatibility test was performed.

## Remaining release gates

- Build the solution and execute `Monarch.Core.SmokeTests` on Windows 11 with the pinned .NET SDK/reference assemblies.
- Launch WPF and test login, company/branch selection, multi-line journals, posting/reversal, reports, and permission revocation.
- Run migration dry-run and import against a disposable copy of a real legacy database; validate encrypted backup and restore.
- Test clean Windows 10, 8.1 and Windows 7 SP1 environments before claiming compatibility.
- Complete full Inventory/COGS-to-GL reconciliation and commercial WPF workflows before production use.

## Release assessment

Source-level tenant UI integration and branch-scoped authorization are implemented. This is not a verified Windows build or production release.
