# Supplier AP Alert Delivery Planning and Escalation — 2026-11-11

## Scope
This stage adds a deterministic escalation policy and durable, recipient-specific in-app delivery intents for the existing Supplier AP operational alert summaries.

## Behavior
- Allowlisted alert codes are restricted to heartbeat failures and lease ownership loss.
- Critical alerts receive escalation level 2 immediately.
- Warning alerts receive level 1 initially and level 2 after 30 minutes.
- Delivery channel is currently `InApp` only.
- `SupplierPayablesAlertDeliveryStore.CreateIntents` bounds recipients and alerts to 1–100, rejects empty identifiers, and authorizes every recipient using `TenantLedgerStore.GetEntries(userId, companyId, branchId)` before opening the write transaction.
- Unique identity prevents duplicate intents for the same company, branch, recipient, alert code, source occurrence, escalation level, and channel.
- SQLite triggers reject update and delete; a later dispatcher must use a separately designed append-only delivery-attempt/event model rather than mutating these intents.

## Explicit boundaries
This stage creates durable intents only. It does not send messages, run a dispatcher, claim delivery work, create delivery receipts, retry sends, or integrate external providers. It does not change worker diagnostics, leases, outbox processing, journal entries, or accounting state. Apply `database/migrations/2026-11-11-supplier-ap-alert-delivery.sql` explicitly after a database backup; no automatic migration is performed.

## Validation limits
Python SQLite tests validate the migration's tenant scoping, idempotency, allowlist, and append-only triggers. Structural tests inspect the C# policy. .NET SDK/MSBuild is not available in this environment, so C# compilation, authorization integration execution, and WPF/runtime behavior are not claimed.
