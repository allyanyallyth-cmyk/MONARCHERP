# Test results — SQLite WAL sidecar-safe restore rollback
Date: 2026-11-12

- `python -W error::ResourceWarning -m pytest -q`: **614 passed**.
- `python -m unittest discover -s tests -p 'test_*.py' -q`: **365 passed**.
- XML/XAML/project parsing: **7 files parsed successfully** (2 XAML files and 5 C# project files; exact paths are listed below).
- `dotnet`: unavailable; C# build and WPF runtime tests were not run.
- Windows file-sharing, actual C# restore, mutex behavior, and live multi-process WAL/SHM integration remain unverified.

Parsed files:
- `src/Monarch.Api/Monarch.Api.csproj`
- `src/Monarch.Core/Monarch.Core.csproj`
- `src/Monarch.Desktop/App.xaml`
- `src/Monarch.Desktop/MainWindow.xaml`
- `src/Monarch.Desktop/Monarch.Desktop.csproj`
- `src/Monarch.Recovery/Monarch.Recovery.csproj`
- `tests/Monarch.Core.SmokeTests/Monarch.Core.SmokeTests.csproj`

The Python restore model uses a test-only authenticated envelope; it is not the production MONARCH encrypted-backup format. C# source assertions are structural checks, not runtime execution.
