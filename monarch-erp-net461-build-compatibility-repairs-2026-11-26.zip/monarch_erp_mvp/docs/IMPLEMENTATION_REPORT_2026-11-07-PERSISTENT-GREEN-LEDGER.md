# Implementation Report — Persistent Green Ledger

## Delivered
- Additive migration `2026-11-07-versioned-green-compliance-ledger.sql`.
- Tenant-scoped carbon factor versions with effective dates, source, version, creator and approver.
- Tax-rule version schema with jurisdiction, official source, version and effective dates.
- Append-only carbon document snapshots tied to the exact factor-version row used.
- SQLite triggers preventing deletion of factor history and modification/deletion of snapshots; approved factor and tax-rule rows cannot be updated.
- `PersistentGreenComplianceLedger` persists factor drafts, approvals and carbon snapshots. Snapshot selection uses the transaction timestamp, not the current date. Snapshot and audit insertion share a SQLite transaction.

## Deliberate boundaries
- Migration is explicit; no commercial schema is changed and no migration runs at startup.
- Tax-rule table is schema foundation only; tax calculation integration, approval API and UI remain pending.
- Carbon snapshots are not yet automatically populated by purchase receipt or supplier invoice workflows.
- C# compilation/runtime validation was not available in this environment unless separately recorded by CI.
