# Restore journal semantic validation — 2026-11-14

## Scope
Expanded regression coverage for strict V1/V2 restore-journal field semantics. The new V2 cases deliberately recompute SHA-256 after inserting invalid values, proving that checksum validity does not bypass semantic validation.

## Changes
- Reject non-canonical V2 `hadPrevious` values (`TRUE`, `False`, `yes`, `1`, empty, and padded values) with a valid recomputed digest.
- Reject unsupported/non-canonical V2 phases (`COMMITTED`, `Prepared`, `pending`, empty, and padded) with a valid recomputed digest.
- Verify all four legal V2 combinations of boolean state and phase.
- Verify V1 compatibility remains strict for boolean and phase values.
- No production C# logic, schema, WPF, or ERP module was changed.

## Verification
- `pytest -q`: **685 passed**.
- `python -m unittest discover -s tests -p 'test_*.py'`: **365 tests, OK**.
- XML/XAML/project/config parsing: **7 parsed, 0 errors**.
- .NET/C# build, WPF runtime, Windows SQLite-provider integration, and process/power-loss tests: **not run**; .NET SDK/Windows runtime are unavailable in this environment.

## Cumulative package integrity
Compared directly with `monarch-erp-restore-journal-v2-corruption-matrix.zip`:
- Previous files: 496
- New files: 498
- Added: 2 (this report and the test-results record)
- Modified: 3 (`README.md`, `docs/ROADMAP.md`, `tests/test_backup_restore_crash_recovery_journal.py`)
- Unchanged: 493
- Deleted: 0
