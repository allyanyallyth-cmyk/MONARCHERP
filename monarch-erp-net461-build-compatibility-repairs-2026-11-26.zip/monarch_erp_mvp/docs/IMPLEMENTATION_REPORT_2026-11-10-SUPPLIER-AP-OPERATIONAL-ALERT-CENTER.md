# Supplier AP Operational Alert Center — 2026-11-10

## Delivered
- Added a read-only alert projection over the existing durable supplier AP worker diagnostics.
- `heartbeat_failed` events are grouped over a rolling 15-minute window: one or two events produce Warning; three or more produce Critical by default.
- `lease_ownership_lost` events produce a Warning over a rolling 24-hour window.
- Alerts expose stable codes, severity, concise operator guidance, event count, and latest event time. Ordering is deterministic: Critical first, then newest event, then stable code.
- Added `GetOperationalAlerts(userId, companyId, branchId, ...)` to the worker. It obtains diagnostics only through the existing authorization path, which calls `TenantLedgerStore.GetEntries` and filters by company and branch.
- Result limit is bounded to 1–500; the default heartbeat critical threshold is 3 and cannot be configured below 2.

## Safety and scope
- No schema migration was added; the existing explicit worker-diagnostics migration remains required.
- The center is a read model only. It does not retry, reschedule, release or renew leases, acknowledge outbox events, post journals, or mutate accounting state.
- Process-local health counters are intentionally not mixed into tenant alerts because they are worker-instance-wide rather than company/branch-attributed. They remain available separately through `GetHealthSnapshot()`.
- Alert windows are query-time projections over the existing append-only diagnostics. No retention, acknowledgement, notification delivery, or durable alert lifecycle is introduced.

## Verification boundaries
- Python regression tests validate source contracts and tenant-scope wiring; they do not execute the C# implementation.
- C# build, WPF runtime, worker timer, and live multi-process behavior require a .NET-enabled Windows CI agent and are not claimed as tested here.
