# Commercial return RBAC and atomic audit — 2026-11-08

## Changes
- Replaced the legacy `role_code != Viewer` branch pre-check in `CommercialReturnStore` with explicit type-specific RBAC.
- Sales return draft creation and posting require `commercial.sales.manage`; purchase return draft creation and posting require `commercial.purchases.manage`.
- Authorization is checked on the same SQLite connection and transaction as the return operation. It verifies active user, company, company membership, branch membership, active branch, and an explicit role-permission grant.
- Return draft creation now writes `SalesReturnDraftCreated` or `PurchaseReturnDraftCreated` to `monarch_company_audit_log` before commit.
- Return posting continues to write its existing stock movements, return-cost allocations, state transition, accounting outbox, and audit record in one transaction.
- An audit insert failure aborts the transaction, including the draft/lines or posting mutations.
- Undefined return enum values and unsupported stored return types are rejected.

## Compatibility and boundaries
- Public method signatures and database schema are unchanged; no migration is required.
- Existing purchase-return block for receipts already covered by a posted supplier invoice remains in place pending supplier credit-note support.
- This increment covers `CommercialReturnStore`; it does not imply that every legacy party/master-data write API has been converted.

## Verification
- Python structural tests verify permission selection, transaction scope, active tenant/branch checks, audit-before-commit ordering, and removal of the legacy role-name gate.
- Python tests do not execute the C# implementation. .NET build and WPF runtime validation remain pending unless separately run on a supported Windows/.NET environment.
