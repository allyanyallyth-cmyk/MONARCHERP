# Implementation Report — Procurement Forecast History

## Delivered

Added `ProcurementForecastHistoryRow` and the read-only `ProcurementAnalyticsStore.GetForecastHistory` query. The query exposes matured immutable forecast snapshots by item and forecast window, including policy version, horizon, forecast quantity, actual demand, absolute error, and absolute percentage error where actual demand is non-zero.

Actual demand is recomputed from stock movements inside the exact snapshot window and is scoped by company, branch, warehouse, and item. Only `Issue`, `TransferOut`, and `PurchaseReturn` movements are included, matching the existing forecast accuracy definition. Immature windows are excluded. A zero-actual window returns a null percentage rather than a fabricated percentage or divide-by-zero result.

The method enforces `reports.read` and active company/branch membership within its SQLite transaction. It validates date order and bounds the result count (1–2,000). It performs no writes and introduces no schema migration.

## Verification

Python source-contract tests cover authorization, tenant/branch/warehouse/item scoping, matured-window filtering, demand movement semantics, zero-demand handling, bounded inputs, and read-only behavior. This environment does not contain .NET SDK/MSBuild, so C# compilation and WPF runtime verification remain outstanding.
