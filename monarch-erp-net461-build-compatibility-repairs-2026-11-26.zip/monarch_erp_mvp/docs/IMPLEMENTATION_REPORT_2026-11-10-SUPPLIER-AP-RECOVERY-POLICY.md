# Supplier AP worker recovery policy — 2026-11-10

## Scope

Added `SupplierPayablesWorkerRecoveryPolicy`, a pure classification and recommendation component for supplier invoice/payment outbox failures.

- Classifies SQLite `BUSY`, `LOCKED`, and `IOERR`, timeout, and I/O exceptions as potentially transient.
- Treats other SQLite codes and unknown exceptions as requiring investigation.
- Recommends bounded exponential backoff from 15 seconds up to 15 minutes.
- Raises an operator-alert recommendation for non-transient failures or when the consecutive-failure threshold (default 5) is reached.
- Rejects invalid attempt, failure-count, and threshold inputs.

## Safety boundaries

This component is advisory only. It does not schedule retries, acknowledge/release events, change lease ownership, or modify journals. SQLite lease token/expiry conditions and deterministic journal identity remain authoritative. No schema migration, startup migration, public worker behavior, or automatic retry behavior is introduced.

## Verification

Python regression tests check source contracts and policy bounds. They are not execution tests of the C# policy. .NET SDK/MSBuild are unavailable in this environment, so Core compilation, WPF build/runtime, and live SQLite contention remain unverified.
