# Supplier AP historical aging cutoff — 2026-11-10

## Change
- Updated `SupplierPayablesStore.GetAging` to join payment allocations to `monarch_supplier_payments`.
- A payment reduces the historical balance only when it belongs to the same company and branch, is `Posted`, and `payment_date <= asOfDate`.
- The aggregate uses a conditional sum so allocations without an eligible payment row cannot reduce the historical balance.
- Kept `ListOpenInvoices` on `reports.read` because it backs the read-only AP view; `PostPayment` continues to require `commercial.purchases.manage`.

## Compatibility and data safety
- No public API or record signature changed.
- No database schema or migration changed.
- No automatic migration or data rewrite was introduced.
- Payment posting, allocation immutability, outbox, and audit behavior are unchanged.

## Verification
- Python regression test asserts posted-payment status, branch match, and as-of cutoff in the aging query.
- Python tests are structural checks; they do not execute the C# store.
- C# build and WPF runtime were not run because the .NET SDK/MSBuild toolchain is unavailable in this environment.
