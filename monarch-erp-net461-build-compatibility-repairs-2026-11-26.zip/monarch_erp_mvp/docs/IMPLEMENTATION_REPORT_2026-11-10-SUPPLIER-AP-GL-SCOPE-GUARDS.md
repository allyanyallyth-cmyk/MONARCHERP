# MONARCH ERP — Supplier AP to GL scope guards

Date: 2026-11-10

## Delivered
- Hardened `SupplierPayablesAccountingOutboxWorker.LoadInvoice` so a posted supplier invoice is not eligible for GL posting unless its AP subledger row matches the same company/invoice, branch, supplier, currency, currency scale, and invoice total.
- Hardened `LoadPayment` to validate every payment allocation against the payable and posted invoice before producing the AP-to-cash/bank journal. Allocations are rejected when the payable is missing, the invoice is not posted, or supplier/branch/currency/currency scale differ from the payment.
- Kept deterministic invoice/payment journal numbers, exact journal-content comparison, posted-journal recognition, and separate outbox acknowledgement. A retry after a committed journal but failed acknowledgement therefore recognizes the existing matching journal instead of posting a second journal.
- Retained company/branch scoping on outbox reads and source-document loads, existing RBAC through `TenantLedgerStore`, base-currency-only policy, and current error/attempt tracking.
- Added regression checks for invoice-to-AP identity matching and per-allocation payment scope validation.

## Compatibility and migration
- No database schema change.
- No migration added or automatically executed.
- No public API signature change.
- No existing module or source file removed.

## Verification scope
- Focused Python structural regression tests: 16 passed.
- Full Python test suite and XML/XAML/project parsing are recorded in the companion test log.
- These Python checks inspect source structure; they are not execution tests of the C# worker or SQLite transaction behavior.
- C# build and WPF runtime remain NOT RUN unless a .NET SDK/MSBuild toolchain is available.
