# MONARCH ERP — Inventory Valuation Engine

Date: 2026-11-07

## Delivered

- Added a pure C# valuation engine supporting FIFO and moving weighted average.
- Inputs are immutable movement records scoped by the caller to one company/warehouse/item stream.
- Stable ordering uses occurrence timestamp, explicit sequence, then movement ID.
- Quantities use milli-units; monetary values use integer minor units.
- Inbound and outbound movement types are explicit, including transfer and return directions.
- FIFO consumes oldest layers first and returns remaining layers.
- Moving average recomputes the weighted unit cost after receipts and issues.
- Outbound movement beyond available quantity is rejected.
- Checked arithmetic and away-from-zero rounding are used for monetary conversions.

## Verification

- Python/SQLite and source-contract suite: 155/155 passed.
- The six new tests verify the engine contract, deterministic ordering, FIFO layer consumption, weighted-average recalculation, negative-quantity rejection, and explicit movement directions.
- C# compilation was not run: this environment does not have the .NET SDK/compiler.
- WPF/Windows execution was not run.

## Not delivered / production blockers

- The engine is not yet invoked by `CommercialDocumentStore` or `CommercialReturnStore`.
- Cost layers and FIFO issue allocations are not persisted in SQLite.
- Current commercial posting paths still need to snapshot purchase receipt costs from document line prices and persist source-line cost allocations; item master `cost_minor` must not be treated as a complete valuation ledger.
- Sales COGS and inventory asset journals are not posted by this engine.
- Sales-return COGS reversal must use original issue allocations, not current item cost.
- Purchase-return cost reversal must be bounded by the source receipt's remaining unreturned quantity/cost layer.
- Transfer pairing, cross-warehouse layer provenance, rounding residual policy, and GL reconciliation require integration tests.

This stage is an algorithm foundation, not a production-ready perpetual inventory valuation subsystem.
