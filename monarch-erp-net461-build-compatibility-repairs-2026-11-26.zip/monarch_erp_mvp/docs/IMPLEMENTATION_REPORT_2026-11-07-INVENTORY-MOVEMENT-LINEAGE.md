# Implementation report — Inventory Movement Lineage Audit

Date: 2026-11-07

## Scope

Added a read-only audit query that traces stock movements through commercial source records, immutable cost allocations, accounting outbox events, and deterministic tenant-ledger journals.

## Files

- `src/Monarch.Core/Commercial/InventoryMovementLineageStore.cs` — new scoped audit store and result models.
- `tests/test_inventory_movement_lineage.py` — five Python/SQLite tests, including execution of the actual C# SQL query against a minimal SQLite fixture.
- `README.md` — current scope and verification boundary.
- `docs/ROADMAP.md` — completed and pending lineage work.

## Controls

- Requires user, company, branch, and explicit UTC cutoff.
- Checks active user/company/branch membership in the same SQLite read transaction.
- Filters movements by exact company and branch and excludes movements after the cutoff.
- Does not mutate inventory, outbox, or general-ledger tables.
- Links commercial document movements to cost allocations, document outbox, and `AUTO-COM-*` journal.
- Links return movements to return cost allocations, return record, original invoice, return outbox, and `AUTO-RET-*` journal.
- Checks transfer pair count, direction diversity, distinct warehouses, quantity equality, and unit-cost equality.

## Result states

The audit distinguishes linked commercial movements, paired transfers, source-not-required movements, missing allocations, missing source records, missing outbox, pending/failed outbox, missing journals, non-posted journals, and incomplete transfer pairs.

## Verification

- Python/SQLite lineage tests: 5/5 passed.
- Full Python suite: 215/215 passed.
- XML/XAML/project parse: 7/7 passed.
- C# build: NOT RUN; .NET SDK/MSBuild/compiler unavailable.
- WPF runtime/UI: NOT RUN.
- Windows 7 SP1/8.1/10/11 compatibility: NOT verified by runtime tests.

## Known limits

- The store is not yet exposed through WPF.
- No automatic repair or journal posting is performed.
- Warehouse transfers are represented as paired movement legs; the current design does not post a separate GL journal for an internal transfer.
- Manual adjustments/opening entries without commercial source are classified as source-not-required rather than falsely flagged as broken commercial lineage.
