# MONARCH ERP — Commercial Data Foundation

Date: 2026-11-07

## Implemented
- Company-scoped commercial parties (customer/supplier/both), units, item groups, stock/service/non-stock items and branch-bound warehouses.
- Append-only inventory movement ledger with integer milli-quantities and integer minor-currency costs.
- Composite foreign keys prevent cross-company and cross-branch references.
- Unique company-scoped idempotency key; immutable movement triggers; negative inventory guard enforced by SQLite.
- `CommercialStore` applies company/branch membership checks in the storage layer and provides party, unit, item, warehouse, movement and balance operations.
- Desktop project copies the commercial schema to its output directory.

## Verification
- `python -m unittest discover -s tests -v`: 110 tests passed.
- New commercial tests cover party-code uniqueness, cross-company reference rejection, stock receipt/issue balance, negative stock rejection, immutability and idempotency.
- ZIP integrity verified after packaging.
- C# compilation and WPF execution were not performed: this environment has no .NET SDK or Windows runtime.

## Not implemented / not production-ready
- WPF commercial management screens.
- Purchase/sales document lifecycle, taxes, returns and automatic accounting postings.
- Atomic warehouse transfer workflow and approved stock counts.
- FIFO/weighted-average valuation and inventory closing.
- Windows interactive acceptance and installer execution.

This is a commercial data foundation, not a complete ERP release. Do not use for live financial or inventory records before the missing workflows and Windows acceptance tests are completed.
