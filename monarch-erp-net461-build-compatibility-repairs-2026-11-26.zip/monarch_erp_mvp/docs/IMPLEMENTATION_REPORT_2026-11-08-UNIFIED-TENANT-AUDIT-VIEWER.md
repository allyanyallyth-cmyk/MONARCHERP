# Implementation report — Unified tenant audit viewer

## Delivered

- Added `src/Monarch.Core/Security/TenantAuditLogReader.cs` and its DTO.
- The reader is read-only and requires `users.manage` plus an active actor membership in the requested company and branch.
- Query scope is explicitly constrained by both `company_id` and `branch_id`.
- Supports bounded filters: UTC range, action substring, entity type, and actor user ID. SQL values are parameterized; the action substring escapes SQL LIKE metacharacters.
- Added the Arabic WPF tab `سجل التدقيق الموحد`, visible to users with `users.manage`, showing the selected company/branch only.
- Updated README and ROADMAP. No database migration or package dependency was added.

## Important boundaries

- The viewer reads `monarch_company_audit_log` in the active local SQLite database. It does not combine the local append-only file journals (`TenantAuditEventStore` or procurement export audit) and does not receive events from other workstations.
- Existing legacy events with `branch_id IS NULL` are intentionally excluded from branch-scoped results.
- The view is read-only; it does not provide edit/delete actions.
- The 1,000-row WPF display cap is lower than the Core API maximum of 5,000.

## Validation

- Python structural tests are included in `tests/test_tenant_audit_log_reader.py`.
- XML/XAML/project-file parsing is performed as part of packaging checks.
- .NET SDK/MSBuild availability must be checked in the execution environment. No successful C# build or Windows WPF runtime test is claimed unless the corresponding commands actually run.
