# Implementation report — SQLite WAL sidecar-safe restore rollback

**Date:** 2026-11-12  
**Scope:** `BackupRecoveryService` restore rollback and SQLite backup regression coverage.

## Changes

- Restore now moves any existing live `-wal` and `-shm` sidecars to unique rollback-sidecar names before replacing the database. This avoids discarding the prior database's sidecar state before the replacement is known to be valid.
- On a failed replacement or failed post-replacement integrity check, the prior database file is restored when available and quarantined sidecars are moved back to their original paths.
- On success, the prior database rollback file and quarantined sidecars are removed after the restored database passes integrity and foreign-key checks.
- Added Python regression models for database-plus-sidecar rollback, successful stale-sidecar cleanup, and a committed-WAL online-backup snapshot. Added source assertions for the C# sidecar operations.
- The production backup continues to use `SqliteConnection.BackupDatabase`, which snapshots committed SQLite state through the online backup API rather than raw-copying database/WAL files independently.

## Safety boundary

Restore still requires MONARCH and every other process using the database to be closed. The named mutex only coordinates builds that use this service and the same mutex convention; it does not control unrelated SQLite clients. If an external process holds WAL/SHM handles, Windows may reject sidecar moves or replacement; the operation must fail rather than be treated as safe.

## Validation

- Python pytest: **614 passed**, with `ResourceWarning` promoted to errors.
- Python unittest discovery: **365 passed**.
- XML/XAML/project parsing: see the accompanying test log for the exact count.
- Python tests model SQLite semantics and inspect C# source structure; they do not execute `BackupRecoveryService` or prove Windows filesystem behavior.
- C# build and WPF/Windows runtime tests were not run because `dotnet` is unavailable in this environment.

No database migration or encrypted-backup format change was introduced.
