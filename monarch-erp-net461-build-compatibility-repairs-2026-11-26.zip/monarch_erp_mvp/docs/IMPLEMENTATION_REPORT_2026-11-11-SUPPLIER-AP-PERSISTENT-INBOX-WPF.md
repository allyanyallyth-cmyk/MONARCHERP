# Supplier AP persistent inbox WPF integration — 2026-11-11

## Scope
Completed the WPF integration of the previously implemented persistent recipient inbox read-state store. This stage is additive and preserves the existing delivery dispatcher, operational alert center, tenant ledger, accounting worker, and all prior modules.

## Implementation
- Loads the durable delivered-inbox projection when the supplier AP alerts tab is opened.
- Refreshes the durable projection after the user receives a batch and confirms delivery.
- Adds explicit refresh, mark-viewed, and acknowledge-selected-notification actions.
- Displays alert identity/code/severity/escalation, delivery timestamp, viewed state/time, and acknowledgement state/time.
- Applies `reports.read` gating in each WPF action and passes the authenticated user plus active company/branch IDs to the store.
- Keeps `Viewed` and `Acknowledged` separate, append-only, idempotent, and restricted to delivered intents.

## Safety boundaries
- No dispatcher claim/retry operation is triggered by viewing or acknowledging an inbox item.
- No worker lease, accounting outbox, journal, payment, supplier balance, or source diagnostic is changed.
- Operator dead-letter inspection and audited manual retry are not included in this stage.

## Validation
- Python pytest suite: see `TEST_RESULTS_2026-11-11-SUPPLIER-AP-PERSISTENT-INBOX-WPF.log`.
- Python unittest suite: see the same test log.
- XML/XAML parsing and archive comparison: see the same test log.
- C# build and WPF runtime: NOT RUN; .NET SDK is unavailable in this environment. Python structural tests do not establish C# compilation or Windows runtime correctness.

## Migration
The existing explicit migration remains required: `database/migrations/2026-11-11-supplier-ap-alert-inbox-read-state.sql`. Apply after backup and after its delivery/dispatcher prerequisite migrations, following the project's migration procedure. No automatic migration was introduced.
