# MONARCH ERP — Procurement Forecast Snapshots & Accuracy

Date: 2026-11-08

## Delivered

- Added immutable `ProcurementForecastSnapshot` data to predictive draft orchestration.
- Captures expected demand as `AverageDailyDemandMilli × TargetCoverageDays`, rounded to integer milli-units, with a frozen UTC measurement window and policy version `demand-average-v1`.
- The SQLite draft gateway inserts the forecast snapshot in the same transaction as the durable recommendation claim, purchase-order header and lines, manager approval queue, and audit event. A rollback therefore removes all of those writes together.
- Added an explicit migration creating `monarch_procurement_forecast_snapshots`, uniquely keyed to the durable recommendation identity and indexed for matured-period analytics.
- Extended read-only procurement analytics with matured-window WAPE: sum of absolute forecast errors divided by total actual demand. Actual demand is drawn from `Issue`, `TransferOut`, and `PurchaseReturn` stock movements within the same company, branch, warehouse, item, and forecast window.
- Forecast windows that have not ended by the report cutoff are excluded. If total actual demand is zero, the percentage remains null rather than fabricating a score.

## Migration

Apply `database/migrations/2026-11-08-procurement-forecast-snapshots.sql` explicitly after `2026-11-08-durable-procurement-recommendation-idempotency.sql`, after a verified database backup. No automatic migration was added.

## Verification

- Pytest: 408 passed.
- Unittest discovery: 308 tests, OK. Existing SQLite ResourceWarnings were emitted by older tests.
- Migration exercised against SQLite, including repeat application, uniqueness, and foreign-key relationship.
- XML/XAML/CSProj parse and changed C# delimiter checks are recorded in the release verification log.
- C# build and WPF runtime were not executed because .NET SDK/MSBuild/C# compiler are unavailable in this environment.

## Limitations

- This metric is WAPE for the stored demand horizon, not a complete forecasting-model validation suite. It does not yet account for stockouts, seasonality, promotions, substitutions, or censored demand.
- The WPF executive dashboard has not yet been connected to this new accuracy result.
