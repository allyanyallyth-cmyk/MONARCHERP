# MONARCH ERP — Startup membership and migration guard hardening

Date: 2026-11-07

## Changes

- Added `CompanyDirectoryStore.HasCompanyMembership(Guid userId)` to query active company membership for the authenticated user only.
- Updated WPF startup bootstrap to grant the seeded default company to the currently authenticated Administrator only when that user has no active company membership. It no longer uses a global “any user has membership” condition.
- Updated the legacy-ledger startup gate to require the migration history row for the seeded default company specifically. A migration marker for another company can no longer satisfy this gate.
- Extended Python structural tests and C# smoke assertions for per-user membership detection.

## Verification

- Python and SQLite tests: 97/97 passed.
- ZIP integrity and SHA-256: verified at packaging time.
- C# build and execution: not run; no .NET SDK/MSBuild is installed in this environment.
- WPF runtime/UI acceptance: not run; requires Windows.
- GitHub Actions: workflow exists but has not been executed against a remote repository from this environment.

## Remaining acceptance work

1. Push this source tree to a GitHub repository and run `MONARCH Windows build`.
2. Resolve any compiler, restore, WPF, or Inno Setup failures reported by the runner.
3. Perform interactive Windows 11 acceptance: first administrator bootstrap, login, company/branch selection, account creation, multi-line journal, posting, reports, backup verification, restore, and installer uninstall/reinstall.
4. Test the legacy migration using a disposable copy of a real legacy database and reconcile all balances before production use.
5. Test supported Windows versions on clean virtual machines.

No claim is made that this stage is a compiled or production-ready Windows release.
