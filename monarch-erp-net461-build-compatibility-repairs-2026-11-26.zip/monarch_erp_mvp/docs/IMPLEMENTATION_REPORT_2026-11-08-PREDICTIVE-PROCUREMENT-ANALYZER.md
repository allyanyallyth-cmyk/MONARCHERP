# Implementation report — Predictive Procurement Analyzer

Date: 2026-11-08

## Delivered
- Added `SqlitePredictiveProcurementAnalyzer` as a read-only SQLite adapter.
- Scope is explicitly constrained by company, branch and warehouse; only active stock items in the requested warehouse are considered.
- Demand is calculated from immutable `Issue`, `TransferOut`, and `PurchaseReturn` movements over a bounded lookback window.
- Inventory position includes current on-hand balance and remaining quantities from `Approved` / `PartiallyReceived` purchase orders.
- Reorder point = ceiling(average daily demand × supplier lead-time days) + item reorder buffer.
- Suggested quantity = max(0, ceiling(average daily demand × (lead-time days + target coverage days)) + reorder buffer − inventory position).
- Each candidate includes the calculation inputs and an explanatory rationale.
- Added explicit additive indexes for the demand-window and open-PO queries.

## Safety and boundaries
- Analyzer performs SELECT-only work and has no write, approval, or posting capability.
- It does not guess supplier identity, price, tax, or vendor lead time. Lead time and target coverage are supplied by policy; production sourcing master data remains future work.
- This analyzer does not itself authorize the caller. The host application must enforce the appropriate tenant-scoped procurement-analysis permission before invocation.
- No automatic draft creation is triggered here. A reviewed candidate may be passed to the existing draft-only procurement gateway with explicit supplier and commercial terms; human manager approval remains mandatory.
- The new index migration is explicit and is not run at startup.

## Verification
- `python3 -m pytest -q`: 375 passed.
- `python3 -m unittest discover -s tests -p 'test_*.py' -q`: 308 tests, OK. Existing ResourceWarnings about unclosed SQLite connections remain in older tests.
- XML/XAML/CSProj parsing: 7/7 OK.
- .NET build was not run: `dotnet`, `msbuild`, and `csc` are not installed in this environment.
