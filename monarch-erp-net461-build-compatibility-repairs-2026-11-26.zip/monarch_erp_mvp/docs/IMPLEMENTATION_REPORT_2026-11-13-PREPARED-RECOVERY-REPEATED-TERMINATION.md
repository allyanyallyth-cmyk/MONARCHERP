# MONARCH ERP — Prepared recovery repeated-termination coverage

Date: 2026-11-13
Baseline: `monarch-erp-committed-cleanup-fault-injection.zip`

## Change
Added a deterministic regression that exercises two consecutive simulated process terminations during `prepared` rollback recovery. For each of the first five filesystem mutation points, the test interrupts the initial recovery, interrupts the next recovery after its first mutation, and then starts recovery again without fault injection. The final state must contain the original database and original WAL/SHM sidecars, with no quarantined rollback artifacts remaining.

No production C# code, database schema, module, or UI behavior was changed.

## Validation
- pytest: 645 passed.
- unittest: 365 passed.
- XML/XAML/project parsing: 7 files, 0 errors.
- .NET SDK: unavailable; C# build and WPF runtime not run.
- Windows SQLite provider and real process-termination tests: not run.

The new regression exercises the Python filesystem model only. It does not execute the compiled `BackupRecoveryService` and is not evidence of Windows filesystem durability or power-loss safety.
