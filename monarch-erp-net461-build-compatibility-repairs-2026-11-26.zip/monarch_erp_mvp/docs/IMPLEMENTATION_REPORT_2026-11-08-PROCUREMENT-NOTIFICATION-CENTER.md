# Procurement Notification Center & Decision Timeline — 2026-11-08

## Delivered

- Added `ProcurementNotificationCenterStore` with tenant/branch membership checks for inbox access and an approval-permission check for decision history.
- Added per-user read state in `monarch_procurement_notification_reads`. This is deliberately separate from the notification outbox's `Pending` / `Delivered` / `Failed` transport state, so reading a message never claims external delivery.
- Added bounded inbox retrieval (latest 500), idempotent mark-one-read, and mark-all-read operations.
- Added read-only decision timeline retrieval from append-only decision snapshots.
- Added WPF tab `الإشعارات والسجل` with inbox, mark selected/all as read, and decision timeline.
- Added explicit migration `database/migrations/2026-11-08-procurement-notification-center.sql`.

## Security and consistency

- Inbox SQL always constrains recipient user, company and branch.
- Read mutations only succeed for a notification addressed to the current user in the current tenant scope.
- Timeline requires `commercial.purchases.approve` and remains read-only.
- Existing outbox rows and delivery status are not modified by the read-state migration.
- Migration is not executed automatically at application startup.

## Explicit limitations

- This is an in-app notification center. No email, SMS, mobile push, external delivery worker, or retry scheduler is claimed as implemented.
- The center requires the explicit migration before use. Existing databases without it will fail closed and display the underlying schema error.
- .NET SDK/MSBuild availability must be checked separately; Python/source and SQLite migration tests do not prove a successful C# compilation or Windows runtime.
