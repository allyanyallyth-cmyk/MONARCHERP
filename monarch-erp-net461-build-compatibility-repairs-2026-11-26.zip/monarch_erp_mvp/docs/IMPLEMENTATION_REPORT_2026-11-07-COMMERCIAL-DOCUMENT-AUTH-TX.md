# Implementation report — Commercial document transaction authorization

Date: 2026-11-07

## Change
- Moved `CommercialDocumentStore` authorization for draft creation and posting into the same SQLite transaction and connection as each write.
- The authorization query joins active company access and active branch membership, and rejects Viewer for writes.
- Added structural Python tests to guard transaction binding and prevent reintroduction of the separate preflight check.

## Validation
- Python test suite: 193/193 passed (`python3 -m unittest discover -s tests -q`).
- C# compilation, C# smoke tests, WPF launch and Windows CI: not run in this environment; `dotnet`, `msbuild` and `csc` are unavailable. XML/XAML parse: 7/7 passed.

## Scope and limits
This specifically hardens `CommercialDocumentStore`; it does not certify every write path in the application or replace concurrent C# integration tests against SQLite.
