# MONARCH ERP — First-restore repeated-termination matrix

Date: 2026-11-13

## Scope

Extended the Python filesystem recovery model for the `prepared` first-restore path (`hadPrevious=false`). The test explores a matrix of first termination points and every selected second-termination point across the subsequent recovery attempt. A final clean retry must remove the unverified live database, restore quarantined pre-existing WAL/SHM sidecars, and leave no rollback artifacts.

## Change set

- Added one deterministic matrix regression to `tests/test_backup_restore_crash_recovery_journal.py`.
- Updated `README.md` and `ROADMAP.md`.
- Added this report and the corresponding test log.
- No production C# code, database schema, UI, or ERP module was changed.

## Evidence boundary

This is a Python filesystem-model test. It does not execute `BackupRecoveryService`, Microsoft.Data.Sqlite, WPF, or Windows process termination. The .NET SDK is not installed in the current environment; therefore no C# build or Windows runtime integration test is claimed.
