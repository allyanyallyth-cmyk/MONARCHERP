# Implementation report — Persistent inventory cost allocations

## Implemented
- Added `monarch_inventory_cost_allocations`, an immutable trace table linking company/branch, source document line, stock movement, quantity, unit cost, extended cost and costing method.
- Purchase receipt allocations use the purchase document line unit price (`DocumentCost`).
- Sales issue allocations use the moving weighted-average cost calculated from the preceding warehouse/item ledger (`MovingWeightedAverage`).
- `CommercialDocumentStore.Post` inserts each allocation in the same SQLite transaction as its stock movement, posted-document transition and accounting outbox event.
- Added database triggers prohibiting allocation UPDATE/DELETE and tests for schema and write-path contracts.

## Verification
Python/SQLite and structural tests are run in the Linux workspace. This does not compile the C# projects or validate WPF runtime behavior.

## Limitations
Sales/purchase return reversals do not yet consume this allocation table; FIFO layer depletion, transfer cost lineage, COGS/Inventory general-ledger posting and inventory-to-GL reconciliation remain incomplete. Do not use this build as a production financial inventory valuation system.
