# Supplier AP durable worker diagnostics — 2026-11-10

## Scope

This cumulative stage adds durable, tenant/branch-scoped diagnostics for two operational conditions:

- Heartbeat renewal exceptions (`heartbeat_failed`).
- Rejected invoice/payment acknowledgement or failure updates when the lease is no longer owned (`lease_ownership_lost`).

## Implementation

- Added `database/migrations/2026-11-10-supplier-ap-worker-diagnostics.sql` as an explicit additive migration. Startup does not apply it.
- Added a bounded diagnostic schema with event/entity checks, timestamp, company and branch scope, optional outbox entity id, and an index for scoped chronological reads.
- Added best-effort writes. Diagnostic persistence errors increment `DiagnosticWriteFailures` and do not alter posting, acknowledgement, retry, lease, or journal idempotency decisions.
- Added `GetRecentDiagnostics`, which first calls the tenant ledger authorization path, filters by company and branch, and limits results to 1–500.
- Diagnostic rows deliberately omit lease tokens and raw exception messages. `detail_code` is bounded to 80 characters.
- No automatic retention/deletion policy or alert threshold is enabled; the table is append-only until an operator policy is approved.

## Compatibility and safety

- No existing module or prior file was removed.
- Existing supplier AP lease and deterministic journal behavior remains authoritative.
- Existing databases require the explicit migration before durable diagnostics can be written/read. Until then, writes are swallowed and counted, so accounting processing is not blocked.
- No multi-company UI exposure or tenant-isolation relaxation was introduced.

## Verification limits

Python/SQLite tests validate migration constraints and query scoping. They do not execute the C# worker, .NET SQLite provider, WPF UI, or multi-process Windows contention. .NET SDK/MSBuild are unavailable in this environment; no C# build or WPF runtime test is claimed.
