# Identity administration: scoped WPF mutations and atomic role audit

## Delivered

- Updated the Windows user-administration screen to call the company/branch-scoped `IdentityStore.CreateUser` and `SetUserActive` overloads.
- Added a role selector and `ChangeUserRole_Click` action for the selected user.
- Added `IdentityStore.SetUserRole`, requiring `users.manage`, active actor membership in the selected company/branch, and active target membership in the same scope.
- Role reassignment updates the role mapping and writes both the legacy identity audit row and tenant company audit row in one SQLite transaction.
- The API rejects self-role changes to avoid invalidating the current administrator session, validates the supported role codes, and returns without creating a redundant audit event when the role is unchanged.
- No schema migration or external package was added. Existing unscoped APIs remain for compatibility.

## Scope and limitations

- The user list remains the existing global identity list; an attempted role change for a user without active membership in the current company/branch is rejected by Core.
- Company membership and branch membership grants/revocations still use `CompanyDirectoryStore` and are not yet folded into the identity transaction API. They remain a separate next increment.
- The role changed here is the global identity role (`monarch_user_roles`), not the company-specific access role (`monarch_user_company_access.role_code`). The screen label and report make this explicit; company-role editing needs its own scoped operation.
- Static Python tests verify source integration only. C# compilation and WPF runtime execution were not available in this environment.
