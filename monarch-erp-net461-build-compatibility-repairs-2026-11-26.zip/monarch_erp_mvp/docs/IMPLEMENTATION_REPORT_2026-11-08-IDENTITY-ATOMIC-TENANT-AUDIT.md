# Identity mutations with atomic tenant audit — 2026-11-08

## Delivered
- Added tenant-scoped `IdentityStore.CreateUser(..., companyId, branchId)` overload.
- Added tenant-scoped `IdentityStore.SetUserActive(..., companyId, branchId)` overload.
- Both overloads require `users.manage` and verify active actor membership in the selected company and branch.
- User creation/deactivation or activation, legacy audit, and `monarch_company_audit_log` insertion share one SQLite transaction. An audit failure therefore rolls back the identity mutation.
- Existing unscoped overloads remain for compatibility; callers that need tenant audit must use the scoped overloads. The desktop UI has not yet been migrated to these overloads.
- No schema migration or external dependency added.

## Boundaries
- Role reassignment and membership changes are not implemented by these overloads and are not claimed as covered.
- Existing unscoped mutation methods remain available and do not emit tenant-scoped audit because they do not receive company/branch context.
- C# compilation and WPF runtime validation require Windows/.NET tooling not available in this environment.
