# Implementation report — Supplier/item procurement performance

## Delivered
- Added `ProcurementSupplierItemPerformance` and the read-only `GetSupplierItemPerformance` query to `ProcurementAnalyticsStore`.
- Metrics are based only on posted receipt lines, linked to the purchase order, supplier, item and branch. The reporting window uses the receipt posting timestamp.
- Results include completed-order count, received quantity and weighted average unit cost.
- Monetary unit costs are grouped by currency code; values from different currencies are never combined.
- The query validates the same active user/company/branch membership and `reports.read` permission inside its SQLite transaction, and applies bounded `topRows`.
- Added an optional additive index on receipt-line company/receipt/item fields. It is not auto-applied.
- Added source-contract tests for tenant/permission scope, receipt evidence, currency separation, read-only behavior and migration idempotency.

## Important interpretation
- This is a receipt-backed realized procurement view, not a quote comparison and not a currency-normalized price ranking.
- `CompletedOrders` counts distinct purchase orders represented in the receipt-line group. A partially received order can contribute because the evidence is posted receipt quantity; it must not be interpreted as a fully completed PO.
- Average unit cost is quantity-weighted within the same supplier/item/currency grouping.

## Validation boundary
- Python/SQLite tests and archive integrity are run for this package.
- C# compilation and WPF runtime are not claimed; the environment does not have the .NET SDK/MSBuild toolchain.
