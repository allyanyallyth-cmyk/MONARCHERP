# MONARCH ERP — Supplier AP Durable Outbox Claims

Date: 2026-11-10

## Delivered
- Added durable lease token and UTC expiry columns to both supplier invoice and supplier payment accounting outboxes in the fresh-install commercial schema.
- Added an explicit additive migration for existing databases: `database/migrations/2026-11-10-supplier-ap-outbox-leases.sql`. It must be applied once after a verified backup; startup does not apply it.
- Replaced unclaimed pending-row reads in the Supplier AP worker with conditional per-row SQLite updates. Only a worker that successfully changes an eligible row receives its lease token.
- Leases are scoped by company and branch in both candidate selection and claim updates. Expired leases are eligible for reclamation after a worker/process crash.
- Acknowledgement and failure updates require the exact current lease token. A stale worker cannot acknowledge or clear a lease subsequently acquired by another worker.
- Successful acknowledgement clears the lease. Failure increments attempts and clears the lease for retry. Existing deterministic journal numbers remain the final duplicate-posting barrier.
- Retained the in-process semaphore as an optimization; the durable database claim is the cross-process coordination mechanism.

## Operational constraints
- Apply the migration before deploying this worker version to an existing database. The application intentionally does not auto-migrate.
- Lease duration is currently five minutes. There is no lease heartbeat/renewal yet; if a single posting operation exceeds that duration, another process may reclaim the row. Deterministic journal identity and token-fenced acknowledgement mitigate duplicate effects, but a future heartbeat/lease-duration policy should be considered before very long-running workloads.
- Ledger journal posting and outbox acknowledgement remain separate transactions. The worker is retry-safe, not a distributed atomic transaction.
- This change does not implement an explicit owner heartbeat or cancellation protocol.

## Verification boundary

- `pytest`: 528 passed; `unittest`: 337 passed; XML/XAML/project metadata parsing: 7/7; explicit migration executed successfully against minimal existing outbox tables.
- Python tests assert migration/schema contracts and source-level lease fencing.
- No claim is made that separate Windows processes were executed against a live database in this environment.
- C# build and WPF runtime remain unverified because .NET SDK/MSBuild are unavailable.
