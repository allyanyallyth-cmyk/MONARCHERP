# Implementation report — inventory valuation authorization transaction

Date: 2026-11-07

## Delivered

- Moved inventory valuation authorization from a separate SQLite connection into the same connection and transaction used to read stock movements and persist valuation snapshots.
- Added an active-user check to company/branch membership authorization.
- Changed write authorization from a Viewer-only denial to an explicit allowlist: only `Administrator` and `Accountant` may calculate and persist valuation snapshots.
- Kept warehouse, item, company, and branch validation inside the same transaction.
- Added structural regression tests covering transaction-bound authorization, inactive-user rejection, explicit role allowlisting, and authorization ordering.

## Verification

- Python/SQLite test suite: see release report for exact run count.
- C# build and WPF execution: not run; .NET SDK is not installed in this environment.
- Windows compatibility: not established by this stage.

## Remaining inventory accounting work

- Snapshot calculation is still a separate operation, not atomically invoked by source-document posting.
- Transfer cost carry-forward and persistent source-line cost allocations require end-to-end C# tests and transactional integration.
- COGS/Inventory journal generation and GL reconciliation remain incomplete.
