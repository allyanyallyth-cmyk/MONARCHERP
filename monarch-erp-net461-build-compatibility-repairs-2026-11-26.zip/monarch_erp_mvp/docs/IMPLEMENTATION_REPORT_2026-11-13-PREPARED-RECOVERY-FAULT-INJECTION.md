# MONARCH ERP — Prepared recovery fault-injection model

Date: 2026-11-13  
Baseline: `monarch-erp-restore-integrity-result-cardinality.zip`

## Scope

Extended the existing Python filesystem recovery model with deterministic process-stop injection after each of six individual mutations in the `prepared` rollback path:

1. Remove the uncommitted live database.
2. Move the prior database back to the live path.
3. Remove a conflicting live WAL destination.
4. Move the quarantined prior WAL back.
5. Remove a conflicting live SHM destination.
6. Move the quarantined prior SHM back.

For every injected interruption, the test starts recovery again using only the filesystem state left by the interrupted attempt. It verifies that the prior database, WAL, and SHM are restored and all quarantine artifacts are consumed only after successful restoration.

## Production-code decision

No C# production logic was changed. This stage improves fault-model coverage but does not establish that the compiled `BackupRecoveryService` behaves identically under Windows process termination, nor does it validate filesystem durability or SQLite provider behavior.

## Validation

See `TEST_RESULTS_2026-11-13-PREPARED-RECOVERY-FAULT-INJECTION.log` for exact commands and outcomes.

## Remaining work

- Add a C# integration seam or harness capable of terminating/restarting around each actual filesystem operation.
- Run on supported Windows filesystems and validate `File.Move`, `File.Replace`, journal durability, and active SQLite WAL/SHM handle behavior.
- Build Core/Desktop and execute WPF/.NET Framework checks on Windows.
