# MONARCH ERP — First-restore repeated-termination coverage

Date: 2026-11-13
Baseline: `monarch-erp-prepared-recovery-repeated-termination.zip`

## Change
Added a deterministic regression for the `prepared` recovery path when `hadPrevious=false`. The test begins with an unverified first-restore database, new live WAL/SHM files, and quarantined prior WAL/SHM files. For each of five filesystem mutation points it injects one process termination, injects a second termination during the next recovery attempt, and then allows a third attempt to complete.

The final state must have no live unverified database, the quarantined prior WAL and SHM restored as the live sidecars, and no remaining rollback artifacts. This covers a distinct first-install/first-restore branch not covered by the previous-database rollback tests.

No production C# code, database schema, module, or UI behavior changed.

## Validation
- pytest: 646 passed.
- unittest: 365 passed.
- XML/XAML/project/config parsing: 7 files, 0 errors.
- ZIP integrity: passed.
- .NET SDK: unavailable; C# build and WPF runtime not run.
- Actual Windows SQLite provider and process-termination tests: not run.

The added regression exercises the Python filesystem model only. It does not execute the compiled `BackupRecoveryService` and is not evidence of Windows filesystem durability or power-loss safety.
