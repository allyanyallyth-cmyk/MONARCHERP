# Supplier AP lease takeover and finalization hardening — 2026-11-10

## Changes

- Invoice and payment acknowledgement updates now require the row to remain unprocessed, the exact lease token, matching company and branch, and `lease_expires_utc > now`.
- Invoice and payment failure/release updates use the same expiry fence. A worker that has passed its lease deadline cannot clear or mutate a claim, even if another worker has not reclaimed it yet.
- Heartbeat renewal uses a monotonic `CASE` expression to preserve the later expiry if callbacks overlap or complete out of order.
- Existing five-minute lease duration, one-minute heartbeat cadence, deterministic journal idempotency, and explicit migration policy are retained.
- No schema migration, public API, or module removal was introduced.

## SQLite contract coverage

The new Python tests execute equivalent lease SQL against SQLite and verify:

1. Worker B cannot claim while worker A's lease is live.
2. Worker B can take over after expiry with a different token.
3. Worker A cannot renew, acknowledge, or fail after token takeover.
4. An expired owner cannot acknowledge or fail before a takeover occurs.
5. The current owner can renew and acknowledge.
6. A delayed heartbeat cannot shorten a later expiry.

These are SQLite SQL-contract/integration-style tests. They do not instantiate or execute the C# worker, the .NET timer, concurrent OS processes, or forced process termination.

## Operational boundaries

- C# build and WPF runtime were not executed because .NET SDK/MSBuild are unavailable in this environment.
- Real multi-process contention and process-crash recovery remain pending on a .NET-enabled Windows CI agent.
- Heartbeat database exceptions remain intentionally non-authoritative and are not yet emitted through a dedicated health metric.
- The explicit migration `database/migrations/2026-11-10-supplier-ap-outbox-leases.sql` remains manual; no startup migration was added.
