# Procurement Decision & Notification Workflow

## Delivered
- Added explicit additive migration `2026-11-08-procurement-decision-notifications.sql`.
- Added immutable `monarch_procurement_decision_history` snapshots containing queue/order identity, decision, rationale, manager note, order number, supplier, currency, total and actor/time.
- Added durable `monarch_procurement_notification_outbox` with tenant/branch scope, recipient, event type, queue/order references, payload, status and attempts.
- Queue creation writes `ApprovalRequested` outbox rows for active branch users holding `commercial.purchases.approve`.
- Approval/rejection writes the immutable decision snapshot and notifies the original draft creator in the same SQLite transaction as the queue/PO decision and audit event.
- Rejection notification includes the manager's reason, or explicitly states that no reason was supplied. The existing UI's rejection reason requirement remains an important presentation-level rule; server-side enforcement should be strengthened separately.

## Boundaries
- The outbox guarantees durable enqueue, not successful external delivery.
- No email, SMS, push, or Telegram delivery is claimed.
- No schema migration runs automatically at startup.
- Existing queue status, permissions, tenant isolation and PO posting boundaries are preserved.

## Validation
Python/SQLite migration and source-contract tests cover the new schema, append-only history, transactional enqueue hooks and notification event paths. C# compilation and WPF runtime validation require a Windows/.NET build environment and are not claimed here.
