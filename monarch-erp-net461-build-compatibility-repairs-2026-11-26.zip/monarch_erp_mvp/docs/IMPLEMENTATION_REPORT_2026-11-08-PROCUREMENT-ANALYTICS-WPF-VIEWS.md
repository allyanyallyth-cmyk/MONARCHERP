# Procurement Analytics WPF Views — 2026-11-08

## Scope
Extended the existing read-only procurement executive dashboard with three additional views backed by the existing Core analytics store:

- Supplier/item performance, retaining currency separation.
- Supplier performance trends and alert classification.
- Matured forecast history by item and forecast window.

## Security and behavior
- The dashboard continues to require `reports.read`.
- All service calls pass the active user, company, and branch identifiers.
- No write, approval, posting, or schema migration path was added.
- Existing analytics and dashboard views remain in place.
- On refresh failure, all grids are cleared to avoid displaying stale data as current.

## Validation
Python static regression tests verify that all three views are wired to the existing Core methods with tenant context and read permission checks. XML/XAML/project parsing and Python test suites are run as part of this package build.

A C#/.NET build and WPF runtime validation remain unverified where the .NET SDK/MSBuild toolchain is unavailable.
