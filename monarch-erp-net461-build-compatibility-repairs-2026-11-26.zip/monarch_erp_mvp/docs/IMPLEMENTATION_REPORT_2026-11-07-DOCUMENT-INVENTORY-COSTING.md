# MONARCH ERP — Document inventory costing integration

Date: 2026-11-07

## Implemented

- Purchase document posting now creates receipt movements using the posted document line's `unit_price_minor`; it no longer substitutes the item's default `cost_minor`.
- Sales document posting calculates the issue cost from the existing warehouse/item movement stream using `InventoryValuationEngine` with `MovingWeightedAverage` before inserting the issue movement.
- The costing preview reads movements by persisted `ledger_sequence` and runs on the same SQLite connection and transaction as document posting.
- Commercial-document stock movements now receive a persistent per-company/warehouse/item `ledger_sequence` rather than relying on the schema default of zero.
- Document state transition, stock movements, and the accounting outbox event remain committed in the same SQLite transaction. A failure rolls back the whole posting operation.
- Added contract tests for purchase line cost, sales moving-average issue costing, sequence assignment, and transaction/outbox scope.

## Explicit scope limits

- The document-posting integration currently applies **Moving Weighted Average** to sales issues. A company/item configurable costing policy has not yet been introduced; FIFO remains available in the standalone engine/snapshot service but is not yet selected by document posting.
- Purchase receipt cost currently uses the line's net unit price. Landed costs, freight allocation, non-recoverable taxes, and purchase price variance are not yet allocated.
- Return posting has not yet been integrated with original issue cost allocations. Sales returns therefore do not yet restore the original FIFO/weighted-average cost reliably, and purchase returns do not yet reverse the original receipt layer cost.
- Warehouse transfers still require a verified source-cost calculation; manually supplied transfer costs must not be treated as production-safe.
- Persistent per-line cost-allocation rows, COGS/Inventory accounting outbox events, and valuation-to-general-ledger reconciliation remain open.
- No .NET build, WPF execution, installer build, or Windows compatibility run was performed in this Linux environment.

## Verification

- Python/SQLite tests: 175 passed.
- XML/XAML/project-file parse: recorded separately in the release check.
- C# compilation: not run; .NET SDK unavailable.

## Operational warning

This is an integration milestone, not production financial certification. Take a verified backup before applying schema changes. Do not use generated inventory values for statutory reporting, period close, or customer production data until return costing, transfers, COGS/Inventory posting, reconciliation, and Windows integration tests are complete.
