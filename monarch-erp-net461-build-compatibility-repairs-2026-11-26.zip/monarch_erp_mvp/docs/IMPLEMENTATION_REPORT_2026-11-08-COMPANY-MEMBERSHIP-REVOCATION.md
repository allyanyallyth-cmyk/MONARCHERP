# Implementation report — Company membership revocation

## Delivered

- Added `CompanyDirectoryStore.RevokeCompanyAccess(userId, companyId, revokedByUserId)`.
- Requires a non-empty target, company, and actor; rejects self-revocation.
- Requires an active global Administrator actor and an active target membership.
- Prevents revoking the last active company Administrator.
- Deactivates all active branch grants and the company membership without deleting historical rows.
- Writes `CompanyAccessRevoked` to both `monarch_company_audit_log` and `monarch_audit_log` inside the same SQLite transaction.
- Added a confirmation-protected WPF action to the company directory administration tab.
- No schema migration or new external dependency was introduced.

## Boundaries

- The method is intended for global-administrator company-directory management, matching the existing grant workflow.
- This stage revokes the entire company membership, not an individual branch grant.
- The WPF action is available through the existing global administrator screen; the existing selection controls are reused.
- Python tests are structural contract tests; they do not execute the C# method against SQLite.

## Validation

- `python3 -m pytest -q`: **458 passed**.
- `python3 -m unittest discover -s tests -p 'test_*.py' -q`: **308 passed**.
- XML/XAML/CSProj/props/targets parsing: **7/7 passed**.
- .NET SDK, MSBuild, and C# compiler were not available; C# build and WPF runtime were not executed.
- Cumulative package comparison and ZIP integrity are recorded in the release handoff.
