# MONARCH ERP — Sales & Purchase Foundation

Date: 2026-11-07

## Delivered
- Company/branch-scoped sales and purchase document tables.
- Party role validation (Customer for Sale, Supplier for Purchase, Both for either).
- Draft document creation with currency code/scale, line snapshots, integer minor-unit arithmetic, and tax rates stored as basis points.
- Posting service that atomically transitions the document, records stock receipts/issues for stock items, and writes a unique accounting outbox event.
- Negative inventory remains guarded by the existing database trigger; a failed stock issue rolls back the whole posting transaction.
- Posted document headers and lines are protected against mutation/deletion.

## Verification
- `python -m unittest discover -s tests -q`: 116 tests passed.
- SQLite schema creation and document/outbox constraints covered by tests.
- C# compilation and Windows/WPF execution were not performed: .NET SDK/Windows runtime are unavailable in this execution environment.

## Important limitations
- The outbox is not yet consumed. Automatic General Ledger posting is not implemented or claimed.
- No returns/credit notes, payment allocation, VAT filing/reporting, FIFO/weighted-average costing, approval workflow, or WPF sales/purchase screens yet.
- Do not use for production financial transactions until C# build, Windows acceptance, outbox reconciliation, and accounting review are completed.
