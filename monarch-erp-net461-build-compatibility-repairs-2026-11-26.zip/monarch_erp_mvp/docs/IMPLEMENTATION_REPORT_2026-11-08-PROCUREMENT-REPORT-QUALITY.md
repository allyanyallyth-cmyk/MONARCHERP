# Procurement report quality improvements — 2026-11-08

## Scope

Improved the self-contained Arabic RTL procurement HTML print report without introducing dependencies or schema changes. The report now includes counts of reliable supplier comparisons, critical alerts, warning alerts, and insufficient-comparison rows. Alert classification is based on the existing `AlertLevel` value and does not recalculate or mutate business data.

Print layout no longer fixes the footer over the page content. The footer remains in normal document flow, while table headers repeat and rows are kept together where supported by the browser print engine.

## Security and tenancy

The existing WPF export path continues to re-check `reports.read`, use the active company and branch, HTML-encode tenant labels, and embed only bounded PNG/JPEG logo payloads. This change adds no database writes, permissions, migrations, or external dependencies.

## Verification

Python source-level regression tests cover the alert summary and print-footer behavior. A Windows/.NET build and browser-to-PDF visual verification remain outstanding and must not be inferred from Python tests.
