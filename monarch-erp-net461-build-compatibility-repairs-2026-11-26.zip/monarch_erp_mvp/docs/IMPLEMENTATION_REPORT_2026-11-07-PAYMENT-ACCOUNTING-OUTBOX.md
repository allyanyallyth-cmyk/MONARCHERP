# Implementation report — Commercial payment accounting outbox

Date: 2026-11-07

## Delivered

- Added `CommercialPaymentAccountingOutboxWorker` to consume `CustomerReceiptPosted` and `SupplierPaymentPosted` events.
- Customer receipts post debit cash/bank and credit accounts receivable.
- Supplier payments post debit accounts payable and credit cash/bank.
- Cash/bank account must be active and of Asset type; receivables must be Asset; payables must be Liability.
- Queue reads and journal operations are scoped to the explicitly selected company and branch.
- Deterministic `AUTO-PAY-<payment-guid>` journal numbers make retries idempotent if the ledger commit succeeds but outbox acknowledgement does not.
- Failures are recorded with bounded error text and attempt count.

## Verification

- Python/SQLite test suite: 133 tests passed.
- XML/XAML project files: 7/7 parsed successfully.
- ZIP integrity checked after packaging.
- No .NET SDK, C# compiler, MSBuild, or Windows runtime is available in this environment. C# build and WPF execution are therefore not claimed.

## Accounting boundary

The ledger journal commit and outbox acknowledgement are separate SQLite transactions. Deterministic journal identity provides retry safety; it does not make the two commits a single atomic transaction. Configure and validate each company's control accounts and cash/bank account codes before use.
