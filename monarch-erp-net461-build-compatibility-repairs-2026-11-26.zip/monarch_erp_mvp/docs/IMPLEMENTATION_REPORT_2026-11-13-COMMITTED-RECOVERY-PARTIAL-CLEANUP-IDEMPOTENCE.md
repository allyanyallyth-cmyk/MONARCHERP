# MONARCH ERP — Committed recovery partial-cleanup idempotence

Date: 2026-11-13  
Baseline: `monarch-erp-committed-recovery-double-crash-matrix.zip`

## Scope

The committed-recovery model already covered termination during cleanup. This increment closes a related state-space gap: after a process has removed an arbitrary subset of the rollback database, quarantined WAL, and quarantined SHM, a subsequent recovery must tolerate that partially completed cleanup and remain safe when invoked again.

## Regression coverage

The new test enumerates all eight presence/absence combinations for those three artifacts. It invokes committed recovery twice for each combination and verifies that:

- the verified live database remains byte-for-byte unchanged;
- every rollback artifact is absent after recovery;
- no live WAL/SHM sidecars are introduced.

## Validation and limitations

- pytest: 650 passed.
- unittest discovery: 365 passed.
- XML/XAML/project/config parsing: 7 files, 0 errors.
- No .NET SDK was available. C# build, WPF runtime, actual SQLite-provider integration, Windows process-kill, and power-loss tests were not run.
- No production C# logic, schema, ERP module, or WPF behavior was changed.

This is Python filesystem-model coverage, not runtime proof for `BackupRecoveryService`.
