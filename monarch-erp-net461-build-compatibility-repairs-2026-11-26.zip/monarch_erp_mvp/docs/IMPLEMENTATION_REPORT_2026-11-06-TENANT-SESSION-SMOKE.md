# MONARCH ERP — Tenant session acceptance smoke coverage

Date: 2026-11-06

## Added

Extended `tests/Monarch.Core.SmokeTests/Program.cs` to exercise the public `TenantAccountingSession.Open` flow used by the desktop application. The smoke suite now checks:

- selected company and branch identifiers are retained by the opened session;
- company base currency and exponent are resolved through the organization directory;
- journal reads remain scoped to the selected branch;
- chart-of-accounts reads remain scoped to the selected company;
- a Viewer can open an explicitly assigned company/branch;
- a Viewer cannot open an unassigned company or a branch belonging to another company.

## Verification in this environment

- Python/SQLite integration and structural suite: run separately; this C# change does not affect Python tests.
- C# compilation and execution: not run because this Linux environment has no .NET SDK, MSBuild, or Windows Desktop runtime.
- The Windows CI workflow already runs the C# smoke executable after restoring/building the solution. The new assertions will therefore execute on the next successful Windows CI run.

## Acceptance limitation

These are core-level smoke checks, not interactive UI automation. A Windows 11 user acceptance pass is still required for login, tenant selection, WPF navigation, keyboard/mouse entry, backup UI, restore utility, and installer behavior.
