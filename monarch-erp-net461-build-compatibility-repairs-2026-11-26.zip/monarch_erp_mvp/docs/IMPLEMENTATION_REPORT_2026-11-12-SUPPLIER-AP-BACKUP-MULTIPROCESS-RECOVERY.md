# MONARCH ERP — Supplier AP backup and competing-worker recovery

Date: 2026-11-12

## Scope

This cumulative stage hardens encrypted SQLite backup/restore validation and adds file-backed competing-worker regression coverage for the Supplier AP alert dispatcher. It starts from the previous `supplier-ap-dispatch-integrity` package and retains all prior modules and changes.

## Changes

1. `BackupRecoveryService.CheckIntegrity` now collects all `PRAGMA integrity_check` findings and all `PRAGMA foreign_key_check` violations. The shared validator is already used by encrypted backup creation, backup verification, restore preflight, and post-replacement verification.
2. Added a database-copy regression proving delivery attempt history, dead-letter administrative decisions, and recipient inbox events survive backup/restore copying.
3. Added a file-backed two-connection contention test. Independent workers begin write transactions and compete for the same due intent; the guarded state transition allows exactly one claim.
4. Added an orphan-row regression showing why `foreign_key_check` is necessary: page integrity may remain `ok` while referential integrity is broken.
5. No migration was added; the change is backward-compatible with the existing encrypted backup container format.

## Validation

- `python -W error::ResourceWarning -m pytest -q`: **601 passed**.
- `python -m unittest discover -s tests -p 'test_*.py' -q`: **365 passed**.
- XML/XAML/project parse: **6 files passed**.
- ZIP archive integrity: passed.
- C# build and WPF runtime: **NOT RUN**; `dotnet` is unavailable in this environment.
- The competing-worker test uses Python SQLite connections and validates database locking/claim semantics; it is not a Windows multi-process C# integration test.

## Cumulative integrity

The new archive was compared against the previous `monarch-erp-supplier-ap-dispatch-integrity.zip`. No prior file was removed. Only this report, this stage's test module, and its test log are new; README, ROADMAP, and `BackupRecoveryService.cs` are updated.
