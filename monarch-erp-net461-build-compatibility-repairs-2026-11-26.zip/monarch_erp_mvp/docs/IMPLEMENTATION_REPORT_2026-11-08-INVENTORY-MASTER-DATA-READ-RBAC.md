# Inventory master-data read authorization — 2026-11-08

## Scope
Corrected the inventory catalog read path so read-only inventory roles can view item groups and units without receiving master-data write privileges. Aligned the WPF catalog tab with `inventory.read`, while keeping create/update/activate controls gated by `inventory.items.manage`.

## Core changes
- `InventoryMasterDataStore.GetUnits` and `GetItemGroups` now require `inventory.read`; all master-data write methods continue to require `inventory.items.manage`.
- `CommercialStore.GetItems` now checks active user, active company membership, active company, and the `inventory.read` RBAC grant inside the same SQLite read transaction.
- `CommercialStore.GetWarehouses` now performs the existing active user/company/branch/RBAC check and the branch-scoped query inside one SQLite read transaction.
- WPF inventory catalog visibility and refresh now require `inventory.read`, not the unrelated `reports.read` permission.
- Group and unit tabs are visible to inventory readers, but their mutation buttons remain visible only to users with `inventory.items.manage`.

## Security and compatibility
- No database migration or schema change was required.
- No write permission was broadened.
- Warehouse reads remain restricted to the selected authorized branch; item, group, and unit master data remain company-scoped.
- The catalog remains read-only for roles that have `inventory.read` without `inventory.items.manage`.

## Verification boundary
Python tests validate source structure and authorization wiring. They do not execute the C# code. C# build and WPF runtime verification were not performed in this environment.
