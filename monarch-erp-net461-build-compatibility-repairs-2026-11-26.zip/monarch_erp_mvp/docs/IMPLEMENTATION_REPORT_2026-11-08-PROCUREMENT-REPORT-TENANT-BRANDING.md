# Procurement report tenant branding — 2026-11-08

## Scope
Extended the existing procurement analytics print-ready HTML report without changing its data queries or adding dependencies/migrations.

## Delivered
- Uses the active `TenantAccountingSession.CompanyName` and `BranchName` in the report header and footer.
- Optional PNG/JPEG logo is embedded as a data URI, making the saved HTML self-contained.
- Logo size is capped at 2 MiB and file signatures are checked before embedding.
- UTC generation timestamp is included in report metadata/footer.
- Tenant-controlled display names remain HTML-encoded.
- WPF prompts the operator whether to include a logo, then uses a file picker; the report export continues to require `reports.read` and retrieves all datasets through the active user/company/branch context.

## Safety and scope
- Read-only analytics only; no procurement, inventory, or accounting records are modified.
- No external image URL/path is embedded.
- No database migration or package dependency added.
- Existing CSV, XLSX, dashboard, forecast, supplier, accounting, and ZATCA modules remain in the cumulative package.

## Validation
Python structural tests cover branding, logo constraints, HTML encoding, active tenant names, and permission guard. Full C# compilation and WPF runtime execution remain unverified because the environment does not provide the .NET SDK/MSBuild toolchain.

## Remaining
Native PDF generation is intentionally deferred until an Arabic shaping/font embedding pipeline can be built and validated against actual PDF readers. Current HTML remains printable to PDF through a modern browser.
