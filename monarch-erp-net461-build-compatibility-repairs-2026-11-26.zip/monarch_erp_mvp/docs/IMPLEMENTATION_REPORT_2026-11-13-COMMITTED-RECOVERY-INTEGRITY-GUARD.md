# MONARCH ERP — Committed restore recovery integrity guard

Date: 2026-11-13  
Baseline: `monarch-erp-restore-recovery-code-review.zip`

## Finding and change

The committed-journal recovery branch previously checked only that the live database file existed before deleting the rollback database and quarantined WAL/SHM artifacts. The normal restore flow had integrity-checked the database before writing `committed`, but a later storage fault or external modification before recovery could leave a present yet invalid live database. In that state, cleanup could discard the last local rollback artifacts.

The branch now reruns the existing `CheckIntegrity` routine (SQLite `integrity_check` plus `foreign_key_check`) on the live database before any rollback-artifact or journal deletion. If validation fails, recovery throws a descriptive `InvalidDataException` and preserves the rollback database, sidecars, and journal for manual recovery.

## Regression coverage

- Added a Python crash-state model proving failed committed-live integrity validation leaves all rollback artifacts and the journal-state scenario intact.
- Added a structural assertion that the C# integrity check and fail-closed guard precede rollback cleanup.
- These are Python model/source-structure checks, not execution of the C# service.

## Validation

- Full pytest suite: **640 passed**.
- unittest discovery: **365 passed**.
- XML/XAML/project/config parsing: **7 files parsed, 0 errors**.
- .NET SDK: unavailable (`dotnet` not found).
- C# build: **NOT RUN**.
- WPF runtime: **NOT RUN**.
- Windows filesystem corruption, process termination, power-loss, and live SQLite recovery integration: **NOT RUN**.

## Compatibility and scope

- No SQLite schema or migration changes.
- No encrypted backup format changes.
- No WPF/UI changes.
- No modules or prior features intentionally removed.
- The change only adds a validation gate before destructive cleanup in committed recovery.
