# Implementation report — return inventory cost reversals

## Delivered

- Added `monarch_inventory_return_cost_allocations`, an append-only, tenant-scoped record connecting each posted return line and stock movement to the original purchase-receipt or sales-issue cost allocation.
- Sales returns now load the original `SalesIssue` allocation; purchase returns load the original `PurchaseReceipt` allocation. Posting is rejected if the source line has no persisted cost allocation.
- Partial returns use cumulative proportional allocation against the original extended cost and subtract amounts already reversed. This ensures the cumulative returned cost converges to the original allocation amount when the full source quantity is returned.
- Added upgrade-safe composite unique indexes so legacy databases can enforce tenant-scoped foreign keys for the new return-cost trace.
- Return stock movements now receive a per-company/warehouse/item `ledger_sequence` in the same SQLite transaction as the return movement, return cost trace, posted state and accounting outbox event.
- The return accounting worker now restores Inventory and reverses COGS for sales returns at the historical cost allocation. Purchase returns credit Inventory at original carrying cost, reverse non-stock purchase expense, and post any difference between supplier credit and carrying cost to the configured purchase price variance account (`5190` by default).

## Verification

- Python/SQLite suite: 185 tests passed.
- C# compilation and Windows runtime tests were not run because this environment does not contain the .NET SDK or Windows.

## Remaining limitations

- FIFO layer consumption is not yet persisted at issue time; sales issue allocations currently represent moving weighted average only.
- Transfer-in/out cost lineage and cross-warehouse valuation remain incomplete.
- Partial-return monetary rounding can differ by a minor unit between the movement's integer unit-cost representation and the exact cumulative extended-cost allocation. The allocation table is the authoritative return journal amount; a future scaled-cost/extended-cost movement model and reconciliation is required before production use.
- Full Inventory/COGS reconciliation against the general ledger, VAT end-to-end validation, WPF commercial screens, Windows build and installer validation remain outstanding.
