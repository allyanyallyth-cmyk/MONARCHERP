# MONARCH ERP — Supplier AP Outbox Concurrency Guard

Date: 2026-11-10

## Delivered
- Added an in-process serialization gate keyed by normalized database path, company, and branch for the supplier AP GL outbox worker.
- The gate covers pending-row selection, journal creation/posting, and outbox acknowledgement, preventing two worker instances in the same process from racing over the same tenant branch queue.
- The gate is always released in a `finally` block, including authorization and processing failures.
- Retained deterministic invoice/payment journal numbers and the ledger's `UNIQUE(company_id,number)` constraint as the cross-process duplicate-journal guard.
- Retained journal content verification before reusing an existing deterministic journal.
- Retained retry-safe acknowledgement: if a journal committed but the outbox acknowledgement failed, a later run validates and reuses the posted journal, then acknowledges the outbox row.
- No schema change, migration, public API signature change, or automatic migration was introduced.

## Boundary and limitation
- The semaphore coordinates workers only inside one process. Separate OS processes are not serialized by this in-memory gate. Cross-process duplicate journal creation remains constrained by the ledger's company-scoped unique journal number; the losing worker may record a retryable outbox failure and will reconcile on a later run.
- Journal posting and outbox acknowledgement are still separate SQLite transactions. This is intentional in the current design; the deterministic journal identity makes the gap recoverable, but this is not a single atomic commit across the ledger and commercial outbox stores.
- C# compilation and real multi-thread execution were not available in this environment; validation is structural Python coverage only.

## Verification
See `docs/TEST_RESULTS_2026-11-10-SUPPLIER-AP-OUTBOX-CONCURRENCY.log`.
