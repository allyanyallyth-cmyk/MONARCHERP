# Supplier AP outbox lease heartbeat — 2026-11-10

## Change

The supplier invoice and supplier payment accounting outbox worker now runs a periodic heartbeat while processing claimed batches. A `System.Threading.Timer` fires every minute and extends each eligible lease to five minutes from the heartbeat timestamp.

Each renewal is conditional on all of the following:

- exact outbox row ID;
- matching company and branch;
- row remains unprocessed;
- exact current lease token;
- existing lease expiry is still later than the heartbeat timestamp.

The last condition is important: an expired lease cannot be resurrected by a delayed worker. A worker whose token has been replaced cannot extend the new owner's lease. A heartbeat database exception is contained; the worker's final acknowledgement/failure update remains token-fenced, and deterministic journal identity remains the duplicate-posting barrier.

## Compatibility and migration

- No schema change or new migration.
- No public API change.
- Existing five-minute lease duration is retained.
- Existing explicit migration policy remains unchanged; no startup migration is introduced.
- All prior modules and documents are retained in the cumulative package.

## Limits

This is a source-level implementation plus Python structural regression coverage. It is not proof of runtime timer behavior under real SQLite contention. Live multi-process contention, forced process termination, and lease-takeover integration tests require a .NET-enabled environment and remain outstanding. The timer's heartbeat errors are not currently surfaced through a dedicated operational health metric.
