# MONARCH ERP — Purchase Receipts WPF

Date: 2026-11-07

## Delivered
- WPF purchase tab now shows remaining lines for the selected approved/partially received purchase order.
- Displays ordered, received and remaining quantities.
- Posts a one-line receipt from the selected row through `PurchaseOrderReceiptStore.Receive`, after explicit confirmation.
- Displays receipt history scoped to the selected order.
- Added `ListReceiptableLines` Core read API, authorized by `reports.read` and scoped to company + branch.
- No direct SQL was added to the desktop layer. Existing receipt posting remains atomic in Core.

## Known limitation
- UI currently posts one PO line per receipt document. Core `Receive` already supports multiple lines; multi-line selection UI remains future work.
- Supplier invoice, three-way matching, AP settlement and payment posting remain future work.

## Tests
- `python -m pytest -q`: 283 passed.
- `python -m unittest discover -s tests -p 'test_*.py' -q`: 260 tests, OK.
- XML/XAML/CSProj parsing and ZIP integrity checked separately.
- .NET SDK/MSBuild/csc unavailable; C# build NOT RUN; WPF runtime NOT RUN; Windows compatibility NOT VERIFIED.
