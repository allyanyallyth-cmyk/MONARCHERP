# Supplier Intelligence — implementation report

## Delivered
- Explicit SQLite migration `2026-11-08-supplier-intelligence.sql` creates effective-dated supplier/item commercial terms and supporting indexes.
- `SupplierIntelligenceStore.SaveTerms` validates commercial values and a mandatory source reference, verifies supplier identity in the tenant, checks `commercial.purchases.manage`, and records an audit event in the same transaction.
- `GetItemOptions` checks `reports.read`, scopes results to company and branch, and returns effective supplier terms plus observed delivery metrics from posted purchase receipts.
- Delivery history is evidence-based: no completed receipts means null average lead time/on-time rate, not an invented score.

## Boundaries
- Migration is explicit and is not run automatically at application startup.
- The service is a Core foundation; it does not yet populate the predictive orchestrator automatically.
- The manager approval WPF screen, notifications, supplier scorecard calibration, and Windows runtime/build validation remain outstanding.
- Average actual lead time currently measures from purchase-order creation to posted receipt, not supplier-confirmed dispatch; split/partial receipts can affect the aggregate and should be refined in the next analytics stage.
