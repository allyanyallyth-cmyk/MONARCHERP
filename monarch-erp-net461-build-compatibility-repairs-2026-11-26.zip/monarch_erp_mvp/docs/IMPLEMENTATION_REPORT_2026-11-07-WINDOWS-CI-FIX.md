# MONARCH ERP — Windows CI publication and release verification fix

Date: 2026-11-07

## Findings and changes

- Found `.github/workflows/windows-build.yml` explicitly listed in `.gitignore`; normal `git add .` could therefore omit the CI workflow from the GitHub repository. Removed that ignore rule.
- Added `scripts/verify-windows-release.ps1` to verify both Portable ZIP and Setup EXE exist, their SHA-256 sidecars match the actual files, and the ZIP contains the desktop and recovery executables plus core documentation.
- Added the verifier to the Windows Actions workflow after installer packaging.
- Added regression tests for the ignore-rule defect and release-verifier wiring.

## Verification

- Python/SQLite and structural suite: 99/99 passed.
- Project XML: 5/5 `.csproj` files parsed; XAML: 2/2 files parsed.
- Git ignore regression: workflow path is no longer listed in `.gitignore`; regression test passed.
- Windows build, Inno Setup compilation, artifact verification, and WPF runtime: not executed in this Linux environment.
- GitHub Actions: still requires pushing the source to a remote repository and running the workflow.

## Release status

This is a source/CI hardening stage, not a compiled Windows release. No claim is made that the installer or WPF runtime has been executed.
