# Restore-journal cleanup: concurrent temp disappearance (2026-11-14)

## Change
- Added a regression case for a GUID-N abandoned journal temp that is enumerated, then removed by another actor before strict cleanup reaches it.
- The model uses idempotent single-file deletion semantics and verifies the cleanup pass completes without recreating or altering the removed entry.
- Added a C# source guard ensuring the strict helper calls `File.Delete(path)` directly and does not preflight with `File.Exists`, preserving the intended missing-file no-op while allowing real I/O/authorization failures to propagate.

## Scope and limitations
- Test and documentation only; no production C#, schema, WPF, or ERP module was changed.
- This is a Python filesystem-model test plus a source-structure assertion. It is not a multi-process Windows/NTFS execution test.
- Compiled C#, WPF runtime, Windows ACL/sharing behavior, and SQLite integration remain unverified in this environment.
