# Restore journal partial-write cleanup ownership — 2026-11-14

## Change
Added a regression for an I/O failure after exclusive creation has succeeded and a partial journal payload has been written. The test verifies that the invocation-owned temporary file is removed while no published journal appears. Added a source-order guard proving the C# writer establishes ownership only after `CreateNew` succeeds, performs writes and atomic publication afterward, and applies ownership-gated cleanup in `finally`.

## Scope
Test and documentation increment only. No production C#, database schema, WPF, installer, or ERP module changed. The existing ownership fix remains intact.

## Validation
See the accompanying test-results log. Python tests and structural parsing do not substitute for compiled C# execution or Windows/NTFS integration.
