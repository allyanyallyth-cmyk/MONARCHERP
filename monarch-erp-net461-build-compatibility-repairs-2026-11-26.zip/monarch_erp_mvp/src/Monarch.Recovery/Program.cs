using System;
using System.IO;
using Monarch.Core.Backup;

namespace Monarch.Recovery
{
    internal static class Program
    {
        private static int Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.WriteLine("MONARCH ERP - أداة استعادة قاعدة البيانات");
            Console.WriteLine("يجب إغلاق MONARCH ERP وجميع عملياته قبل المتابعة.");
            if (args.Length != 2)
            {
                Console.WriteLine("الاستخدام:");
                Console.WriteLine("Monarch.Recovery.exe <مسار-قاعدة-البيانات> <مسار-النسخة.mbackup>");
                return 2;
            }

            var databasePath = Path.GetFullPath(args[0]);
            var backupPath = Path.GetFullPath(args[1]);
            if (!File.Exists(backupPath))
            {
                Console.WriteLine("ملف النسخة الاحتياطية غير موجود.");
                return 3;
            }
            Console.Write("كلمة مرور النسخة: ");
            var password = ReadSecret();
            var service = new BackupRecoveryService(databasePath);
            var verification = service.VerifyEncryptedBackup(backupPath, password);
            if (!verification.IsValid)
            {
                Console.WriteLine("فشل التحقق: " + verification.Message);
                return 5;
            }

            Console.WriteLine("النسخة اجتازت التحقق التشفيري وفحص SQLite.");
            Console.Write("اكتب RESTORE للتأكيد النهائي: ");
            var confirmation = Console.ReadLine();
            if (!string.Equals(confirmation, "RESTORE", StringComparison.Ordinal))
            {
                Console.WriteLine("أُلغيت الاستعادة دون تغيير قاعدة البيانات.");
                return 0;
            }

            try
            {
                var safetyPath = Path.Combine(Path.GetDirectoryName(databasePath),
                    "monarch-before-restore-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".mbackup");
                var result = service.RestoreEncryptedBackup(backupPath, password, safetyPath);
                Console.WriteLine("نجحت الاستعادة. نتيجة فحص SQLite: " + result.IntegrityResult);
                if (!string.IsNullOrEmpty(result.SafetyBackupPath))
                    Console.WriteLine("نسخة الأمان السابقة: " + result.SafetyBackupPath);
                return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("تعذرت الاستعادة: " + ex.Message);
                return 6;
            }
            finally
            {
                password = string.Empty;
            }
        }

        private static string ReadSecret()
        {
            var value = new System.Text.StringBuilder();
            while (true)
            {
                var key = Console.ReadKey(true);
                if (key.Key == ConsoleKey.Enter) break;
                if (key.Key == ConsoleKey.Backspace)
                {
                    if (value.Length > 0) value.Length--;
                    continue;
                }
                if (!char.IsControl(key.KeyChar)) value.Append(key.KeyChar);
            }
            Console.WriteLine();
            return value.ToString();
        }
    }
}
