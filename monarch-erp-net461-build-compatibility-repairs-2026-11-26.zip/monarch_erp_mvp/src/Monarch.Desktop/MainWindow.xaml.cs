using Monarch.Core.Accounting;
using Monarch.Core.Backup;
using Monarch.Core.Security;
using Monarch.Core.Organizations;
using Monarch.Core.Commercial;
using Monarch.Core.Autonomy;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;

namespace Monarch.Desktop;

public sealed class PurchaseReceiptLineEntry
{
    public Guid Id { get; init; }
    public string Item { get; init; } = string.Empty;
    public decimal Approved { get; init; }
    public decimal Received { get; init; }
    public decimal Remaining { get; init; }
    public long UnitCostMinor { get; init; }
    public int TaxRateBasisPoints { get; init; }
    public decimal ReceiveNow { get; set; }
}

public sealed class SupplierInvoiceLineEntry
{
    public Guid Id { get; init; }
    public string Receipt { get; init; } = string.Empty;
    public string Item { get; init; } = string.Empty;
    public decimal Received { get; init; }
    public decimal Invoiced { get; init; }
    public decimal Available { get; init; }
    public long UnitPriceMinor { get; init; }
    public int TaxRateBasisPoints { get; init; }
    public decimal InvoiceNow { get; set; }
}

public partial class MainWindow : Window
{
    private TenantAccountingSession _ledgerSession;
    private CompanyDirectoryStore _directory;
    private TenantLedgerStore _tenantStore;
    private IdentityStore _identity;
    private UserSession _session;
    private readonly string _databasePath;
    private readonly DataGrid _accountsGrid = new();
    private readonly DataGrid _journalsGrid = new();
    private readonly DataGrid _trialGrid = new();
    private readonly DataGrid _inventoryLineageGrid = new();
    private readonly DataGrid _masterItemsGrid = new();
    private readonly DataGrid _masterWarehousesGrid = new();
    private readonly DataGrid _itemGroupsGrid = new();
    private readonly DataGrid _unitsGrid = new();
    private readonly DataGrid _purchaseOrdersGrid = new();
    private readonly DataGrid _purchaseReceiptableLinesGrid = new();
    private readonly DataGrid _purchaseReceiptsGrid = new();
    private readonly DataGrid _supplierInvoiceLinesGrid = new();
    private readonly DataGrid _supplierInvoicesGrid = new();
    private readonly DataGrid _supplierPayablesGrid = new();
    private readonly DataGrid _supplierPayablesAgingGrid = new();
    private readonly DataGrid _supplierApAlertsGrid = new();
    private readonly TextBlock _supplierApAlertsStatus = new();
    private readonly DataGrid _supplierApInboxGrid = new();
    private readonly TextBlock _supplierApInboxStatus = new();
    private readonly DataGrid _supplierApDeadLettersGrid = new();
    private readonly TextBlock _supplierApDeadLettersStatus = new();
    private readonly ObservableCollection<SupplierPayablesOperationalAlert> _supplierApAlerts = new();
    private readonly DataGrid _procurementApprovalGrid = new();
    private readonly DataGrid _procurementApprovalIntelligenceGrid = new();
    private readonly DataGrid _procurementNotificationsGrid = new();
    private readonly DataGrid _procurementDecisionTimelineGrid = new();
    private readonly DataGrid _procurementAnalyticsSuppliersGrid = new();
    private readonly DataGrid _procurementAnalyticsConsumptionGrid = new();
    private readonly DataGrid _procurementSupplierItemGrid = new();
    private readonly DataGrid _procurementSupplierTrendsGrid = new();
    private readonly DataGrid _procurementForecastHistoryGrid = new();
    private readonly DatePicker _procurementAnalyticsFrom = new() { Width = 140 };
    private readonly DatePicker _procurementAnalyticsTo = new() { Width = 140 };
    private readonly TextBlock _procurementAnalyticsSummary = new();
    private readonly ComboBox _payablesSupplier = new() { MinWidth = 240 };
    private readonly TextBox _supplierPaymentNumber = new() { Width = 130 };
    private readonly TextBox _supplierPaymentAccount = new() { Width = 130 };
    private readonly TextBox _supplierPaymentAmount = new() { Width = 130 };
    private readonly ComboBox _supplierPaymentMethod = new() { Width = 110 };
    private readonly DatePicker _supplierPaymentDate = new() { Width = 130 };
    private readonly DatePicker _payablesAgingDate = new() { Width = 130 };
    private readonly TextBox _supplierInvoiceNumber = new() { Width = 150 };
    private readonly DatePicker _supplierInvoiceDate = new() { Width = 130 };
    private readonly TextBox _purchaseReceiptNumber = new() { Width = 150 };
    private readonly TextBox _purchaseReceiptQuantity = new() { Width = 100, Text = "1" };
    private readonly ComboBox _purchaseSupplier = new() { MinWidth = 220 };
    private readonly ComboBox _purchaseWarehouse = new() { MinWidth = 220 };
    private readonly ComboBox _purchaseItem = new() { MinWidth = 220 };
    private readonly TextBox _purchaseOrderNumber = new() { Width = 150 };
    private readonly TextBox _purchaseQuantity = new() { Width = 100, Text = "1" };
    private readonly TextBox _purchaseUnitCost = new() { Width = 110, Text = "0" };
    private readonly TextBox _purchaseTaxRate = new() { Width = 90, Text = "0" };
    private readonly TextBox _purchaseCurrency = new() { Width = 75, Text = "SAR" };
    private readonly TextBox _purchaseCurrencyScale = new() { Width = 55, Text = "2" };
    private readonly TextBlock _purchaseSummary = new();
    private readonly TextBlock _masterDataSummary = new();
    private readonly TextBlock _schemaUpgradeSummary = new();
    private CommercialSchemaUpgradePlan _pendingSchemaUpgradePlan;
    private readonly DatePicker _inventoryAuditDate = new();
    private readonly TextBlock _inventoryAuditSummary = new();
    private readonly TextBlock _status = new();
    private readonly DataGrid _journalLinesGrid = new();
    private readonly ObservableCollection<JournalLineDraftRow> _journalLines = new();
    private readonly TextBox _journalNumber = new();
    private readonly TextBox _journalDescription = new();
    private readonly DatePicker _journalDate = new();
    private readonly TextBox _accountCode = new();
    private readonly TextBox _accountName = new();
    private readonly ComboBox _accountType = new();
    private readonly DataGrid _usersGrid = new();
    private readonly TextBox _newUsername = new();
    private readonly TextBox _newDisplayName = new();
    private readonly PasswordBox _newPassword = new();
    private readonly ComboBox _newRole = new();
    private readonly ComboBox _editUserRole = new() { MinWidth = 135 };
    private readonly PasswordBox _backupPassword = new();
    private readonly DataGrid _backupsGrid = new();
    private readonly string _backupDirectory;
    private readonly TextBox _companyCode = new();
    private readonly TextBox _companyLegalName = new();
    private readonly TextBox _companyDisplayName = new();
    private readonly TextBox _companyCountry = new() { Text = "SA" };
    private readonly TextBox _companyCurrency = new() { Text = "SAR" };
    private readonly TextBox _companyTimeZone = new() { Text = "Asia/Riyadh" };
    private readonly ComboBox _adminCompanies = new() { MinWidth = 220 };
    private readonly TextBox _branchCode = new();
    private readonly TextBox _branchName = new();
    private readonly ComboBox _accessUsers = new() { MinWidth = 180 };
    private readonly ComboBox _accessCompanies = new() { MinWidth = 220 };
    private readonly ComboBox _accessBranches = new() { MinWidth = 220 };
    private readonly ComboBox _accessRole = new() { MinWidth = 150 };

    public MainWindow()
    {
        InitializeComponent();
        var dataDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MONARCH", "Data");
        Directory.CreateDirectory(dataDirectory);
        _databasePath = Path.Combine(dataDirectory, "monarch-ledger.db");
        _backupDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MONARCH", "Backups");
        Directory.CreateDirectory(_backupDirectory);
        try
        {
            // Bootstrap the preserved legacy schema only. Live accounting reads/writes below
            // must use TenantAccountingSession -> TenantLedgerStore, never this legacy adapter.
            new SqliteLedgerStore(_databasePath).Initialize();
            _identity = new IdentityStore(_databasePath);
            _identity.Initialize();
            _directory = new CompanyDirectoryStore(_databasePath);
            _directory.Initialize();
            _tenantStore = new TenantLedgerStore(_databasePath);
            _tenantStore.Initialize();
            _session = SecurityGateWindow.Run(_identity);
            if (_session == null) { Close(); return; }
            var defaultCompany = Guid.Parse("00000000-0000-0000-0000-000000000001");
            if (!_directory.HasCompanyMembership(_session.UserId) &&
                string.Equals(_session.RoleCode, "Administrator", StringComparison.OrdinalIgnoreCase))
            {
                _directory.GrantCompanyAccess(_session.UserId, defaultCompany, "Administrator", _session.UserId);
            }
            // Fail closed before displaying any tenant/company selector when legacy balances
            // exist but the verified migration marker for the default company is absent.
            if (_directory.HasLegacyLedgerData() && !_directory.HasCompletedLegacyMigration(defaultCompany))
            {
                MessageBox.Show("توجد بيانات محاسبية قديمة لم تُنقل بعد إلى دفتر المنشآت. أوقف البرنامج وشغّل أداة الترحيل من مجلد المشروع.\n\nأولاً: python tools\\migrate_legacy_ledger.py --database \"" + _databasePath + "\" --company-id 00000000-0000-0000-0000-000000000001 --branch-id 00000000-0000-0000-0000-000000000002 --dry-run\nثم أعد الأمر دون --dry-run مع تعيين MONARCH_BACKUP_PASSPHRASE لإنشاء نسخة مشفرة قبل الترحيل.\nلم تُحذف أو تُعدّل البيانات القديمة.", "يلزم ترحيل آمن للبيانات", MessageBoxButton.OK, MessageBoxImage.Warning);
                Close(); return;
            }
            if (TenantAccountingSession.GetAvailableCompanies(_directory, _session).Count == 0)
            {
                MessageBox.Show("لا توجد منشأة مرتبطة بحسابك. اطلب من مدير النظام منحك صلاحية على منشأة وفرع.", "لا توجد صلاحيات منشآت", MessageBoxButton.OK, MessageBoxImage.Warning);
                Close(); return;
            }
            // Only authorized active companies/branches are selectable. Open rechecks access
            // at the ledger boundary before any accounting UI is constructed.
            var selector = new TenantContextWindow(_directory, _session);
            if (selector.ShowDialog() != true) { Close(); return; }
            _ledgerSession = TenantAccountingSession.Open(_directory, _tenantStore, _session, selector.SelectedCompanyId, selector.SelectedBranchId);
            SeedStarterAccounts();
            BuildInterface();
            RefreshAll();
        }
        catch (Exception ex)
        {
            MessageBox.Show("تعذر تهيئة MONARCH:\n" + ex.Message, "خطأ في بدء التشغيل", MessageBoxButton.OK, MessageBoxImage.Error);
            Close();
        }
    }

    private void BuildInterface()
    {
        var root = new DockPanel();
        Content = root;
        var header = new Border { Background = Brush("#0B1F3A"), Padding = new Thickness(22, 14, 22, 14) };
        DockPanel.SetDock(header, Dock.Top);
        var headerStack = new StackPanel();
        headerStack.Children.Add(new TextBlock { Text = "♛ MONARCH ERP", Foreground = Brushes.White, FontSize = 23, FontWeight = FontWeights.Bold });
        headerStack.Children.Add(new TextBlock { Text = "النظام الإداري والمحاسبي | " + _session.DisplayName + " | " + _session.RoleCode + " | " + _ledgerSession.CompanyName + " / " + _ledgerSession.BranchName + " | يعمل محلياً دون إنترنت", Foreground = Brush("#D7A943"), FontSize = 12, Margin = new Thickness(1, 3, 0, 0) });
        header.Child = headerStack;
        root.Children.Add(header);

        var footer = new Border { Background = Brushes.White, Padding = new Thickness(12, 7, 12, 7), BorderBrush = Brush("#DCE3EC"), BorderThickness = new Thickness(0, 1, 0, 0) };
        DockPanel.SetDock(footer, Dock.Bottom);
        _status.Foreground = Brush("#52647B");
        _status.Text = "قاعدة البيانات المحلية: " + _databasePath;
        footer.Child = _status;
        root.Children.Add(footer);

        var tabs = new TabControl { Margin = new Thickness(16) };
        tabs.Items.Add(BuildDashboardTab());
        tabs.Items.Add(BuildAccountsTab());
        tabs.Items.Add(BuildJournalTab());
        tabs.Items.Add(BuildReportsTab());
        if (_session.HasPermission("inventory.read"))
            tabs.Items.Add(BuildMasterDataTab());
        if (_session.HasPermission("reports.read"))
            tabs.Items.Add(BuildInventoryAuditTab());
        if (_session.HasPermission("commercial.purchases.manage") && _session.HasPermission("reports.read")) tabs.Items.Add(BuildPurchaseOrdersTab());
        if (_session.HasPermission("commercial.purchases.approve"))
        {
            tabs.Items.Add(BuildProcurementApprovalTab());
            tabs.Items.Add(BuildProcurementNotificationCenterTab());
        }
        if (_session.HasPermission("reports.read")) tabs.Items.Add(BuildSupplierPayablesTab());
        if (_session.HasPermission("reports.read")) tabs.Items.Add(BuildSupplierApAlertsTab());
        if (_session.HasPermission("reports.read")) tabs.Items.Add(BuildProcurementAnalyticsDashboardTab());
        if (_session.HasPermission("reports.read")) tabs.Items.Add(BuildProcurementExportAuditTab());
        if (_session.HasPermission("users.manage"))
        {
            tabs.Items.Add(BuildUsersTab());
            tabs.Items.Add(BuildTenantAuditLogTab());
        }
        if (_session.HasPermission("users.manage") && string.Equals(_session.RoleCode, "Administrator", StringComparison.OrdinalIgnoreCase))
        {
            tabs.Items.Add(BuildDirectoryAdminTab());
            tabs.Items.Add(BuildCommercialSchemaUpgradeTab());
        }
        if (_session.HasPermission("backups.manage")) tabs.Items.Add(BuildBackupsTab());
        root.Children.Add(tabs);
    }

    private TabItem BuildDashboardTab()
    {
        var panel = new StackPanel { Margin = new Thickness(20) };
        panel.Children.Add(Heading("لوحة التحكم"));
        panel.Children.Add(new TextBlock { Text = "نسخة تشغيل محلية أولية. الأرقام التالية تُقرأ من قاعدة البيانات وليست بيانات عرض تجريبية.", Foreground = Brush("#65758B"), Margin = new Thickness(0, 6, 0, 18) });
        var summary = new TextBlock { Name = "SummaryText", FontSize = 17, TextWrapping = TextWrapping.Wrap, LineHeight = 34 };
        panel.Children.Add(summary);
        var refresh = Button("تحديث البيانات");
        refresh.Click += (_, __) => { RefreshAll(); summary.Text = BuildSummary(); };
        panel.Children.Add(refresh);
        panel.Loaded += (_, __) => summary.Text = BuildSummary();
        return new TabItem { Header = "الرئيسية", Content = Scroll(panel) };
    }

    private TabItem BuildAccountsTab()
    {
        var panel = new DockPanel { Margin = new Thickness(18) };
        var form = new WrapPanel { Margin = new Thickness(0, 0, 0, 12), VerticalAlignment = VerticalAlignment.Center };
        form.Children.Add(Labelled("رمز الحساب", _accountCode, 120));
        form.Children.Add(Labelled("اسم الحساب", _accountName, 220));
        foreach (AccountType type in Enum.GetValues(typeof(AccountType)))
            _accountType.Items.Add(new ComboBoxItem { Content = ArabicType(type), Tag = type });
        _accountType.SelectedIndex = 0;
        form.Children.Add(Labelled("نوع الحساب", _accountType, 150));
        var add = Button("إضافة حساب");
        add.IsEnabled = _session.HasPermission("accounts.manage") && !string.Equals(_ledgerSession.CompanyRoleCode, "Viewer", StringComparison.OrdinalIgnoreCase);
        add.Click += AddAccount_Click;
        form.Children.Add(add);
        DockPanel.SetDock(form, Dock.Top);
        panel.Children.Add(form);
        ConfigureGrid(_accountsGrid);
        panel.Children.Add(_accountsGrid);
        return new TabItem { Header = "دليل الحسابات", Content = panel };
    }

    private TabItem BuildJournalTab()
    {
        var panel = new DockPanel { Margin = new Thickness(18) };
        var form = new StackPanel { Margin = new Thickness(0, 0, 0, 12) };
        _journalDate.SelectedDate = DateTime.Today;
        form.Children.Add(Heading("إنشاء قيد يومية مبسط"));
        var row1 = new WrapPanel();
        row1.Children.Add(Labelled("رقم القيد", _journalNumber, 130));
        row1.Children.Add(Labelled("التاريخ", _journalDate, 150));
        row1.Children.Add(Labelled("البيان", _journalDescription, 280));
        form.Children.Add(row1);
        ConfigureJournalLinesGrid();
        _journalLinesGrid.Height = 190;
        _journalLinesGrid.Margin = new Thickness(2, 8, 2, 8);
        form.Children.Add(_journalLinesGrid);
        var create = Button("حفظ القيد كمسودة");
        create.IsEnabled = _session.HasPermission("journals.create") && !string.Equals(_ledgerSession.CompanyRoleCode, "Viewer", StringComparison.OrdinalIgnoreCase);
        create.Click += CreateJournal_Click;
        form.Children.Add(create);
        var post = Button("ترحيل القيد المحدد");
        post.IsEnabled = _session.HasPermission("journals.post") && !string.Equals(_ledgerSession.CompanyRoleCode, "Viewer", StringComparison.OrdinalIgnoreCase);
        post.HorizontalAlignment = HorizontalAlignment.Left;
        post.Click += (_, __) => PostSelectedJournal();
        form.Children.Add(post);
        form.Children.Add(new TextBlock { Text = "أضف سطرين أو أكثر. يجب أن يتساوى إجمالي المدين والدائن، وتُحفظ المبالغ بوحدات العملة الصغرى.", Foreground = Brush("#65758B"), Margin = new Thickness(4, 6, 4, 0) });
        DockPanel.SetDock(form, Dock.Top);
        panel.Children.Add(form);
        ConfigureGrid(_journalsGrid);
        panel.Children.Add(_journalsGrid);
        return new TabItem { Header = "القيود اليومية", Content = panel };
    }

    private TabItem BuildReportsTab()
    {
        var panel = new DockPanel { Margin = new Thickness(18) };
        var top = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 12) };
        top.Children.Add(Heading("ميزان المراجعة"));
        var refresh = Button("تحديث التقرير");
        refresh.Click += (_, __) => RefreshTrialBalance();
        top.Children.Add(refresh);
        DockPanel.SetDock(top, Dock.Top);
        panel.Children.Add(top);
        ConfigureGrid(_trialGrid);
        panel.Children.Add(_trialGrid);
        return new TabItem { Header = "التقارير", Content = panel };
    }

    private TabItem BuildMasterDataTab()
    {
        var panel = new DockPanel { Margin = new Thickness(18) };
        var top = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
        top.Children.Add(Heading("دليل الأصناف والمستودعات"));
        top.Children.Add(new TextBlock
        {
            Text = "إدارة الأصناف على مستوى المنشأة والمستودعات ضمن الفرع الحالي. تتطلب عمليات الكتابة صلاحيات مستقلة وتُسجل في سجل التدقيق. لا تُنشأ جداول الوحدة التجارية ولا تُنفذ ترحيلات تلقائية من هذه الشاشة.",
            TextWrapping = TextWrapping.Wrap, Foreground = Brush("#65758B"), Margin = new Thickness(3, 0, 3, 8)
        });
        var actions = new WrapPanel { Margin = new Thickness(0, 2, 0, 4) };
        var refresh = Button("تحديث الدليل");
        refresh.Click += (_, __) => LoadMasterData();
        actions.Children.Add(refresh);
        if (_session.HasPermission("inventory.items.manage"))
        {
            var addItem = Button("إضافة صنف"); addItem.Margin = new Thickness(6, 0, 0, 0);
            addItem.Click += (_, __) => CreateInventoryItem(); actions.Children.Add(addItem);
            var editItem = Button("تعديل الصنف المحدد"); editItem.Margin = new Thickness(6, 0, 0, 0);
            editItem.Click += (_, __) => EditSelectedInventoryItem(); actions.Children.Add(editItem);
            var disableItem = Button("تعطيل الصنف المحدد"); disableItem.Margin = new Thickness(6, 0, 0, 0);
            disableItem.Click += (_, __) => SetSelectedItemActive(false); actions.Children.Add(disableItem);
            var enableItem = Button("تنشيط الصنف المحدد"); enableItem.Margin = new Thickness(6, 0, 0, 0);
            enableItem.Click += (_, __) => SetSelectedItemActive(true); actions.Children.Add(enableItem);
        }
        if (_session.HasPermission("inventory.warehouses.manage"))
        {
            var addWarehouse = Button("إضافة مستودع للفرع"); addWarehouse.Margin = new Thickness(6, 0, 0, 0);
            addWarehouse.Click += (_, __) => CreateInventoryWarehouse(); actions.Children.Add(addWarehouse);
            var editWarehouse = Button("تعديل المستودع المحدد"); editWarehouse.Margin = new Thickness(6, 0, 0, 0);
            editWarehouse.Click += (_, __) => EditSelectedInventoryWarehouse(); actions.Children.Add(editWarehouse);
            var disableWarehouse = Button("تعطيل المستودع المحدد"); disableWarehouse.Margin = new Thickness(6, 0, 0, 0);
            disableWarehouse.Click += (_, __) => SetSelectedWarehouseActive(false); actions.Children.Add(disableWarehouse);
            var enableWarehouse = Button("تنشيط المستودع المحدد"); enableWarehouse.Margin = new Thickness(6, 0, 0, 0);
            enableWarehouse.Click += (_, __) => SetSelectedWarehouseActive(true); actions.Children.Add(enableWarehouse);
        }
        top.Children.Add(actions);
        _masterDataSummary.Margin = new Thickness(4, 8, 4, 8);
        _masterDataSummary.TextWrapping = TextWrapping.Wrap;
        _masterDataSummary.Foreground = Brush("#173B68");
        top.Children.Add(_masterDataSummary);
        DockPanel.SetDock(top, Dock.Top);
        panel.Children.Add(top);

        var tabs = new TabControl();
        ConfigureGrid(_masterItemsGrid);
        ConfigureGrid(_masterWarehousesGrid);
        tabs.Items.Add(new TabItem { Header = "الأصناف", Content = _masterItemsGrid });
        tabs.Items.Add(new TabItem { Header = "المستودعات", Content = _masterWarehousesGrid });
        if (_session.HasPermission("inventory.read"))
        {
            ConfigureGrid(_itemGroupsGrid);
            ConfigureGrid(_unitsGrid);
            tabs.Items.Add(new TabItem { Header = "مجموعات الأصناف", Content = BuildItemGroupsPanel() });
            tabs.Items.Add(new TabItem { Header = "وحدات القياس", Content = BuildUnitsPanel() });
        }
        panel.Children.Add(tabs);
        panel.Loaded += (_, __) => LoadMasterData();
        return new TabItem { Header = "دليل المخزون", Content = panel };
    }

    private UIElement BuildItemGroupsPanel()
    {
        var panel = new DockPanel { Margin = new Thickness(8) };
        var actions = new WrapPanel { Margin = new Thickness(0, 0, 0, 8) };
        if (_session.HasPermission("inventory.items.manage"))
        {
            var add = Button("إضافة مجموعة"); add.Click += (_, __) => CreateItemGroup(); actions.Children.Add(add);
            var edit = Button("تعديل المجموعة المحددة"); edit.Margin = new Thickness(6, 0, 0, 0); edit.Click += (_, __) => EditItemGroup(); actions.Children.Add(edit);
            var deactivate = Button("تعطيل المجموعة"); deactivate.Margin = new Thickness(6, 0, 0, 0); deactivate.Click += (_, __) => SetItemGroupActive(false); actions.Children.Add(deactivate);
            var activate = Button("تنشيط المجموعة"); activate.Margin = new Thickness(6, 0, 0, 0); activate.Click += (_, __) => SetItemGroupActive(true); actions.Children.Add(activate);
        }
        DockPanel.SetDock(actions, Dock.Top); panel.Children.Add(actions); panel.Children.Add(_itemGroupsGrid); return panel;
    }

    private UIElement BuildUnitsPanel()
    {
        var panel = new DockPanel { Margin = new Thickness(8) };
        var actions = new WrapPanel { Margin = new Thickness(0, 0, 0, 8) };
        if (_session.HasPermission("inventory.items.manage"))
        {
            var add = Button("إضافة وحدة قياس"); add.Click += (_, __) => CreateUnit(); actions.Children.Add(add);
            var edit = Button("تعديل الوحدة المحددة"); edit.Margin = new Thickness(6, 0, 0, 0); edit.Click += (_, __) => EditUnit(); actions.Children.Add(edit);
        }
        DockPanel.SetDock(actions, Dock.Top); panel.Children.Add(actions); panel.Children.Add(_unitsGrid); return panel;
    }

    private void CreateItemGroup()
    {
        if (!_session.HasPermission("inventory.items.manage")) { ShowError(new UnauthorizedAccessException("لا تملك صلاحية إدارة مجموعات الأصناف.")); return; }
        try
        {
            var store = new InventoryMasterDataStore(_databasePath);
            var groups = store.GetItemGroups(_session.UserId, _ledgerSession.CompanyId);
            var code = PromptText("رمز المجموعة", "إضافة مجموعة أصناف", ""); if (code == null) return;
            var name = PromptText("اسم المجموعة", "إضافة مجموعة أصناف", ""); if (name == null) return;
            var parentText = PromptText("معرف المجموعة الأم (اتركه فارغاً للمجموعة الرئيسية):\n" + string.Join("\n", groups.Select(x => x.Code + " — " + x.Name + " — " + x.Id)), "المجموعة الأم", ""); if (parentText == null) return;
            Guid? parentId = null;
            if (!string.IsNullOrWhiteSpace(parentText)) { if (!Guid.TryParse(parentText, out var parsed) || !groups.Any(x => x.Id == parsed && x.IsActive)) throw new ArgumentException("المجموعة الأم غير صحيحة أو غير نشطة."); parentId = parsed; }
            store.CreateItemGroup(_session.UserId, _ledgerSession.CompanyId, new ItemGroup(Guid.NewGuid(), parentId, code, name));
            LoadMasterData(); SetStatus("تم إنشاء مجموعة الأصناف.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void EditItemGroup()
    {
        if (!_session.HasPermission("inventory.items.manage")) { ShowError(new UnauthorizedAccessException("لا تملك صلاحية إدارة مجموعات الأصناف.")); return; }
        try
        {
            var row = _itemGroupsGrid.SelectedItem ?? throw new InvalidOperationException("حدد مجموعة من الجدول أولاً.");
            var id = SelectedGridGuid(_itemGroupsGrid);
            var code = PromptText("رمز المجموعة", "تعديل مجموعة", SelectedGridText(row, "الرمز")); if (code == null) return;
            var name = PromptText("اسم المجموعة", "تعديل مجموعة", SelectedGridText(row, "الاسم")); if (name == null) return;
            var store = new InventoryMasterDataStore(_databasePath);
            var groups = store.GetItemGroups(_session.UserId, _ledgerSession.CompanyId);
            var parentText = PromptText("معرف المجموعة الأم أو فارغ للرئيسية:\n" + string.Join("\n", groups.Where(x => x.Id != id && x.IsActive).Select(x => x.Code + " — " + x.Name + " — " + x.Id)), "المجموعة الأم", SelectedGridText(row, "المجموعة_الأم") == "—" ? "" : SelectedGridText(row, "المجموعة_الأم")); if (parentText == null) return;
            Guid? parentId = null;
            if (!string.IsNullOrWhiteSpace(parentText)) { if (!Guid.TryParse(parentText, out var parsed) || !groups.Any(x => x.Id == parsed && x.IsActive && x.Id != id)) throw new ArgumentException("المجموعة الأم غير صحيحة."); parentId = parsed; }
            store.UpdateItemGroup(_session.UserId, _ledgerSession.CompanyId, new ItemGroup(id, parentId, code, name, true));
            LoadMasterData(); SetStatus("تم تعديل مجموعة الأصناف.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void SetItemGroupActive(bool active)
    {
        try
        {
            if (!_session.HasPermission("inventory.items.manage")) throw new UnauthorizedAccessException("لا تملك صلاحية إدارة مجموعات الأصناف.");
            var id = SelectedGridGuid(_itemGroupsGrid); if (id == Guid.Empty) throw new InvalidOperationException("حدد مجموعة من الجدول أولاً.");
            if (MessageBox.Show("سيتم تغيير حالة المجموعة دون حذفها. لا يمكن تعطيل مجموعة مرتبطة بأصناف أو مجموعات فرعية نشطة. متابعة؟", "تأكيد", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
            new InventoryMasterDataStore(_databasePath).SetItemGroupActive(_session.UserId, _ledgerSession.CompanyId, id, active);
            LoadMasterData();
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void CreateUnit()
    {
        if (!_session.HasPermission("inventory.items.manage")) { ShowError(new UnauthorizedAccessException("لا تملك صلاحية إدارة وحدات القياس.")); return; }
        try
        {
            var code = PromptText("رمز الوحدة", "إضافة وحدة قياس", ""); if (code == null) return;
            var name = PromptText("اسم الوحدة", "إضافة وحدة قياس", ""); if (name == null) return;
            var placesText = PromptText("عدد المنازل العشرية (0 إلى 6)", "دقة الوحدة", "0"); if (placesText == null) return;
            if (!int.TryParse(placesText, out var places) || places < 0 || places > 6) throw new ArgumentException("دقة الوحدة يجب أن تكون من 0 إلى 6.");
            new InventoryMasterDataStore(_databasePath).CreateUnit(_session.UserId, _ledgerSession.CompanyId, new UnitOfMeasure(Guid.NewGuid(), code, name, places));
            LoadMasterData(); SetStatus("تم إنشاء وحدة القياس.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void EditUnit()
    {
        if (!_session.HasPermission("inventory.items.manage")) { ShowError(new UnauthorizedAccessException("لا تملك صلاحية إدارة وحدات القياس.")); return; }
        try
        {
            var row = _unitsGrid.SelectedItem ?? throw new InvalidOperationException("حدد وحدة قياس من الجدول أولاً.");
            var id = SelectedGridGuid(_unitsGrid);
            var code = PromptText("رمز الوحدة", "تعديل وحدة قياس", SelectedGridText(row, "الرمز")); if (code == null) return;
            var name = PromptText("اسم الوحدة", "تعديل وحدة قياس", SelectedGridText(row, "الاسم")); if (name == null) return;
            var placesText = PromptText("عدد المنازل العشرية (لا يمكن تغييرها إذا كانت الوحدة مستخدمة)", "دقة الوحدة", SelectedGridText(row, "المنازل_العشرية")); if (placesText == null) return;
            if (!int.TryParse(placesText, out var places) || places < 0 || places > 6) throw new ArgumentException("دقة الوحدة يجب أن تكون من 0 إلى 6.");
            new InventoryMasterDataStore(_databasePath).UpdateUnit(_session.UserId, _ledgerSession.CompanyId, new UnitOfMeasure(id, code, name, places));
            LoadMasterData(); SetStatus("تم تعديل وحدة القياس.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private TabItem BuildPurchaseOrdersTab()
    {
        var panel = new DockPanel { Margin = new Thickness(18) };
        var form = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
        form.Children.Add(Heading("أوامر الشراء"));
        form.Children.Add(new TextBlock { Text = "إنشاء مسودة أمر شراء واعتمادها أو إلغاؤها. هذه المرحلة لا تنشئ استلاماً مخزنياً أو فاتورة مورد أو قيداً محاسبياً.", TextWrapping = TextWrapping.Wrap, Foreground = Brush("#8A4B08"), Margin = new Thickness(0, 4, 0, 10) });
        var row1 = new WrapPanel();
        row1.Children.Add(FormLabel("رقم الأمر")); row1.Children.Add(_purchaseOrderNumber);
        row1.Children.Add(FormLabel("المورد")); row1.Children.Add(_purchaseSupplier);
        row1.Children.Add(FormLabel("المستودع")); row1.Children.Add(_purchaseWarehouse);
        form.Children.Add(row1);
        var row2 = new WrapPanel { Margin = new Thickness(0, 8, 0, 0) };
        row2.Children.Add(FormLabel("الصنف")); row2.Children.Add(_purchaseItem);
        row2.Children.Add(FormLabel("الكمية")); row2.Children.Add(_purchaseQuantity);
        row2.Children.Add(FormLabel("تكلفة الوحدة (أصغر وحدة نقدية)")); row2.Children.Add(_purchaseUnitCost);
        row2.Children.Add(FormLabel("الضريبة bps")); row2.Children.Add(_purchaseTaxRate);
        form.Children.Add(row2);
        var row3 = new WrapPanel { Margin = new Thickness(0, 8, 0, 0) };
        row3.Children.Add(FormLabel("العملة")); row3.Children.Add(_purchaseCurrency);
        row3.Children.Add(FormLabel("دقة العملة")); row3.Children.Add(_purchaseCurrencyScale);
        var create = Button("إنشاء مسودة"); create.Click += (_, __) => CreatePurchaseOrderDraft(); row3.Children.Add(create);
        var refresh = Button("تحديث القائمة"); refresh.Click += (_, __) => LoadPurchaseOrders(); row3.Children.Add(refresh);
        var approve = Button("اعتماد المحدد"); approve.Click += (_, __) => ChangePurchaseOrderState(true); row3.Children.Add(approve);
        var cancel = Button("إلغاء المحدد"); cancel.Click += (_, __) => ChangePurchaseOrderState(false); row3.Children.Add(cancel);
        form.Children.Add(row3);
        _purchaseSummary.TextWrapping = TextWrapping.Wrap; _purchaseSummary.Margin = new Thickness(4, 8, 4, 8); _purchaseSummary.Foreground = Brush("#173B68");
        form.Children.Add(_purchaseSummary);
        DockPanel.SetDock(form, Dock.Top); panel.Children.Add(form);
        _purchaseOrdersGrid.AutoGenerateColumns = true; _purchaseOrdersGrid.IsReadOnly = true;
        _purchaseOrdersGrid.SelectionChanged += (_, __) => { LoadPurchaseReceiptLines(); LoadPurchaseReceipts(); LoadSupplierInvoiceLines(); LoadSupplierInvoices(); };
        panel.Children.Add(_purchaseOrdersGrid);
        var receiptPanel = new StackPanel { Margin = new Thickness(0, 12, 0, 0) };
        receiptPanel.Children.Add(Heading("الاستلام المخزني الجزئي والكامل"));
        receiptPanel.Children.Add(new TextBlock { Text = "حدد أمراً معتمداً، ثم أدخل كمية الاستلام لكل بند في عمود (استلام الآن). اترك البنود غير المستلمة صفراً؛ يمكن ترحيل عدة بنود في سند واحد. ينفذ Core الاستلام وحركة المخزون والتكلفة وOutbox في معاملة واحدة.", TextWrapping = TextWrapping.Wrap, Foreground = Brush("#8A4B08"), Margin = new Thickness(2, 4, 2, 8) });
        var receiptRow = new WrapPanel();
        receiptRow.Children.Add(FormLabel("رقم سند الاستلام")); receiptRow.Children.Add(_purchaseReceiptNumber);
        var loadLines = Button("تحميل البنود المتبقية"); loadLines.Click += (_, __) => LoadPurchaseReceiptLines(); receiptRow.Children.Add(loadLines);
        var postReceipt = Button("ترحيل الاستلام المحدد"); postReceipt.Click += (_, __) => PostPurchaseReceipt(); receiptRow.Children.Add(postReceipt);
        var loadHistory = Button("تحديث سجل الاستلام"); loadHistory.Click += (_, __) => LoadPurchaseReceipts(); receiptRow.Children.Add(loadHistory);
        receiptPanel.Children.Add(receiptRow);
        _purchaseReceiptableLinesGrid.AutoGenerateColumns = true; _purchaseReceiptableLinesGrid.IsReadOnly = false; _purchaseReceiptableLinesGrid.CanUserAddRows = false; _purchaseReceiptableLinesGrid.Height = 160;
        receiptPanel.Children.Add(_purchaseReceiptableLinesGrid);
        _purchaseReceiptsGrid.AutoGenerateColumns = true; _purchaseReceiptsGrid.IsReadOnly = true; _purchaseReceiptsGrid.Height = 100;
        receiptPanel.Children.Add(new TextBlock { Text = "سجل الاستلامات", FontWeight = FontWeights.Bold, Margin = new Thickness(2, 6, 2, 3) });
        receiptPanel.Children.Add(_purchaseReceiptsGrid);

        receiptPanel.Children.Add(Heading("فواتير المورد — المطابقة الثلاثية"));
        receiptPanel.Children.Add(new TextBlock { Text = "اختر أمر الشراء، ثم حمّل بنود سندات الاستلام المرحّلة. أدخل الكمية المراد فوترتها؛ السعر والضريبة يُستمدان من أمر الشراء، ولا تُقبل كمية تتجاوز المتبقي غير المفوتر. أنشئ المسودة ثم حددها لترحيلها.", TextWrapping = TextWrapping.Wrap, Foreground = Brush("#8A4B08"), Margin = new Thickness(2, 4, 2, 8) });
        _supplierInvoiceDate.SelectedDate = DateTime.Today;
        var invoiceRow = new WrapPanel();
        invoiceRow.Children.Add(FormLabel("رقم فاتورة المورد")); invoiceRow.Children.Add(_supplierInvoiceNumber);
        invoiceRow.Children.Add(FormLabel("تاريخ الفاتورة")); invoiceRow.Children.Add(_supplierInvoiceDate);
        var loadInvoiceLines = Button("تحميل البنود غير المفوترة"); loadInvoiceLines.Click += (_, __) => LoadSupplierInvoiceLines(); invoiceRow.Children.Add(loadInvoiceLines);
        var createInvoice = Button("إنشاء مسودة فاتورة"); createInvoice.Click += (_, __) => CreateSupplierInvoiceDraft(); invoiceRow.Children.Add(createInvoice);
        var refreshInvoices = Button("تحديث سجل الفواتير"); refreshInvoices.Click += (_, __) => LoadSupplierInvoices(); invoiceRow.Children.Add(refreshInvoices);
        var postInvoice = Button("ترحيل الفاتورة المحددة"); postInvoice.Click += (_, __) => PostSupplierInvoice(); invoiceRow.Children.Add(postInvoice);
        receiptPanel.Children.Add(invoiceRow);
        _supplierInvoiceLinesGrid.AutoGenerateColumns = true; _supplierInvoiceLinesGrid.IsReadOnly = false; _supplierInvoiceLinesGrid.CanUserAddRows = false; _supplierInvoiceLinesGrid.Height = 145;
        receiptPanel.Children.Add(_supplierInvoiceLinesGrid);
        _supplierInvoicesGrid.AutoGenerateColumns = true; _supplierInvoicesGrid.IsReadOnly = true; _supplierInvoicesGrid.Height = 100;
        receiptPanel.Children.Add(new TextBlock { Text = "سجل فواتير المورد", FontWeight = FontWeights.Bold, Margin = new Thickness(2, 6, 2, 3) });
        receiptPanel.Children.Add(_supplierInvoicesGrid);
        DockPanel.SetDock(receiptPanel, Dock.Bottom); panel.Children.Insert(1, receiptPanel);
        panel.Loaded += (_, __) => LoadPurchaseOrderLookups();
        return new TabItem { Header = "المشتريات", Content = panel };
    }

    private TabItem BuildProcurementApprovalTab()
    {
        var panel = new DockPanel { Margin = new Thickness(18), LastChildFill = false };
        var header = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
        header.Children.Add(Heading("مركز اعتماد المشتريات"));
        header.Children.Add(new TextBlock { Text = "يعرض المسودات المنتظرة لاعتماد المدير ضمن المنشأة والفرع الحاليين. قرار الاعتماد أو الرفض نهائي ومسجل في سجل التدقيق؛ الاعتماد لا ينشئ استلاماً أو فاتورة أو قيداً محاسبياً.", TextWrapping = TextWrapping.Wrap, Foreground = Brush("#8A4B08"), Margin = new Thickness(2, 4, 2, 8) });
        var actions = new WrapPanel();
        var refresh = Button("تحديث صندوق الاعتماد"); refresh.Click += (_, __) => LoadProcurementApprovals(); actions.Children.Add(refresh);
        var approve = Button("اعتماد المحدد"); approve.Click += (_, __) => DecideProcurementApproval(true); actions.Children.Add(approve);
        var reject = Button("رفض المحدد"); reject.Click += (_, __) => DecideProcurementApproval(false); actions.Children.Add(reject);
        header.Children.Add(actions);
        DockPanel.SetDock(header, Dock.Top); panel.Children.Add(header);
        ConfigureGrid(_procurementApprovalGrid);
        _procurementApprovalGrid.Height = 190;
        DockPanel.SetDock(_procurementApprovalGrid, Dock.Top);
        _procurementApprovalGrid.SelectionChanged += (_, __) => LoadProcurementApprovalIntelligence();
        panel.Children.Add(_procurementApprovalGrid);
        var intelligencePanel = new DockPanel { Margin = new Thickness(0, 10, 0, 0) };
        var intelligenceTitle = Heading("مقارنة الموردين للصنف المحدد — بيانات استرشادية للمدير");
        DockPanel.SetDock(intelligenceTitle, Dock.Top); intelligencePanel.Children.Add(intelligenceTitle);
        ConfigureGrid(_procurementApprovalIntelligenceGrid);
        _procurementApprovalIntelligenceGrid.IsReadOnly = true;
        _procurementApprovalIntelligenceGrid.Height = 180;
        intelligencePanel.Children.Add(_procurementApprovalIntelligenceGrid);
        DockPanel.SetDock(intelligencePanel, Dock.Bottom); panel.Children.Add(intelligencePanel);
        panel.Loaded += (_, __) => LoadProcurementApprovals();
        return new TabItem { Header = "اعتمادات المشتريات", Content = panel };
    }

    private TabItem BuildProcurementNotificationCenterTab()
    {
        var panel = new DockPanel { Margin = new Thickness(18) };
        var header = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
        header.Children.Add(Heading("إشعارات المشتريات وسجل القرارات"));
        header.Children.Add(new TextBlock { Text = "الإشعارات خاصة بالمستخدم الحالي ومقيدة بالمنشأة والفرع. حالة القراءة منفصلة عن حالة تسليم الإشعار، وسجل القرارات للعرض فقط.", TextWrapping = TextWrapping.Wrap, Foreground = Brush("#65758B"), Margin = new Thickness(2, 4, 2, 8) });
        var actions = new WrapPanel();
        var refresh = Button("تحديث الإشعارات والسجل"); refresh.Click += (_, __) => { LoadProcurementNotifications(); LoadProcurementDecisionTimeline(); }; actions.Children.Add(refresh);
        var markRead = Button("تعليم المحدد كمقروء"); markRead.Click += (_, __) => MarkSelectedProcurementNotificationRead(); actions.Children.Add(markRead);
        var markAll = Button("تعليم الكل كمقروء"); markAll.Click += (_, __) => MarkAllProcurementNotificationsRead(); actions.Children.Add(markAll);
        header.Children.Add(actions);
        DockPanel.SetDock(header, Dock.Top); panel.Children.Add(header);
        var content = new Grid();
        content.RowDefinitions.Add(new RowDefinition { Height = new GridLength(2, GridUnitType.Star) });
        content.RowDefinitions.Add(new RowDefinition { Height = new GridLength(12) });
        content.RowDefinitions.Add(new RowDefinition { Height = new GridLength(3, GridUnitType.Star) });
        var inboxPanel = new DockPanel();
        var inboxTitle = Heading("صندوق الإشعارات"); DockPanel.SetDock(inboxTitle, Dock.Top); inboxPanel.Children.Add(inboxTitle);
        ConfigureGrid(_procurementNotificationsGrid); _procurementNotificationsGrid.IsReadOnly = true;
        inboxPanel.Children.Add(_procurementNotificationsGrid);
        Grid.SetRow(inboxPanel, 0); content.Children.Add(inboxPanel);
        var timelinePanel = new DockPanel();
        var timelineTitle = Heading("السجل التاريخي لقرارات المدير — غير قابل للتعديل"); DockPanel.SetDock(timelineTitle, Dock.Top); timelinePanel.Children.Add(timelineTitle);
        ConfigureGrid(_procurementDecisionTimelineGrid); _procurementDecisionTimelineGrid.IsReadOnly = true;
        timelinePanel.Children.Add(_procurementDecisionTimelineGrid);
        Grid.SetRow(timelinePanel, 2); content.Children.Add(timelinePanel);
        panel.Children.Add(content);
        panel.Loaded += (_, __) => { LoadProcurementNotifications(); LoadProcurementDecisionTimeline(); };
        return new TabItem { Header = "الإشعارات والسجل", Content = panel };
    }

    private void LoadProcurementNotifications()
    {
        try
        {
            var store = new ProcurementNotificationCenterStore(_databasePath);
            var rows = store.ListInbox(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId);
            _procurementNotificationsGrid.ItemsSource = rows.Select(x => new
            {
                NotificationId = x.NotificationId,
                الحالة = x.IsRead ? "مقروء" : "غير مقروء",
                النوع = x.EventType,
                العنوان = x.Title,
                التفاصيل = x.Body,
                PurchaseOrderId = x.PurchaseOrderId,
                QueueId = x.QueueId,
                التاريخ = x.CreatedAt.ToLocalTime().ToString("yyyy-MM-dd HH:mm")
            }).ToList();
            SetStatus("صندوق إشعارات المشتريات: " + rows.Count(x => !x.IsRead) + " غير مقروء من " + rows.Count + ".");
        }
        catch (Exception ex) { _procurementNotificationsGrid.ItemsSource = null; ShowError(ex); }
    }

    private void MarkSelectedProcurementNotificationRead()
    {
        try
        {
            var row = _procurementNotificationsGrid.SelectedItem ?? throw new InvalidOperationException("حدد إشعاراً أولاً.");
            var id = Guid.Parse(SelectedGridText(row, "NotificationId"));
            new ProcurementNotificationCenterStore(_databasePath).MarkRead(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, id);
            LoadProcurementNotifications();
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void MarkAllProcurementNotificationsRead()
    {
        try
        {
            var count = new ProcurementNotificationCenterStore(_databasePath).MarkAllRead(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId);
            LoadProcurementNotifications();
            SetStatus("تم تعليم " + count + " إشعاراً كمقروء.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void LoadProcurementDecisionTimeline()
    {
        try
        {
            if (!_session.HasPermission("commercial.purchases.approve")) throw new UnauthorizedAccessException("عرض سجل قرارات المشتريات يتطلب صلاحية الاعتماد.");
            var rows = new ProcurementNotificationCenterStore(_databasePath).ListDecisionTimeline(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId);
            _procurementDecisionTimelineGrid.ItemsSource = rows.Select(x => new
            {
                رقم_الأمر = x.OrderNumber,
                القرار = x.Decision == "Approved" ? "معتمد" : "مرفوض",
                المورد = x.SupplierId,
                العملة = x.CurrencyCode,
                الإجمالي = x.TotalMinor,
                مبرر_التوصية = x.Rationale,
                ملاحظة_المدير = x.DecisionNote,
                DecidedBy = x.DecidedBy,
                التاريخ = x.DecidedAt.ToLocalTime().ToString("yyyy-MM-dd HH:mm")
            }).ToList();
        }
        catch (Exception ex) { _procurementDecisionTimelineGrid.ItemsSource = null; ShowError(ex); }
    }

    private void LoadProcurementApprovals()
    {
        try
        {
            if (!_session.HasPermission("commercial.purchases.approve")) throw new UnauthorizedAccessException("لا تملك صلاحية اعتماد أوامر الشراء.");
            var rows = new ProcurementApprovalQueueStore(_databasePath).ListPending(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId);
            _procurementApprovalGrid.ItemsSource = rows.Select(x => new
            {
                QueueId = x.QueueId,
                PurchaseOrderId = x.PurchaseOrderId,
                رقم_الأمر = x.OrderNumber,
                المورد = x.SupplierName,
                العملة = x.CurrencyCode,
                الإجمالي = x.TotalMinor,
                موعد_التوريد = x.ExpectedAt?.ToString("yyyy-MM-dd") ?? "غير محدد",
                مبرر_التوصية = x.Rationale,
                تاريخ_الإضافة = x.CreatedAt.ToLocalTime().ToString("yyyy-MM-dd HH:mm")
            }).ToList();
            SetStatus("صندوق اعتماد المشتريات: " + rows.Count + " مسودة منتظرة.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void LoadProcurementApprovalIntelligence()
    {
        try
        {
            if (!_session.HasPermission("reports.read"))
            { _procurementApprovalIntelligenceGrid.ItemsSource = null; SetStatus("عرض مقارنة الموردين يتطلب صلاحية reports.read؛ يبقى صندوق الاعتماد متاحاً بصلاحية الاعتماد."); return; }
            var row = _procurementApprovalGrid.SelectedItem;
            if (row == null) { _procurementApprovalIntelligenceGrid.ItemsSource = null; return; }
            var queueId = Guid.Parse(SelectedGridText(row, "QueueId"));
            var queue = new ProcurementApprovalQueueStore(_databasePath);
            var supplierStore = new SupplierIntelligenceStore(_databasePath);
            var advisor = new ProcurementSupplierIntelligenceAdvisor(supplierStore);
            var service = new ProcurementApprovalIntelligenceService(_databasePath, queue, advisor);
            var evidence = service.GetPendingOrderEvidence(_session.UserId, _ledgerSession.CompanyId,
                _ledgerSession.BranchId, queueId, DateOnly.FromDateTime(DateTime.Today));
            _procurementApprovalIntelligenceGrid.ItemsSource = evidence.SelectMany(line =>
                line.Alternatives.Select(option => new
                {
                    الصنف = line.Sku + " — " + line.ItemName,
                    المورد = option.SupplierName,
                    المورد_المختار_حاليا = option.SupplierId == line.SelectedSupplierId ? "نعم" : "لا",
                    العملة = option.CurrencyCode,
                    سعر_الوحدة = option.UnitCostMinor,
                    الضريبة_نقطة_أساس = option.TaxRateBasisPoints,
                    مهلة_التوريد_يوم = option.LeadTimeDays,
                    الاستلامات_المكتملة = option.CompletedReceipts,
                    الالتزام_بالموعد = option.OnTimeDeliveryRate.HasValue ? (option.OnTimeDeliveryRate.Value * 100).ToString("0.0") + "%" : "لا توجد بيانات",
                    التقييم = option.Score,
                    المخاطر = option.RiskLevel,
                    التحذيرات = string.Join(", ", option.RiskFlags)
                })).ToList();
            SetStatus("تم تحميل مقارنة الموردين الاسترشادية. لا تغيّر هذه المقارنة المورد أو شروط أمر الشراء.");
        }
        catch (Exception ex) { _procurementApprovalIntelligenceGrid.ItemsSource = null; ShowError(ex); }
    }

    private void DecideProcurementApproval(bool approve)
    {
        try
        {
            if (!_session.HasPermission("commercial.purchases.approve")) throw new UnauthorizedAccessException("لا تملك صلاحية اعتماد أوامر الشراء.");
            var row = _procurementApprovalGrid.SelectedItem ?? throw new InvalidOperationException("حدد طلب اعتماد من القائمة أولاً.");
            var queueId = Guid.Parse(SelectedGridText(row, "QueueId"));
            var note = PromptText(approve ? "ملاحظة الاعتماد (اختياري)" : "سبب الرفض (مطلوب)", approve ? "اعتماد أمر الشراء" : "رفض أمر الشراء", string.Empty);
            if (note == null) return;
            if (!approve && string.IsNullOrWhiteSpace(note)) throw new ArgumentException("يجب تسجيل سبب الرفض.");
            var confirmation = MessageBox.Show(approve ? "تأكيد اعتماد مسودة أمر الشراء؟" : "تأكيد رفض مسودة أمر الشراء؟", "تأكيد القرار", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (confirmation != MessageBoxResult.Yes) return;
            new ProcurementApprovalQueueStore(_databasePath).Decide(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, queueId, approve, note);
            LoadProcurementApprovals();
            SetStatus(approve ? "تم اعتماد أمر الشراء وتسجيل القرار." : "تم رفض أمر الشراء وتسجيل السبب.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private TabItem BuildProcurementAnalyticsDashboardTab()
    {
        var panel = new StackPanel { Margin = new Thickness(12) };
        panel.Children.Add(Heading("لوحة مؤشرات المشتريات والإدارة التنفيذية"));
        var filters = new WrapPanel { Margin = new Thickness(0, 8, 0, 12) };
        _procurementAnalyticsFrom.SelectedDate = DateTime.Today.AddDays(-30);
        _procurementAnalyticsTo.SelectedDate = DateTime.Today;
        filters.Children.Add(new TextBlock { Text = "من:", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(4) });
        filters.Children.Add(_procurementAnalyticsFrom);
        filters.Children.Add(new TextBlock { Text = "إلى:", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(12, 4, 4, 4) });
        filters.Children.Add(_procurementAnalyticsTo);
        var refresh = new Button { Content = "تحديث المؤشرات", Margin = new Thickness(12, 0, 0, 0), Padding = new Thickness(14, 5, 14, 5) };
        refresh.Click += (_, __) => RefreshProcurementAnalytics();
        filters.Children.Add(refresh);
        var exportItems = new Button { Content = "تصدير أداء المورد/الصنف CSV", Margin = new Thickness(8, 0, 0, 0), Padding = new Thickness(10, 5, 10, 5) };
        exportItems.Click += (_, __) => ExportProcurementAnalyticsCsv("supplier-items"); filters.Children.Add(exportItems);
        var exportTrends = new Button { Content = "تصدير اتجاهات الموردين CSV", Margin = new Thickness(8, 0, 0, 0), Padding = new Thickness(10, 5, 10, 5) };
        exportTrends.Click += (_, __) => ExportProcurementAnalyticsCsv("supplier-trends"); filters.Children.Add(exportTrends);
        var exportForecast = new Button { Content = "تصدير سجل التوقعات CSV", Margin = new Thickness(8, 0, 0, 0), Padding = new Thickness(10, 5, 10, 5) };
        exportForecast.Click += (_, __) => ExportProcurementAnalyticsCsv("forecast-history"); filters.Children.Add(exportForecast);
        var exportWorkbook = new Button { Content = "تصدير جميع التحليلات Excel", Margin = new Thickness(8, 0, 0, 0), Padding = new Thickness(10, 5, 10, 5) };
        exportWorkbook.Click += (_, __) => ExportProcurementAnalyticsWorkbook(); filters.Children.Add(exportWorkbook);
        var exportPrintReport = new Button { Content = "تقرير للطباعة / PDF", Margin = new Thickness(8, 0, 0, 0), Padding = new Thickness(10, 5, 10, 5) };
        exportPrintReport.Click += (_, __) => ExportProcurementAnalyticsPrintReport(); filters.Children.Add(exportPrintReport);
        panel.Children.Add(filters);
        _procurementAnalyticsSummary.TextWrapping = TextWrapping.Wrap;
        _procurementAnalyticsSummary.Margin = new Thickness(0, 4, 0, 14);
        _procurementAnalyticsSummary.FontSize = 14;
        panel.Children.Add(_procurementAnalyticsSummary);
        panel.Children.Add(Heading("أداء الموردين"));
        ConfigureGrid(_procurementAnalyticsSuppliersGrid); _procurementAnalyticsSuppliersGrid.Height = 210;
        panel.Children.Add(_procurementAnalyticsSuppliersGrid);
        panel.Children.Add(Heading("الأصناف الأعلى استهلاكاً"));
        ConfigureGrid(_procurementAnalyticsConsumptionGrid); _procurementAnalyticsConsumptionGrid.Height = 230;
        panel.Children.Add(_procurementAnalyticsConsumptionGrid);
        panel.Children.Add(Heading("أداء المورد حسب الصنف والعملـة"));
        ConfigureGrid(_procurementSupplierItemGrid); _procurementSupplierItemGrid.Height = 230;
        panel.Children.Add(_procurementSupplierItemGrid);
        panel.Children.Add(Heading("اتجاهات أداء الموردين والتنبيهات"));
        ConfigureGrid(_procurementSupplierTrendsGrid); _procurementSupplierTrendsGrid.Height = 230;
        panel.Children.Add(_procurementSupplierTrendsGrid);
        panel.Children.Add(Heading("السجل التاريخي لدقة التوقعات"));
        ConfigureGrid(_procurementForecastHistoryGrid); _procurementForecastHistoryGrid.Height = 250;
        panel.Children.Add(_procurementForecastHistoryGrid);
        RefreshProcurementAnalytics();
        return new TabItem { Header = "لوحة المشتريات", Content = Scroll(panel) };
    }

    private void RefreshProcurementAnalytics()
    {
        try
        {
            IdentityStore.Require(_session, "reports.read");
            if (!_procurementAnalyticsFrom.SelectedDate.HasValue || !_procurementAnalyticsTo.SelectedDate.HasValue)
                throw new InvalidOperationException("حدد تاريخ البداية والنهاية.");
            var from = DateOnly.FromDateTime(_procurementAnalyticsFrom.SelectedDate.Value.Date);
            var to = DateOnly.FromDateTime(_procurementAnalyticsTo.SelectedDate.Value.Date);
            var snapshot = new ProcurementAnalyticsStore(_databasePath).GetSnapshot(
                _session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, from, to);
            var k = snapshot.Decisions;
            var lines = new System.Collections.Generic.List<string>
            {
                "قرارات الاعتماد: " + k.TotalDecisions + " | معتمدة: " + k.Approved + " | مرفوضة: " + k.Rejected,
                "معدل الرفض: " + (k.RejectionRate.HasValue ? (k.RejectionRate.Value * 100).ToString("N1", CultureInfo.InvariantCulture) + "%" : "غير متاح") +
                " | متوسط زمن القرار: " + (k.AverageDecisionHours.HasValue ? k.AverageDecisionHours.Value.ToString("N1", CultureInfo.InvariantCulture) + " ساعة" : "غير متاح")
            };
            if (snapshot.ForecastAccuracy != null)
            {
                var f = snapshot.ForecastAccuracy;
                lines.Add("دقة التوقع WAPE: " + (f.WeightedAbsolutePercentageError.HasValue ? (f.WeightedAbsolutePercentageError.Value * 100).ToString("N1", CultureInfo.InvariantCulture) + "% خطأ" : "غير قابلة للحساب لانعدام الاستهلاك الفعلي") +
                    " | فترات ناضجة: " + f.MaturedForecasts + " | متوقع: " + f.ForecastDemandMilli + " | فعلي: " + f.ActualDemandMilli);
            }
            else lines.Add(snapshot.ForecastAccuracyNote);
            _procurementAnalyticsSummary.Text = string.Join(Environment.NewLine, lines);
            _procurementAnalyticsSuppliersGrid.ItemsSource = snapshot.SupplierPerformance.Select(x => new
            {
                كود_المورد = x.SupplierCode, المورد = x.SupplierName, أوامر_مكتملة = x.CompletedOrders,
                أوامر_بموعد = x.OrdersWithExpectedDate, تسليم_في_الموعد = x.OnTimeOrders,
                نسبة_الالتزام = x.OnTimeRate.HasValue ? (x.OnTimeRate.Value * 100).ToString("N1") + "%" : "غير متاح",
                متوسط_التوريد_أيام = x.AverageCompletionLeadTimeDays
            }).ToList();
            _procurementAnalyticsConsumptionGrid.ItemsSource = snapshot.Consumption.Select(x => new
            { SKU = x.Sku, الصنف = x.ItemName, الكمية_المستهلكة_بالملي = x.IssuedQuantityMilli, عدد_الحركات = x.MovementCount }).ToList();
            var analytics = new ProcurementAnalyticsStore(_databasePath);
            _procurementSupplierItemGrid.ItemsSource = analytics.GetSupplierItemPerformance(
                _session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, from, to)
                .Select(x => new { كود_المورد = x.SupplierCode, المورد = x.SupplierName, SKU = x.Sku,
                    الصنف = x.ItemName, العملة = x.CurrencyCode, أوامر_مكتملة = x.CompletedOrders,
                    الكمية_المستلمة_بالملي = x.ReceivedQuantityMilli, متوسط_تكلفة_الوحدة_الصغرى = x.AverageUnitCostMinor }).ToList();
            _procurementSupplierTrendsGrid.ItemsSource = analytics.GetSupplierPerformanceTrends(
                _session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, from, to)
                .Select(x => new { كود_المورد = x.SupplierCode, المورد = x.SupplierName,
                    أوامر_الفترة = x.CurrentCompletedOrders, أوامر_الفترة_السابقة = x.PreviousCompletedOrders,
                    الالتزام_الحالي = x.CurrentOnTimeRate.HasValue ? (x.CurrentOnTimeRate.Value * 100).ToString("N1") + "%" : "غير متاح",
                    الالتزام_السابق = x.PreviousOnTimeRate.HasValue ? (x.PreviousOnTimeRate.Value * 100).ToString("N1") + "%" : "غير متاح",
                    متوسط_التوريد_الحالي = x.CurrentAverageLeadTimeDays, متوسط_التوريد_السابق = x.PreviousAverageLeadTimeDays,
                    التنبيه = x.AlertLevel }).ToList();
            _procurementForecastHistoryGrid.ItemsSource = analytics.GetForecastHistory(
                _session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, from, to)
                .Select(x => new { SKU = x.Sku, الصنف = x.ItemName, إصدار_السياسة = x.PolicyVersion,
                    أفق_التوقع_أيام = x.HorizonDays, بداية_الفترة = x.WindowStartUtc, نهاية_الفترة = x.WindowEndUtc,
                    المتوقع_بالملي = x.ForecastDemandMilli, الفعلي_بالملي = x.ActualDemandMilli,
                    الخطأ_المطلق_بالملي = x.AbsoluteErrorMilli,
                    نسبة_الخطأ = x.AbsolutePercentageError.HasValue ? (x.AbsolutePercentageError.Value * 100).ToString("N1") + "%" : "غير متاح" }).ToList();
            SetStatus("تم تحديث لوحة المشتريات وتحليلات الموردين والتوقعات ضمن المنشأة والفرع الحاليين.");
        }
        catch (Exception ex)
        {
            _procurementAnalyticsSummary.Text = "تعذر تحميل مؤشرات المشتريات. تحقق من صلاحية reports.read ومن تطبيق ترحيلات التحليلات ولقطات التوقع المطلوبة.\n" + ex.Message;
            _procurementAnalyticsSuppliersGrid.ItemsSource = null; _procurementAnalyticsConsumptionGrid.ItemsSource = null;
            _procurementSupplierItemGrid.ItemsSource = null; _procurementSupplierTrendsGrid.ItemsSource = null;
            _procurementForecastHistoryGrid.ItemsSource = null;
            SetStatus("تعذر تحديث لوحة المشتريات.");
        }
    }

    private void ExportProcurementAnalyticsCsv(string report)
    {
        try
        {
            IdentityStore.Require(_session, "reports.read");
            if (!_procurementAnalyticsFrom.SelectedDate.HasValue || !_procurementAnalyticsTo.SelectedDate.HasValue)
                throw new InvalidOperationException("حدد تاريخ البداية والنهاية قبل التصدير.");
            var from = DateOnly.FromDateTime(_procurementAnalyticsFrom.SelectedDate.Value.Date);
            var to = DateOnly.FromDateTime(_procurementAnalyticsTo.SelectedDate.Value.Date);
            var analytics = new ProcurementAnalyticsStore(_databasePath);
            byte[] content;
            string defaultName;
            if (report == "supplier-items")
            {
                content = ProcurementAnalyticsCsvExporter.ExportSupplierItemPerformance(
                    analytics.GetSupplierItemPerformance(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, from, to));
                defaultName = "monarch-supplier-item-performance";
            }
            else if (report == "supplier-trends")
            {
                content = ProcurementAnalyticsCsvExporter.ExportSupplierTrends(
                    analytics.GetSupplierPerformanceTrends(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, from, to));
                defaultName = "monarch-supplier-performance-trends";
            }
            else if (report == "forecast-history")
            {
                content = ProcurementAnalyticsCsvExporter.ExportForecastHistory(
                    analytics.GetForecastHistory(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, from, to));
                defaultName = "monarch-procurement-forecast-history";
            }
            else throw new ArgumentException("نوع تقرير التصدير غير معروف.", nameof(report));

            var dialog = new SaveFileDialog
            {
                Title = "تصدير تقرير المشتريات",
                FileName = defaultName + "-" + DateTime.Now.ToString("yyyyMMdd-HHmm", CultureInfo.InvariantCulture) + ".csv",
                DefaultExt = ".csv", Filter = "CSV UTF-8 (*.csv)|*.csv", AddExtension = true,
                OverwritePrompt = true
            };
            if (dialog.ShowDialog(this) != true) return;
            File.WriteAllBytes(dialog.FileName, content);
            RecordProcurementReportExport(report, "CSV", from, to, dialog.FileName, content);
            SetStatus("تم تصدير التقرير بصيغة CSV UTF-8 مع دعم العربية، وتسجيل عملية التصدير.");
            MessageBox.Show(this, "تم حفظ التقرير بنجاح.", "تصدير تقارير المشتريات", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void ExportProcurementAnalyticsWorkbook()
    {
        try
        {
            IdentityStore.Require(_session, "reports.read");
            if (!_procurementAnalyticsFrom.SelectedDate.HasValue || !_procurementAnalyticsTo.SelectedDate.HasValue)
                throw new InvalidOperationException("حدد تاريخ البداية والنهاية قبل التصدير.");
            var from = DateOnly.FromDateTime(_procurementAnalyticsFrom.SelectedDate.Value.Date);
            var to = DateOnly.FromDateTime(_procurementAnalyticsTo.SelectedDate.Value.Date);
            var analytics = new ProcurementAnalyticsStore(_databasePath);
            var userId = _session.UserId;
            var companyId = _ledgerSession.CompanyId;
            var branchId = _ledgerSession.BranchId;
            var content = ProcurementAnalyticsXlsxExporter.Export(
                analytics.GetSupplierItemPerformance(userId, companyId, branchId, from, to),
                analytics.GetSupplierPerformanceTrends(userId, companyId, branchId, from, to),
                analytics.GetForecastHistory(userId, companyId, branchId, from, to));
            var dialog = new SaveFileDialog
            {
                Title = "تصدير تحليلات المشتريات إلى Excel",
                FileName = "monarch-procurement-analytics-" + DateTime.Now.ToString("yyyyMMdd-HHmm", CultureInfo.InvariantCulture) + ".xlsx",
                DefaultExt = ".xlsx", Filter = "Excel Workbook (*.xlsx)|*.xlsx", AddExtension = true, OverwritePrompt = true
            };
            if (dialog.ShowDialog(this) != true) return;
            File.WriteAllBytes(dialog.FileName, content);
            RecordProcurementReportExport("procurement-analytics", "XLSX", from, to, dialog.FileName, content);
            SetStatus("تم تصدير تحليلات المشتريات إلى مصنف Excel بثلاث أوراق وتسجيل عملية التصدير.");
            MessageBox.Show(this, "تم حفظ مصنف Excel بنجاح.", "تصدير تقارير المشتريات", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void ExportProcurementAnalyticsPrintReport()
    {
        try
        {
            IdentityStore.Require(_session, "reports.read");
            if (!_procurementAnalyticsFrom.SelectedDate.HasValue || !_procurementAnalyticsTo.SelectedDate.HasValue)
                throw new InvalidOperationException("حدد تاريخ البداية والنهاية قبل إنشاء التقرير.");
            var from = DateOnly.FromDateTime(_procurementAnalyticsFrom.SelectedDate.Value.Date);
            var to = DateOnly.FromDateTime(_procurementAnalyticsTo.SelectedDate.Value.Date);
            var analytics = new ProcurementAnalyticsStore(_databasePath);
            byte[]? logoImage = null;
            var logoChoice = MessageBox.Show(this, "هل تريد إضافة شعار المنشأة إلى التقرير؟", "هوية التقرير", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
            if (logoChoice == MessageBoxResult.Cancel) return;
            if (logoChoice == MessageBoxResult.Yes)
            {
                var logoDialog = new OpenFileDialog
                {
                    Title = "اختيار شعار المنشأة (PNG أو JPEG)",
                    Filter = "Logo image (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg",
                    CheckFileExists = true, Multiselect = false
                };
                if (logoDialog.ShowDialog(this) != true) return;
                var logoInfo = new FileInfo(logoDialog.FileName);
                if (logoInfo.Length > 2 * 1024 * 1024) throw new InvalidOperationException("يجب ألا يتجاوز حجم الشعار 2 ميجابايت.");
                logoImage = File.ReadAllBytes(logoDialog.FileName);
            }
            var content = ProcurementAnalyticsHtmlReportExporter.Export(
                _ledgerSession.CompanyId, _ledgerSession.BranchId, from, to,
                analytics.GetSupplierItemPerformance(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, from, to),
                analytics.GetSupplierPerformanceTrends(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, from, to),
                analytics.GetForecastHistory(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, from, to),
                _ledgerSession.CompanyName, _ledgerSession.BranchName, logoImage, DateTime.UtcNow);
            var dialog = new SaveFileDialog
            {
                Title = "حفظ تقرير المشتريات للطباعة أو PDF",
                FileName = "monarch-procurement-report-" + DateTime.Now.ToString("yyyyMMdd-HHmm", CultureInfo.InvariantCulture) + ".html",
                DefaultExt = ".html", Filter = "HTML report (*.html)|*.html", AddExtension = true, OverwritePrompt = true
            };
            if (dialog.ShowDialog(this) != true) return;
            File.WriteAllBytes(dialog.FileName, content);
            RecordProcurementReportExport("procurement-analytics", "HTML", from, to, dialog.FileName, content);
            SetStatus("تم إنشاء تقرير HTML بهوية المنشأة والفرع وتسجيل عملية التصدير.");
            MessageBox.Show(this, "تم حفظ التقرير. افتحه في متصفح حديث ثم اختر طباعة ← حفظ كملف PDF.", "تقرير المشتريات", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void RecordProcurementReportExport(string reportType, string format, DateOnly from, DateOnly to, string outputPath, byte[] content)
    {
        var auditPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "MONARCH ERP", "Audit", "procurement-report-exports.log");
        ProcurementReportExportAuditStore.Append(auditPath, _session.UserId, _ledgerSession.CompanyId,
            _ledgerSession.BranchId, reportType, format, from, to, outputPath, content, DateTime.UtcNow);
    }

    private TabItem BuildProcurementExportAuditTab()
    {
        IdentityStore.Require(_session, "reports.read");
        var panel = new StackPanel { Margin = new Thickness(18) };
        panel.Children.Add(Heading("سجل تدقيق تصدير تقارير المشتريات"));
        panel.Children.Add(new TextBlock { Text = "السجل محلي على هذا الجهاز. يعرض هذا المركز عمليات المنشأة والفرع الحاليين فقط؛ ولا يمثل سجلاً مركزياً متعدد الأجهزة.", TextWrapping = TextWrapping.Wrap, Foreground = Brush("#8A4B08"), Margin = new Thickness(2, 5, 2, 10) });
        var row = new WrapPanel();
        var format = new ComboBox { Width = 130, Margin = new Thickness(4), ItemsSource = new[] { "الكل", "CSV", "XLSX", "HTML" }, SelectedIndex = 0 };
        row.Children.Add(new TextBlock { Text = "التنسيق:", VerticalAlignment = VerticalAlignment.Center }); row.Children.Add(format);
        var grid = new DataGrid { AutoGenerateColumns = true, IsReadOnly = true, Height = 330, Margin = new Thickness(0, 8, 0, 8) };
        var status = new TextBlock { Margin = new Thickness(2, 4, 2, 8), TextWrapping = TextWrapping.Wrap };
        Action refresh = () =>
        {
            try
            {
                IdentityStore.Require(_session, "reports.read");
                var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MONARCH ERP", "Audit", "procurement-report-exports.log");
                var valid = ProcurementReportExportAuditStore.Verify(path, out var count);
                if (!valid) { grid.ItemsSource = null; status.Text = "تحذير: فشل التحقق من سلسلة التدقيق؛ أوقف عرض السجلات والتصدير."; return; }
                var selected = Convert.ToString(format.SelectedItem, CultureInfo.InvariantCulture);
                grid.ItemsSource = ProcurementReportExportAuditStore.ReadEntries(path, _ledgerSession.CompanyId, _ledgerSession.BranchId, null, selected == "الكل" ? null : selected);
                status.Text = "سلامة السلسلة: سليمة | إجمالي سجلات ملف الجهاز: " + count.ToString(CultureInfo.InvariantCulture) + " | المعروض ضمن المنشأة والفرع الحاليين.";
            }
            catch (Exception ex) { grid.ItemsSource = null; status.Text = "تعذر قراءة سجل التدقيق: " + ex.Message; }
        };
        var verify = Button("تحقق وتحديث"); verify.Click += (_, __) => refresh(); row.Children.Add(verify);
        var export = Button("تصدير السجل المعروض CSV"); export.Click += (_, __) =>
        {
            try
            {
                IdentityStore.Require(_session, "reports.read");
                var dialog = new SaveFileDialog { Title = "تصدير سجل التدقيق الموثق", FileName = "monarch-procurement-export-audit.csv", Filter = "CSV (*.csv)|*.csv", AddExtension = true, DefaultExt = ".csv" };
                if (dialog.ShowDialog(this) != true) return;
                var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MONARCH ERP", "Audit", "procurement-report-exports.log");
                var selectedFormat = Convert.ToString(format.SelectedItem, CultureInfo.InvariantCulture);
                ProcurementReportExportAuditStore.ExportVerifiedCsv(path, dialog.FileName, _ledgerSession.CompanyId, _ledgerSession.BranchId, selectedFormat == "الكل" ? null : selectedFormat);
                SetStatus("تم تصدير سجل التدقيق بعد التحقق من سلامة السلسلة.");
            }
            catch (Exception ex) { ShowError(ex); }
        }; row.Children.Add(export);
        panel.Children.Add(row); panel.Children.Add(status); panel.Children.Add(grid);
        refresh();
        return new TabItem { Header = "تدقيق التصدير", Content = new ScrollViewer { Content = panel, VerticalScrollBarVisibility = ScrollBarVisibility.Auto } };
    }

    private TabItem BuildSupplierPayablesTab()
    {
        var panel = new StackPanel { Margin = new Thickness(18) };
        panel.Children.Add(Heading("الذمم الدائنة للموردين"));
        panel.Children.Add(new TextBlock { Text = "يعرض هذا القسم أرصدة فواتير المورد المرحلة فقط. تسجيل الدفعة يحفظ التخصيص وحدث Outbox والتدقيق ذرياً؛ لا يُعد ذلك قيداً في الأستاذ العام حتى تفعيل عامل الترحيل المحاسبي واختباره.", TextWrapping = TextWrapping.Wrap, Foreground = Brush("#8A4B08"), Margin = new Thickness(2, 4, 2, 10) });
        var supplierRow = new WrapPanel();
        supplierRow.Children.Add(FormLabel("المورد")); supplierRow.Children.Add(_payablesSupplier);
        var refresh = Button("عرض الفواتير المفتوحة"); refresh.Click += (_, __) => LoadSupplierPayables(); supplierRow.Children.Add(refresh);
        supplierRow.Children.Add(FormLabel("تاريخ تقرير الأعمار")); _payablesAgingDate.SelectedDate = DateTime.Today; supplierRow.Children.Add(_payablesAgingDate);
        var aging = Button("تحديث أعمار الذمم"); aging.Click += (_, __) => LoadSupplierPayablesAging(); supplierRow.Children.Add(aging);
        panel.Children.Add(supplierRow);
        _supplierPayablesGrid.AutoGenerateColumns = true; _supplierPayablesGrid.IsReadOnly = true; _supplierPayablesGrid.Height = 180;
        panel.Children.Add(new TextBlock { Text = "الفواتير المفتوحة — حدد فاتورة لتخصيص دفعة", FontWeight = FontWeights.Bold, Margin = new Thickness(2, 8, 2, 4) });
        panel.Children.Add(_supplierPayablesGrid);
        var paymentRow = new WrapPanel { Margin = new Thickness(0, 10, 0, 6) };
        paymentRow.Children.Add(FormLabel("رقم الدفعة")); paymentRow.Children.Add(_supplierPaymentNumber);
        paymentRow.Children.Add(FormLabel("التاريخ")); _supplierPaymentDate.SelectedDate = DateTime.Today; paymentRow.Children.Add(_supplierPaymentDate);
        paymentRow.Children.Add(FormLabel("المبلغ بوحدات العملة الصغرى")); paymentRow.Children.Add(_supplierPaymentAmount);
        paymentRow.Children.Add(FormLabel("الطريقة")); _supplierPaymentMethod.ItemsSource = new[] { "Cash", "Bank" }; _supplierPaymentMethod.SelectedIndex = 1; paymentRow.Children.Add(_supplierPaymentMethod);
        paymentRow.Children.Add(FormLabel("رمز حساب النقد/البنك")); paymentRow.Children.Add(_supplierPaymentAccount);
        if (_session.HasPermission("commercial.purchases.manage"))
        {
            var post = Button("تسجيل دفعة على الفاتورة المحددة"); post.Click += (_, __) => PostSupplierPaymentForSelectedInvoice(); paymentRow.Children.Add(post);
        }
        else paymentRow.Children.Add(new TextBlock { Text = "صلاحية تسجيل الدفعات غير متاحة لهذا المستخدم.", Foreground = Brush("#8A4B08"), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(8) });
        panel.Children.Add(paymentRow);
        panel.Children.Add(new TextBlock { Text = "تقرير أعمار الذمم (كل مبالغ العملات تبقى منفصلة حسب رمز العملة)", FontWeight = FontWeights.Bold, Margin = new Thickness(2, 10, 2, 4) });
        _supplierPayablesAgingGrid.AutoGenerateColumns = true; _supplierPayablesAgingGrid.IsReadOnly = true; _supplierPayablesAgingGrid.Height = 210;
        panel.Children.Add(_supplierPayablesAgingGrid);
        panel.Loaded += (_, __) => LoadSupplierPayablesSuppliers();
        return new TabItem { Header = "الذمم الدائنة", Content = Scroll(panel) };
    }

    private TabItem BuildSupplierApAlertsTab()
    {
        var panel = new StackPanel { Margin = new Thickness(18) };
        panel.Children.Add(Heading("مركز تنبيهات مستحقات الموردين"));
        panel.Children.Add(new TextBlock
        {
            Text = "يعرض التنبيهات التشغيلية المحفوظة ضمن الشركة والفرع الحاليين. الاطلاع والإقرار يسجلان كأحداث مستقلة؛ لا يؤدي الإقرار إلى إعادة تشغيل العامل أو تغيير القيود أو المهام.",
            TextWrapping = TextWrapping.Wrap, Foreground = Brush("#65758B"), Margin = new Thickness(2, 5, 2, 10)
        });
        var actions = new WrapPanel { Margin = new Thickness(0, 0, 0, 8) };
        var refresh = Button("تحديث التنبيهات");
        refresh.Click += (_, __) => LoadSupplierApOperationalAlerts();
        actions.Children.Add(refresh);
        var viewed = Button("تسجيل الاطلاع");
        viewed.Click += (_, __) => RecordSupplierApAlertLifecycle(false);
        actions.Children.Add(viewed);
        var acknowledge = Button("الإقرار بالتنبيه");
        acknowledge.Click += (_, __) => RecordSupplierApAlertLifecycle(true);
        actions.Children.Add(acknowledge);
        panel.Children.Add(actions);
        panel.Children.Add(Heading("صندوق الإشعارات الواردة للمستخدم الحالي"));
        panel.Children.Add(new TextBlock
        {
            Text = "يستلم هذا الصندوق مهام In-App الموجهة حصراً للمستخدم المسجل ضمن الشركة والفرع الحاليين. يُسجل التسليم بعد تجهيز الصفوف للعرض، ولا يعني ذلك أن المستخدم قرأ الإشعار.",
            TextWrapping = TextWrapping.Wrap, Foreground = Brush("#65758B"), Margin = new Thickness(2, 4, 2, 8)
        });
        var inboxActions = new WrapPanel { Margin = new Thickness(0, 0, 0, 8) };
        var receive = Button("استلام الإشعارات الواردة");
        receive.Click += (_, __) => LoadSupplierApInbox();
        inboxActions.Children.Add(receive);
        var refreshInbox = Button("تحديث الصندوق المحفوظ");
        refreshInbox.Click += (_, __) => LoadSupplierApPersistentInbox();
        inboxActions.Children.Add(refreshInbox);
        var markInboxViewed = Button("تسجيل مشاهدة الإشعار المحدد");
        markInboxViewed.Click += (_, __) => RecordSupplierApInboxLifecycle(false);
        inboxActions.Children.Add(markInboxViewed);
        var acknowledgeInbox = Button("الإقرار بالإشعار المحدد");
        acknowledgeInbox.Click += (_, __) => RecordSupplierApInboxLifecycle(true);
        inboxActions.Children.Add(acknowledgeInbox);
        panel.Children.Add(inboxActions);
        _supplierApInboxGrid.AutoGenerateColumns = true;
        _supplierApInboxGrid.IsReadOnly = true;
        _supplierApInboxGrid.SelectionMode = DataGridSelectionMode.Single;
        _supplierApInboxGrid.Height = 190;
        panel.Children.Add(_supplierApInboxGrid);
        _supplierApInboxStatus.TextWrapping = TextWrapping.Wrap;
        _supplierApInboxStatus.Margin = new Thickness(2, 6, 2, 10);
        _supplierApInboxStatus.Foreground = Brush("#52647B");
        panel.Children.Add(_supplierApInboxStatus);
        _supplierApAlertsGrid.AutoGenerateColumns = true;
        _supplierApAlertsGrid.IsReadOnly = true;
        _supplierApAlertsGrid.SelectionMode = DataGridSelectionMode.Single;
        _supplierApAlertsGrid.Height = 330;
        panel.Children.Add(_supplierApAlertsGrid);
        _supplierApAlertsStatus.TextWrapping = TextWrapping.Wrap;
        _supplierApAlertsStatus.Margin = new Thickness(2, 8, 2, 4);
        _supplierApAlertsStatus.Foreground = Brush("#52647B");
        panel.Children.Add(_supplierApAlertsStatus);
        if (_session.HasPermission("users.manage"))
        {
            panel.Children.Add(Heading("إدارة الإشعارات المتوقفة نهائياً"));
            panel.Children.Add(new TextBlock { Text = "عرض وإعادة إدراج الرسائل Dead-Letter متاحان للمستخدم المخول users.manage فقط. إعادة الإدراج لا تحذف سجل المحاولات؛ وتُسجل كعملية إدارية مستقلة.", TextWrapping = TextWrapping.Wrap, Foreground = Brush("#65758B"), Margin = new Thickness(2, 4, 2, 8) });
            var deadActions = new WrapPanel { Margin = new Thickness(0, 0, 0, 8) };
            var refreshDead = Button("تحديث الرسائل المتوقفة"); refreshDead.Click += (_, __) => LoadSupplierApDeadLetters(); deadActions.Children.Add(refreshDead);
            var retryDead = Button("إعادة محاولة الرسالة المحددة"); retryDead.Click += (_, __) => QueueSelectedSupplierApDeadLetterRetry(); deadActions.Children.Add(retryDead);
            panel.Children.Add(deadActions);
            _supplierApDeadLettersGrid.AutoGenerateColumns = true; _supplierApDeadLettersGrid.IsReadOnly = true;
            _supplierApDeadLettersGrid.SelectionMode = DataGridSelectionMode.Single; _supplierApDeadLettersGrid.Height = 180;
            panel.Children.Add(_supplierApDeadLettersGrid);
            _supplierApDeadLettersStatus.TextWrapping = TextWrapping.Wrap; _supplierApDeadLettersStatus.Margin = new Thickness(2, 6, 2, 10);
            _supplierApDeadLettersStatus.Foreground = Brush("#52647B"); panel.Children.Add(_supplierApDeadLettersStatus);
        }
        panel.Loaded += (_, __) => { LoadSupplierApOperationalAlerts(); LoadSupplierApPersistentInbox(); if (_session.HasPermission("users.manage")) LoadSupplierApDeadLetters(); };
        return new TabItem { Header = "تنبيهات الموردين", Content = Scroll(panel) };
    }

    private void LoadSupplierApDeadLetters()
    {
        try
        {
            IdentityStore.Require(_session, "users.manage");
            var store = new SupplierPayablesAlertDeadLetterStore(_databasePath, _tenantStore);
            var items = store.GetDeadLetters(_session, _ledgerSession.CompanyId, _ledgerSession.BranchId, 100);
            _supplierApDeadLettersGrid.ItemsSource = items.Select(item => new
            {
                معرف_الإشعار = item.IntentId, المستخدم_المستلم = item.RecipientUserId,
                الرمز = item.AlertCode, الخطورة = item.Severity, عدد_المحاولات_الحالية = item.AttemptCount,
                إجمالي_المحاولات_التاريخية = item.HistoricalAttempts, رمز_آخر_خطأ = item.LastErrorCode,
                آخر_تحديث_UTC = item.UpdatedUtc
            }).ToList();
            _supplierApDeadLettersStatus.Text = "عدد الرسائل المتوقفة المعروضة: " + items.Count.ToString(CultureInfo.InvariantCulture) + ". إعادة المحاولة تتطلب تأكيداً وتسجيلاً إدارياً.";
        }
        catch (Exception ex) { _supplierApDeadLettersGrid.ItemsSource = null; _supplierApDeadLettersStatus.Text = "تعذر تحميل الرسائل المتوقفة: " + ex.Message; }
    }

    private void QueueSelectedSupplierApDeadLetterRetry()
    {
        try
        {
            IdentityStore.Require(_session, "users.manage");
            if (_supplierApDeadLettersGrid.SelectedItem is null) throw new InvalidOperationException("حدد رسالة متوقفة أولاً.");
            var idProperty = _supplierApDeadLettersGrid.SelectedItem.GetType().GetProperty("معرف_الإشعار");
            if (idProperty?.GetValue(_supplierApDeadLettersGrid.SelectedItem) is not Guid intentId) throw new InvalidOperationException("تعذر قراءة معرف الرسالة المحددة.");
            if (MessageBox.Show("سيُعاد إدراج الرسالة في قائمة الانتظار مع الاحتفاظ بسجل المحاولات السابق. هل تريد المتابعة؟", "تأكيد إعادة المحاولة", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
            var store = new SupplierPayablesAlertDeadLetterStore(_databasePath, _tenantStore);
            var queued = store.QueueManualRetry(_session, _ledgerSession.CompanyId, _ledgerSession.BranchId, intentId, "MANUAL_OPERATOR_RETRY");
            if (!queued) throw new InvalidOperationException("لم تعد الرسالة في حالة Dead-Letter أو أنها خارج نطاق الشركة والفرع الحاليين.");
            _supplierApDeadLettersStatus.Text = "تم تسجيل قرار إعادة المحاولة وإدراج الرسالة في قائمة الانتظار. لم يتم تنفيذ التسليم بعد.";
            LoadSupplierApDeadLetters();
        }
        catch (Exception ex) { _supplierApDeadLettersStatus.Text = "تعذرت إعادة المحاولة: " + ex.Message; }
    }

    private void LoadSupplierApInbox()
    {
        IReadOnlyList<SupplierPayablesAlertDispatchClaim>? claims = null;
        try
        {
            IdentityStore.Require(_session, "reports.read");
            var dispatcher = new SupplierPayablesAlertDispatcher(_databasePath, _tenantStore);
            claims = dispatcher.ClaimDue(_session.UserId, _ledgerSession.CompanyId,
                _ledgerSession.BranchId, limit: 50, leaseSeconds: 60);
            var rows = claims.Select(claim => new
            {
                معرف_الإشعار = claim.IntentId,
                الرمز = claim.AlertCode,
                الخطورة = claim.Severity,
                مستوى_التصعيد = claim.EscalationLevel,
                رقم_المحاولة = claim.AttemptNumber,
                حالة_العرض = "تم تجهيز الإشعار للعرض"
            }).ToList();
            // Bind the complete batch before acknowledging delivery. If binding fails, the
            // catch path releases each owned claim through a bounded retry outcome.
            try
            {
                _supplierApInboxGrid.ItemsSource = rows;
            }
            catch
            {
                foreach (var claim in claims)
                {
                    try
                    {
                        dispatcher.CompleteAttempt(_session.UserId, _ledgerSession.CompanyId,
                            _ledgerSession.BranchId, claim.IntentId, claim.LeaseToken,
                            delivered: false, errorCode: "UI_PRESENTATION_FAILED");
                    }
                    catch { /* Lease expiry remains the recovery path if retry persistence fails. */ }
                }
                throw;
            }
            var delivered = 0;
            var unresolved = 0;
            foreach (var claim in claims)
            {
                try
                {
                    var result = dispatcher.CompleteAttempt(_session.UserId, _ledgerSession.CompanyId,
                        _ledgerSession.BranchId, claim.IntentId, claim.LeaseToken, delivered: true);
                    if (result.Accepted && result.Status == "Delivered") delivered++;
                    else unresolved++;
                }
                catch { unresolved++; /* Keep the already-bound rows visible; lease expiry recovers the claim. */ }
            }
            _supplierApInboxStatus.Text = claims.Count == 0
                ? "لا توجد إشعارات مستحقة لهذا المستخدم حالياً."
                : "تم تجهيز " + claims.Count.ToString(CultureInfo.InvariantCulture) +
                  " إشعاراً للعرض؛ تم تأكيد تسليم " + delivered.ToString(CultureInfo.InvariantCulture) +
                  "؛ مهام بانتظار استعادة الحجز: " + unresolved.ToString(CultureInfo.InvariantCulture) +
                  ". هذا التأكيد لا يمثل إثبات قراءة.";
            LoadSupplierApPersistentInbox();
        }
        catch (Exception ex)
        {
            if (claims is not null)
            {
                var dispatcher = new SupplierPayablesAlertDispatcher(_databasePath, _tenantStore);
                foreach (var claim in claims)
                {
                    try
                    {
                        dispatcher.CompleteAttempt(_session.UserId, _ledgerSession.CompanyId,
                            _ledgerSession.BranchId, claim.IntentId, claim.LeaseToken,
                            delivered: false, errorCode: "UI_PRESENTATION_FAILED");
                    }
                    catch { /* Preserve the original UI failure; lease expiry remains the recovery path. */ }
                }
            }
            _supplierApInboxGrid.ItemsSource = null;
            _supplierApInboxStatus.Text = "تعذر استلام الإشعارات. ستُستعاد المهام بعد انتهاء الحجز عند الحاجة. " + ex.Message;
        }
    }

    private void LoadSupplierApPersistentInbox()
    {
        try
        {
            IdentityStore.Require(_session, "reports.read");
            var store = new SupplierPayablesAlertInboxStore(_databasePath, _tenantStore);
            var items = store.GetDelivered(_session.UserId, _ledgerSession.CompanyId,
                _ledgerSession.BranchId, limit: 100);
            _supplierApInboxGrid.ItemsSource = items.Select(item => new
            {
                معرف_الإشعار = item.IntentId,
                الرمز = item.AlertCode,
                الخطورة = item.Severity,
                مستوى_التصعيد = item.EscalationLevel,
                وقت_التسليم_UTC = item.DeliveredUtc,
                تمت_المشاهدة = item.Viewed ? "نعم" : "لا",
                وقت_المشاهدة_UTC = item.ViewedUtc,
                تم_الإقرار = item.Acknowledged ? "نعم" : "لا",
                وقت_الإقرار_UTC = item.AcknowledgedUtc
            }).ToList();
            _supplierApInboxStatus.Text = items.Count == 0
                ? "لا توجد إشعارات مسلّمة محفوظة لهذا المستخدم ضمن الشركة والفرع الحاليين."
                : "الإشعارات المسلّمة المحفوظة: " + items.Count.ToString(CultureInfo.InvariantCulture) +
                  " | المشاهدة والإقرار محفوظان بصورة مستقلة.";
        }
        catch (Exception ex)
        {
            _supplierApInboxStatus.Text = "تعذر تحميل سجل صندوق الإشعارات الدائم. تحقق من تطبيق ترحيل 2026-11-11-supplier-ap-alert-inbox-read-state.sql ومن الصلاحيات. " + ex.Message;
        }
    }

    private void RecordSupplierApInboxLifecycle(bool acknowledge)
    {
        try
        {
            IdentityStore.Require(_session, "reports.read");
            if (_supplierApInboxGrid.SelectedItem is null)
                throw new InvalidOperationException("حدد إشعاراً مسلّماً من الصندوق أولاً.");
            var intentValue = _supplierApInboxGrid.SelectedItem.GetType()
                .GetProperty("معرف_الإشعار")?.GetValue(_supplierApInboxGrid.SelectedItem);
            if (intentValue is not Guid intentId || intentId == Guid.Empty)
                throw new InvalidOperationException("تعذر قراءة معرف الإشعار المحدد.");
            var store = new SupplierPayablesAlertInboxStore(_databasePath, _tenantStore);
            if (acknowledge)
                store.Acknowledge(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, intentId);
            else
                store.MarkViewed(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, intentId);
            LoadSupplierApPersistentInbox();
            _supplierApInboxStatus.Text = acknowledge
                ? "تم حفظ إقرارك بالإشعار في سجل دائم."
                : "تم حفظ مشاهدة الإشعار في سجل دائم.";
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void LoadSupplierApOperationalAlerts()
    {
        try
        {
            if (!_session.HasPermission("reports.read"))
                throw new UnauthorizedAccessException("لا تملك صلاحية قراءة التقارير.");
            var worker = new SupplierPayablesAccountingOutboxWorker(_databasePath, _tenantStore);
            var alerts = worker.GetOperationalAlerts(_session.UserId, _ledgerSession.CompanyId,
                _ledgerSession.BranchId, 100);
            var lifecycle = new SupplierPayablesOperationalAlertLifecycleStore(_databasePath, _tenantStore);
            var states = lifecycle.GetStates(_session.UserId, _ledgerSession.CompanyId,
                _ledgerSession.BranchId, alerts);
            _supplierApAlerts.Clear();
            foreach (var alert in alerts) _supplierApAlerts.Add(alert);
            _supplierApAlertsGrid.ItemsSource = alerts.Select((a, i) => new
            {
                الرمز = a.Code,
                الخطورة = a.Severity,
                التنبيه = a.Title,
                التفاصيل = a.Summary,
                عدد_الأحداث = a.EventCount,
                آخر_حدث_UTC = a.LastOccurredUtc,
                تمت_المشاهدة = states[i].Viewed ? "نعم" : "لا",
                تمت_الموافقة = states[i].Acknowledged ? "نعم" : "لا"
            }).ToList();
            _supplierApAlertsStatus.Text = alerts.Count == 0
                ? "لا توجد تنبيهات ضمن نوافذ الرصد الحالية."
                : "عدد التنبيهات: " + alerts.Count + " | النطاق: " + _ledgerSession.CompanyName + " / " + _ledgerSession.BranchName;
        }
        catch (Exception ex)
        {
            _supplierApAlertsGrid.ItemsSource = null;
            _supplierApAlertsStatus.Text = "تعذر تحميل التنبيهات. تحقق من تطبيق ترحيل قاعدة البيانات 2026-11-11-supplier-ap-alert-lifecycle.sql ومن صلاحيات الحساب. " + ex.Message;
        }
    }

    private void RecordSupplierApAlertLifecycle(bool acknowledge)
    {
        try
        {
            if (!_session.HasPermission("reports.read"))
                throw new UnauthorizedAccessException("لا تملك صلاحية قراءة التقارير.");
            if (_supplierApAlertsGrid.SelectedItem is null)
                throw new InvalidOperationException("حدد تنبيهاً أولاً.");
            var code = Convert.ToString(_supplierApAlertsGrid.SelectedItem.GetType()
                .GetProperty("الرمز")?.GetValue(_supplierApAlertsGrid.SelectedItem), CultureInfo.InvariantCulture);
            var alert = _supplierApAlerts.FirstOrDefault(x => string.Equals(x.Code, code, StringComparison.Ordinal));
            if (alert is null) throw new InvalidOperationException("تعذر تحديد التنبيه المحدد؛ حدّث القائمة.");
            var lifecycle = new SupplierPayablesOperationalAlertLifecycleStore(_databasePath, _tenantStore);
            if (acknowledge)
                lifecycle.Acknowledge(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, alert);
            else
                lifecycle.MarkViewed(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, alert);
            LoadSupplierApOperationalAlerts();
            _supplierApAlertsStatus.Text = acknowledge ? "تم تسجيل الإقرار بالتنبيه." : "تم تسجيل الاطلاع على التنبيه.";
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void LoadSupplierPayablesSuppliers()
    {
        try
        {
            var suppliers = new PurchaseOrderStore(_databasePath).ListActiveSuppliers(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId);
            _payablesSupplier.ItemsSource = suppliers.Select(x => new { x.Id, Display = x.Code + " — " + x.DisplayName }).ToList();
            _payablesSupplier.DisplayMemberPath = "Display"; _payablesSupplier.SelectedValuePath = "Id";
            if (_payablesSupplier.Items.Count > 0) _payablesSupplier.SelectedIndex = 0;
            LoadSupplierPayables(); LoadSupplierPayablesAging();
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void LoadSupplierPayables()
    {
        try
        {
            if (_payablesSupplier.SelectedValue is not Guid supplierId) { _supplierPayablesGrid.ItemsSource = null; return; }
            var rows = new SupplierPayablesStore(_databasePath).ListOpenInvoices(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, supplierId);
            _supplierPayablesGrid.ItemsSource = rows.Select(x => new { المعرف = x.InvoiceId, رقم_الفاتورة = x.InvoiceNumber, تاريخ_الفاتورة = x.InvoiceDate.ToString("yyyy-MM-dd"), الاستحقاق = x.DueDate.ToString("yyyy-MM-dd"), العملة = x.CurrencyCode, إجمالي_الفاتورة = x.OriginalMinor, المدفوع = x.PaidMinor, المتبقي = x.OutstandingMinor }).ToList();
        }
        catch (Exception ex) { _supplierPayablesGrid.ItemsSource = null; ShowError(ex); }
    }

    private void PostSupplierPaymentForSelectedInvoice()
    {
        try
        {
            if (_payablesSupplier.SelectedValue is not Guid supplierId) throw new InvalidOperationException("اختر المورد أولاً.");
            if (_supplierPayablesGrid.SelectedItem is null) throw new InvalidOperationException("حدد فاتورة مفتوحة أولاً.");
            var invoiceId = SelectedGridGuid(_supplierPayablesGrid); if (invoiceId == Guid.Empty) throw new InvalidOperationException("تعذر قراءة معرف الفاتورة المحددة.");
            if (!long.TryParse(_supplierPaymentAmount.Text.Trim(), NumberStyles.None, CultureInfo.InvariantCulture, out var amount) || amount <= 0) throw new ArgumentException("أدخل مبلغاً موجباً بوحدات العملة الصغرى.");
            if (string.IsNullOrWhiteSpace(_supplierPaymentNumber.Text) || string.IsNullOrWhiteSpace(_supplierPaymentAccount.Text)) throw new ArgumentException("رقم الدفعة ورمز حساب النقد/البنك مطلوبان.");
            if (_supplierPaymentDate.SelectedDate is null) throw new ArgumentException("تاريخ الدفعة مطلوب.");
            var invoice = new SupplierPayablesStore(_databasePath).ListOpenInvoices(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, supplierId).Single(x => x.InvoiceId == invoiceId);
            if (amount > invoice.OutstandingMinor) throw new ArgumentException("المبلغ يتجاوز الرصيد المفتوح للفاتورة.");
            if (MessageBox.Show($"سيتم تسجيل دفعة بقيمة {amount} {invoice.CurrencyCode} على الفاتورة {invoice.InvoiceNumber}. لن يُنشأ قيد أستاذ عام في هذه المرحلة. متابعة؟", "تأكيد دفعة المورد", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
            var method = string.Equals(_supplierPaymentMethod.SelectedItem as string, "Cash", StringComparison.OrdinalIgnoreCase) ? CommercialPaymentMethod.Cash : CommercialPaymentMethod.Bank;
            new SupplierPayablesStore(_databasePath).PostPayment(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId,
                new SupplierPayablePaymentDraft(Guid.NewGuid(), _supplierPaymentNumber.Text.Trim(), supplierId, DateOnly.FromDateTime(_supplierPaymentDate.SelectedDate.Value), method, _supplierPaymentAccount.Text.Trim(), invoice.CurrencyCode, invoice.CurrencyScale, new[] { new SupplierPayableAllocation(invoiceId, amount) }));
            _supplierPaymentNumber.Clear(); _supplierPaymentAmount.Clear();
            LoadSupplierPayables(); LoadSupplierPayablesAging();
            _purchaseSummary.Text = "تم تسجيل دفعة المورد وتخصيصها. أُنشئ حدث Outbox؛ لم يُنشأ قيد أستاذ عام.";
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void LoadSupplierPayablesAging()
    {
        try
        {
            if (_payablesAgingDate.SelectedDate is null) throw new ArgumentException("حدد التاريخ المرجعي لتقرير الأعمار.");
            var rows = new SupplierPayablesStore(_databasePath).GetAging(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, DateOnly.FromDateTime(_payablesAgingDate.SelectedDate.Value));
            _supplierPayablesAgingGrid.ItemsSource = rows.Select(x => new { المورد = x.SupplierName, رقم_الفاتورة = x.InvoiceNumber, العملة = x.CurrencyCode, الرصيد = x.OutstandingMinor, أيام_التأخير = x.DaysOverdue, غير_مستحق = x.CurrentMinor, من_1_إلى_30 = x.Days1To30Minor, من_31_إلى_60 = x.Days31To60Minor, من_61_إلى_90 = x.Days61To90Minor, أكثر_من_90 = x.Over90Minor }).ToList();
        }
        catch (Exception ex) { _supplierPayablesAgingGrid.ItemsSource = null; ShowError(ex); }
    }

    private static TextBlock FormLabel(string text) => new TextBlock { Text = text + ":", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(8, 4, 4, 4), Foreground = Brush("#52647B") };

    private void LoadPurchaseOrderLookups()
    {
        try
        {
            if (!_session.HasPermission("reports.read") || !_session.HasPermission("commercial.purchases.manage")) throw new UnauthorizedAccessException("يلزم امتلاك صلاحية إدارة المشتريات وقراءة البيانات.");
            var purchase = new PurchaseOrderStore(_databasePath);
            var suppliers = purchase.ListActiveSuppliers(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId);
            var commercial = new CommercialStore(_databasePath);
            var warehouses = commercial.GetWarehouses(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, true);
            var items = commercial.GetItems(_session.UserId, _ledgerSession.CompanyId, true);
            _purchaseSupplier.ItemsSource = suppliers.Select(x => new { x.Id, Display = x.Code + " — " + x.DisplayName }).ToList();
            _purchaseSupplier.DisplayMemberPath = "Display"; _purchaseSupplier.SelectedValuePath = "Id";
            _purchaseWarehouse.ItemsSource = warehouses.Select(x => new { x.Id, Display = x.Code + " — " + x.Name }).ToList();
            _purchaseWarehouse.DisplayMemberPath = "Display"; _purchaseWarehouse.SelectedValuePath = "Id";
            _purchaseItem.ItemsSource = items.Select(x => new { x.Id, Display = x.Sku + " — " + x.Name, x.Type }).ToList();
            _purchaseItem.DisplayMemberPath = "Display"; _purchaseItem.SelectedValuePath = "Id";
            if (_purchaseSupplier.Items.Count > 0) _purchaseSupplier.SelectedIndex = 0;
            if (_purchaseWarehouse.Items.Count > 0) _purchaseWarehouse.SelectedIndex = 0;
            if (_purchaseItem.Items.Count > 0) _purchaseItem.SelectedIndex = 0;
            LoadPurchaseOrders();
        }
        catch (Exception ex) { _purchaseSummary.Text = "تعذر تحميل قوائم المشتريات. تحقق من تهيئة المخطط التجاري والصلاحيات. لم تُجرَ أي ترقية تلقائية.\n" + ex.Message; }
    }

    private void CreatePurchaseOrderDraft()
    {
        try
        {
            if (!_session.HasPermission("commercial.purchases.manage")) throw new UnauthorizedAccessException("لا تملك صلاحية إدارة المشتريات.");
            if (_purchaseSupplier.SelectedValue == null || _purchaseWarehouse.SelectedValue == null || _purchaseItem.SelectedValue == null) throw new InvalidOperationException("أضف مورداً ومستودعاً وصنفاً نشطاً أولاً.");
            if (!decimal.TryParse(_purchaseQuantity.Text, NumberStyles.Number, CultureInfo.InvariantCulture, out var quantity) || quantity <= 0 || quantity > 9_000_000_000m) throw new ArgumentException("الكمية غير صحيحة؛ استخدم قيمة موجبة.");
            if (!decimal.TryParse(_purchaseUnitCost.Text, NumberStyles.Number, CultureInfo.InvariantCulture, out var unitCost) || unitCost < 0 || unitCost > long.MaxValue) throw new ArgumentException("تكلفة الوحدة غير صحيحة.");
            if (!int.TryParse(_purchaseTaxRate.Text, NumberStyles.Integer, CultureInfo.InvariantCulture, out var taxRate) || taxRate < 0 || taxRate > 10000) throw new ArgumentException("معدل الضريبة يجب أن يكون بين 0 و10000 نقطة أساس.");
            if (!int.TryParse(_purchaseCurrencyScale.Text, NumberStyles.Integer, CultureInfo.InvariantCulture, out var scale) || scale < 0 || scale > 4) throw new ArgumentException("دقة العملة يجب أن تكون بين صفر و4.");
            var currency = _purchaseCurrency.Text.Trim().ToUpperInvariant(); if (currency.Length != 3) throw new ArgumentException("أدخل رمز عملة من ثلاثة أحرف.");
            var number = _purchaseOrderNumber.Text.Trim(); if (string.IsNullOrWhiteSpace(number)) throw new ArgumentException("رقم أمر الشراء مطلوب.");
            var quantityMilli = checked((long)decimal.Round(quantity * 1000m, 0, MidpointRounding.AwayFromZero));
            var costMinor = checked((long)decimal.Round(unitCost, 0, MidpointRounding.AwayFromZero));
            var draft = new PurchaseOrderDraft(Guid.NewGuid(), number, (Guid)_purchaseSupplier.SelectedValue, (Guid)_purchaseWarehouse.SelectedValue,
                currency, scale, new[] { new PurchaseOrderLineInput((Guid)_purchaseItem.SelectedValue, quantityMilli, costMinor, taxRate) });
            var totals = new PurchaseOrderStore(_databasePath).CreateDraft(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, draft);
            _purchaseOrderNumber.Clear();
            _purchaseSummary.Text = "تم إنشاء المسودة. الصافي: " + totals.SubtotalMinor + " | الضريبة: " + totals.TaxMinor + " | الإجمالي: " + totals.TotalMinor + " " + currency + " (القيم بوحدات العملة الصغرى).";
            LoadPurchaseOrders();
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void ChangePurchaseOrderState(bool approve)
    {
        try
        {
            if (!_session.HasPermission("commercial.purchases.manage")) throw new UnauthorizedAccessException("لا تملك صلاحية إدارة المشتريات.");
            if (_purchaseOrdersGrid.SelectedItem == null) throw new InvalidOperationException("حدد أمر شراء من القائمة أولاً.");
            var id = SelectedGridGuid(_purchaseOrdersGrid);
            var action = approve ? "اعتماد" : "إلغاء";
            if (MessageBox.Show("هل تريد " + action + " أمر الشراء المحدد؟", "تأكيد العملية", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            var store = new PurchaseOrderStore(_databasePath);
            if (approve) store.Approve(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, id);
            else store.Cancel(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, id);
            LoadPurchaseOrders();
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void LoadPurchaseOrders()
    {
        try
        {
            if (!_session.HasPermission("reports.read")) throw new UnauthorizedAccessException("لا تملك صلاحية قراءة أوامر الشراء.");
            var orders = new PurchaseOrderStore(_databasePath).List(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId);
            _purchaseOrdersGrid.ItemsSource = orders.Select(x => new { المعرف = x.Id, رقم_الأمر = x.Number, الحالة = ArabicPurchaseOrderStatus(x.Status), المورد = x.SupplierName, المستودع = x.WarehouseName, الإجمالي_بوحدات_العملة_الصغرى = x.TotalMinor, العملة = x.CurrencyCode, تاريخ_الإنشاء = x.CreatedAt.ToLocalTime() }).ToList();
            _purchaseSummary.Text = "أوامر الشراء في الفرع: " + orders.Count;
        }
        catch (Exception ex) { _purchaseOrdersGrid.ItemsSource = null; _purchaseSummary.Text = "تعذر قراءة أوامر الشراء: " + ex.Message; }
    }

    private void LoadPurchaseReceiptLines()
    {
        try
        {
            if (_purchaseOrdersGrid.SelectedItem == null) { _purchaseReceiptableLinesGrid.ItemsSource = null; return; }
            var orderId = SelectedGridGuid(_purchaseOrdersGrid);
            var lines = new PurchaseOrderReceiptStore(_databasePath).ListReceiptableLines(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, orderId);
            _purchaseReceiptableLinesGrid.ItemsSource = lines.Select(x => new PurchaseReceiptLineEntry { Id = x.Id,
                Item = x.Sku + " — " + x.ItemName, Approved = x.OrderedQuantityMilli / 1000m,
                Received = x.ReceivedQuantityMilli / 1000m, Remaining = x.RemainingQuantityMilli / 1000m,
                UnitCostMinor = x.UnitCostMinor, TaxRateBasisPoints = x.TaxRateBasisPoints, ReceiveNow = 0m }).ToList();
        }
        catch (Exception ex) { _purchaseReceiptableLinesGrid.ItemsSource = null; _purchaseSummary.Text = "تعذر تحميل بنود الاستلام: " + ex.Message; }
    }

    private void PostPurchaseReceipt()
    {
        try
        {
            if (!_session.HasPermission("commercial.purchases.manage")) throw new UnauthorizedAccessException("لا تملك صلاحية إدارة المشتريات.");
            if (_purchaseOrdersGrid.SelectedItem == null) throw new InvalidOperationException("حدد أمر شراء معتمداً أولاً.");
            _purchaseReceiptableLinesGrid.CommitEdit(DataGridEditingUnit.Cell, true);
            _purchaseReceiptableLinesGrid.CommitEdit(DataGridEditingUnit.Row, true);
            var entries = (_purchaseReceiptableLinesGrid.ItemsSource as System.Collections.Generic.IEnumerable<PurchaseReceiptLineEntry>)?.ToList()
                ?? new System.Collections.Generic.List<PurchaseReceiptLineEntry>();
            var selectedLines = entries.Where(x => x.ReceiveNow > 0m).ToList();
            if (selectedLines.Count == 0) throw new InvalidOperationException("أدخل كمية موجبة في عمود (استلام الآن) لبند واحد على الأقل.");
            if (selectedLines.Any(x => x.ReceiveNow > x.Remaining || x.ReceiveNow > 9_000_000_000m))
                throw new ArgumentException("إحدى كميات الاستلام تتجاوز الكمية المتبقية أو الحد المسموح.");
            var number = _purchaseReceiptNumber.Text.Trim(); if (string.IsNullOrWhiteSpace(number)) throw new ArgumentException("رقم سند الاستلام مطلوب.");
            if (MessageBox.Show($"سيتم ترحيل {selectedLines.Count} بنداً في سند واحد، وتسجيل حركات المخزون والتكلفة وإنشاء حدث محاسبي. لا يمكن تعديل سند مرحّل. متابعة؟", "تأكيد الاستلام", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
            var inputs = selectedLines.Select(x => new PurchaseOrderReceiptLineInput(x.Id,
                checked((long)decimal.Round(x.ReceiveNow * 1000m, 0, MidpointRounding.AwayFromZero)))).ToArray();
            var draft = new PurchaseOrderReceiptDraft(Guid.NewGuid(), number, SelectedGridGuid(_purchaseOrdersGrid), inputs);
            var result = new PurchaseOrderReceiptStore(_databasePath).Receive(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, draft);
            _purchaseReceiptNumber.Clear();
            _purchaseSummary.Text = "تم ترحيل سند الاستلام متعدد البنود (" + inputs.Length + "). الحالة: " + ArabicPurchaseOrderStatus(result.PurchaseOrderStatus) +
                " | الإجمالي: " + result.TotalMinor + " (وحدات العملة الصغرى). حدث Outbox أُنشئ؛ الترحيل المحاسبي الفعلي يعالجه العامل المحاسبي.";
            LoadPurchaseOrders(); LoadPurchaseReceiptLines(); LoadPurchaseReceipts();
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void LoadPurchaseReceipts()
    {
        try
        {
            if (_purchaseOrdersGrid.SelectedItem == null) { _purchaseReceiptsGrid.ItemsSource = null; return; }
            var orderId = SelectedGridGuid(_purchaseOrdersGrid);
            var receipts = new PurchaseOrderReceiptStore(_databasePath).List(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, orderId);
            _purchaseReceiptsGrid.ItemsSource = receipts.Select(x => new { رقم_السند = x.Number, رقم_أمر_الشراء = x.PurchaseOrderNumber,
                الإجمالي = x.TotalMinor, العملة = x.CurrencyCode, التاريخ = x.PostedAt.ToLocalTime() }).ToList();
        }
        catch (Exception ex) { _purchaseReceiptsGrid.ItemsSource = null; _purchaseSummary.Text = "تعذر تحميل سجل الاستلام: " + ex.Message; }
    }

    private void LoadSupplierInvoiceLines()
    {
        try
        {
            if (_purchaseOrdersGrid.SelectedItem == null) { _supplierInvoiceLinesGrid.ItemsSource = null; return; }
            var lines = new SupplierInvoiceStore(_databasePath).ListReceiptableLines(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, SelectedGridGuid(_purchaseOrdersGrid));
            _supplierInvoiceLinesGrid.ItemsSource = lines.Select(x => new SupplierInvoiceLineEntry { Id=x.ReceiptLineId,
                Receipt=x.ReceiptNumber, Item=x.Sku + " — " + x.ItemName, Received=x.ReceivedQuantityMilli/1000m,
                Invoiced=x.PreviouslyInvoicedQuantityMilli/1000m, Available=x.AvailableQuantityMilli/1000m,
                UnitPriceMinor=x.UnitPriceMinor, TaxRateBasisPoints=x.TaxRateBasisPoints, InvoiceNow=0m }).ToList();
        }
        catch (Exception ex) { _supplierInvoiceLinesGrid.ItemsSource=null; _purchaseSummary.Text="تعذر تحميل بنود فاتورة المورد: "+ex.Message; }
    }

    private void CreateSupplierInvoiceDraft()
    {
        try
        {
            if (_purchaseOrdersGrid.SelectedItem == null) throw new InvalidOperationException("حدد أمر الشراء أولاً.");
            _supplierInvoiceLinesGrid.CommitEdit(DataGridEditingUnit.Cell,true); _supplierInvoiceLinesGrid.CommitEdit(DataGridEditingUnit.Row,true);
            var rows=(_supplierInvoiceLinesGrid.ItemsSource as System.Collections.Generic.IEnumerable<SupplierInvoiceLineEntry>)?.ToList() ?? new();
            var selected=rows.Where(x=>x.InvoiceNow>0m).ToList();
            if(selected.Count==0) throw new InvalidOperationException("أدخل كمية موجبة في عمود (الفوترة الآن) لبند واحد على الأقل.");
            if(selected.Any(x=>x.InvoiceNow>x.Available || x.InvoiceNow>9_000_000_000m)) throw new ArgumentException("إحدى الكميات تتجاوز المتبقي غير المفوتر.");
            var number=_supplierInvoiceNumber.Text.Trim(); if(string.IsNullOrWhiteSpace(number)) throw new ArgumentException("رقم فاتورة المورد مطلوب.");
            if(_supplierInvoiceDate.SelectedDate is null) throw new ArgumentException("تاريخ فاتورة المورد مطلوب.");
            if(MessageBox.Show($"سيتم إنشاء مسودة فاتورة مورد من {selected.Count} بنداً. ستُحتسب الأسعار والضرائب وفق أمر الشراء، ولن تُنشأ ذمم أو قيود محاسبية عند إنشاء المسودة. متابعة؟","تأكيد مسودة الفاتورة",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes) return;
            var inputs=selected.Select(x=>new SupplierInvoiceLineInput(x.Id,checked((long)decimal.Round(x.InvoiceNow*1000m,0,MidpointRounding.AwayFromZero)))).ToArray();
            var result=new SupplierInvoiceStore(_databasePath).CreateDraft(_session.UserId,_ledgerSession.CompanyId,_ledgerSession.BranchId,SelectedGridGuid(_purchaseOrdersGrid),new SupplierInvoiceDraft(Guid.NewGuid(),number,_supplierInvoiceDate.SelectedDate.Value,inputs));
            _supplierInvoiceNumber.Clear(); _purchaseSummary.Text=$"تم إنشاء مسودة فاتورة المورد. الإجمالي: {result.TotalMinor} (وحدات العملة الصغرى). حددها من سجل الفواتير ثم رحّلها.";
            LoadSupplierInvoices(); LoadSupplierInvoiceLines();
        }
        catch(Exception ex){ShowError(ex);}
    }

    private void PostSupplierInvoice()
    {
        try
        {
            if(_supplierInvoicesGrid.SelectedItem==null) throw new InvalidOperationException("حدد فاتورة من سجل الفواتير.");
            var id=SelectedGridGuid(_supplierInvoicesGrid); if(id==Guid.Empty) throw new InvalidOperationException("تعذر قراءة معرف الفاتورة المحددة.");
            if(MessageBox.Show("سيتم ترحيل فاتورة المورد نهائياً وإنشاء حدث Outbox للمحاسبة. لا يمكن تعديل الفاتورة بعد الترحيل. لا تُنشأ ذمم دائنة أو قيود أستاذ عام في هذه المرحلة. متابعة؟","تأكيد ترحيل فاتورة المورد",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes) return;
            new SupplierInvoiceStore(_databasePath).Post(_session.UserId,_ledgerSession.CompanyId,_ledgerSession.BranchId,id);
            _purchaseSummary.Text="تم ترحيل فاتورة المورد وإنشاء حدث SupplierInvoicePosted في Outbox. لم يُنشأ قيد أستاذ عام أو رصيد ذمم دائنة.";
            LoadSupplierInvoices(); LoadSupplierInvoiceLines();
        }
        catch(Exception ex){ShowError(ex);}
    }

    private void LoadSupplierInvoices()
    {
        try
        {
            if(_purchaseOrdersGrid.SelectedItem==null){_supplierInvoicesGrid.ItemsSource=null;return;}
            var rows=new SupplierInvoiceStore(_databasePath).List(_session.UserId,_ledgerSession.CompanyId,_ledgerSession.BranchId,SelectedGridGuid(_purchaseOrdersGrid));
            _supplierInvoicesGrid.ItemsSource=rows.Select(x=>new { المعرف=x.Id, رقم_الفاتورة=x.Number, رقم_أمر_الشراء=x.PurchaseOrderNumber,
                الحالة=x.Status=="Draft"?"مسودة":x.Status=="Posted"?"مرحّلة":x.Status, التاريخ=x.InvoiceDate.ToString("yyyy-MM-dd"), الإجمالي=x.TotalMinor, العملة=x.CurrencyCode }).ToList();
        }
        catch(Exception ex){_supplierInvoicesGrid.ItemsSource=null;_purchaseSummary.Text="تعذر تحميل سجل فواتير المورد: "+ex.Message;}
    }

    private static string ArabicPurchaseOrderStatus(string status) => status switch
    {
        "Draft" => "مسودة", "Approved" => "معتمد", "Cancelled" => "ملغى", "PartiallyReceived" => "مستلم جزئياً", "Received" => "مستلم بالكامل", _ => status
    };

    private TabItem BuildCommercialSchemaUpgradeTab()
    {
        var panel = new StackPanel { Margin = new Thickness(20) };
        panel.Children.Add(Heading("ترقية مخطط الوحدة التجارية"));
        panel.Children.Add(new TextBlock
        {
            Text = "أداة إدارية صريحة. الفحص لا يغير قاعدة البيانات. قبل التطبيق أوقف أي نسخة أخرى من MONARCH، وتأكد من وجود مساحة كافية للنسخة الاحتياطية. لن تبدأ الترقية إلا بعد اختيار ملف النسخة الاحتياطية والموافقة النهائية.",
            TextWrapping = TextWrapping.Wrap, Foreground = Brush("#8A4B08"), Margin = new Thickness(2, 8, 2, 12)
        });
        var inspect = Button("فحص مخطط الوحدة التجارية");
        inspect.Click += (_, __) => InspectCommercialSchemaForUpgrade();
        panel.Children.Add(inspect);
        var apply = Button("تنفيذ الترقية بعد النسخ الاحتياطي");
        apply.Margin = new Thickness(0, 8, 0, 8);
        apply.Click += (_, __) => ApplyCommercialSchemaUpgrade();
        panel.Children.Add(apply);
        _schemaUpgradeSummary.TextWrapping = TextWrapping.Wrap;
        _schemaUpgradeSummary.Foreground = Brush("#173B68");
        _schemaUpgradeSummary.Margin = new Thickness(4, 10, 4, 4);
        _schemaUpgradeSummary.Text = "لم يتم إجراء فحص بعد.";
        panel.Children.Add(_schemaUpgradeSummary);
        return new TabItem { Header = "ترقية المخطط التجاري", Content = Scroll(panel) };
    }

    private string CommercialSchemaPath()
    {
        return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "database", "commercial-data.sql");
    }

    private void InspectCommercialSchemaForUpgrade()
    {
        if (!_session.HasPermission("users.manage") || !string.Equals(_session.RoleCode, "Administrator", StringComparison.OrdinalIgnoreCase))
        {
            ShowError(new UnauthorizedAccessException("ترقية المخطط متاحة لمدير النظام فقط."));
            return;
        }
        try
        {
            var schema = CommercialSchemaPath();
            _pendingSchemaUpgradePlan = new CommercialSchemaUpgradeService(_databasePath).Inspect(schema);
            var plan = _pendingSchemaUpgradePlan;
            _schemaUpgradeSummary.Text = "سلامة قاعدة البيانات: " + plan.Integrity + Environment.NewLine +
                "الجداول الموجودة: " + plan.PresentTableCount + " من " + plan.ExpectedTableCount + Environment.NewLine +
                "الجداول المفقودة: " + (plan.MissingTables.Length == 0 ? "لا يوجد" : string.Join("، ", plan.MissingTables)) + Environment.NewLine +
                "ترقية تسلسل حركات المخزون مطلوبة: " + (plan.NeedsMovementSequenceUpgrade ? "نعم" : "لا") + Environment.NewLine +
                "التوصية: " + (plan.UpgradeRecommended ? "توجد ترقية مطلوبة" : "المخطط مكتمل حسب الفحص" ) + Environment.NewLine +
                "ملف المخطط: " + schema;
        }
        catch (Exception ex) { _pendingSchemaUpgradePlan = null; ShowError(ex); }
    }

    private void ApplyCommercialSchemaUpgrade()
    {
        if (!_session.HasPermission("users.manage") || !string.Equals(_session.RoleCode, "Administrator", StringComparison.OrdinalIgnoreCase))
        {
            ShowError(new UnauthorizedAccessException("ترقية المخطط متاحة لمدير النظام فقط."));
            return;
        }
        if (_pendingSchemaUpgradePlan == null)
        {
            MessageBox.Show("نفّذ الفحص أولاً قبل الترقية.", "MONARCH ERP", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        if (!_pendingSchemaUpgradePlan.UpgradeRecommended)
        {
            MessageBox.Show("لا توجد ترقية مطلوبة وفق نتيجة الفحص الحالية.", "MONARCH ERP", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var backupDialog = new SaveFileDialog
        {
            Title = "اختر موقع النسخة الاحتياطية قبل الترقية",
            Filter = "SQLite backup (*.db)|*.db|All files (*.*)|*.*",
            FileName = "monarch-before-commercial-upgrade-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".db",
            InitialDirectory = _backupDirectory,
            OverwritePrompt = false
        };
        if (backupDialog.ShowDialog(this) != true) return;
        var confirmation = MessageBox.Show(
            "سيتم إنشاء نسخة احتياطية والتحقق منها ثم ترقية المخطط التجاري.

أغلق جميع نسخ MONARCH الأخرى التي تستخدم قاعدة البيانات. احتفظ بالنسخة الاحتياطية ولا تحذفها قبل التحقق من النظام.

هل توافق على تنفيذ الترقية الآن؟",
            "تأكيد ترقية قاعدة البيانات", MessageBoxButton.YesNo, MessageBoxImage.Warning);
        if (confirmation != MessageBoxResult.Yes) return;
        try
        {
            var result = new CommercialSchemaUpgradeService(_databasePath).Apply(CommercialSchemaPath(), backupDialog.FileName, true);
            _pendingSchemaUpgradePlan = null;
            _schemaUpgradeSummary.Text = result.Message + Environment.NewLine + "النسخة الاحتياطية: " + result.BackupPath + Environment.NewLine + "Integrity: " + result.Integrity;
            MessageBox.Show("اكتملت الترقية. يوصى بإغلاق MONARCH وإعادة تشغيله قبل متابعة العمل.

النسخة الاحتياطية محفوظة في:
" + result.BackupPath,
                "اكتملت الترقية", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { _pendingSchemaUpgradePlan = null; ShowError(ex); }
    }

    private void LoadMasterData()
    {
        if (!_session.HasPermission("inventory.read"))
        {
            ShowError(new UnauthorizedAccessException("لا تملك صلاحية قراءة دليل المخزون."));
            return;
        }
        try
        {
            var store = new CommercialStore(_databasePath);
            var items = store.GetItems(_session.UserId, _ledgerSession.CompanyId, false);
            var warehouses = store.GetWarehouses(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, false);
            var masterStore = new InventoryMasterDataStore(_databasePath);
            var groups = masterStore.GetItemGroups(_session.UserId, _ledgerSession.CompanyId).ToList();
            var units = masterStore.GetUnits(_session.UserId, _ledgerSession.CompanyId).ToList();
            _masterItemsGrid.ItemsSource = items.Select(x => new
            {
                المعرف = x.Id,
                رمز_الصنف = x.Sku,
                اسم_الصنف = x.Name,
                النوع = x.Type,
                الوحدة = x.UnitId,
                الباركود = x.Barcode ?? "—",
                مجموعة_الصنف = x.GroupId,
                التكلفة_الافتراضية = x.CostMinor,
                سعر_البيع = x.SalePriceMinor,
                حد_إعادة_الطلب_بالألف = x.ReorderLevelMilli,
                السماح_بالسالب = x.AllowNegative,
                الحالة = x.IsActive ? "نشط" : "غير نشط"
            }).ToList();
            _masterWarehousesGrid.ItemsSource = warehouses.Select(x => new
            {
                المعرف = x.Id,
                الرمز = x.Code,
                الاسم = x.Name,
                الحالة = x.IsActive ? "نشط" : "غير نشط"
            }).ToList();
            if (_session.HasPermission("inventory.read"))
            {
                _itemGroupsGrid.ItemsSource = groups.Select(x => new { المعرف = x.Id, الرمز = x.Code, الاسم = x.Name, المجموعة_الأم = x.ParentId?.ToString() ?? "—", الحالة = x.IsActive ? "نشط" : "غير نشط" }).ToList();
                _unitsGrid.ItemsSource = units.Select(x => new { المعرف = x.Id, الرمز = x.Code, الاسم = x.Name, المنازل_العشرية = x.DecimalPlaces }).ToList();
            }
            _masterDataSummary.Text = "الأصناف: " + items.Count + " | مستودعات الفرع: " + warehouses.Count +
                " | مجموعات الأصناف: " + groups.Count + " | وحدات القياس: " + units.Count +
                " | المنشأة: " + _ledgerSession.CompanyName + " | الفرع: " + _ledgerSession.BranchName;
            SetStatus("تم تحديث دليل الأصناف والمستودعات");
        }
        catch (Exception ex)
        {
            _masterItemsGrid.ItemsSource = null;
            _masterWarehousesGrid.ItemsSource = null;
            _masterDataSummary.Text = "تعذر قراءة الدليل. تحقق من تهيئة مخطط الوحدة التجارية وصلاحيات المنشأة والفرع. لم يُنفذ أي ترحيل.";
            ShowError(ex);
        }
    }

    private void CreateInventoryItem()
    {
        if (!_session.HasPermission("inventory.items.manage")) { ShowError(new UnauthorizedAccessException("لا تملك صلاحية إدارة الأصناف.")); return; }
        try
        {
            var store = new InventoryMasterDataStore(_databasePath);
            var units = store.GetUnits(_session.UserId, _ledgerSession.CompanyId);
            if (units.Count == 0) { MessageBox.Show("لا توجد وحدات قياس معرفة لهذه المنشأة. أضف وحدة قياس قبل إنشاء الأصناف.", "MONARCH ERP", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
            var sku = PromptText("رمز الصنف", "إضافة صنف", ""); if (sku == null) return;
            var name = PromptText("اسم الصنف", "إضافة صنف", ""); if (name == null) return;
            var unitText = PromptText("أدخل معرف وحدة القياس من دليل الوحدات:\n" + string.Join("\n", units.Select(x => x.Code + " — " + x.Name + " — " + x.Id)), "وحدة القياس", units[0].Id.ToString());
            if (unitText == null) return;
            if (!Guid.TryParse(unitText, out var unitId) || !units.Any(x => x.Id == unitId)) throw new ArgumentException("معرف وحدة القياس غير صحيح أو غير تابع للمنشأة.");
            var typeText = PromptText("نوع الصنف: Stock أو Service أو NonStock", "نوع الصنف", "Stock"); if (typeText == null) return;
            if (!Enum.TryParse<ItemType>(typeText, true, out var type) || !Enum.IsDefined(typeof(ItemType), type)) throw new ArgumentException("نوع الصنف غير صالح.");
            store.CreateItem(_session.UserId, _ledgerSession.CompanyId, new StockItem(Guid.NewGuid(), unitId, sku, name, type));
            LoadMasterData(); SetStatus("تم إنشاء الصنف وتسجيل العملية في سجل التدقيق.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void EditSelectedInventoryItem()
    {
        if (!_session.HasPermission("inventory.items.manage")) { ShowError(new UnauthorizedAccessException("لا تملك صلاحية إدارة الأصناف.")); return; }
        try
        {
            var row = _masterItemsGrid.SelectedItem ?? throw new InvalidOperationException("حدد صنفاً من الجدول أولاً.");
            var id = SelectedGridGuid(_masterItemsGrid);
            var sku = PromptText("رمز الصنف", "تعديل صنف", SelectedGridText(row, "رمز_الصنف")); if (sku == null) return;
            var name = PromptText("اسم الصنف", "تعديل صنف", SelectedGridText(row, "اسم_الصنف")); if (name == null) return;
            var store = new InventoryMasterDataStore(_databasePath);
            var units = store.GetUnits(_session.UserId, _ledgerSession.CompanyId);
            var unitDefault = SelectedGridText(row, "الوحدة");
            var unitText = PromptText("معرف وحدة القياس:\n" + string.Join("\n", units.Select(x => x.Code + " — " + x.Name + " — " + x.Id)), "وحدة القياس", unitDefault);
            if (unitText == null) return;
            if (!Guid.TryParse(unitText, out var unitId) || !units.Any(x => x.Id == unitId)) throw new ArgumentException("وحدة القياس غير صحيحة أو لا تتبع المنشأة.");
            var typeText = PromptText("نوع الصنف: Stock أو Service أو NonStock", "نوع الصنف", SelectedGridText(row, "النوع")); if (typeText == null) return;
            if (!Enum.TryParse<ItemType>(typeText, true, out var type) || !Enum.IsDefined(typeof(ItemType), type)) throw new ArgumentException("نوع الصنف غير صالح.");
            var item = new StockItem(id, unitId, sku, name, type,
                SelectedGridLong(row, "التكلفة_الافتراضية"), SelectedGridLong(row, "سعر_البيع"),
                SelectedGridLong(row, "حد_إعادة_الطلب_بالألف"), SelectedGridNullableGuid(row, "مجموعة_الصنف"),
                SelectedGridText(row, "الباركود") == "—" ? null : SelectedGridText(row, "الباركود"),
                SelectedGridBool(row, "السماح_بالسالب"), true);
            store.UpdateItem(_session.UserId, _ledgerSession.CompanyId, item);
            LoadMasterData(); SetStatus("تم تعديل الصنف وتسجيل التغيير في سجل التدقيق.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void EditSelectedInventoryWarehouse()
    {
        if (!_session.HasPermission("inventory.warehouses.manage")) { ShowError(new UnauthorizedAccessException("لا تملك صلاحية إدارة المستودعات.")); return; }
        try
        {
            var row = _masterWarehousesGrid.SelectedItem ?? throw new InvalidOperationException("حدد مستودعاً من الجدول أولاً.");
            var id = SelectedGridGuid(_masterWarehousesGrid);
            var code = PromptText("رمز المستودع", "تعديل مستودع", SelectedGridText(row, "الرمز")); if (code == null) return;
            var name = PromptText("اسم المستودع", "تعديل مستودع", SelectedGridText(row, "الاسم")); if (name == null) return;
            new InventoryMasterDataStore(_databasePath).UpdateWarehouse(_session.UserId, _ledgerSession.CompanyId,
                new Warehouse(id, _ledgerSession.BranchId, code, name, true));
            LoadMasterData(); SetStatus("تم تعديل المستودع وتسجيل التغيير في سجل التدقيق.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void CreateInventoryWarehouse()
    {
        if (!_session.HasPermission("inventory.warehouses.manage")) { ShowError(new UnauthorizedAccessException("لا تملك صلاحية إدارة المستودعات.")); return; }
        try
        {
            var code = PromptText("رمز المستودع", "إضافة مستودع", ""); if (code == null) return;
            var name = PromptText("اسم المستودع", "إضافة مستودع", ""); if (name == null) return;
            new InventoryMasterDataStore(_databasePath).CreateWarehouse(_session.UserId, _ledgerSession.CompanyId,
                new Warehouse(Guid.NewGuid(), _ledgerSession.BranchId, code, name));
            LoadMasterData(); SetStatus("تم إنشاء المستودع في الفرع الحالي وتسجيل العملية في سجل التدقيق.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void SetSelectedItemActive(bool active)
    {
        try
        {
            if (!_session.HasPermission("inventory.items.manage")) throw new UnauthorizedAccessException("لا تملك صلاحية إدارة الأصناف.");
            var id = SelectedGridGuid(_masterItemsGrid); if (id == Guid.Empty) throw new InvalidOperationException("حدد صنفاً من الجدول أولاً.");
            if (MessageBox.Show("سيتم تغيير حالة الصنف دون حذف سجلاته التاريخية. متابعة؟", "تأكيد", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
            new InventoryMasterDataStore(_databasePath).SetItemActive(_session.UserId, _ledgerSession.CompanyId, id, active);
            LoadMasterData();
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void SetSelectedWarehouseActive(bool active)
    {
        try
        {
            if (!_session.HasPermission("inventory.warehouses.manage")) throw new UnauthorizedAccessException("لا تملك صلاحية إدارة المستودعات.");
            var id = SelectedGridGuid(_masterWarehousesGrid); if (id == Guid.Empty) throw new InvalidOperationException("حدد مستودعاً من الجدول أولاً.");
            if (MessageBox.Show("سيتم تغيير حالة المستودع دون حذف سجلاته. لا يمكن تعطيله إذا كانت له أرصدة غير صفرية. متابعة؟", "تأكيد", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
            new InventoryMasterDataStore(_databasePath).SetWarehouseActive(_session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, id, active);
            LoadMasterData();
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private static object SelectedGridValue(object row, string property)
    {
        var value = row.GetType().GetProperty(property)?.GetValue(row);
        return value ?? throw new InvalidOperationException("تعذر قراءة الحقل المحدد: " + property);
    }
    private static string SelectedGridText(object row, string property) => Convert.ToString(SelectedGridValue(row, property), CultureInfo.InvariantCulture) ?? string.Empty;
    private static long SelectedGridLong(object row, string property) => Convert.ToInt64(SelectedGridValue(row, property), CultureInfo.InvariantCulture);
    private static bool SelectedGridBool(object row, string property) => Convert.ToBoolean(SelectedGridValue(row, property), CultureInfo.InvariantCulture);
    private static Guid? SelectedGridNullableGuid(object row, string property)
    {
        var value = row.GetType().GetProperty(property)?.GetValue(row);
        return value == null ? null : (Guid?)Guid.Parse(Convert.ToString(value, CultureInfo.InvariantCulture));
    }

    private static Guid SelectedGridGuid(DataGrid grid)
    {
        if (grid.SelectedItem == null) return Guid.Empty;
        var property = grid.SelectedItem.GetType().GetProperty("المعرف");
        return property != null && Guid.TryParse(Convert.ToString(property.GetValue(grid.SelectedItem)), out var id) ? id : Guid.Empty;
    }

    private string PromptText(string label, string title, string initial)
    {
        var dialog = new Window { Title = title, Owner = this, Width = 520, Height = 190, WindowStartupLocation = WindowStartupLocation.CenterOwner, ResizeMode = ResizeMode.NoResize };
        var panel = new StackPanel { Margin = new Thickness(14) };
        panel.Children.Add(new TextBlock { Text = label, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 8) });
        var input = new TextBox { Text = initial, MinWidth = 460, Margin = new Thickness(0, 0, 0, 12) }; panel.Children.Add(input);
        var buttons = new WrapPanel { HorizontalAlignment = HorizontalAlignment.Right };
        var ok = Button("موافق"); ok.Click += (_, __) => { dialog.DialogResult = true; dialog.Close(); };
        var cancel = Button("إلغاء"); cancel.Margin = new Thickness(8, 0, 0, 0); cancel.Click += (_, __) => { dialog.DialogResult = false; dialog.Close(); };
        buttons.Children.Add(ok); buttons.Children.Add(cancel); panel.Children.Add(buttons); dialog.Content = panel;
        return dialog.ShowDialog() == true ? input.Text.Trim() : null;
    }

    private TabItem BuildInventoryAuditTab()
    {
        var panel = new DockPanel { Margin = new Thickness(18) };
        var top = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
        top.Children.Add(Heading("تدقيق ترابط حركات المخزون والمحاسبة"));
        top.Children.Add(new TextBlock
        {
            Text = "تقرير قراءة فقط يربط الحركة بالمستند وتخصيص التكلفة وOutbox وقيد الأستاذ. نطاق الفحص هو المنشأة والفرع الحاليان، ولا ينفذ أي إصلاح أو ترحيل.",
            TextWrapping = TextWrapping.Wrap, Foreground = Brush("#65758B"), Margin = new Thickness(3, 0, 3, 8)
        });
        var filters = new WrapPanel { VerticalAlignment = VerticalAlignment.Center };
        _inventoryAuditDate.SelectedDate = DateTime.Today;
        filters.Children.Add(Labelled("تاريخ القطع (حتى نهاية اليوم المحلي)", _inventoryAuditDate, 210));
        var inspect = Button("تنفيذ فحص التدقيق");
        inspect.Click += (_, __) => InspectInventoryLineage();
        filters.Children.Add(inspect);
        top.Children.Add(filters);
        _inventoryAuditSummary.Margin = new Thickness(4, 8, 4, 8);
        _inventoryAuditSummary.TextWrapping = TextWrapping.Wrap;
        _inventoryAuditSummary.Foreground = Brush("#173B68");
        top.Children.Add(_inventoryAuditSummary);
        DockPanel.SetDock(top, Dock.Top);
        panel.Children.Add(top);
        ConfigureGrid(_inventoryLineageGrid);
        panel.Children.Add(_inventoryLineageGrid);
        return new TabItem { Header = "تدقيق المخزون", Content = panel };
    }

    private void InspectInventoryLineage()
    {
        if (!_session.HasPermission("reports.read"))
        {
            ShowError(new UnauthorizedAccessException("لا تملك صلاحية قراءة تقارير التدقيق."));
            return;
        }
        if (!_inventoryAuditDate.SelectedDate.HasValue)
        {
            ShowError(new ArgumentException("حدد تاريخ القطع أولاً."));
            return;
        }
        try
        {
            var localEnd = DateTime.SpecifyKind(_inventoryAuditDate.SelectedDate.Value.Date.AddDays(1).AddTicks(-1), DateTimeKind.Unspecified);
            var utcEnd = TimeZoneInfo.ConvertTimeToUtc(localEnd, TimeZoneInfo.Local);
            var cutoff = new DateTimeOffset(utcEnd, TimeSpan.Zero);
            var result = new InventoryMovementLineageStore(_databasePath).Inspect(
                _session.UserId, _ledgerSession.CompanyId, _ledgerSession.BranchId, cutoff);
            _inventoryLineageGrid.ItemsSource = result.Entries.Select(x => new
            {
                الحركة = x.MovementId,
                التاريخ_UTC = x.OccurredUtc.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                التسلسل = x.LedgerSequence,
                نوع_الحركة = x.MovementType,
                المستودع = x.WarehouseCode,
                الصنف = x.Sku,
                اسم_الصنف = x.ItemName,
                الكمية_بالألف = x.QuantityMilli,
                تكلفة_الوحدة_بالعملة_الصغرى = x.UnitCostMinor,
                نوع_المصدر = x.SourceType ?? "—",
                رقم_المستند = x.SourceRecordNumber ?? "—",
                تخصيص_التكلفة = x.AllocationType ?? "—",
                إجمالي_التكلفة_بالعملة_الصغرى = x.AllocatedCostMinor,
                حالة_Outbox = x.OutboxStatus ?? "—",
                رقم_القيد = x.JournalNumber ?? "—",
                حالة_القيد = x.JournalStatus ?? "—",
                نتيجة_التدقيق = ArabicLineageState(x.State)
            }).ToList();
            _inventoryAuditSummary.Text = "الحركات: " + result.MovementCount +
                " | مرتبطة بالكامل: " + result.FullyLinkedCount +
                " | استثناءات تحتاج مراجعة: " + result.ExceptionCount +
                " | حتى UTC: " + result.AsOfUtc.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
            SetStatus("اكتمل فحص ترابط المخزون | " + result.ExceptionCount + " استثناء");
        }
        catch (Exception ex)
        {
            _inventoryLineageGrid.ItemsSource = null;
            _inventoryAuditSummary.Text = "تعذر إكمال الفحص. تحقق من وجود مخططات وحدة المخزون وصلاحيات التقارير.";
            ShowError(ex);
        }
    }

    private static string ArabicLineageState(InventoryLineageState state) => state switch
    {
        InventoryLineageState.Linked => "مرتبط بالكامل",
        InventoryLineageState.SourceNotRequired => "لا يتطلب مستنداً تجارياً",
        InventoryLineageState.TransferPaired => "تحويل مزدوج متطابق",
        InventoryLineageState.TransferPairIncomplete => "تحويل غير مكتمل",
        InventoryLineageState.MissingCostAllocation => "تخصيص تكلفة مفقود",
        InventoryLineageState.MissingReturnCostAllocation => "تخصيص تكلفة المرتجع مفقود",
        InventoryLineageState.MissingSourceDocument => "المستند المصدر مفقود",
        InventoryLineageState.MissingAccountingOutbox => "حدث الترحيل المحاسبي مفقود",
        InventoryLineageState.OutboxPending => "الترحيل المحاسبي قيد الانتظار",
        InventoryLineageState.OutboxFailed => "فشل الترحيل المحاسبي",
        InventoryLineageState.MissingJournal => "القيد المحاسبي مفقود",
        InventoryLineageState.JournalNotPosted => "القيد غير مرحّل",
        _ => "مصدر حركة غير مصنف"
    };

    private TabItem BuildUsersTab()
    {
        var panel = new DockPanel { Margin = new Thickness(18) };
        var form = new WrapPanel { Margin = new Thickness(0, 0, 0, 12) };
        form.Children.Add(Labelled("اسم المستخدم", _newUsername, 150));
        form.Children.Add(Labelled("الاسم الظاهر", _newDisplayName, 190));
        form.Children.Add(Labelled("كلمة المرور (12+)", _newPassword, 180));
        _newRole.Items.Add(new ComboBoxItem { Content = "محاسب", Tag = "Accountant" });
        _newRole.Items.Add(new ComboBoxItem { Content = "مشاهد", Tag = "Viewer" });
        _newRole.Items.Add(new ComboBoxItem { Content = "مدير النظام", Tag = "Administrator" });
        _newRole.SelectedIndex = 0;
        form.Children.Add(Labelled("الدور", _newRole, 130));
        var add = Button("إنشاء مستخدم");
        add.Click += CreateUser_Click;
        form.Children.Add(add);
        _editUserRole.Items.Clear();
        _editUserRole.Items.Add(new ComboBoxItem { Content = "مدير النظام", Tag = "Administrator" });
        _editUserRole.Items.Add(new ComboBoxItem { Content = "محاسب", Tag = "Accountant" });
        _editUserRole.Items.Add(new ComboBoxItem { Content = "مشاهد", Tag = "Viewer" });
        _editUserRole.SelectedIndex = 1;
        form.Children.Add(Labelled("الدور الجديد للمستخدم المحدد", _editUserRole, 190));
        var changeRole = Button("تغيير الدور");
        changeRole.Click += ChangeUserRole_Click;
        form.Children.Add(changeRole);
        var deactivate = Button("تعطيل المستخدم المحدد");
        deactivate.Click += DeactivateUser_Click;
        form.Children.Add(deactivate);
        DockPanel.SetDock(form, Dock.Top);
        panel.Children.Add(form);
        panel.Children.Add(new TextBlock { Text = "يُمنح المستخدم الجديد صلاحية على المنشأة والفرع الحاليين فقط وفق الدور المختار.", Foreground = Brush("#65758B"), Margin = new Thickness(4, 0, 4, 10), TextWrapping = TextWrapping.Wrap });
        ConfigureGrid(_usersGrid);
        panel.Children.Add(_usersGrid);
        RefreshUsers();
        return new TabItem { Header = "المستخدمون والصلاحيات", Content = panel };
    }

    private TabItem BuildTenantAuditLogTab()
    {
        IdentityStore.Require(_session, "users.manage");
        var panel = new DockPanel { Margin = new Thickness(18) };
        var top = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
        top.Children.Add(Heading("سجل التدقيق الموحد للمنشأة والفرع"));
        top.Children.Add(new TextBlock
        {
            Text = "يعرض هذا المركز أحداث سجل المنشأة المسجلة في قاعدة البيانات الحالية فقط، ضمن المنشأة والفرع المحددين. لا يشمل بعد سجلات الملفات المحلية أو الأجهزة الأخرى.",
            TextWrapping = TextWrapping.Wrap, Foreground = Brush("#8A4B08"), Margin = new Thickness(3, 3, 3, 9)
        });
        var filters = new WrapPanel();
        var from = new DatePicker { Width = 135, SelectedDate = DateTime.Today.AddDays(-30), Margin = new Thickness(3) };
        var to = new DatePicker { Width = 135, SelectedDate = DateTime.Today, Margin = new Thickness(3) };
        var action = new TextBox { Width = 150, Margin = new Thickness(3), ToolTip = "جزء من اسم العملية" };
        var entity = new ComboBox { Width = 125, Margin = new Thickness(3), ItemsSource = new[] { "الكل", "User", "Company", "Branch", "Journal", "Inventory", "PurchaseOrder", "SupplierInvoice" }, SelectedIndex = 0 };
        var actor = new TextBox { Width = 235, Margin = new Thickness(3), ToolTip = "معرف المستخدم المنفذ (اختياري GUID)" };
        filters.Children.Add(Labelled("من", from, 150));
        filters.Children.Add(Labelled("إلى", to, 150));
        filters.Children.Add(Labelled("العملية", action, 165));
        filters.Children.Add(Labelled("نوع الكيان", entity, 140));
        filters.Children.Add(Labelled("معرف المنفذ", actor, 245));
        var grid = new DataGrid { AutoGenerateColumns = true, IsReadOnly = true, Height = 390, Margin = new Thickness(0, 8, 0, 8) };
        var status = new TextBlock { Margin = new Thickness(3, 5, 3, 8), TextWrapping = TextWrapping.Wrap, Foreground = Brush("#173B68") };
        Action refresh = () =>
        {
            try
            {
                IdentityStore.Require(_session, "users.manage");
                DateTime? fromUtc = from.SelectedDate.HasValue ? TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(from.SelectedDate.Value.Date, DateTimeKind.Unspecified), TimeZoneInfo.Local) : (DateTime?)null;
                DateTime? toUtc = to.SelectedDate.HasValue ? TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(to.SelectedDate.Value.Date.AddDays(1).AddTicks(-1), DateTimeKind.Unspecified), TimeZoneInfo.Local) : (DateTime?)null;
                Guid? actorId = null;
                if (!string.IsNullOrWhiteSpace(actor.Text)) actorId = Guid.Parse(actor.Text.Trim());
                var entityType = Convert.ToString(entity.SelectedItem, CultureInfo.InvariantCulture);
                var rows = new TenantAuditLogReader(_databasePath).Read(_session, _ledgerSession.CompanyId, _ledgerSession.BranchId,
                    fromUtc, toUtc, action.Text, entityType == "الكل" ? null : entityType, actorId, 1000);
                grid.ItemsSource = rows.Select(x => new
                {
                    رقم_السجل = x.Id,
                    التاريخ_UTC = x.OccurredUtc.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                    المنفذ = x.ActorName,
                    معرف_المنفذ = x.ActorUserId,
                    العملية = x.Action,
                    نوع_الكيان = x.EntityType,
                    معرف_الكيان = x.EntityId,
                    التفاصيل = x.Details
                }).ToList();
                status.Text = "السجلات المعروضة: " + rows.Count.ToString(CultureInfo.InvariantCulture) + " | النطاق: المنشأة والفرع الحاليان | الحد الأقصى: 1000 سجل.";
            }
            catch (Exception ex)
            {
                grid.ItemsSource = null;
                status.Text = "تعذر قراءة سجل التدقيق. تحقق من صلاحية users.manage ونطاق العضوية وصحة المرشحات.";
                ShowError(ex);
            }
        };
        var refreshButton = Button("بحث وتحديث السجل");
        refreshButton.Click += (_, __) => refresh();
        filters.Children.Add(refreshButton);
        top.Children.Add(filters);
        top.Children.Add(status);
        DockPanel.SetDock(top, Dock.Top);
        panel.Children.Add(top);
        panel.Children.Add(grid);
        refresh();
        return new TabItem { Header = "سجل التدقيق الموحد", Content = panel };
    }

    private TabItem BuildDirectoryAdminTab()
    {
        var panel = new StackPanel { Margin = new Thickness(18) };
        panel.Children.Add(Heading("إدارة المنشآت والفروع والصلاحيات"));
        panel.Children.Add(new TextBlock
        {
            Text = "هذه الشاشة متاحة لمدير النظام العام فقط. إنشاء المنشأة يمنح المدير الحالي صلاحية Administrator عليها، بينما تُمنح الحسابات الأخرى الصلاحيات على منشأة وفرع محددين.",
            TextWrapping = TextWrapping.Wrap, Foreground = Brush("#65758B"), Margin = new Thickness(3, 0, 3, 12)
        });

        var companyBox = new GroupBox { Header = "إنشاء منشأة جديدة", Padding = new Thickness(10), Margin = new Thickness(0, 4, 0, 12) };
        var companyForm = new WrapPanel();
        companyForm.Children.Add(Labelled("رمز المنشأة", _companyCode, 110));
        companyForm.Children.Add(Labelled("الاسم القانوني", _companyLegalName, 190));
        companyForm.Children.Add(Labelled("الاسم الظاهر", _companyDisplayName, 170));
        companyForm.Children.Add(Labelled("الدولة ISO", _companyCountry, 70));
        companyForm.Children.Add(Labelled("العملة ISO", _companyCurrency, 80));
        companyForm.Children.Add(Labelled("المنطقة الزمنية", _companyTimeZone, 150));
        var createCompany = Button("إنشاء المنشأة");
        createCompany.Click += CreateCompany_Click;
        companyForm.Children.Add(createCompany);
        companyBox.Content = companyForm;
        panel.Children.Add(companyBox);

        var branchBox = new GroupBox { Header = "إضافة فرع", Padding = new Thickness(10), Margin = new Thickness(0, 4, 0, 12) };
        var branchForm = new WrapPanel();
        branchForm.Children.Add(Labelled("المنشأة", _adminCompanies, 230));
        branchForm.Children.Add(Labelled("رمز الفرع", _branchCode, 110));
        branchForm.Children.Add(Labelled("اسم الفرع", _branchName, 180));
        var createBranch = Button("إضافة الفرع");
        createBranch.Click += CreateBranch_Click;
        branchForm.Children.Add(createBranch);
        branchBox.Content = branchForm;
        panel.Children.Add(branchBox);

        var accessBox = new GroupBox { Header = "منح مستخدم صلاحية على منشأة وفرع", Padding = new Thickness(10), Margin = new Thickness(0, 4, 0, 12) };
        var accessForm = new WrapPanel();
        accessForm.Children.Add(Labelled("المستخدم", _accessUsers, 190));
        accessForm.Children.Add(Labelled("المنشأة", _accessCompanies, 230));
        accessForm.Children.Add(Labelled("الفرع", _accessBranches, 230));
        _accessRole.Items.Clear();
        _accessRole.Items.Add(new ComboBoxItem { Content = "مدير منشأة", Tag = "Administrator" });
        _accessRole.Items.Add(new ComboBoxItem { Content = "محاسب", Tag = "Accountant" });
        _accessRole.Items.Add(new ComboBoxItem { Content = "مشاهد", Tag = "Viewer" });
        _accessRole.SelectedIndex = 1;
        accessForm.Children.Add(Labelled("الدور", _accessRole, 150));
        var grant = Button("منح الصلاحية");
        grant.Click += GrantDirectoryAccess_Click;
        accessForm.Children.Add(grant);
        var revoke = Button("سحب عضوية المنشأة بالكامل");
        revoke.Click += RevokeDirectoryAccess_Click;
        accessForm.Children.Add(revoke);
        accessBox.Content = accessForm;
        panel.Children.Add(accessBox);

        _adminCompanies.DisplayMemberPath = "DisplayName";
        _accessCompanies.DisplayMemberPath = "DisplayName";
        _accessBranches.DisplayMemberPath = "Name";
        _accessUsers.DisplayMemberPath = "DisplayName";
        _adminCompanies.SelectionChanged += (_, __) => { };
        _accessCompanies.SelectionChanged += (_, __) => RefreshAccessBranches();
        RefreshDirectoryAdminLists();
        return new TabItem { Header = "إدارة المنشآت", Content = Scroll(panel) };
    }

    private void RefreshDirectoryAdminLists()
    {
        var companies = _directory.GetCompanies().Where(c => c.IsActive).ToList();
        _adminCompanies.ItemsSource = companies;
        _accessCompanies.ItemsSource = companies;
        if (companies.Count > 0)
        {
            _adminCompanies.SelectedIndex = Math.Max(0, _adminCompanies.SelectedIndex);
            _accessCompanies.SelectedIndex = Math.Max(0, _accessCompanies.SelectedIndex);
        }
        _accessUsers.ItemsSource = _identity.GetUsers(_session).Where(u => u.IsActive).ToList();
        RefreshAccessBranches();
    }

    private void RefreshAccessBranches()
    {
        _accessBranches.ItemsSource = null;
        if (_accessCompanies.SelectedItem is CompanySummary company)
        {
            _accessBranches.ItemsSource = _directory.GetBranches(company.Id).Where(b => b.IsActive).ToList();
            if (_accessBranches.Items.Count > 0) _accessBranches.SelectedIndex = 0;
        }
    }

    private void CreateCompany_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            IdentityStore.Require(_session, "users.manage");
            if (!string.Equals(_session.RoleCode, "Administrator", StringComparison.OrdinalIgnoreCase))
                throw new UnauthorizedAccessException("إنشاء المنشآت متاح لمدير النظام العام فقط.");
            _directory.CreateCompanyForAdministrator(_companyCode.Text, _companyLegalName.Text,
                _companyDisplayName.Text, _companyCountry.Text, _companyCurrency.Text, _companyTimeZone.Text, _session.UserId);
            _companyCode.Clear(); _companyLegalName.Clear(); _companyDisplayName.Clear();
            RefreshDirectoryAdminLists();
            SetStatus("تم إنشاء المنشأة والمقر الرئيسي ومنح المدير الحالي صلاحية الإدارة.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void CreateBranch_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            IdentityStore.Require(_session, "users.manage");
            if (!string.Equals(_session.RoleCode, "Administrator", StringComparison.OrdinalIgnoreCase))
                throw new UnauthorizedAccessException("إدارة الفروع متاحة لمدير النظام العام فقط.");
            if (!(_adminCompanies.SelectedItem is CompanySummary company))
                throw new InvalidOperationException("اختر المنشأة أولاً.");
            _directory.CreateBranch(company.Id, _branchCode.Text, _branchName.Text, _session.UserId);
            _branchCode.Clear(); _branchName.Clear();
            RefreshDirectoryAdminLists();
            SetStatus("تمت إضافة الفرع.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void GrantDirectoryAccess_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            IdentityStore.Require(_session, "users.manage");
            if (!string.Equals(_session.RoleCode, "Administrator", StringComparison.OrdinalIgnoreCase))
                throw new UnauthorizedAccessException("منح صلاحيات المنشآت متاح لمدير النظام العام فقط.");
            if (!(_accessUsers.SelectedItem is UserSummary user) ||
                !(_accessCompanies.SelectedItem is CompanySummary company) ||
                !(_accessBranches.SelectedItem is BranchSummary branch) ||
                !(_accessRole.SelectedItem is ComboBoxItem role))
                throw new InvalidOperationException("اختر المستخدم والمنشأة والفرع والدور.");
            _directory.GrantCompanyAndBranchAccess(user.Id, company.Id, branch.Id, (string)role.Tag, _session.UserId);
            SetStatus("تم منح الصلاحية وتسجيلها في سجل تدقيق المنشأة.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void RevokeDirectoryAccess_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            IdentityStore.Require(_session, "users.manage");
            if (!string.Equals(_session.RoleCode, "Administrator", StringComparison.OrdinalIgnoreCase))
                throw new UnauthorizedAccessException("سحب عضويات المنشآت متاح لمدير النظام العام فقط.");
            if (!(_accessUsers.SelectedItem is UserSummary user) || !(_accessCompanies.SelectedItem is CompanySummary company))
                throw new InvalidOperationException("اختر المستخدم والمنشأة أولاً.");
            var confirmation = MessageBox.Show("سيتم تعطيل عضوية المستخدم في المنشأة وجميع فروعها. هل تريد المتابعة؟",
                "تأكيد سحب العضوية", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (confirmation != MessageBoxResult.Yes) return;
            _directory.RevokeCompanyAccess(user.Id, company.Id, _session.UserId);
            RefreshDirectoryAdminLists();
            SetStatus("تم سحب عضوية المنشأة والفروع وتسجيل العملية في سجلي التدقيق.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private TabItem BuildBackupsTab()
    {
        var panel = new DockPanel { Margin = new Thickness(18) };
        var top = new StackPanel { Margin = new Thickness(0, 0, 0, 12) };
        top.Children.Add(Heading("النسخ الاحتياطي والاستعادة"));
        top.Children.Add(new TextBlock
        {
            Text = "تُنشأ نسخة مشفرة لقاعدة البيانات كاملة. استخدم كلمة مرور قوية من 12 حرفاً على الأقل، واحفظها خارج هذا الجهاز. الاستعادة تتم من أداة منفصلة بعد إغلاق MONARCH بالكامل.",
            TextWrapping = TextWrapping.Wrap, Foreground = Brush("#65758B"), Margin = new Thickness(3, 0, 3, 8)
        });
        top.Children.Add(Labelled("كلمة مرور النسخة (12 حرفاً على الأقل)", _backupPassword, 300));
        var actions = new WrapPanel();
        var create = Button("إنشاء نسخة مشفرة");
        create.Click += CreateBackup_Click;
        actions.Children.Add(create);
        var verify = Button("التحقق من نسخة خارجية");
        verify.Click += VerifyBackup_Click;
        actions.Children.Add(verify);
        var refresh = Button("تحديث القائمة");
        refresh.Click += (_, __) => RefreshBackups();
        actions.Children.Add(refresh);
        top.Children.Add(actions);
        top.Children.Add(new TextBlock { Text = "مجلد النسخ المحلية: " + _backupDirectory, TextWrapping = TextWrapping.Wrap, Foreground = Brush("#52647B"), Margin = new Thickness(4, 6, 4, 8) });
        DockPanel.SetDock(top, Dock.Top);
        panel.Children.Add(top);
        ConfigureGrid(_backupsGrid);
        panel.Children.Add(_backupsGrid);
        RefreshBackups();
        return new TabItem { Header = "النسخ الاحتياطي", Content = panel };
    }

    private void CreateBackup_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            IdentityStore.Require(_session, "backups.manage");
            var password = _backupPassword.Password;
            if (password.Length < 12) throw new InvalidOperationException("كلمة مرور النسخة يجب ألا تقل عن 12 حرفاً.");
            var name = "monarch-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".mbackup";
            var path = Path.Combine(_backupDirectory, name);
            var result = new BackupRecoveryService(_databasePath).CreateEncryptedBackup(path, password, 20);
            _backupPassword.Clear();
            RefreshBackups();
            SetStatus("اكتملت النسخة المشفرة وفحص SQLite: " + result.IntegrityResult + " | " + result.Path);
            MessageBox.Show("تم إنشاء نسخة احتياطية مشفرة بنجاح. احتفظ بكلمة المرور في مكان آمن خارج الجهاز.", "MONARCH ERP", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void VerifyBackup_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            IdentityStore.Require(_session, "backups.manage");
            var dialog = new OpenFileDialog { Title = "اختر نسخة MONARCH الاحتياطية", Filter = "MONARCH Backup (*.mbackup)|*.mbackup|All files (*.*)|*.*", CheckFileExists = true };
            if (dialog.ShowDialog() != true) return;
            var password = _backupPassword.Password;
            if (password.Length < 12) throw new InvalidOperationException("أدخل كلمة مرور النسخة الصحيحة (12 حرفاً على الأقل).");
            var result = new BackupRecoveryService(_databasePath).VerifyEncryptedBackup(dialog.FileName, password);
            _backupPassword.Clear();
            MessageBox.Show(result.Message, result.IsValid ? "النسخة سليمة" : "فشل التحقق", MessageBoxButton.OK,
                result.IsValid ? MessageBoxImage.Information : MessageBoxImage.Warning);
            SetStatus(result.IsValid ? "تم التحقق من النسخة الاحتياطية بنجاح." : "تعذر التحقق من النسخة الاحتياطية.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void RefreshBackups()
    {
        if (!Directory.Exists(_backupDirectory)) return;
        _backupsGrid.ItemsSource = Directory.GetFiles(_backupDirectory, "*.mbackup")
            .Select(path => new FileInfo(path))
            .OrderByDescending(file => file.LastWriteTimeUtc)
            .Select(file => new { الملف = file.Name, الحجم_MB = Math.Round(file.Length / 1024d / 1024d, 2), تاريخ_التعديل = file.LastWriteTime.ToString("yyyy-MM-dd HH:mm"), المسار = file.FullName })
            .ToList();
    }

    private void CreateUser_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var role = _newRole.SelectedItem as ComboBoxItem;
            if (role == null) throw new InvalidOperationException("اختر دور المستخدم.");
            var roleCode = (string)role.Tag;
            _identity.CreateUser(_session, _newUsername.Text, _newDisplayName.Text, _newPassword.Password, roleCode, _ledgerSession.CompanyId, _ledgerSession.BranchId);
            var created = _identity.GetUsers(_session).First(u => string.Equals(u.Username, _newUsername.Text.Trim(), StringComparison.OrdinalIgnoreCase));
            _directory.GrantCompanyAccess(created.Id, _ledgerSession.CompanyId, roleCode, _session.UserId);
            if (!string.Equals(roleCode, "Administrator", StringComparison.OrdinalIgnoreCase))
                _directory.GrantBranchAccess(created.Id, _ledgerSession.CompanyId, _ledgerSession.BranchId, true, _session.UserId);
            _newUsername.Clear(); _newDisplayName.Clear(); _newPassword.Clear();
            RefreshUsers();
            SetStatus("تم إنشاء المستخدم وتسجيل العملية في سجل التدقيق.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void ChangeUserRole_Click(object sender, RoutedEventArgs e)
    {
        if (!(_usersGrid.SelectedItem is UserRow row)) return;
        try
        {
            if (!(_editUserRole.SelectedItem is ComboBoxItem role))
                throw new InvalidOperationException("اختر الدور الجديد.");
            _identity.SetUserRole(_session, row.Id, (string)role.Tag, _ledgerSession.CompanyId, _ledgerSession.BranchId);
            RefreshUsers();
            SetStatus("تم تغيير دور المستخدم وتسجيل العملية ذرياً في سجل التدقيق.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void DeactivateUser_Click(object sender, RoutedEventArgs e)
    {
        if (!(_usersGrid.SelectedItem is UserRow row)) return;
        try
        {
            _identity.SetUserActive(_session, row.Id, false, _ledgerSession.CompanyId, _ledgerSession.BranchId);
            RefreshUsers();
            SetStatus("تم تعطيل المستخدم المحدد.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void RefreshUsers()
    {
        if (_identity == null || _session == null || !_session.HasPermission("users.manage")) return;
        _usersGrid.ItemsSource = _identity.GetUsers(_session).Select(u => new UserRow(u.Id, u.Username, u.DisplayName, u.RoleCode, u.IsActive ? "نشط" : "معطل", u.CreatedUtc.ToString("yyyy-MM-dd"))).ToList();
    }

    private void SeedStarterAccounts()
    {
        if (!_session.HasPermission("accounts.manage") ||
            !new[] { "Administrator", "Accountant" }.Contains(_ledgerSession.CompanyRoleCode, StringComparer.OrdinalIgnoreCase)) return;
        if (_ledgerSession.GetAccounts().Count != 0) return;
        var starter = new[]
        {
            new Account(Guid.NewGuid(), "1000", "الصندوق", AccountType.Asset),
            new Account(Guid.NewGuid(), "1100", "البنك", AccountType.Asset),
            new Account(Guid.NewGuid(), "2000", "الموردون", AccountType.Liability),
            new Account(Guid.NewGuid(), "3000", "رأس المال", AccountType.Equity),
            new Account(Guid.NewGuid(), "4000", "إيرادات المبيعات", AccountType.Revenue),
            new Account(Guid.NewGuid(), "5000", "مصروفات تشغيل", AccountType.Expense)
        };
        foreach (var account in starter) _ledgerSession.AddAccount(account);
    }

    private void AddAccount_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            IdentityStore.Require(_session, "accounts.manage");
        }
        catch (Exception ex) { ShowError(ex); return; }
        try
        {
            var code = _accountCode.Text.Trim();
            var name = _accountName.Text.Trim();
            if (code.Length == 0 || name.Length == 0) throw new InvalidOperationException("أدخل رمز الحساب واسمه.");
            var selectedType = _accountType.SelectedItem as ComboBoxItem;
            if (selectedType == null || !(selectedType.Tag is AccountType)) throw new InvalidOperationException("اختر نوع الحساب.");
            _ledgerSession.AddAccount(new Account(Guid.NewGuid(), code, name, (AccountType)selectedType.Tag));
            _accountCode.Clear(); _accountName.Clear();
            RefreshAll();
            SetStatus("تمت إضافة الحساب.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void ConfigureJournalLinesGrid()
    {
        _journalLinesGrid.AutoGenerateColumns = false;
        _journalLinesGrid.CanUserAddRows = true;
        _journalLinesGrid.CanUserDeleteRows = true;
        _journalLinesGrid.HeadersVisibility = DataGridHeadersVisibility.Column;
        _journalLinesGrid.ItemsSource = _journalLines;
        _journalLinesGrid.Columns.Add(new DataGridComboBoxColumn
        {
            Header = "الحساب",
            ItemsSource = _ledgerSession.GetAccounts().Where(a => a.IsActive).ToList(),
            DisplayMemberPath = "Name", SelectedValuePath = "Id",
            SelectedValueBinding = new System.Windows.Data.Binding("AccountId") { Mode = System.Windows.Data.BindingMode.TwoWay, UpdateSourceTrigger = System.Windows.Data.UpdateSourceTrigger.PropertyChanged },
            Width = new DataGridLength(2, DataGridLengthUnitType.Star)
        });
        _journalLinesGrid.Columns.Add(new DataGridTextColumn { Header = "مدين", Binding = new System.Windows.Data.Binding("DebitAmount") { UpdateSourceTrigger = System.Windows.Data.UpdateSourceTrigger.PropertyChanged }, Width = new DataGridLength(1, DataGridLengthUnitType.Star) });
        _journalLinesGrid.Columns.Add(new DataGridTextColumn { Header = "دائن", Binding = new System.Windows.Data.Binding("CreditAmount") { UpdateSourceTrigger = System.Windows.Data.UpdateSourceTrigger.PropertyChanged }, Width = new DataGridLength(1, DataGridLengthUnitType.Star) });
        _journalLines.Add(new JournalLineDraftRow());
        _journalLines.Add(new JournalLineDraftRow());
    }

    private void CreateJournal_Click(object sender, RoutedEventArgs e)
    {
        try { IdentityStore.Require(_session, "journals.create"); }
        catch (Exception ex) { ShowError(ex); return; }
        try
        {
            _journalLinesGrid.CommitEdit(DataGridEditingUnit.Cell, true);
            _journalLinesGrid.CommitEdit(DataGridEditingUnit.Row, true);
            if (string.IsNullOrWhiteSpace(_journalDescription.Text)) throw new InvalidOperationException("أدخل بيان القيد.");
            var exponent = _ledgerSession.CurrencyExponent;
            var lines = _journalLines.Where(x => x.AccountId != Guid.Empty).Select(x =>
            {
                var debit = ParseJournalAmount(x.DebitAmount, exponent);
                var credit = ParseJournalAmount(x.CreditAmount, exponent);
                if (debit < 0 || credit < 0 || (debit > 0 && credit > 0) || (debit == 0 && credit == 0))
                    throw new InvalidOperationException("كل سطر يجب أن يحتوي مبلغاً موجباً في جانب واحد فقط: مدين أو دائن.");
                return new JournalLine(x.AccountId, debit, credit);
            }).ToList();
            if (lines.Count < 2) throw new InvalidOperationException("يجب إدخال سطرين محاسبيين على الأقل.");
            if (lines.Sum(x => x.DebitMinor) != lines.Sum(x => x.CreditMinor))
                throw new InvalidOperationException("القيد غير متوازن: إجمالي المدين لا يساوي إجمالي الدائن.");
            var number = _journalNumber.Text.Trim();
            if (number.Length == 0) number = "JV-" + DateTime.Now.ToString("yyyyMMdd-HHmmss");
            var date = _journalDate.SelectedDate ?? DateTime.Today;
            _ledgerSession.CreateDraft(number, new DateOnly(date.Year, date.Month, date.Day), _journalDescription.Text.Trim(), lines);
            _journalNumber.Clear(); _journalDescription.Clear(); _journalLines.Clear();
            _journalLines.Add(new JournalLineDraftRow()); _journalLines.Add(new JournalLineDraftRow());
            RefreshAll();
            SetStatus("تم حفظ القيد متعدد الأسطر كمسودة بعد التحقق من توازنه.");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private static long ParseJournalAmount(string value, int exponent)
    {
        if (string.IsNullOrWhiteSpace(value)) return 0;
        if (!decimal.TryParse(value, NumberStyles.Number, CultureInfo.CurrentCulture, out var amount) &&
            !decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out amount))
            throw new InvalidOperationException("يوجد مبلغ غير صالح في أحد أسطر القيد.");
        return MinorUnits.FromMajor(amount, exponent);
    }

    private void PostSelectedJournal()
    {
        try { IdentityStore.Require(_session, "journals.post"); }
        catch (Exception ex) { ShowError(ex); return; }
        if (!(_journalsGrid.SelectedItem is JournalRow row)) return;
        try { _ledgerSession.Post(row.Id); RefreshAll(); SetStatus("تم ترحيل القيد " + row.Number); }
        catch (Exception ex) { ShowError(ex); }
    }

    private void RefreshAll()
    {
        _accountsGrid.ItemsSource = _ledgerSession.GetAccounts().Select(a => new { a.Code, a.Name, Type = ArabicType(a.Type), الحالة = a.IsActive ? "نشط" : "متوقف" }).ToList();
        _journalsGrid.ItemsSource = _ledgerSession.GetEntries().Select(e => new JournalRow(e.Id, e.Number, e.Date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture), e.Description, ArabicStatus(e.Status), MinorUnits.ToMajor(e.Lines.Sum(l => l.DebitMinor), _ledgerSession.CurrencyExponent))).ToList();
        RefreshTrialBalance();
    }

    private void RefreshTrialBalance()
    {
        var today = DateTime.Today;
        var report = _ledgerSession.GetTrialBalance(new DateOnly(1900, 1, 1), new DateOnly(today.Year, today.Month, today.Day));
        _trialGrid.ItemsSource = report.Accounts.Select(a => new { a.Code, a.Name, Type = ArabicType(a.Type), مدين = MinorUnits.ToMajor(a.DebitMinor, _ledgerSession.CurrencyExponent), دائن = MinorUnits.ToMajor(a.CreditMinor, _ledgerSession.CurrencyExponent), صافي_مدين = MinorUnits.ToMajor(a.NetDebitMinor, _ledgerSession.CurrencyExponent), صافي_دائن = MinorUnits.ToMajor(a.NetCreditMinor, _ledgerSession.CurrencyExponent) }).ToList();
        SetStatus("ميزان المراجعة: " + (report.IsBalanced ? "متوازن" : "غير متوازن") + " | العملة: " + _ledgerSession.BaseCurrencyCode);
    }

    private string BuildSummary()
    {
        var accounts = _ledgerSession.GetAccounts().Count;
        var entries = _ledgerSession.GetEntries();
        var posted = entries.Count(e => e.Status != JournalStatus.Draft);
        var draft = entries.Count(e => e.Status == JournalStatus.Draft);
        return "العملة الأساسية: " + _ledgerSession.BaseCurrencyCode + "\nعدد الحسابات: " + accounts + "\nإجمالي القيود: " + entries.Count + "\nالقيود المرحلة/المعكوسة: " + posted + "\nالمسودات غير المرحلة: " + draft + "\n\nمسار قاعدة البيانات:\n" + _databasePath;
    }

    private static void ConfigureGrid(DataGrid grid)
    {
        grid.AutoGenerateColumns = true;
        grid.IsReadOnly = true;
        grid.CanUserAddRows = false;
        grid.HeadersVisibility = DataGridHeadersVisibility.Column;
        grid.GridLinesVisibility = DataGridGridLinesVisibility.Horizontal;
        grid.AlternatingRowBackground = Brush("#F5F8FC");
        grid.Margin = new Thickness(2);
    }

    private static Border Labelled(string label, Control control, double width)
    {
        control.Width = width; control.Margin = new Thickness(4); control.Height = 32;
        if (control is TextBox text) text.VerticalContentAlignment = VerticalAlignment.Center;
        var stack = new StackPanel { Margin = new Thickness(3) };
        stack.Children.Add(new TextBlock { Text = label, Foreground = Brush("#52647B"), Margin = new Thickness(2, 0, 2, 3) });
        stack.Children.Add(control);
        return new Border { Child = stack };
    }

    private static TextBlock Heading(string text) => new TextBlock { Text = text, FontSize = 22, FontWeight = FontWeights.Bold, Foreground = Brush("#172B4D"), Margin = new Thickness(3, 3, 12, 10), VerticalAlignment = VerticalAlignment.Center };
    private static Button Button(string text) => new Button { Content = text, Padding = new Thickness(16, 8, 16, 8), Margin = new Thickness(5, 18, 5, 3), Background = Brush("#173B68"), Foreground = Brushes.White, BorderThickness = new Thickness(0), MinWidth = 105 };
    private static Brush Brush(string color) => (Brush)new BrushConverter().ConvertFromString(color);
    private static ScrollViewer Scroll(UIElement child) => new ScrollViewer { Content = child, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
    private static string ArabicStatus(JournalStatus status) => status == JournalStatus.Draft ? "مسودة" : status == JournalStatus.Posted ? "مرحّل" : "معكوس";
    private static string ArabicType(AccountType type) => type switch { AccountType.Asset => "أصول", AccountType.Liability => "التزامات", AccountType.Equity => "حقوق ملكية", AccountType.Revenue => "إيرادات", AccountType.Expense => "مصروفات", _ => type.ToString() };
    private void SetStatus(string text) => _status.Text = text + " | قاعدة البيانات محلية";
    private static void ShowError(Exception ex) => MessageBox.Show(ex.Message, "تعذر تنفيذ العملية", MessageBoxButton.OK, MessageBoxImage.Warning);

    public sealed class UserRow
    {
        public Guid Id { get; }
        public string Username { get; }
        public string DisplayName { get; }
        public string Role { get; }
        public string Status { get; }
        public string Created { get; }
        public UserRow(Guid id, string username, string displayName, string role, string status, string created)
        { Id = id; Username = username; DisplayName = displayName; Role = role; Status = status; Created = created; }
    }

    public sealed class JournalRow
    {
        public Guid Id { get; }
        public string Number { get; }
        public string Date { get; }
        public string Description { get; }
        public string Status { get; }
        public decimal DebitTotal { get; }
        public JournalRow(Guid id, string number, string date, string description, string status, decimal debitTotal)
        { Id = id; Number = number; Date = date; Description = description; Status = status; DebitTotal = debitTotal; }
    }
    public sealed class JournalLineDraftRow
    {
        public Guid AccountId { get; set; }
        public string DebitAmount { get; set; } = "";
        public string CreditAmount { get; set; } = "";
    }
}
