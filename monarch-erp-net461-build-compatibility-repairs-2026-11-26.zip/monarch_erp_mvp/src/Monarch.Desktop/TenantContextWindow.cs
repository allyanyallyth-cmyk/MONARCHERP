using Monarch.Core.Accounting;
using Monarch.Core.Organizations;
using Monarch.Core.Security;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Monarch.Desktop;

/// <summary>Requires an explicit authorized company and branch before accounting UI is created.</summary>
internal sealed class TenantContextWindow : Window
{
    private readonly CompanyDirectoryStore _directory;
    private readonly UserSession _session;
    private readonly ComboBox _companies = new ComboBox { MinWidth = 300, Height = 34, Margin = new Thickness(0, 5, 0, 14) };
    private readonly ComboBox _branches = new ComboBox { MinWidth = 300, Height = 34, Margin = new Thickness(0, 5, 0, 14) };
    public Guid SelectedCompanyId { get; private set; }
    public Guid SelectedBranchId { get; private set; }

    public TenantContextWindow(CompanyDirectoryStore directory, UserSession session)
    {
        _directory = directory ?? throw new ArgumentNullException(nameof(directory));
        _session = session ?? throw new UnauthorizedAccessException("تسجيل الدخول مطلوب.");
        Title = "اختيار المنشأة والفرع - MONARCH ERP"; Width = 440; Height = 300;
        WindowStartupLocation = WindowStartupLocation.CenterScreen; ResizeMode = ResizeMode.NoResize;
        Background = Brushes.White;
        var panel = new StackPanel { Margin = new Thickness(26) };
        panel.Children.Add(new TextBlock { Text = "تحديد السياق المحاسبي", FontSize = 22, FontWeight = FontWeights.Bold, Foreground = Brush("#172B4D"), Margin = new Thickness(0, 0, 0, 18) });
        panel.Children.Add(new TextBlock { Text = "المنشأة المصرح بها" }); panel.Children.Add(_companies);
        panel.Children.Add(new TextBlock { Text = "الفرع المصرح به" }); panel.Children.Add(_branches);
        var open = new Button { Content = "فتح مساحة العمل", Height = 38, Background = Brush("#0B1F3A"), Foreground = Brushes.White, BorderThickness = new Thickness(0) };
        open.Click += (_, __) =>
        {
            if (!(_companies.SelectedItem is CompanyAccessSummary company) || !(_branches.SelectedItem is BranchSummary branch))
            { MessageBox.Show("اختر منشأة وفرعاً من العناصر المصرح بها.", "MONARCH ERP", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
            SelectedCompanyId = company.CompanyId; SelectedBranchId = branch.Id; DialogResult = true;
        };
        panel.Children.Add(open); Content = panel;
        _companies.SelectionChanged += (_, __) => LoadBranches();
        var available = TenantAccountingSession.GetAvailableCompanies(_directory, _session);
        foreach (var item in available) _companies.Items.Add(item);
        _companies.DisplayMemberPath = "CompanyName";
        if (_companies.Items.Count == 1) _companies.SelectedIndex = 0;
    }

    private void LoadBranches()
    {
        _branches.Items.Clear();
        if (!(_companies.SelectedItem is CompanyAccessSummary company)) return;
        foreach (var branch in TenantAccountingSession.GetAvailableBranches(_directory, _session, company.CompanyId)) _branches.Items.Add(branch);
        _branches.DisplayMemberPath = "Name";
        if (_branches.Items.Count == 1) _branches.SelectedIndex = 0;
    }

    private static SolidColorBrush Brush(string value) => (SolidColorBrush)new BrushConverter().ConvertFromString(value);
}
