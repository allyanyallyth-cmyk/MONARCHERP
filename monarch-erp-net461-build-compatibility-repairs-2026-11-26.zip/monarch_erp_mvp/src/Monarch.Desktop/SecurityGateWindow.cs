using Monarch.Core.Security;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Monarch.Desktop;

internal static class SecurityGateWindow
{
    public static UserSession? Run(IdentityStore identity)
    {
        if (!identity.HasUsers())
        {
            var setup = new Window
            {
                Title = "إعداد MONARCH لأول مرة", Width = 440, Height = 430,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ResizeMode = ResizeMode.NoResize, FlowDirection = FlowDirection.RightToLeft,
                Background = Brushes.White
            };
            var panel = Panel();
            panel.Children.Add(Title("إنشاء حساب مدير النظام"));
            panel.Children.Add(Label("اسم المستخدم"));
            var username = new TextBox { Text = "admin", Height = 32, Margin = new Thickness(0, 3, 0, 10) };
            panel.Children.Add(username);
            panel.Children.Add(Label("الاسم الظاهر"));
            var display = new TextBox { Text = "مدير النظام", Height = 32, Margin = new Thickness(0, 3, 0, 10) };
            panel.Children.Add(display);
            panel.Children.Add(Label("كلمة المرور (12 حرفاً على الأقل)"));
            var password = new PasswordBox { Height = 32, Margin = new Thickness(0, 3, 0, 10) };
            panel.Children.Add(password);
            panel.Children.Add(Label("تأكيد كلمة المرور"));
            var confirm = new PasswordBox { Height = 32, Margin = new Thickness(0, 3, 0, 10) };
            panel.Children.Add(confirm);
            var create = ActionButton("إنشاء المدير وبدء الاستخدام");
            create.Click += (_, __) =>
            {
                try
                {
                    if (password.Password != confirm.Password) throw new InvalidOperationException("كلمتا المرور غير متطابقتين.");
                    identity.CreateFirstAdministrator(username.Text, display.Text, password.Password);
                    setup.DialogResult = true;
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "تعذر إنشاء الحساب", MessageBoxButton.OK, MessageBoxImage.Warning); }
            };
            panel.Children.Add(create);
            setup.Content = panel;
            if (setup.ShowDialog() != true) return null;
            return identity.Authenticate(username.Text, password.Password);
        }

        while (true)
        {
            var login = new Window
            {
                Title = "تسجيل الدخول إلى MONARCH ERP", Width = 400, Height = 330,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ResizeMode = ResizeMode.NoResize, FlowDirection = FlowDirection.RightToLeft,
                Background = Brushes.White
            };
            var panel = Panel();
            panel.Children.Add(Title("مرحباً بك في MONARCH"));
            panel.Children.Add(Label("اسم المستخدم"));
            var username = new TextBox { Height = 34, Margin = new Thickness(0, 4, 0, 12) };
            panel.Children.Add(username);
            panel.Children.Add(Label("كلمة المرور"));
            var password = new PasswordBox { Height = 34, Margin = new Thickness(0, 4, 0, 16) };
            panel.Children.Add(password);
            var loginButton = ActionButton("دخول");
            loginButton.Click += (_, __) => login.DialogResult = true;
            panel.Children.Add(loginButton);
            var cancel = new Button { Content = "إغلاق", Height = 32, Margin = new Thickness(0, 8, 0, 0) };
            cancel.Click += (_, __) => login.DialogResult = false;
            panel.Children.Add(cancel);
            login.Content = panel;
            if (login.ShowDialog() != true) return null;
            var session = identity.Authenticate(username.Text, password.Password);
            if (session != null) return session;
            MessageBox.Show("تعذر تسجيل الدخول. تحقق من البيانات أو انتظر انتهاء القفل المؤقت.", "فشل الدخول", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private static StackPanel Panel() => new StackPanel { Margin = new Thickness(28), VerticalAlignment = VerticalAlignment.Center };
    private static TextBlock Title(string text) => new TextBlock { Text = text, FontSize = 22, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(Color.FromRgb(23, 43, 77)), Margin = new Thickness(0, 0, 0, 18) };
    private static TextBlock Label(string text) => new TextBlock { Text = text, Foreground = new SolidColorBrush(Color.FromRgb(82, 100, 123)) };
    private static Button ActionButton(string text) => new Button { Content = text, Height = 38, Margin = new Thickness(0, 12, 0, 0), Background = new SolidColorBrush(Color.FromRgb(23, 59, 104)), Foreground = Brushes.White, BorderThickness = new Thickness(0) };
}
