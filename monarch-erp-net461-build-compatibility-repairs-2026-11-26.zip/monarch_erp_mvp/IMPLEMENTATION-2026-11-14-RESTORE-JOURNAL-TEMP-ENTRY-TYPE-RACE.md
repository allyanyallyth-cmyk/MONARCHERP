# Restore-journal temporary entry-type race — 2026-11-14

## Change
Added a focused regression model for a time-of-check/time-of-use race in abandoned restore-journal temp cleanup: a matching file path yielded by enumeration is replaced by a directory before strict deletion.

## Expected safety contract
- Cleanup must fail closed when a file-only deletion encounters a directory at the same path.
- It must not recursively remove the directory or any child content.
- The failure must remain visible to the caller; a later retry may clean a regular temp after the conflicting directory is removed.
- The C# source guard confirms top-directory file enumeration and the strict single-entry delete helper remain in use.

## Scope and limitations
This adds Python filesystem-model tests and C# source-structure assertions only. It does not change C# production logic, database schema, WPF, or ERP modules. Actual Windows/NTFS replacement races, ACL behavior, and sharing violations remain untested; no .NET build or WPF runtime was executed.
