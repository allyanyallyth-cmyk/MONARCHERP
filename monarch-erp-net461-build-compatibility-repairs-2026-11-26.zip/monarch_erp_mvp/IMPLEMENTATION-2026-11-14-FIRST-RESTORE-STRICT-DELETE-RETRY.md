# MONARCH ERP — First-Restore Strict Delete Retry Boundary

Date: 2026-11-14

## Finding

The first-restore recovery path (`hadPrevious == false`) used best-effort `TryDelete(_databasePath)`. If the unverified replacement database was locked or access was denied, deletion could be swallowed while recovery continued to restore sidecars and remove the durable `prepared` journal. That could leave an unverified live database without its retry journal. The direct restore failure handler had the same best-effort deletion boundary.

## Change

- Replaced best-effort deletion with `DeleteIfExistsStrict(_databasePath)` in startup prepared recovery when no prior database exists.
- Applied the same strict deletion in the direct restore catch path for failed first-time restores.
- A deletion failure now propagates before sidecar restoration or journal removal, preserving the prepared state for a later retry.

## Tests

- Added a fault-injection test that denies the first deletion of the unverified live DB.
- Verified the live DB, durable journal, and quarantined WAL/SHM remain byte-for-byte unchanged after the failed attempt.
- Retried without the injected failure and verified the unverified DB is removed and the original WAL/SHM are restored.
- Added source assertions for strict deletion in both C# paths.

## Validation

- `pytest -q`: **712 passed**.
- `python -m unittest discover -s tests -p 'test_*.py'`: **365 tests, OK**.
- XML/XAML/project parsing: **7 parsed, 0 errors**.
- C# build: **not run** — .NET SDK unavailable.
- WPF runtime, Windows ACL/sharing integration, SQLite provider integration, and real process-kill/power-loss tests: **not run** — Windows/.NET runtime unavailable.

This change fixes a concrete fail-closed gap in production C# logic. The Python test remains a filesystem fault model plus source-level verification; compiled Windows behavior still requires validation in the target environment.
