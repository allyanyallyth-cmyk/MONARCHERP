# Restore-journal cross-directory hard-link cleanup safety — 2026-11-14

## Scope

Extended the abandoned restore-journal temporary cleanup filesystem model with a cross-directory hard-link case. The generated GUID-N temp entry is placed in the database/journal directory while its retained hard-link name is placed in a separate directory on the same filesystem.

## Expected and verified behavior

- The cleanup removes only the matching temporary directory entry.
- The separately retained name remains readable with byte-for-byte identical content.
- The inode link count decreases by exactly one, demonstrating unlink semantics rather than truncation or content mutation.
- The test skips only when the host filesystem does not support creating the required hard link.

## Boundaries

This is Python filesystem-model coverage. It does not execute `BackupRecoveryService.cs`, establish Windows NTFS behavior, or validate Windows ACL/sharing semantics. No production C#, database schema, WPF, or ERP module was modified.
