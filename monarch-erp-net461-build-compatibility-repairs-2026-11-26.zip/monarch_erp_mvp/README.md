# MONARCH ERP — Foundation MVP

## تحديث التحقق وإصلاح توافق البناء — 2026-11-26

- تمت معالجة عائلات أخطاء المترجم المسجلة في تشغيل Windows CI السابق: `Enum.Parse`، وتوافق `DateOnly` لهدف `net461`، و`Enumerable.Zip`، وتجميع صف بيانات المشتريات ذي ثمانية حقول، وإسناد نتيجة دالة `void`.
- أضيفت اختبارات انحدار بنيوية لهذه الإصلاحات.
- نتائج التحقق الحالية: **773/773 pytest** و**365/365 unittest** و**7/7** ملفات XML/XAML/project/config قابلة للتحليل.
- **تنبيه مهم:** لم يتوفر .NET SDK أو مترجم C# في بيئة إعداد هذه الحزمة؛ لذلك لم يتم تأكيد نجاح بناء `MonarchERP.sln` أو تشغيل WPF. راجع `IMPLEMENTATION-2026-11-26-NET461-BUILD-COMPATIBILITY-REPAIRS.md`.
- **حالة العميل: غير جاهز للتسليم التجاري** حتى ينجح بناء Windows الفعلي واختبارات C# وWPF والتثبيت والاستعادة.


منصة ERP مكتبية مستقلة (Offline-first) قابلة للتوسع بوحدات إضافية، مع واجهة عربية RTL ونواة أولية للتقارير والتنبيهات.

## ما الذي يتضمنه هذا الإصدار؟
- مشروع WPF مبدئي لواجهة Windows عربية.
- نواة أعمال مستقلة عن الواجهة: المنتجات، حركات النقد، فواتير البيع، وحساب مؤشرات لوحة التحكم.
- محرك تنبيهات حتمي لقواعد المخزون والسيولة؛ لا يختلق أرقاماً ولا يعتمد على نموذج لغوي لإجراء الحسابات.
- مخطط SQLite أولي للعمل المحلي.
- ASP.NET Core API هيكلية للصحة ولوحة التحكم، تمهيداً لاتصال LAN والهاتف.
- وثائق بنية النظام وخطة المراحل.

## نواة المحاسبة C# — مرحلة أولى مضافة

أضيفت طبقة مجال مستقلة في `src/Monarch.Core/Accounting`:
- مبالغ دفتر الأستاذ بوحدات العملة الصغرى الصحيحة (`long`)، مع تحويل عشري صريح حسب عدد الخانات العشرية للعملة.
- دليل حسابات مع طبيعة الحساب المدينة/الدائنة.
- إنشاء مسودات قيود والتحقق من توازنها والحسابات النشطة قبل الترحيل.
- قيد عكسي مستقل مرتبط بالأصل، مع منع العكس المكرر والتحقق من التطابق على مستوى كل حساب.
- ميزان مراجعة، وقائمة دخل، ومعادلة مركز مالي.
- أضيف مشغل اختبارات دخاني مستقل بلا حزم خارجية في `tests/Monarch.Core.SmokeTests`.

هذه الطبقة هي محرك المجال المحاسبي، وقد أضيف لها لاحقاً مستودع SQLite دائم وواجهة WPF أولية لإنشاء الحسابات ومسودات القيود وترحيلها وعرض ميزان المراجعة. لا تزال لا تطبق بعد تعدد العملات داخل القيد الواحد أو الضرائب أو مراكز التكلفة أو إقفال الفترات؛ لذلك لا تعتبر دورة محاسبية إنتاجية مكتملة.

تشغيل اختبارات C# على جهاز مثبت عليه .NET 8 SDK:
```powershell
dotnet run --project tests/Monarch.Core.SmokeTests/Monarch.Core.SmokeTests.csproj
```
ينبغي أن تظهر رسالة `PASS: 16 accounting smoke checks completed.`؛ لم يتم تشغيل هذه الاختبارات في بيئة إعداد هذه الحزمة لعدم توفر `dotnet` هنا.


## الحالة الحالية — ربط واجهة Windows بعزل المنشآت والفروع (2026-11-07)

هذه هي الحالة المرجعية الأحدث لمسار تعدد المنشآت، وتستبدل القيود التاريخية التي تذكر أن واجهة WPF لم تكن مربوطة:

- `MainWindow.xaml.cs` يهيئ مخططات قاعدة البيانات القديمة والجديدة، لكنه لا يستخدم `SqliteLedgerStore` لتنفيذ العمل المحاسبي. مسار العمل الفعلي يفتح `TenantAccountingSession` ثم يبني الواجهة بعد اختيار منشأة وفرع مصرح بهما.
- إذا وجدت بيانات دفتر أستاذ قديم، يتوقف بدء التشغيل قبل إظهار محدد المنشأة/الفرع ما لم يوجد سجل ترحيل مكتمل للمنشأة الافتراضية. أداة الترحيل تحتفظ بالجداول القديمة، وتنفذ dry-run ونسخة مشفرة واستيراداً ذرياً ومطابقة للأرصدة.
- كل API تشغيلية عامة في `TenantLedgerStore` تتطلب الآن `userId + companyId + branchId`؛ لا توجد عمليات قراءة أو كتابة للحسابات دون فرع محدد. دليل الحسابات يبقى مشتركاً على مستوى المنشأة، لكن الوصول إليه مشروط بعضوية الفرع المحدد.
- يجري فحص المستخدم النشط والمنشأة والفرع ودور المنشأة وإسناد الفرع داخل معاملة SQLite نفسها التي تنفذ القراءة أو الكتابة. أدوار Administrator/Accountant تستطيع الكتابة؛ Viewer للقراءة فقط. الترحيل والعكس مقيدان بالفرع المختار نفسه.
- عمال Outbox للمبيعات والمشتريات والمدفوعات والمرتجعات يمررون الفرع نفسه عند قراءة دليل الحسابات وعند إنشاء/ترحيل القيود.
- حزمة `monarch-erp-multiline-journals-stage` المؤرخة 2026-11-06 17:21 ليست أحدث حزمة مستقلة؛ وظيفتها موجودة في الحزم التراكمية الأحدث، وآخر حزمة تمت مراجعتها هي `monarch-erp-return-cost-reversals-stage` المؤرخة 2026-11-06 23:29 UTC.
- اختبارات Python/SQLite في حزمة التحديث السابقة: **190/190 ناجحة**؛ وبعد تحصين صلاحيات المستندات التجارية أصبح العدد **193/193 ناجحة**. أضيفت اختبارات C# دخانية جديدة لعزل الحسابات على مستوى الفرع، رفض الوصول غير المصرح به، إعادة التحقق بعد سحب الإذن، ومنع الترحيل/العكس عبر فرع آخر؛ لم تُشغّل لعدم توفر .NET SDK.

**حدود التحقق:** هذا يثبت الربط على مستوى الشيفرة والاختبارات البنيوية/SQLite فقط. لم يُنفذ بناء C# أو WPF أو Windows CI أو مثبت Setup في هذه البيئة. لا يُعلن توافق Windows 7 SP1 أو 8.1 أو 10 أو 11 قبل بناء وتشغيل فعلي على كل إصدار.

## تحديث 2026-11-07 — ترحيل تكلفة البضاعة المباعة

- عامل `CommercialAccountingOutboxWorker` يقرأ تكلفة المخزون الفعلية من مجموع تخصيصات `SalesIssue` الدائمة للمستند، ضمن نطاق الشركة والفرع نفسيهما.
- قيد البيع يتضمن الآن: مدين الذمم المدينة، دائن الإيراد وضريبة المخرجات، ثم مدين تكلفة البضاعة المباعة (`CostOfGoodsSoldCode`, الافتراضي `5000`) ودائن المخزون بقيمة التكلفة التاريخية المخصصة.
- يمنع العامل ترحيل بيع يحتوي بنود مخزون إذا لم توجد تخصيصات تكلفة محفوظة؛ لا يستخدم سعر البيع بديلاً عن تكلفة المخزون.
- هذا المسار يخص المبيعات الجديدة التي لم يُنشأ لها قيد مرحّل سابقاً. لا توجد بعد أداة تسوية تلقائية للقيود التاريخية التي رُحّلت قبل إضافة COGS.
- اختبارات Python/SQLite البنيوية بعد التحديث: **201/201 ناجحة**. لم يُنفذ بناء C# أو تشغيل WPF في هذه البيئة.

## ما الذي لا يدّعيه هذا الإصدار؟
هذا **هيكل تأسيسي قابل للتطوير وليس برنامجاً محاسبياً مكتملاً أو معتمداً للإنتاج**. توجد دورة محاسبية أولية محدودة (حسابات، مسودة قيد ثنائي، ترحيل، ميزان مراجعة) لكنها ليست دورة شاملة. لا يوجد بعد تكامل فعلي مع Telegram أو تطبيق Android/iOS أو نظام إضافات مكتمل.

## توافق أنظمة Windows (تحديث التوافق متعدد الإصدارات)
- تطبيق سطح المكتب WPF يستهدف .NET Framework 4.6.1 لتغطية Windows 7 SP1 وWindows 8 و8.1 وWindows 10 وWindows 11 (على Windows 11 يعمل فوق إصدار .NET Framework الأحدث المثبت).
- نواة الأعمال متعددة الاستهداف: `net8.0` لخدمات API الحديثة و`net461` لبرنامج سطح المكتب القديم.
- يتطلب Windows 7 وجود Service Pack 1 والتحديثات اللازمة، وتثبيت .NET Framework 4.6.1 أو إصدار 4.x أحدث متوافق مع النظام. يجب أن تكون معمارية الحزمة (x86/x64) مناسبة للنظام.
- خدمات ASP.NET Core API تبقى على .NET 8 ولا يُفترض تشغيلها على Windows 7؛ وهي اختيارية ولا تمنع تشغيل البرنامج المكتبي محلياً دون إنترنت.
- البناء يتطلب .NET 8 SDK وVisual Studio 2022، إضافة إلى استعادة حزم NuGet.

**قيد تحقق مهم:** تم تعديل ملفات الاستهداف والتوافق البرمجي، لكن لم يتم بناء WPF أو تشغيله على Windows 7/8/10/11 في بيئة إعداد هذه الحزمة. يلزم اختبار مصفوفة الأنظمة فعلياً قبل إعلان التوافق النهائي. Windows 7 دون SP1 غير مدعوم. .NET Framework 4.6.1 إصدار قديم انتهى دعمه العام؛ يُستخدم فقط كجسر توافق للأجهزة القديمة، بينما يجب اعتماد إصدار Framework أحدث حيثما يسمح نظام التشغيل.

## فتح المشروع
افتح `MonarchERP.sln` في Visual Studio. شغّل `Monarch.Desktop` لواجهة Windows أو `Monarch.Api` لتجربة نقطة API.

## التشغيل المحلي للـ API
```bash
dotnet run --project src/Monarch.Api
```
ثم افتح `/health` أو `/api/dashboard/demo`.

## بناء الواجهة
```bash
dotnet build MonarchERP.sln
```

## اختبارات سلامة القيود المحاسبية

أُضيفت حواجز SQLite واختبارات تكامل قابلة للتشغيل دون حزم Python خارجية:

- لا يُنشأ القيد إلا بحالة `Draft`، ولا يُرحّل إلا إذا احتوى سطرين فعليين على الأقل وكان إجمالي المدين مساوياً للدائن.
- يمنع استخدام حساب غير نشط أو إضافة سطر صفري.
- لا يسمح بتعديل أو حذف قيد مرحّل أو سطوره.
- العكس يتم بقيد مستقل مرتبط بالقيد الأصلي عبر `reversal_of_id`، ويجب أن يعكس مبالغ كل حساب في الاتجاه المقابل قبل ترحيله؛ ولا تتحول حالة الأصل إلى `Reversed` إلا بعد ترحيل القيد العكسي.
- يمنع إنشاء أكثر من قيد عكسي واحد للقيد الأصلي.

على Windows 11 مع Python 3:
```powershell
.\scripts\test-accounting.ps1
```
أو مباشرة:
```powershell
py -3 -m unittest discover -s tests -v
```

هذه الاختبارات تتحقق من حواجز مخطط SQLite وسلوك واجهة WPF من ناحية الربط البنيوي. توجد أيضاً اختبارات C# مستقلة لمحرك المجال والتخزين، ويجب تشغيلها على جهاز Windows/SDK قبل اعتماد البناء. المخطط المحاسبي الدائم `ledger-storage.sql` يخزن المبالغ بوحدات العملة الصغرى الصحيحة (`INTEGER`)، بينما `schema.sql` القديم جزء تأسيسي سابق لا يستخدمه مستودع دفتر الأستاذ الحالي. لا توجد بعد آلية ترحيل تلقائي لقواعد بيانات العملاء السابقة.

## مبدأ البيانات
- الوضع المستقل: SQLite محلي على جهاز العميل.
- وضع LAN لاحقاً: خدمة API على جهاز خادم داخل الشبكة؛ لا يتم فتح ملف قاعدة البيانات على الشبكة مباشرة.
- وضع الوصول الخارجي لاحقاً: VPN أو بوابة HTTPS آمنة، مع مصادقة وصلاحيات وتدقيق.

راجع `docs/ARCHITECTURE.md` و `docs/ROADMAP.md` قبل توسيع الوحدات.

## إدارة المنشآت والفروع — مرحلة سابقة (2026-11-07)

أضيفت شاشة إدارة منشآت وفروع مخصصة لمدير النظام العام:
- إنشاء منشأة جديدة ومقرها الرئيسي، ومنح منشئها دور Administrator على المنشأة في معاملة واحدة.
- إنشاء فروع إضافية.
- إسناد مستخدم موجود إلى منشأة وفرع بدور مدير منشأة أو محاسب أو مشاهد.
- التحقق داخل طبقة التخزين من أن الجهة المانحة مدير نظام عام نشط، وأن المستخدم والمنشأة والفرع نشطون، وأن الفرع تابع للمنشأة.
- تسجيل الإنشاء ومنح الصلاحيات في سجل تدقيق المنشأة.

نتائج الحزمة الأصلية لهذه المرحلة: **102/102** اختبار Python/SQLite ناجح، و7/7 ملفات XML/XAML سليمة. تم توسيع الاختبارات في التحديثات التراكمية اللاحقة؛ العدد الأحدث هو 190/190 كما هو موضح في الحالة الحالية ببداية هذا الملف.

## حالة التحقق لهذه المرحلة السابقة — 2026-11-07

- أُضيفت اختبارات C# دخانية لفتح `TenantAccountingSession` وعزل المنشأة والفرع وقراءة العملة؛ ثم وُسعت في تحديث التفويض اللاحق. لم تُشغّل لعدم توفر .NET SDK.
- واجهة WPF مربوطة على مستوى الكود بـ `TenantAccountingSession`، ونافذة اختيار المنشأة/الفرع تسبق بناء مساحة العمل. هذا لا يثبت نجاح تجميع WPF أو التشغيل التفاعلي على Windows.
- لم يُشغّل GitHub Actions على مستودع فعلي؛ لا يوجد سجل CI ناجح أو ملف Setup/Portable ناتج عن Windows runner.
- لا تستخدم بيانات مالية إنتاجية قبل نجاح بناء Windows واختبار الواجهة والترحيل والاستعادة فعلياً.

## بناء Windows وحل مشكلة غياب .NET SDK

تستهدف واجهة سطح المكتب .NET Framework 4.6.1 وتستهدف خدمات API .NET 8. ثبّت **.NET 8 SDK** (وليس Runtime فقط) على جهاز Windows، ثم افتح PowerShell جديداً من مجلد المشروع.

تحقق من التثبيت:
```powershell
dotnet --info
```

ابنِ الحل وانشر واجهة Windows:
```powershell
.\scripts\build-windows.ps1 -Configuration Release
```

ينتج هذا المسار تطبيق .NET Framework يعتمد على وجود .NET Framework 4.6.1 أو أحدث على جهاز العميل؛ لا يمكن وصفه بأنه Self-contained.

تظهر الملفات المنشورة في `artifacts/desktop-net461`. هذه نسخة نشر أولية وليست مُثبّت MSI/Setup بعد.

### البناء السحابي على Windows
يوجد GitHub Actions workflow في `.github/workflows/windows-build.yml` (تأكدنا في تحديث 2026-11-07 من أنه غير مستثنى في `.gitignore`). بعد رفع المشروع إلى مستودع GitHub على فرع `main` أو `master`، شغّل workflow باسم **Windows build** من تبويب Actions، ثم نزّل artifact باسم `monarch-windows-<run_number>` من نتيجة التشغيل؛ يحتوي على حزمة Portable ومثبت Setup وملفات SHA-256 إذا نجحت جميع خطوات البناء والتغليف. هذا المسار يبني WPF على Windows runner، وهو الأنسب إذا كان جهاز التطوير الحالي Linux أو لا يحتوي SDK.

### ملاحظة بيئة التطوير
لا يمكن تشغيل واجهة WPF على Linux. يمكن بناء مكتبات .NET متعددة المنصات هناك عند توفر SDK، لكن بناء WPF والتحقق من تشغيلها يجب أن يتم على Windows. غياب DNS/الاتصال الخارجي في بيئة العمل الحالية يمنع تنزيل SDK تلقائياً؛ لذلك أُضيف مسار بناء محلي على Windows ومسار CI على GitHub بدلاً من الادعاء بأن التطبيق بُني هنا.

## تشغيل سريع على Windows 11
افتح PowerShell داخل مجلد المشروع. إذا كان winget متاحاً وتريد تثبيت .NET 8 SDK تلقائياً:
```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\setup-and-run-windows11.ps1 -InstallSdk
```
بعد انتهاء التثبيت، أغلق PowerShell وافتحه مجدداً، ثم شغّل:
```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\setup-and-run-windows11.ps1
```
يتطلب النشر اتصال إنترنت عند أول استرجاع لحزم NuGet. بعد تثبيت .NET Framework 4.6.1 أو أحدث، لا يحتاج التطبيق المكتبي المحلي إلى الإنترنت أثناء التشغيل.


## SQLite ledger persistence — implementation stage

أضيف `SqliteLedgerStore` في `src/Monarch.Core/Accounting` باستخدام `Microsoft.Data.Sqlite`، مع مخطط مستقل `database/ledger-storage.sql`:
- يحفظ دليل الحسابات والقيود وسطورها محلياً، ويعيد تحميلها عند إعادة فتح البرنامج.
- كل عملية إنشاء/ترحيل/عكس تنفذ ضمن معاملة SQLite واحدة؛ وعند الفشل يتم التراجع عن المعاملة.
- تخزن مبالغ القيود كأعداد صحيحة `INTEGER` بوحدات العملة الصغرى، وليس `REAL` أو `NUMERIC`.
- إعداد افتراضي للعملة الأساسية SAR بخانتين عشريتين، مع جدول عملات قابل للتوسع وتحديد العملة الأساسية.
- حواجز قاعدة البيانات تمنع ترحيل القيود غير المتوازنة وتعديل سطور القيود المرحلة أو حذفها.

هذه خطوة تخزين محاسبي أولية وليست اعتماداً إنتاجياً: لا يوجد بعد عزل منشآت/شركات وفروع، ولا ترحيل آمن لمخطط قواعد العملاء السابق، ولا إدارة عملات أجنبية وأسعار صرف، ولا إقفال فترات. أضيفت في المرحلة التالية هوية المستخدمين والأدوار وسجل التدقيق الأساسي كما هو موضح أدناه. لا تغيّر عملة منشأة لديها قيود قائمة دون سياسة محاسبية معتمدة؛ إعداد العملة الحالي يحدد العملة الأساسية ولا يعيد تقييم الأرصدة.

اختبارات C# الإضافية في `Monarch.Core.SmokeTests` تغطي إعادة الفتح والحفظ والترحيل والعكس. لم تُنفذ هنا لعدم توفر .NET SDK؛ تم التحقق فعلياً من تنفيذ مخطط SQLite واختبار ترحيل قيد متوازن ومنع تعديل سطوره باستخدام SQLite في بيئة الإعداد.

## Desktop accounting workflow (new stage)

The WPF desktop shell now initializes a persistent SQLite ledger in the current Windows user's local application data folder:

`%LOCALAPPDATA%\\MONARCH\\Data\\monarch-ledger.db`

On first launch it creates a small starter chart of accounts. The Arabic desktop interface exposes:

- Dashboard counts read from the local ledger (not demo financial amounts).
- Chart of accounts listing and account creation.
- A multi-line journal draft grid with account selection, debit/credit validation, balance enforcement, and minor-unit precision.
- Journal listing and posting of the selected draft.
- Trial balance generated from posted ledger data.

Historical note from the first desktop workflow stage (superseded by the tenant integration section above): this initial screen originally lacked multi-company isolation and backup/restore UI. The current accounting path uses `TenantAccountingSession` and `TenantLedgerStore`; period controls, tax workflows, password reset/reactivation UI, audit browsing UI, and full financial statement acceptance remain incomplete. This remains a development build, not a production release.

### Build and run on Windows

Install Visual Studio 2022 with the .NET desktop development workload and the .NET Framework 4.6.1 targeting pack/reference assemblies. Open `MonarchERP.sln`, restore NuGet packages, set `Monarch.Desktop` as startup project, then build and run. The desktop target is .NET Framework 4.6.1 for legacy compatibility. Actual runtime compatibility must still be validated on clean Windows 7 SP1, 8, 8.1, 10, and 11 machines; .NET Framework 4.6.1 may require its supported prerequisites and is out of mainstream support.

Run the Python structural checks from the repository root:

`py -3 -m unittest discover -s tests -v`

The C# project has not been compiled in this development environment because the .NET SDK/Windows desktop build toolchain is unavailable here.


## المستخدمون والصلاحيات المحلية — مرحلة تأسيسية

أضيف `IdentityStore` في `src/Monarch.Core/Security` ومخطط `database/security.sql` إلى قاعدة SQLite المحلية نفسها:
- عند أول تشغيل، يطلب التطبيق إنشاء حساب مدير أولي؛ لا يوجد اسم مرور افتراضي ثابت.
- تخزن كلمات المرور كتجزئة PBKDF2-HMAC-SHA256 مع Salt عشوائي مستقل لكل مستخدم و210,000 دورة، ولا تخزن كلمة المرور الأصلية.
- سياسة كلمة المرور الحالية: 12 حرفاً على الأقل.
- أدوار مبدئية: مدير النظام، محاسب، مشاهد، مع صلاحيات منفصلة لقراءة الحسابات وإدارتها وإنشاء القيود وترحيلها وعرض التقارير وإدارة المستخدمين.
- قفل مؤقت بعد خمس محاولات دخول فاشلة لمدة 15 دقيقة.
- يسجل النظام عمليات الدخول وإنشاء المستخدمين وتعطيلهم في سجل تدقيق محلي.
- شاشة إدارة المستخدمين تسمح للمدير بإنشاء مستخدم وتحديد دوره وتعطيل مستخدم قائم.

ملاحظة تاريخية لهذه المرحلة التأسيسية: عند إضافتها لم يكن دفتر الأستاذ قد عُزل بعد. أُنجز العزل لاحقاً عبر `TenantLedgerStore` وربط WPF بـ`TenantAccountingSession` كما هو موثق في الحالة الحالية أعلاه. ما زالت شاشة استعراض/تصدير سجل التدقيق واستعادة كلمة المرور وإعادة تفعيل المستخدم من الواجهة غير مكتملة. اختبارات Python لا تحل محل اختبارات C# على Windows.

تشغيل جميع اختبارات Python:

`py -3 -m unittest discover -s tests -v`


## دليل المنشآت والفروع — مرحلة تأسيسية غير مفعّلة محاسبياً

أضيفت طبقة دليل المنشآت في `src/Monarch.Core/Organizations` ومخطط `database/tenancy.sql`، وتشمل:
- سجل منشآت مع رمز فريد، اسم قانوني/تجاري، بلد، عملة أساسية ومنطقة زمنية.
- إنشاء فرع مقر رئيسي تلقائياً لكل منشأة جديدة، مع منع وجود أكثر من مقر رئيسي واحد للمنشأة.
- رموز فروع فريدة داخل المنشأة، لا على مستوى النظام كله.
- جداول إسناد وصول المستخدمين إلى المنشآت بأدوار Administrator/Accountant/Viewer، وإسناد الوصول للفروع بقيود مفاتيح خارجية مركبة تمنع ربط مستخدم بفرع خارج منشأته المصرح بها.
- سجل تدقيق خاص بالمنشأة والفرع.

`CompanyDirectoryStore` يوفر عمليات إنشاء المنشأة والفرع ومنح الوصول وقراءة القوائم. يهيأ المخطط بعد `ledger-storage.sql` و`security.sql`؛ لأن مخططه يعتمد على العملات والمستخدمين.

**قيد أمان تاريخي لهذه المرحلة:** وقت إنشاء دليل المنشآت كانت جداول دفتر الأستاذ القديم أحادية المنشأة. لا تستخدم هذه الفقرة كحالة حالية؛ تم لاحقاً إضافة جداول `monarch_tenant_*`، ومستودع `TenantLedgerStore`، وأداة ترحيل، وربط واجهة WPF بسياق منشأة/فرع. تبقى اختبارات C# وWindows الفعلية بوابة إلزامية قبل الإنتاج.

تشغيل اختبارات المخطط:
```powershell
py -3 -m unittest discover -s tests -v
```

الاختبارات الحالية تختبر مخططات SQLite وقيودها، ولا تثبت بناء C# أو تشغيل WPF.


## عزل المحاسبة حسب المنشأة والفرع — مرحلة تنفيذية جديدة

أضيف `TenantLedgerStore` ومخطط `database/tenant-accounting.sql` لتشغيل دفتر أستاذ منفصل لكل منشأة وفرع، مع إبقاء جداول دفتر الأستاذ القديم دون تغيير لتسهيل التوافق والتراجع. وتشمل الحماية:

- جداول منفصلة للحسابات والقيود والسطور مع `company_id` إلزامي.
- مفاتيح خارجية مركبة تمنع ربط قيد بحساب أو فرع تابع لمنشأة أخرى.
- السماح بتكرار رمز الحساب ورقم القيد بين منشآت مختلفة، مع فرض التفرد داخل المنشأة.
- تحقق من توازن القيد وصحة العكس وعدم تعديل السطور المرحلة.
- كل قراءة محاسبية في المستودع الجديد محددة بمعرّف المنشأة؛ وتقارير القيود تتطلب فرعاً محدداً.
- فحص عضوية المستخدم في المنشأة، ودوره، وصلاحية الفرع؛ المدير يتجاوز إسناد الفرع، بينما يحتاج المحاسب/المشاهد إلى إسناد فرعي صريح.
- أضيف `GrantBranchAccess` لإسناد المستخدم إلى فرع ضمن منشأته فقط.

تهيئة قاعدة البيانات بالترتيب: `ledger-storage.sql` ثم `security.sql` ثم `tenancy.sql` ثم `tenant-accounting.sql`. أضيف ملف المخطط الجديد إلى ملفات إخراج WPF.

تشغيل اختبارات هذه المرحلة على Windows:
```powershell
.\scripts\test-tenant-accounting.ps1
```
أو تشغيل جميع اختبارات Python:
```powershell
py -3 -m unittest discover -s tests -v
```

**حدود هذه المرحلة وقت إصدارها:** لم يكن المستودع مربوطاً بواجهة WPF حينها. تم تجاوز هذا القيد لاحقاً بإضافة بوابة الترحيل الآمن ومحدد المنشأة/الفرع وربط الشاشة بـ`TenantAccountingSession`. لا تزال اختبارات C# وWindows الفعلية مطلوبة.

### نتائج التحقق لهذه المرحلة

- نجحت جميع اختبارات Python الحالية: **66/66**، وتشمل اختبارات المخططات والعزل بين المنشآت والفروع، والصلاحيات، وترحيل معرفات المنشأة/الفرع الافتراضية القديمة إلى GUID.
- أضيفت اختبارات C# دخانية لمحرك تعدد المنشآت تشمل حسابين مستقلين بنفس رموز الحسابات وأرقام القيود، تقارير معزولة، ورفض إنشاء قيد بواسطة مستخدم Viewer. لم تُشغّل لأن .NET SDK غير مثبت في بيئة الإعداد.
- تم فحص ZIP بعد إنشائه. لا يعني نجاح اختبارات Python أن WPF أو مكتبة C# قد بُنيت أو شُغّلت.

## النسخ الاحتياطي والاستعادة المشفران — مرحلة تأسيسية

أضيفت `BackupRecoveryService` في `src/Monarch.Core/Backup` لتوفير:
- إنشاء نسخة متسقة من قاعدة SQLite باستخدام SQLite online backup API، بدلاً من نسخ ملف قاعدة البيانات الخام أثناء احتمال وجود معاملات نشطة.
- تشفير ملف النسخة باستخدام AES-256-CBC مع تحقق سلامة HMAC-SHA256 (Encrypt-then-MAC)، ومفاتيح مشتقة عبر PBKDF2-HMAC-SHA1 مع 310,000 تكرار وSalt عشوائي. تم اختيار واجهة PBKDF2 المتوافقة مع .NET Framework 4.6.1؛ لا تستخدم كلمة مرور تقل عن 12 حرفاً.
- التحقق من MAC قبل فك التشفير، ثم تشغيل `PRAGMA integrity_check` على قاعدة البيانات الناتجة.
- استعادة النسخة بعد التحقق منها، مع إنشاء نسخة أمان مشفرة من قاعدة البيانات الحالية قبل الاستبدال، والاحتفاظ بملف رجوع مؤقت إلى أن ينجح فحص القاعدة المستعادة.
- سياسة احتفاظ بعدد نسخ محدد ضمن عائلة اسم الملف نفسها، حتى لا تحذف نسخ قاعدة بيانات أخرى في المجلد.

**حدود مهمة:** هذه الخدمة تنسخ قاعدة البيانات المشتركة كاملة بما فيها جميع المنشآت؛ لا توفر بعد استعادة منشأة واحدة بصورة مستقلة. يجب إغلاق MONARCH وكل عملية أخرى تستخدم ملف SQLite قبل الاستعادة. تشفير النسخة الاحتياطية لا يعني أن ملف قاعدة البيانات الحي مشفر؛ حماية قاعدة البيانات الحية تعتمد حالياً على صلاحيات Windows. احتفظ بكلمة مرور النسخة في مدير كلمات مرور منفصل؛ فقدانها يعني تعذر فك النسخة.

اختبارات C# المضافة في `tests/Monarch.Core.SmokeTests/Program.cs` تغطي إنشاء النسخة، وفحص سلامتها، ورفض كلمة المرور الخاطئة، والاستعادة، والاحتفاظ بنسخة أمان. لم يتم تشغيل هذه الاختبارات في بيئة التطوير الحالية لعدم توفر .NET SDK؛ يجب تنفيذ `scripts/test-backup.ps1` على جهاز تطوير Windows قبل اعتماد الميزة.


## واجهة النسخ الاحتياطي وأداة الاستعادة — مرحلة مكتبية جديدة

أضيفت واجهة **النسخ الاحتياطي** إلى WPF، ولا تظهر إلا للمستخدم الذي يملك `backups.manage` (مدير النظام في الأدوار الافتراضية). توفر الواجهة:
- إنشاء نسخة SQLite متسقة ومشفرة إلى `%LOCALAPPDATA%\MONARCH\Backups`.
- التحقق من نسخة موجودة عبر كلمة المرور وفحص سلامة SQLite.
- عرض ملفات النسخ المحلية وأحجامها وتواريخها.
- سياسة احتفاظ افتراضية تصل إلى 20 نسخة ضمن عائلة ملفات النسخ.

أضيف مشروع `Monarch.Recovery` المستقل المستهدف `net461` لاستعادة قاعدة البيانات خارج التطبيق؛ وذلك لأن استبدال ملف SQLite أثناء فتح WPF غير آمن. طريقة الاستعادة:
1. أغلق MONARCH ERP وكل برنامج قد يستخدم قاعدة البيانات.
2. شغّل `Monarch.Recovery.exe` مع مسار قاعدة البيانات ومسار ملف `.mbackup`.
3. أدخل كلمة المرور، وانتظر نجاح التحقق، ثم اكتب `RESTORE` للتأكيد.
4. تنشئ الأداة نسخة أمان مشفرة من قاعدة البيانات الحالية قبل الاستبدال، ثم تتحقق من القاعدة المستعادة.

مثال:
```powershell
.\Monarch.Recovery.exe "$env:LOCALAPPDATA\MONARCH\Data\monarch-ledger.db" "D:\Backups\monarch-20261106.mbackup"
```

البناء ينشر الأداة في `artifacts/recovery-net461` بجانب تطبيق سطح المكتب. لا تزال الاستعادة تشمل قاعدة البيانات كاملة ولا تدعم استعادة منشأة واحدة. النسخ التلقائي المجدول غير مضاف في هذه المرحلة؛ الإنشاء يتم يدوياً من الواجهة. كما لم يُشغّل بناء .NET/WPF في بيئة الإعداد لعدم توفر .NET SDK، لذا يجب اختبار البناء وتشغيل الواجهة وأداة الاستعادة على Windows قبل اعتمادها.

### نتائج تحقق الحزمة الحالية
- اجتازت اختبارات Python البنيوية ومخططات SQLite: راجع العدد الفعلي في تقرير التسليم.
- اختبارات C# الخاصة بالتشفير والاستعادة موجودة ضمن `Monarch.Core.SmokeTests`، لكنها لم تُشغّل في هذه البيئة لعدم توفر .NET SDK.
- نجاح الاختبارات البنيوية لا يثبت أن مشروع WPF أو أداة الاستعادة بُنيا أو عملا على Windows.


## واجهة القيود متعددة الأسطر — تحديث 2026-11-06
أصبحت شاشة إنشاء القيد تعرض شبكة أسطر قابلة للإضافة والحذف، مع اختيار الحساب لكل سطر وإدخال المدين أو الدائن. قبل الحفظ تتحقق الواجهة من وجود سطرين على الأقل، ومن أن كل سطر يستخدم جانباً واحداً فقط بمبلغ موجب، ومن تساوي إجمالي المدين والدائن. تحفظ المبالغ بوحدات العملة الصغرى عبر `MinorUnits`، ثم ينشئ المستودع القيد كمسودة. هذه الميزة مرتبطة حالياً بمستودع SQLite الأحادي القديم؛ لا تعني تفعيل تعدد المنشآت في WPF.

اختبارات Python البنيوية لهذه المرحلة لا تثبت أن WPF أو كود C# تم بناؤه. يلزم بناء واختبار التطبيق على Windows مع .NET SDK قبل استخدامه تشغيلياً.


## Tenant session boundary — merged foundation (2026-11-06; historical snapshot)

تم دمج `TenantAccountingSession` مع `CompanyDirectoryStore` لتوفير سياق محاسبي صريح مربوط بالمستخدم والمنشأة والفرع. قبل إنشاء السياق، يتحقق المسار من عضوية المستخدم النشطة في المنشأة، ومن إسناد الفرع النشط (أو دور Administrator على مستوى المنشأة)، ثم ينفذ قراءة مصرحاً بها من `TenantLedgerStore`. وتُمرر عمليات الحسابات والقيود والتقارير داخلياً `userId + companyId + branchId` إلى المستودع متعدد المنشآت.

**حد أمان وقتها:** لم يكن `TenantAccountingSession` قد استُخدم بعد في WPF. تم تجاوز هذا القيد في التحديث اللاحق المؤرخ 2026-11-07؛ راجع الحالة الحالية في بداية هذا الملف. تبقى اختبارات Windows والتوافق الفعلي غير منجزة.

أضيفت 3 اختبارات Python بنيوية للتحقق من تصفية الفروع المصرح بها، ورفض فتح سياق دون عضوية صالحة، وأن عمليات السياق تستخدم `TenantLedgerStore` ولا تسمح بالرجوع إلى المستودع الأحادي. إجمالي الاختبارات البنيوية في هذه الحزمة: 77. هذه الاختبارات لا تستبدل بناء C# أو اختبارات تشغيل WPF.

## Tenant desktop integration gate — 2026-11-06 (historical status, superseded on 2026-11-07)

At this checkpoint `TenantAccountingSession` was not yet the active WPF data path. The next-day update below records the completed source-level UI integration and migration gate. This historical note must not be read as the current code state.

Historical security checkpoint (2026-11-06): `Post` and `Reverse` first checked company membership before resolving a journal, then checked its branch. This was superseded by the 2026-11-07 hardening: every ledger API, including company-level chart reads/writes, requires the selected branch and performs authorization in the same SQLite transaction as the operation.

At that checkpoint no legacy ledger migration had been performed. This was intentionally blocked until the later dry-run migration, encrypted pre-migration backup, transactional import, per-account/trial-balance reconciliation, idempotency and rollback checks were added. The 2026-11-07 WPF gate now blocks startup if legacy data exists without a completed migration record.

Validation in this stage: Python structural/SQLite tests only. C# compilation, WPF execution, and Windows compatibility runtime tests were not performed because the environment has no `dotnet` SDK and is not Windows.

---

## أحدث مرحلة تنفيذ — ترحيل آمن وربط WPF بالمنشآت (2026-11-06)

هذه الفقرة هي الحالة الأحدث، وتستبدل القيود المرحلية الأقدم أعلاه فيما يخص مسار WPF وتعدد المنشآت:

- أضيفت أداة `tools/migrate_legacy_ledger.py` لترحيل دليل الحسابات والقيود والسطور من الجداول القديمة إلى جداول `monarch_tenant_*` مع تعيين صريح للمنشأة والفرع.
- تبدأ الأداة بفحص `SQLite integrity_check` و`foreign_key_check`، وتتحقق من العملة وأُسّها، وتوازن القيود المرحلة، وصحة القيود العكسية، وعدم وجود بيانات سابقة في دفتر المنشأة الهدف.
- وضع `--dry-run` لا يكتب إلى قاعدة البيانات؛ يعرض تقرير تحقق فقط. وضع الاستيراد ينشئ نسخة SQLite متسقة ثم يشفرها بـ AES-256-GCM مع اشتقاق مفتاح PBKDF2-HMAC-SHA256 (600,000 دورة)، قبل بدء معاملة الاستيراد.
- الاستيراد ذري داخل `BEGIN IMMEDIATE`، يحتفظ بمعرفات الحسابات والقيود بصيغة GUID التي تتطلبها نواة C#، ويعيد إنشاء سطور القيود، ويتحقق من الأعداد وإجماليات كل قيد والأرصدة المرحلة لكل حساب. تُرفض معرفات النصوص غير المتوافقة وتصادمات المفاتيح العامة. تُسجل هوية الترحيل لمنع تكراره. لا تحذف الأداة أي جدول قديم، ولا تستبدل ملف النسخة الاحتياطية الموجود.
- أضيفت أداة `tools/decrypt_migration_backup.py` لفك النسخة الاحتياطية الخاصة بأداة الترحيل والتحقق من سلامة SQLite. هذه النسخة بصيغة AES-GCM الخاصة بالأداة، وليست صيغة ملفات `.mbackup` التي تنشئها واجهة WPF.
- رُبطت واجهة WPF الآن بـ `TenantAccountingSession` و`TenantLedgerStore`. تظهر نافذة اختيار المنشأة والفرع المصرح بهما قبل بناء مساحة العمل، وتستخدم كل عمليات الحسابات والقيود والتقارير السياق المحدد. الترحيل والعكس يتحققان أيضاً من أن القيد يقع في الفرع المحدد نفسه، لا مجرد فرع آخر يستطيع المستخدم الوصول إليه. تُقرأ العملة وأُسّها من إعداد المنشأة ولا يفترض التطبيق ريالاً سعودياً أو منزلتين عشريتين.
- يمنع التطبيق فتح دفتر العمل إذا وجد بيانات قديمة ولم يجد سجل ترحيل مكتمل. عند إنشاء مستخدم جديد من شاشة المستخدمين، يمنح وصولاً إلى المنشأة والفرع الحاليين فقط وفق الدور المختار.

### تنفيذ ترحيل قاعدة بيانات قديمة

نفّذ الأوامر من مجلد المشروع على جهاز Windows أو جهاز تطوير مثبت عليه Python 3.10 أو أحدث. يجب إغلاق MONARCH أثناء الترحيل. افتح التطبيق مرة واحدة أولاً إذا كانت قاعدة البيانات قديمة حتى يهيئ مخططات دليل المنشآت والجداول الجديدة، ثم أغلقه بالكامل.

```powershell
python -m pip install -r tools/requirements.txt
python tools/migrate_legacy_ledger.py --database "$env:LOCALAPPDATA\MONARCH\Data\monarch-ledger.db" --company-id 00000000-0000-0000-0000-000000000001 --branch-id 00000000-0000-0000-0000-000000000002 --dry-run --report migration-dry-run.json
```

راجع `migration-dry-run.json`. إذا لم توجد أخطاء وكان تعيين المنشأة والفرع صحيحاً، نفّذ الاستيراد:

```powershell
python tools/migrate_legacy_ledger.py --database "$env:LOCALAPPDATA\MONARCH\Data\monarch-ledger.db" --company-id 00000000-0000-0000-0000-000000000001 --branch-id 00000000-0000-0000-0000-000000000002 --report migration-import.json
```

ستطلب الأداة عبارة مرور مرتين (12 حرفاً على الأقل)، وتنشئ نسخة مشفرة قبل الاستيراد. احتفظ بعبارة المرور خارج الجهاز. لفك نسخة الترحيل عند الحاجة:

```powershell
python tools/decrypt_migration_backup.py --input "PATH_TO_BACKUP.monarchbak" --output "recovered-ledger.sqlite"
```

**مهم:** لا تشغّل أمر الاستيراد على قاعدة إنتاج قبل مراجعة تقرير Dry-run، والتحقق من نسخة الاستعادة، والاحتفاظ بنسخة منفصلة. لا تنقل الأداة بيانات المبيعات أو المخزون أو المستخدمين؛ نطاقها دفتر الأستاذ القديم فقط. لا تحذف الجداول القديمة بعد نجاح النقل.

### اختبارات وحدود التحقق لهذه المرحلة

- `python -m unittest discover -s tests -v`: **92 اختباراً ناجحاً** في بيئة التطوير الحالية، تشمل اختبارات SQLite فعلية للترحيل، Dry-run، العكس، عدم التكرار، رفض اختلاف العملة والمعرفات غير المتوافقة، منع تصادم المفاتيح واستبدال النسخة، والتراجع الكامل عند فشل الاستيراد.
- فحص XML لمشاريع `.csproj` وملفات XAML: **7/7 ناجح**.
- لم يتوفر `dotnet` أو `csc` أو `msbuild` في بيئة التطوير؛ لذلك **لم يتم بناء C# أو WPF ولم يتم تشغيل التطبيق على Windows**. اختبارات Python لا تثبت سلامة تجميع C# أو عمل WPF.
- ما زال يلزم تشغيل بناء Windows CI، واختبارات C# الدخانية، وتجربة فتح قاعدة قديمة وجديدة على Windows 11، ثم اختبار توافق فعلي على Windows 10 و8.1 و7 SP1 قبل إصدار مثبت. لا يوجد MSI/Setup حتى الآن.


## بناء Windows والتحقق

على Windows 10/11 مع .NET 8 SDK وPython 3، افتح PowerShell في جذر المشروع وشغّل:

```powershell
./scripts/build-windows.ps1 -Configuration Release
./scripts/package-release.ps1 -Version 0.1.0
```

ينفذ السكربت اختبارات Python/SQLite، ثم restore/build للحل، واختبارات C# الدخانية، وينشر تطبيق WPF وأداة الاستعادة. تنتج حزمة Portable وبجانبها ملف SHA-256. الحزمة المحمولة غير موقعة وليست MSI؛ ويحتوي المستودع أيضاً على تعريف Inno Setup لإنشاء مثبت Windows من خلال مسار CI. يتطلب التطبيق .NET Framework 4.6.1 أو أحدث.

يوجد مسار GitHub Actions في `.github/workflows/windows-build.yml` لبناء Windows آلياً. يجب تشغيله على مستودع فعلي ومراجعة سجلاته قبل اعتبار بناء Windows ناجحاً. لم يتم التحقق بعد من التشغيل التفاعلي على Windows 7/8.1/10/11.


## تحديث 2026-11-07 — إصلاح حراسة تهيئة عضوية المنشأة

- عُدّل فحص تهيئة المدير الأول بحيث يتحقق من عضوية **المستخدم الذي سجل الدخول**، بدلاً من فحص وجود عضوية لأي مستخدم في قاعدة البيانات. هذا يمنع حالة وجود مستخدم آخر مرتبط بمنشأة من حجب إسناد المنشأة الافتراضية عن مدير نظام جديد لا يملك عضوية بعد.
- عُدّل حاجز ترحيل البيانات القديمة ليتحقق من اكتمال الترحيل للمنشأة الافتراضية المستهدفة تحديداً، بدلاً من قبول سجل ترحيل عام لمنشأة أخرى.
- أضيفت اختبارات Python بنيوية واختبارات C# دخانية للبحث عن عضوية المستخدم بصورة مستقلة.
- نتائج هذه البيئة بعد التعديل: 97/97 اختبار Python/SQLite ناجحاً. لم يتم بناء C# أو تشغيل WPF؛ يجب أن ينفذ ذلك Windows CI.


### التحقق من حزمة Windows
بعد إنشاء حزمة Portable والمثبت على Windows runner، ينفذ CI السكربت `scripts/verify-windows-release.ps1` للتحقق من ملفات الإصدار وبصمات SHA-256 ومحتويات ZIP الأساسية. لا تعتبر الحزمة صالحة إذا فشل هذا الفحص.


## تحديث أمني — 2026-11-07

تم تشديد عمليات دليل المنشآت والفروع داخل طبقة Core: إنشاء الفروع ومنح عضويات المنشآت والفروع يتطلب الآن معرف مدير نظام عام نشطاً، وتُنفذ الكتابات مع سجل التدقيق ضمن معاملات ذرية. استثناء التهيئة الذاتية محصور بالمنشأة الافتراضية ولا يسمح بتجاوز التفويض لمنشآت أخرى. راجع `docs/IMPLEMENTATION_REPORT_2026-11-07-DIRECTORY-AUTHORIZATION.md`.

نتائج الحزمة الأصلية لهذه المرحلة: 103/103 اختبار Python/SQLite. أُضيفت بعدها مراحل تجارية ومخزنية واختبارات عزل إضافية؛ لا تمثل هذه النتيجة عدد الاختبارات الحالي. لم يتم تشغيل بناء C# أو WPF على Windows.


## البيانات التجارية ودفتر حركة المخزون — 2026-11-07

أضيف `database/commercial-data.sql` لإنشاء جداول الأطراف التجارية، مجموعات الأصناف، وحدات القياس، الأصناف، المستودعات، وحركات المخزون. المخطط يستخدم مفاتيح مركبة مرتبطة بالمنشأة والفرع، ويخزن الكميات بوحدات milli والكلفة بوحدات العملة الصغرى الصحيحة. دفتر الحركة append-only؛ تمنع قاعدة البيانات تعديل/حذف الحركات، وتمنع الرصيد السالب افتراضياً، وتفرض مفتاح idempotency فريداً لكل منشأة.

أضيفت طبقة `Monarch.Core.Commercial.CommercialStore` لإنشاء العملاء/الموردين والوحدات والأصناف والمستودعات وتسجيل الحركات وقراءة الأرصدة مع فحص صلاحية المنشأة والفرع عند حدود التخزين. ملف المخطط يُنسخ إلى مخرجات WPF. هذه نواة بيانات وخدمات وليست بعد دورة مبيعات/مشتريات أو واجهات إدارة تجارية متكاملة؛ ولا يوجد حتى الآن ترحيل تلقائي من الفواتير إلى قيود الأستاذ أو محرك تقييم FIFO/المتوسط المرجح.

التحقق في هذه الحزمة: `python -m unittest discover -s tests -v` — **110 اختباراً ناجحاً** بما فيها 7 اختبارات تجارية جديدة. لم يُنفذ بناء C# أو تشغيل WPF لعدم توفر .NET SDK/Windows في بيئة إعداد الحزمة.


### تحويل المخزون بين المستودعات
تتضمن طبقة `CommercialStore` الآن عملية `TransferStock` لنقل المخزون بين مستودعين داخل المنشأة نفسها. تتطلب صلاحية كتابة على فرعي المصدر والوجهة، وتتحقق من المستودعين والصنف والرصيد المتاح، ثم تسجل حركتي الخروج والدخول ضمن معاملة SQLite واحدة وبمفتاحي منع تكرار مرتبطين. لا تُعد هذه الميزة بديلاً عن جرد المخزون واعتماده؛ مسار الجرد والتسوية ما زال ضمن الأعمال المتبقية.

### Sales & purchase document foundation

أضيفت `CommercialDocumentStore` لإنشاء مسودات المبيعات والمشتريات وحساب صافي البنود والضريبة بمعدل basis points ومبالغ العملة الصغرى الصحيحة، مع حفظ لقطة بيانات الصنف. عند الترحيل تُسجل حركة استلام للمشتريات أو صرف للمبيعات، وتتحول حالة المستند ويُنشأ حدث `monarch_accounting_posting_outbox` ضمن معاملة SQLite واحدة. يمنع المخطط تعديل المستندات المرحلة أو حذفها، ويمنع تكرار حدث outbox. **هذا ليس ترحيلاً تلقائياً إلى الأستاذ العام بعد**: outbox هو تسليم موثوق ينتظر عامل معالجة يربطه بـ`TenantLedgerStore`. لا تزال المرتجعات والمدفوعات وتقارير VAT وتقييم FIFO/المتوسط المرجح وواجهات WPF واختبارات Windows مطلوبة.


## Commercial-to-ledger posting (2026-11-07)

أضيف عامل Outbox لربط مستندات المبيعات والمشتريات المرحلة بدفتر الأستاذ متعدد المنشآت والفروع. يستخدم أرقام قيود حتمية لتفادي تكرار القيد عند إعادة المحاولة بعد انقطاع، ويتحقق من نوع الحسابات قبل الترحيل. المبيعات: ذمم مدينة/إيراد/ضريبة مخرجات. المشتريات: مخزون للأصناف المخزنية، مصروف للأصناف الخدمية وغير المخزنية، ضريبة مدخلات، وذمم دائنة.

تشغيل الاختبارات المتاحة: `python -m unittest discover -s tests -q`. هذه الاختبارات لا تستبدل بناء C# أو تشغيل اختبارات التكامل على Windows. رموز الحسابات الافتراضية أمثلة ويجب مطابقتها مع دليل حسابات كل منشأة قبل الاستخدام. كما أن اعتماد Outbox منفصل عن معاملة دفتر الأستاذ؛ تتم معالجة انقطاع العملية بإعادة المحاولة والرقم الحتمي، وليس بمعاملة موزعة واحدة.

### Commercial payments foundation (historical snapshot)
The initial payment-store stage added fully allocated customer receipts and supplier payments. Its note that payment journals were not yet posted was superseded by `CommercialPaymentAccountingOutboxWorker`, documented in the section below. Unapplied advances, voids, refunds and reversals remain separate work.


## Commercial payment accounting outbox

The commercial payment workflow now has a dedicated `CommercialPaymentAccountingOutboxWorker`. It posts customer receipts (debit cash/bank, credit receivables) and supplier payments (debit payables, credit cash/bank) into the tenant ledger. The worker validates active account types, scopes queue reads and journal writes to the selected company and branch, and uses deterministic `AUTO-PAY-<payment-guid>` journal numbers so a retry after a ledger commit but before outbox acknowledgement does not duplicate the journal. Configure the cash/bank account code on each payment and configure the receivables/payables control-account codes per company. The ledger commit and outbox acknowledgement remain separate transactions; this is retry-safe, not a single cross-store atomic transaction.

## كشوف العملاء والموردين وأعمار الذمم — إضافة 2026-11-07

أضيف `CommercialReceivablesPayablesReportStore` لتوليد:
- أعمار الذمم المدينة للعملاء والدائنة للموردين وفق تاريخ مرجعي، مع شرائح غير مستحق، 1–30، 31–60، 61–90، وأكثر من 90 يوماً.
- كشوف حساب خلال فترة، مع إظهار الحركات المدينة والدائنة والرصيد التراكمي الذي يحتسب الرصيد الافتتاحي قبل بداية الفترة.
- احتساب الدفعات من التخصيصات المرتبطة بفواتير مرحلة فقط، وبحسب تاريخ السداد وحالة السند.
- استعلامات قراءة فقط مع التحقق من صلاحية المنشأة والفرع، بما في ذلك دور Viewer.

هذه تقارير دفتر فرعي تجارية وليست بعد مطابقة نهائية مع حسابات الرقابة في الأستاذ العام. لا تشمل حالياً الدفعات المقدمة غير المخصصة أو الإشعارات الدائنة والمرتجعات أو فروقات العملة. واجهات WPF وتصدير PDF/Excel ما زالت مطلوبة.

## Commercial returns foundation — 2026-11-07

أضيف `CommercialReturnStore` لدعم مسودات وترحيل مرتجعات المبيعات والمشتريات المرتبطة حصراً بفاتورة أصلية مرحلة. يجب أن تتطابق المنشأة والفرع والطرف والمستودع والعملة ونوع الفاتورة. ترتبط كل سطر مرتجع بسطر الفاتورة الأصلي، ويُعاد فحص الكمية المتبقية عند الترحيل، مع حارس SQLite يمنع تجاوز الكمية الأصلية حتى عند وجود مسودات متزامنة. مرتجع المبيعات يزيد الكمية (`SalesReturn`) ومرتجع المشتريات يخفضها (`PurchaseReturn`). تحفظ حركة المخزون وحالة المرتجع وحدث `monarch_return_accounting_outbox` في معاملة واحدة، وتصبح المستندات المرحلة غير قابلة للتعديل أو الحذف.

**حدود تأسيس المرتجعات:** لم تكن هذه المرحلة تشمل عامل الترحيل المحاسبي؛ أُضيف العامل لاحقاً في `CommercialReturnAccountingOutboxWorker`. لا تزال تكلفة البضاعة المباعة وتقييم المخزون الدائم وتكامل تقارير VAT وواجهات WPF غير مكتملة. راجع `docs/IMPLEMENTATION_REPORT_2026-11-07-COMMERCIAL-RETURNS.md` و`docs/IMPLEMENTATION_REPORT_2026-11-07-RETURN-ACCOUNTING-OUTBOX.md`.


### Latest verification snapshot — 2026-11-07

أحدث حزمة مصدرية تتضمن مرحلة المرتجعات. نتائج بيئة التطوير: **144/144 اختبار Python/SQLite ناجح**، وفحص XML/XAML **6/6**، وإعادة تهيئة مخطط SQLite مرتين بنجاح. لا يتوفر .NET SDK أو Windows runtime في بيئة إعداد الحزمة؛ لذلك لا يوجد ادعاء ببناء C# أو تشغيل WPF أو إنشاء مثبت فعلي.


## Commercial return accounting outbox — 2026-11-07

أضيف `CommercialReturnAccountingOutboxWorker` لمعالجة أحداث مرتجعات المبيعات والمشتريات المرحلة وربطها بدفتر الأستاذ عبر `TenantLedgerStore`. يستخدم أرقام قيود حتمية `AUTO-RET-*`، ويتحقق من صلاحية المنشأة/الفرع وحالة المستند ونوع الحدث والحسابات النشطة وأنواعها. مرتجع المبيعات يعكس الذمم المدينة ومردودات المبيعات وضريبة المخرجات؛ ومرتجع المشتريات يعكس الذمم الدائنة وصافي المشتريات وضريبة المدخلات. تتم إعادة المحاولة بأمان عند توقف التطبيق بين ترحيل القيد وإقرار Outbox.

**حدود مهمة:** لم يكتمل بعد عكس تكلفة البضاعة المباعة أو تقييم المخزون FIFO/المتوسط المرجح. لا يسجل العامل قيمة مرتجع الشراء في حساب المخزون بسعر البيع أو سعر الفاتورة؛ بل يعكس صافي المشتريات وفق معالجة دورية، إلى أن تُحفظ طبقات تكلفة موثوقة. كذلك لا تزال واجهات WPF، وتكامل تقارير VAT، وبناء C# واختبارات Windows مطلوبة.


### تحقق الحزمة — 2026-11-07

بعد إضافة عامل ترحيل المرتجعات، نجحت اختبارات Python/SQLite **149/149**، واجتاز فحص XML/XAML **7/7**. لم يتوفر `dotnet` في بيئة التنفيذ؛ لذلك لم يُنفذ بناء C# أو تشغيل WPF أو بناء مثبت Windows.

## Inventory valuation algorithm — 2026-11-07

Added `InventoryValuationEngine` with two deterministic valuation methods: FIFO and moving weighted average. It processes one warehouse/item movement stream in stable chronological/sequence order, uses milli-quantities and integer minor-currency units, rejects outbound quantities beyond available stock, and returns movement-level cost/balance snapshots plus remaining FIFO layers. Transfers are expected as paired outbound/inbound movements carrying the source cost.

**Important scope boundary at that checkpoint:** the engine was standalone. Later stages added persistent movement sequencing, document cost allocations and return-cost reversals. FIFO layer consumption, transfer cost lineage, rounding reconciliation and full Inventory/COGS-to-GL reconciliation remain incomplete; do not use this as production inventory valuation.

### Persistent inventory valuation snapshots

`InventoryValuationStore` now rebuilds a scoped warehouse/item valuation from immutable stock movements and persists an append-only run header, movement-level balances/costs, and remaining FIFO layers. Snapshot rows are written in one SQLite transaction and are protected against update/delete. The store checks company/branch write access and verifies the active stock item and warehouse. Initialize it with `database/inventory-valuation.sql`.

Historical note: at that point snapshots were not integrated with document posting. Later stages added persistent document and return cost allocations plus return cost reversals. Full Inventory/COGS-to-GL reconciliation and Windows C# acceptance remain open.


### Inventory valuation ordering note (2026-11-07; superseded)
At that checkpoint SQLite `rowid` was used as a transitional tie-breaker. The later persistent stock movement sequence stage added a monotonic `ledger_sequence` and migration/backfill. Cost lineage and full COGS/Inventory reconciliation remain open.


### Persistent stock movement sequence (2026-11-07)

The stock ledger now stores a monotonic `ledger_sequence` per company/warehouse/item stream. Movement inserts and both warehouse-transfer legs allocate sequence numbers within their SQLite transaction. `CommercialStore.Initialize` upgrades older databases by adding the column, backfilling legacy rows in timestamp/insertion order, and creating a unique partial index. Inventory valuation consumes this persisted sequence rather than timestamp/UUID ordering. This is an ordering foundation only: cost allocations, invoice/return atomic costing, COGS/Inventory posting, and GL reconciliation remain incomplete. Back up an existing database before applying schema upgrades. See `docs/IMPLEMENTATION_REPORT_2026-11-07-PERSISTENT-MOVEMENT-SEQUENCE.md`.


### Document posting inventory costing — 2026-11-07

Commercial purchase posting now uses each document line's net unit price for the receipt movement. Sales posting previews the warehouse/item ledger in persisted `ledger_sequence` order and calculates the issue cost using moving weighted average before inserting the issue. The costing preview, stock movement insertion, document status update, and accounting outbox event share the document-posting SQLite transaction. Document-created movements now allocate their own persistent sequence numbers.

**Scope warning:** this posting path currently uses moving weighted average only. FIFO document allocations, configurable costing policy, landed-cost allocation, original-cost return reversals, source-cost transfers, COGS/Inventory journals, GL reconciliation, and Windows build/runtime verification remain incomplete. Do not treat the result as production financial certification. See `docs/IMPLEMENTATION_REPORT_2026-11-07-DOCUMENT-INVENTORY-COSTING.md`.


### Persistent document inventory cost trace

The commercial document posting path now writes an immutable `monarch_inventory_cost_allocations` row for each stock receipt/issue in the same SQLite transaction as the stock movement, document status transition, and accounting outbox event. Each row links the commercial document line to the resulting stock movement and stores quantity, unit cost, rounded extended cost, and the costing basis (`DocumentCost` for purchase receipts and `MovingWeightedAverage` for sales issues). This establishes a durable cost audit trail; return reversals, FIFO layer depletion, transfer-cost propagation, and general-ledger COGS/Inventory posting remain separate work and are not claimed complete.


## أحدث إضافة — عكس تكلفة المرتجعات (2026-11-07)
- أصبح مرتجع المبيعات يستعيد تكلفة الصرف التاريخية من تخصيص سطر فاتورة البيع، ويُنشئ حركة إرجاع وتخصيص تكلفة عكسي دائم.
- أصبح مرتجع المشتريات يستعيد تكلفة الاستلام التاريخية، مع عكس قيمة المخزون لا سعر الصنف الحالي.
- أضيف سجل غير قابل للتعديل/الحذف لتخصيصات تكلفة المرتجعات، مربوط بالمنشأة والفرع وسطر المرتجع والحركة والتخصيص الأصلي.
- أضيفت قيود عكس Inventory/COGS لمرتجعات المبيعات، وقيود Inventory وفروقات سعر الشراء لمرتجعات المشتريات عبر مشغل Outbox.
- تُحفظ حركات المرتجعات بتسلسل دائم داخل المستودع/الصنف.
- اجتاز هذا التحديث 185 اختبار Python/SQLite. لم يُبنَ C# ولم تُشغّل WPF لعدم توفر .NET SDK وWindows.
- لا تزال FIFO allocations والتحويلات ومطابقة دفتر المخزون مع الأستاذ العام ومثبت Windows غير مكتملة. توجد أيضاً نقطة تقريب للوحدات الصغرى في المرتجعات الجزئية موثقة في تقرير المرحلة؛ لا تستخدم الإصدار للإقفال أو الإنتاج. راجع `docs/IMPLEMENTATION_REPORT_2026-11-07-RETURN-COST-REVERSALS.md`.


## Tenant UI authorization hardening — 2026-11-07

- Removed company-only `GetAccounts` and `AddAccount` overloads from `TenantLedgerStore`; all operational ledger APIs now require `userId`, `companyId`, and `branchId`.
- Company-level chart-of-accounts data remains shared inside one company, but every chart read/write now requires active access to the explicitly selected branch. Journal reads, reports, creation, posting and reversal remain branch-scoped.
- Moved active-user, active-company, active-branch, company-role and branch-membership checks into the same SQLite transaction as the associated ledger read/write. This closes the previous gap where chart reads/writes could be made with company membership alone and reduces permission-revocation race windows.
- Posting and reversal resolve the target journal only after selected-branch authorization, then require an exact branch match in the same transaction.
- Updated all three commercial accounting Outbox workers to pass `branchId` when reading the chart of accounts.
- Added C# smoke coverage for cross-company account isolation, unassigned-branch denial, Viewer write denial, branch mismatch on posting/reversal, and permission revocation after a session was opened.
- Python/SQLite suite: **190/190 passed**. C# smoke tests were updated but not executed; `dotnet`, `msbuild`, `csc`, and Windows are unavailable in this environment.


## تحديث أمني — صلاحيات المستندات التجارية (2026-11-07)
أصبح فحص دور المستخدم وعضوية المنشأة والفرع في `CommercialDocumentStore` يجري داخل معاملة SQLite نفسها المستخدمة لإنشاء المسودة أو ترحيل المستند، بدلاً من فحص تمهيدي على اتصال منفصل. يُرفض Viewer وتُشترط العضويتان النشطتان. أضيفت اختبارات Python بنيوية للتحقق من ذلك. هذه الاختبارات لا تثبت سلوك التزامن في محرك C#؛ يلزم تشغيل اختبارات التكامل على Windows قبل اعتماد المسار إنتاجياً.


## تحديث 2026-11-07 — حماية تقييم المخزون

أصبح فحص المستخدم النشط وعضوية المنشأة والفرع لتقييم المخزون داخل معاملة SQLite نفسها التي تقرأ دفتر حركات المخزون وتحفظ لقطة التقييم. صلاحية الكتابة محصورة صراحة في `Administrator` و`Accountant`؛ لا يكفي إخفاء عناصر الواجهة، ولا يسمح لدور Viewer أو دور غير معروف بحفظ لقطة تقييم. هذا التحسين يقلل نافذة TOCTOU لكنه لا يجعل التقييم جزءاً ذرياً من ترحيل فاتورة البيع/الشراء بعد؛ هذا الربط وتوليد قيود Inventory/COGS ما زالا ضمن الأعمال المتبقية.


### Warehouse transfer costing (2026-11-07)
Warehouse transfers no longer accept a caller-supplied unit cost. The transfer service replays the source warehouse/item movement stream in persisted `ledger_sequence` order, derives the current moving-weighted-average carrying cost, and applies the same cost to the paired transfer-out and transfer-in movements in one SQLite transaction. Both source and target branch permissions are checked inside that transaction. A transfer is rejected when the source has no positive valued quantity, including when negative inventory is otherwise enabled. Company/item-configurable costing policy and full inventory-to-general-ledger reconciliation remain future work.

## تحديث 2026-11-07 — مطابقة المخزون مع دفتر الأستاذ (مرحلة قراءة فقط)

أضيف `InventoryGlReconciliationStore` لإنتاج مقارنة على مستوى المنشأة والفرع بين:
- قيمة المخزون الفرعي المحسوبة من سجل حركات المخزون الدائم، لكل مستودع وصنف، باستخدام المتوسط المرجح المتحرك فقط.
- الرصيد المدين الصافي لحساب أصل المخزون المحدد في دفتر الأستاذ، من القيود المرحلة/المعكوسة بحسب وقت ترحيلها وحتى لحظة القطع، وفي الفرع نفسه.

يفرض المستودع صلاحية المستخدم والمنشأة والفرع النشطة داخل معاملة SQLite نفسها، ويتحقق من أن حساب المخزون نشط ومن نوع Asset. النتيجة تتضمن كمية المخزون، قيمة دفتر المخزون، قيمة دفتر الأستاذ، والفرق (`GL - Inventory Subledger`) وتفصيلاً لكل مستودع/صنف.

**قيد محاسبي:** تتطلب المطابقة الآن لحظة قطع صريحة `asOfUtc`، وتطبق اللحظة نفسها على وقت حركة المخزون `occurred_utc` ووقت ترحيل القيد `posted_at_utc`. تُحتسب القيود التي كانت مرحلة عند لحظة القطع حتى لو عُكست لاحقاً، وتُحتسب قيود العكس فقط إذا كان وقت ترحيلها قبل القطع. هذه مطابقة تاريخية حسب أوقات الترحيل وليست حسب تاريخ المستند/الفترة التجارية. يُسمح حالياً بطريقة المتوسط المرجح المتحرك فقط؛ تُرفض FIFO صراحةً إلى أن تُحفظ طبقات FIFO عبر الصرف والتحويلات، حتى لا ينتج تقرير مضلل. يجب أن تتضمن حركات Opening أرصدة المخزون الافتتاحية، وألا يُستخدم حساب المخزون المحدد لقيود غير مخزنية. لا تنشئ الأداة قيود تصحيح؛ أي فرق يتطلب تحليل السبب واعتماد قيد مستقل. لم يتم بناء C# أو تشغيل WPF في بيئة الإعداد.

اختبارات Python البنيوية/SQLite بعد إضافة المطابقة ذات لحظة القطع: **210/210 ناجحة**. XML/XAML/مشاريع C#: **7/7**. هذه الاختبارات لا تثبت بناء C# أو تشغيل WPF.

## أحدث إضافة — Inventory Movement Lineage Audit (2026-11-07)

أضيف `InventoryMovementLineageStore` كخدمة تدقيق للقراءة فقط تربط كل حركة مخزون بمصدرها التجاري وتخصيص تكلفتها ورسالة Outbox والقيد الحتمي في دفتر الأستاذ:

- تمرير `userId + companyId + branchId + asOfUtc`، مع التحقق من نشاط المستخدم والمنشأة والفرع وعضوية الفرع داخل معاملة القراءة نفسها.
- ربط حركات `CommercialDocument` بالمستند وتخصيص `PurchaseReceipt`/`SalesIssue` وحدث `monarch_accounting_posting_outbox` والقيد `AUTO-COM-*`.
- ربط حركات `CommercialReturn` بالمرتجع والفاتورة الأصلية وتخصيص تكلفة المرتجع وحدث `monarch_return_accounting_outbox` والقيد `AUTO-RET-*`.
- إظهار معرف تخصيص التكلفة ومعرف القيد ورقمه وحالته، مع حالات واضحة للحركة التي تفتقد تخصيصاً أو مستنداً أو Outbox أو قيداً، أو التي لا يزال Outbox الخاص بها Pending/Failed.
- التحقق من زوج التحويل WarehouseTransfer: يجب وجود حركتي TransferOut وTransferIn فقط، في مستودعين مختلفين، للصنف والكمية والتكلفة نفسيهما. لا يُفترض وجود قيد GL مستقل للتحويل بين مستودعات المنشأة نفسها.
- تضمين `asOfUtc` لاستبعاد الحركات المستقبلية. الخدمة لا تنشئ قيوداً ولا تعدّل الحركات ولا تصلح الروابط تلقائياً.

أضيفت خمسة اختبارات Python/SQLite تنفذ استعلام الربط فعلياً على قاعدة اختبار مصغرة وتتحقق من ربط البيع والمرتجع وزوج التحويل، إضافة إلى العزل والقراءة فقط. مجموعة Python الكاملة الآن **215/215 ناجحة**، وفحص XML/XAML ومشاريع C# **7/7 ناجح**. هذه اختبارات بنيوية/SQLite وليست اختبار C# runtime. لم يتم بناء `Monarch.Core` أو WPF لعدم توفر `dotnet`/MSBuild/مترجم C# في بيئة الإعداد. لم تُربط الخدمة بعد بشاشة WPF أو تصدير تقارير؛ ذلك هو العمل التالي.

## تحديث 2026-11-07 — شاشة تدقيق ترابط المخزون والمحاسبة

- أضيفت شاشة WPF للقراءة فقط باسم «تدقيق المخزون» تظهر للمستخدم الذي يحمل `reports.read`.
- يمرر الاستعلام `userId + companyId + branchId + asOfUtc` من جلسة المنشأة والفرع الحالية؛ ويعيد Core التحقق داخل معاملة القراءة نفسها من نشاط المستخدم والمنشأة والفرع ومن وجود صلاحية `reports.read` في قاعدة البيانات، وليس من إخفاء الشاشة فقط.
- تعرض الشاشة الحركة والمستودع والصنف والمصدر ورقم المستند وتخصيص التكلفة وحالة Outbox ورقم القيد وحالته ونتيجة التدقيق، مع ملخص عدد الحركات والروابط والاستثناءات.
- تاريخ القطع يُفسر على أنه نهاية اليوم المحلي على الجهاز ثم يحول إلى UTC قبل تمريره إلى Core.
- التقرير لا يعدل حركات المخزون أو القيود ولا ينفذ إصلاحاً أو ترحيلاً. لا يتم تهيئة أو ترحيل مخطط البيانات التجارية تلقائياً عند فتح الشاشة؛ إذا لم تكن جداول الوحدة موجودة فسيظهر خطأ واضح بدلاً من تنفيذ ترحيل ضمني.
- اختبارات Python/SQLite البنيوية بعد التحديث: **217/217 ناجحة**، بما فيها اختبار SQL لصلاحية `reports.read` واختبار ربط الشاشة بنطاق الجلسة. لم يُنفذ بناء C# أو تشغيل WPF لأن .NET SDK/MSBuild غير متاحين في بيئة العمل.

## تحديث 2026-11-07 — قراءة دليل الأصناف والمستودعات

أضيفت إلى `CommercialStore` واجهتا قراءة لدليل البيانات الأساسية التجاري:

- `GetItems(userId, companyId, activeOnly)` يعيد أصناف المنشأة المحددة فقط، مع استبعاد غير النشط افتراضياً أو تضمينه عند طلب ذلك.
- `GetWarehouses(userId, companyId, branchId, activeOnly)` يعيد مستودعات الفرع المصرح به فقط.

كلتا الواجهتين للقراءة فقط، وتتحققان من الوصول قبل تنفيذ الاستعلام. لا تقومان بإنشاء الجداول أو تشغيل migrations. هذه خطوة تأسيسية لواجهة دليل الأصناف والمستودعات وليست شاشة CRUD مكتملة. لا يزال تهيئة مخطط الوحدة التجارية وترقية `ledger_sequence` عملاً صريحاً منفصلاً؛ لا تستدعِ `CommercialStore.Initialize()` تلقائياً عند بدء التطبيق.

اختبارات Python/SQLite: **221/221 ناجحة**. لم يتم بناء C# أو تشغيل WPF في هذه البيئة لعدم توفر .NET SDK/MSBuild؛ لذلك لا يُعد هذا الإصدار مثبتاً أو مختبراً على Windows.

## تحديث 2026-11-07 — واجهة دليل الأصناف والمستودعات

- أضيف تبويب «دليل المخزون» في WPF ويظهر فقط عند امتلاك `reports.read`.
- يعرض دليل الأصناف على مستوى المنشأة الحالية ودليل المستودعات على مستوى الفرع الحالي، مع إظهار الحالة النشطة وغير النشطة.
- يعرض بيانات الأصناف الأساسية (SKU، الاسم، النوع، الوحدة، الباركود، التكلفة والسعر الافتراضي، حد إعادة الطلب، وسياسة المخزون السالب) وبيانات المستودع (الرمز والاسم والحالة).
- التبويب للقراءة فقط ويستخدم `CommercialStore.GetItems` و`GetWarehouses`؛ لا توجد عمليات إضافة أو تعديل أو تعطيل بعد، ولا يستدعي `CommercialStore.Initialize()` أو أي migration.
- إذا لم يكن المخطط التجاري موجوداً، تظهر رسالة خطأ واضحة ولا يجري إنشاء الجداول تلقائياً.
- اختبارات Python/SQLite: **223/223 ناجحة**؛ فحص XML/XAML ومشاريع C#: **7/7 ناجح**. لم ينفذ بناء C# أو تشغيل WPF لعدم توفر .NET SDK/MSBuild في بيئة العمل.

**حدود المرحلة:** هذه واجهة استعراض وليست إدارة CRUD. الخطوة التالية هي ترحيل تجاري صريح مع dry-run ونسخة احتياطية، ثم صلاحيات كتابة وسجل تدقيق وعمليات CRUD محمية قبل فتح الإدخال من الواجهة.

## ترقية مخطط الوحدة التجارية (إجراء صريح فقط)

لا يقوم MONARCH بتهيئة مخطط الوحدة التجارية تلقائياً عند بدء التشغيل. لقواعد البيانات التي تحتاج إلى الترقية، توفر النواة `CommercialSchemaUpgradeService`:

1. استدعِ `Inspect(schemaPath)` أولاً؛ هذه العملية تفتح القاعدة للقراءة فقط وتعيد الجداول المفقودة وحالة `ledger_sequence` ونتيجة `integrity_check`.
2. أوقف جميع عمليات MONARCH وأي خدمة أخرى تستخدم ملف SQLite.
3. راجع نتيجة الفحص، ثم اختر مساراً جديداً لنسخة احتياطية محلية. لا تستعمل مسار قاعدة البيانات نفسها ولا مسار نسخة موجودة.
4. لا تستدعِ `Apply(schemaPath, backupPath, confirmApply: true)` إلا بعد موافقة المشغّل. تنشئ الخدمة نسخة SQLite متسقة وتتحقق منها قبل تشغيل التهيئة، وتحتفظ بها عند النجاح، وتحاول استعادة القاعدة منها عند الفشل.

النسخة الاحتياطية في هذا المسار **غير مشفرة**؛ احفظها في مجلد محمي ومشفّر على مستوى القرص/نظام التشغيل. هذه الخدمة إضافة Core وليست واجهة مستخدم بعد. لم يتم حتى الآن بناء C# أو تشغيل ترقية فعلية على Windows في بيئة إعداد هذه الحزمة.

## ترقية مخطط الوحدة التجارية من واجهة Windows

لدى مدير النظام تبويب «ترقية المخطط التجاري»: نفّذ الفحص أولاً، راجع الجداول الناقصة وحالة قاعدة البيانات، ثم اختر ملف نسخة احتياطية جديداً وأكد التنفيذ. لا توجد تهيئة تجارية تلقائية عند بدء التشغيل. أوقف أي نسخ أخرى من MONARCH تستخدم قاعدة البيانات، واحتفظ بالنسخة الاحتياطية في مسار محمي؛ ملف النسخة الاحتياطية غير مشفر. بعد نجاح الترقية أغلق التطبيق وأعد تشغيله. هذه الواجهة لم تُختبر بعد ببناء WPF فعلي على Windows في بيئة إعداد هذه الحزمة.

## تحديث 2026-11-07 — إدارة بيانات الأصناف والمستودعات في Core

أضيف `InventoryMasterDataStore` لإدارة البيانات الأساسية للمخزون دون حذف فعلي:
- إنشاء/تعديل/تنشيط/تعطيل الأصناف بصلاحية مستقلة `inventory.items.manage`.
- إنشاء/تعديل/تنشيط/تعطيل المستودعات بصلاحية مستقلة `inventory.warehouses.manage`.
- التحقق من نشاط المستخدم والمنشأة وعضوية الفرع والصلاحية من قاعدة البيانات داخل معاملة SQLite نفسها التي تنفذ التغيير.
- تسجيل كل تغيير في `monarch_company_audit_log` ضمن المعاملة نفسها؛ يفشل التغيير كله إذا فشل سجل التدقيق.
- تفويض قيود التفرد لقيود قاعدة البيانات الحالية (SKU والباركود على مستوى المنشأة، ورمز المستودع على مستوى المنشأة).
- منع تعطيل مستودع لديه أرصدة مخزنية غير صفرية. تعطيل الصنف/المستودع soft-disable ولا يمسح الحركات أو المستندات التاريخية.

الصلاحيات الجديدة تُمنح لدور Administrator فقط في مخطط الأمن. هذه المرحلة تضيف Core API ولا تربطها بعد بأزرار WPF؛ يلزم اختبار C# فعلي وبناء الواجهة قبل اعتبارها متاحة للمستخدم النهائي. لا تستدعِ `CommercialStore.Initialize()` أو أي ترحيل تجاري تلقائياً عند بدء التشغيل.

## تحديث 2026-11-07 — ربط إدارة الأصناف والمستودعات بواجهة Windows

- أضيفت أزرار إضافة الصنف وإضافة المستودع وتعطيل السجل المحدد في تبويب «دليل المخزون».
- تظهر أفعال إدارة الأصناف فقط عند وجود `inventory.items.manage`، وأفعال إدارة المستودعات فقط عند وجود `inventory.warehouses.manage`؛ ويعيد Core التحقق من الصلاحيات وعضوية المنشأة/الفرع داخل معاملة SQLite.
- إنشاء الصنف يختار وحدة قياس موجودة فعلياً في المنشأة، ويتحقق Core من علاقة الوحدة عبر قيود قاعدة البيانات. إنشاء المستودع يربطه بالفرع المحدد في جلسة المنشأة.
- التعطيل يتطلب تأكيداً صريحاً ولا يحذف السجلات؛ يظل منع تعطيل المستودع ذي الأرصدة غير الصفرية مفروضاً في Core.
- أضيف `InventoryMasterDataStore.GetUnits` لعرض وحدات المنشأة لمستخدم يملك صلاحية إدارة الأصناف.
- تم تحسين فحص صلاحية Core بحيث يقبل وجود أكثر من دور مفوض للمستخدم بدلاً من اشتراط أن يكون عدد مطابقات الدور واحداً بالضبط.

**حدود المرحلة:** واجهة الإضافة والتعطيل أصبحت مربوطة، بينما التعديل وإعادة التنشيط متاحان في Core فقط ولم يضاف لهما محرر WPF بعد. لم يتم بناء C# أو تشغيل WPF؛ يلزم اختبار فعلي على Windows مع .NET SDK قبل اعتماد الواجهة. لا توجد تهيئة أو ترقية تجارية تلقائية عند فتح الشاشة.


## تحديث 2026-11-07 — استكمال إدارة دليل المخزون

أضيفت إجراءات WPF لتعديل الأصناف والمستودعات وإعادة تنشيط السجلات المعطلة. محرر الصنف يحافظ على قيم التكلفة والسعر وحد إعادة الطلب والمجموعة والباركود والسماح بالمخزون السالب ما لم يغيّرها المستخدم عبر واجهة متخصصة لاحقاً. تعديل المستودع يظل محصوراً في الفرع المحدد. جميع الكتابات تمر عبر `InventoryMasterDataStore` ولا يجري تعديل قاعدة البيانات من عناصر الواجهة مباشرة. راجع `docs/IMPLEMENTATION_REPORT_2026-11-07-INVENTORY-MASTER-DATA-EDIT-REACTIVATE.md`.

**حدود التحقق:** اختبارات Python البنيوية لا تثبت نجاح تجميع C# أو تشغيل WPF؛ يلزم بناء واختبار Windows فعلي قبل اعتماد الإصدار.

## إدارة مجموعات الأصناف ووحدات القياس — تحديث 2026-11-07

أضيفت عمليات Core لإدارة مجموعات الأصناف ووحدات القياس ضمن نطاق المنشأة:
- قراءة وإنشاء وتعديل وتعطيل/إعادة تنشيط مجموعات الأصناف دون حذف فعلي.
- دعم المجموعات الهرمية مع رفض المجموعة الأب غير النشطة، ومنع جعل المجموعة أباً لنفسها أو نقلها إلى أحد فروعها التابعة.
- منع تعطيل مجموعة مرتبطة بأصناف نشطة أو مجموعات فرعية نشطة.
- إنشاء وتعديل وحدات القياس مع ضبط الدقة العشرية بين 0 و6.
- منع تغيير الدقة العشرية لوحدة مستخدمة في أصناف؛ أنشئ وحدة جديدة بدلاً من تغيير تفسير الكميات التاريخية.
- جميع عمليات الكتابة تستخدم صلاحية `inventory.items.manage` وتنفذ التحقق والتعديل وسجل التدقيق ضمن معاملة SQLite واحدة.
- لا يوجد حذف فعلي للمجموعات أو وحدات القياس. وحدات القياس لا تدعم التعطيل في المخطط الحالي، لذلك يقتصر دعمها على الإنشاء والتعديل الآمن.

هذه المرحلة تضيف واجهات Core فقط؛ لم تُضف شاشة WPF لإدارة المجموعات والوحدات بعد، ولم يتم بناء C# أو تشغيل WPF في بيئة Linux الحالية.

### 2026-11-07 — Item groups and units WPF screens
The inventory workspace now includes permission-gated screens for item-group hierarchy and units of measure. Group creation/editing and activation state changes, plus unit creation/editing, are routed through `InventoryMasterDataStore`; the UI does not issue direct SQL. Parent groups are selected from active groups in the current company, and unit precision is constrained to 0–6 decimals. Changing precision for a unit already referenced by an item remains blocked in Core to preserve historical quantity semantics. See `docs/IMPLEMENTATION_REPORT_2026-11-07-ITEM-GROUPS-UNITS-WPF.md` and `docs/TEST_RESULTS_2026-11-07-ITEM-GROUPS-UNITS-WPF.log`. Python tests pass; Windows C# build and WPF runtime are still unverified because the build toolchain is unavailable in the current environment.

## تحديث 2026-11-07 — أوامر الشراء
أضيفت المرحلة الأولى من دورة المشتريات عبر `PurchaseOrderStore`: إنشاء مسودة أمر شراء، اعتمادها، إلغاؤها، وعرض أوامر الفرع. تستخدم صلاحية مستقلة `commercial.purchases.manage`، وتتحقق من المورد والمستودع والصلاحيات ضمن معاملة SQLite، مع سجل تدقيق وقيود تمنع تغيير البنود بعد الاعتماد. أوامر الشراء في هذه المرحلة لا تنشئ حركات مخزون أو فواتير مورد أو قيوداً محاسبية؛ الاستلام الجزئي/الكامل والفاتورة والتسوية مراحل لاحقة. اختبارات Python الحالية: 264 اختبار pytest و241 اختبار unittest ناجح. لم يتم بناء C# أو تشغيل WPF في بيئة الإعداد.


## تحديث 2026-11-07 — واجهة أوامر الشراء في WPF

- [x] إضافة تبويب مشتريات يظهر فقط عند توافر `commercial.purchases.manage` و`reports.read`.
- [x] تحميل الموردين النشطين عبر `PurchaseOrderStore.ListActiveSuppliers` مع فحص صلاحية القراءة ضمن معاملة SQLite ونطاق المنشأة/الفرع.
- [x] تحميل الأصناف النشطة ومستودعات الفرع المحدد من واجهات Core القائمة، دون وصول SQL مباشر من الواجهة.
- [x] إنشاء مسودة أمر شراء من الواجهة ببند واحد مع التحقق من الكمية وتكلفة الوحدة ومعدل الضريبة ودقة العملة ورمزها.
- [x] اعتماد أو إلغاء أمر محدد بعد تأكيد المستخدم، وعرض أوامر الفرع وحالاتها.
- [x] إبقاء الاستلام المخزني وفاتورة المورد والمدفوعات والترحيل المحاسبي خارج هذه المرحلة؛ لا تنشأ حركة مخزون أو قيود GL عند إنشاء/اعتماد الأمر.
- [ ] بناء C# وتشغيل WPF فعلياً على Windows؛ لم يتوفر .NET SDK/MSBuild في بيئة إعداد هذه الحزمة.

**ملاحظة تشغيلية:** تعتمد الشاشة على تهيئة مخطط الوحدة التجارية عبر مسار الترقية الإداري الصريح. لا تنفذ الشاشة `Initialize` أو أي ترحيل تلقائي عند فتح التبويب.

## تحديث 2026-11-07 — الاستلام المخزني لأوامر الشراء

أضيف `PurchaseOrderReceiptStore` لتنفيذ الاستلام الجزئي والكامل من أمر شراء معتمد. تنشئ العملية مستند شراء تجارياً مرحّلاً مرتبطاً بأمر الشراء، وتحدّث الكميات المستلمة وحالة الأمر، وتسجل حركات `Receipt` وتخصيصات التكلفة للصنف المخزني، وتضيف حدث `PurchasePosted` إلى Accounting Outbox، وتسجل التدقيق؛ كل ذلك داخل معاملة SQLite واحدة. تمنع الخدمة تكرار سطر أمر الشراء داخل سند الاستلام، وتمنع تجاوز الكمية المتبقية، وتحصر الصلاحية في `commercial.purchases.manage` ونطاق الشركة/الفرع. سجلات الاستلام وبنودها غير قابلة للتعديل أو الحذف. يسمح قيد تحديث بنود أمر الشراء بعد الاعتماد بتغيير `received_quantity_milli` تصاعدياً فقط، مع إبقاء بقية بيانات البند ثابتة. لم تُضف بعد واجهة WPF للاستلام ولا فاتورة المورد؛ كما أن حدث Outbox هو تسليم للمحاسبة وليس دليلاً على ترحيل قيد GL فعلي.

**التحقق:** 279 اختبار pytest و256 اختبار unittest ناجحة. لم يُنفذ بناء C# أو تشغيل WPF على Windows في بيئة الإعداد الحالية.


## تحديث 2026-11-07 — واجهة الاستلام المخزني
أضيفت إلى تبويب المشتريات واجهة لقراءة البنود المتبقية لأمر الشراء، وإظهار الكمية المعتمدة والمستلمة والمتبقية، وترحيل استلام لبند محدد بعد تأكيد المستخدم، وعرض سجل الاستلامات. الواجهة تستخدم `PurchaseOrderReceiptStore` ولا تنفذ SQL مباشرة. قراءة البنود تتطلب `reports.read` وتُقيد بالشركة والفرع؛ والترحيل يعيد التحقق من `commercial.purchases.manage` داخل Core. يمكن ترحيل عدة بنود في Core، لكن الواجهة الحالية تستقبل بنداً واحداً لكل سند.

**التحقق:** 283/283 اختبار pytest و260/260 اختبار unittest ناجحة. لم يُنفذ بناء C# أو تشغيل WPF؛ لذلك لا تزال الجاهزية التشغيلية وتوافق Windows غير مثبتين.

### تحديث 2026-11-07 — استلام مشتريات متعدد البنود من واجهة Windows
- أُضيف إدخال كمية مستقلة لكل بند في شبكة الاستلام، مع دعم ترحيل عدة بنود في سند واحد.
- تعتمد الواجهة على `PurchaseOrderReceiptStore.Receive` نفسه؛ وتبقى جميع حركات المخزون وتخصيص التكلفة وتحديث كميات أمر الشراء وOutbox والتدقيق ضمن معاملة Core واحدة.
- يتم تثبيت تعديلات خلايا وصفوف WPF قبل إنشاء الطلب، ولا تُرسل إلا البنود ذات الكمية الموجبة؛ ويُرفض تجاوز الكمية المتبقية قبل الاستدعاء، مع بقاء تحقق Core هو الحاجز النهائي.
- اختبارات Python: 286 عبر pytest و263 عبر unittest. لم يُنفذ بناء C# أو تشغيل WPF في هذه البيئة.

### تحديث 2026-11-07 — أساس فاتورة المورد والمطابقة الثلاثية
أضيفت طبقة Core أولية مستقلة لفاتورة المورد عبر `SupplierInvoiceStore` وجداول `monarch_supplier_invoices` و`monarch_supplier_invoice_lines` و`monarch_supplier_invoice_accounting_outbox`. لا يعاد استخدام مستند الاستلام بوصفه فاتورة؛ ترتبط الفاتورة بأمر شراء معتمد وبنود استلام مرحّلة من الأمر نفسه والفرع نفسه. تُورّث تكلفة الوحدة ونسبة الضريبة من بند أمر الشراء المعتمد (مطابقة سعر/ضريبة صارمة دون سماحية فروقات ضمن هذه المرحلة)، ويمنع الترحيل تجاوز الكمية المستلمة بعد احتساب الفواتير المرحّلة السابقة. رقم فاتورة المورد فريد داخل المنشأة/الفرع/المورد، والفاتورة المرحّلة وبنودها غير قابلة للتعديل أو الحذف. ينشأ حدث `SupplierInvoicePosted` في Outbox مستقل وبمعاملة واحدة مع الترحيل والتدقيق. هذا الحدث مجرد hand-off؛ لا تنشأ بعد ذمم دائنة أو دفعة أو قيد GL، ولا توجد واجهة WPF لهذه المرحلة. يلزم استكمال اختبارات تكامل C# قبل الاعتماد التشغيلي.

## تحديث 2026-11-07 — واجهة فواتير المورد في WPF
أضيفت إلى مساحة المشتريات واجهة لإنشاء مسودات فواتير المورد متعددة البنود، وعرض سجل الفواتير، وترحيل المسودة المحددة بعد تأكيد صريح. تعرض الواجهة بنود سندات الاستلام المرحّلة المرتبطة بأمر الشراء، والكمية المستلمة والمفوترة سابقاً والمتاحة للفوترة. يستمد Core السعر والضريبة من أمر الشراء، ويعيد التحقق من المطابقة والكمية عند الترحيل داخل معاملة SQLite. أضيفت واجهتا قراءة `SupplierInvoiceStore.ListReceiptableLines` و`List` بصلاحية `reports.read` ونطاق الشركة/الفرع. لا تنفذ الواجهة SQL مباشرة. ترحيل الفاتورة ينشئ Outbox hand-off فقط؛ الذمم الدائنة والمدفوعات وقيود GL ليست ضمن هذه المرحلة.

**التحقق:** اختبارات Python البنيوية تغطي ربط الواجهة بالـCore وتعدد البنود والتأكيد الصريح ونطاق القراءة. لم يُنفذ بناء C# أو تشغيل WPF؛ لا تُعتبر الواجهة مجرّبة تشغيلياً حتى اختبارها على Windows مع .NET SDK.


## تحديث 2026-11-07 — دفتر الذمم الدائنة للموردين (Core)
أضيف دفتر ذمم دائنة مستقل لفواتير المورد المرحّلة. عند ترحيل فاتورة المورد ينشئ `SupplierInvoiceStore.Post` سجل `monarch_supplier_payables` داخل معاملة الترحيل نفسها، مع تاريخ استحقاق محسوب من تاريخ الفاتورة وشروط المورد `payment_terms_days`، والرصيد الأصلي والعملة. لا ينشأ سجل ذمم لفاتورة غير مرحّلة، وأي فشل في إنشاء الذمم أو Outbox أو التدقيق يعيد معاملة ترحيل الفاتورة كاملة.

أضيف `SupplierPayablesStore` لقراءة الفواتير المفتوحة، وتسجيل دفعة مورد موزعة على فاتورة أو عدة فواتير للمورد نفسه، وإعادة احتساب حالة الرصيد إلى `PartiallyPaid` أو `Paid`، وعرض أعمار الذمم حسب تاريخ مرجعي (حالي، 1–30، 31–60، 61–90، وأكثر من 90 يوماً). يتحقق Core من صلاحية `commercial.purchases.manage` أو `reports.read`، ونطاق الشركة والفرع، والمورد، والعملة، وعدم تجاوز المبلغ المستحق، وتساوي مجموع التخصيصات مع مبلغ الدفعة. تسجل الدفعة والتخصيصات وحدث `SupplierPaymentPosted` والتدقيق ذرياً، مع قيود تمنع تعديل/حذف الدفعات وتخصيصاتها المرحّلة.

**حدود هذه المرحلة:** Outbox الدفعة هو hand-off فقط؛ لم يُنفذ بعد عامل ترحيل فاتورة المورد/دفعة المورد إلى `TenantLedgerStore`، ولا توجد واجهة WPF لإدارة الذمم أو الدفعات. لا تدعم الدفعات المقدمة غير المخصصة، أو الإشعارات الدائنة، أو التسويات/الخصومات، أو توزيع فاتورة واحدة على عدة أوامر شراء. لم يتم بناء C# أو تشغيل WPF في هذه البيئة.

## تحديث 2026-11-07 — واجهة الذمم الدائنة والمدفوعات في WPF
أضيف تبويب «الذمم الدائنة» لعرض الفواتير المفتوحة للمورد المحدد، والرصيد الأصلي والمدفوع والمتبقي وتاريخ الاستحقاق والعملة. يتيح للمستخدم المخوّل `commercial.purchases.manage` تسجيل دفعة على فاتورة محددة مع رقم الدفعة وتاريخها وطريقتها ورمز حساب النقد/البنك؛ ويظل Core مسؤولاً عن التحقق النهائي من المورد والفرع والعملة والرصيد ومنع التخصيص الزائد والتكرار. كما يعرض التبويب تقرير أعمار الذمم بتاريخ مرجعي وبفئات غير مستحق و1–30 و31–60 و61–90 وأكثر من 90 يوماً. الواجهة لا تنفذ SQL مباشرة. المستخدم الذي يملك `reports.read` فقط يستطيع الاطلاع ولا يظهر له إجراء تسجيل الدفعة. لا تزال أحداث Outbox hand-off وليست قيود GL؛ لم يكتمل عامل الترحيل المحاسبي.

## تحديث 2026-11-07 — ترحيل الذمم الدائنة للموردين إلى دفتر الأستاذ العام
أضيف `SupplierPayablesAccountingOutboxWorker` لمعالجة Outbox المستقل لفواتير المورد ودفعات المورد، وإنشاء قيود دفتر أستاذ عبر `TenantLedgerStore` ضمن نطاق المستخدم والمنشأة والفرع. قيد فاتورة المورد يعيد تصنيف قيمة صافي الاستلام من حساب البضائع المستلمة غير المفوترة (GRNI، الافتراضي `2190`) إلى حساب الذمم الدائنة (`2100`) ويثبت ضريبة المدخلات (`1150`)؛ ولا يعيد إثبات المخزون أو المصروف لأن استلام أمر الشراء سبق أن أثبته. لذلك أصبح ترحيل `PurchasePosted` في `CommercialAccountingOutboxWorker` يثبت الاستلام في GRNI، كما يستخدم عامل مرتجعات الشراء GRNI للمرتجعات قبل الفوترة.

قيد دفعة المورد: مدين الذمم الدائنة ودائن حساب النقد/البنك المحدد. يراجع العامل تطابق رؤوس الفواتير مع البنود، وتطابق مجموع تخصيصات الدفعة مع مبلغها، وحالة المستند المرحّلة، وأن عملة المستند هي العملة الأساسية للمنشأة ودقتها مطابقة؛ العملات الأجنبية تُرفض بأمان حتى تنفيذ سياسة فروقات العملة ودفتر متعدد العملات. أرقام القيود حتمية، وتتم مقارنة التاريخ والبنود مع القيد الموجود قبل إعادة استخدامه؛ وهذا يحمي من التكرار ومن اعتماد مسودة حُررت يدوياً. تُسجل محاولات الفشل في Outbox ويُعاد التقاطها في التشغيل اللاحق.

**ضابط دورة المرتجعات:** يمنع Core ترحيل مرتجع شراء إذا كانت هناك فاتورة مورد مرحّلة لأي بند في سند الاستلام المصدر؛ لأن مسار الإشعار الدائن للمورد لم يُنفذ بعد. يلزم استكمال Credit Note وربطه بالفاتورة قبل السماح بهذه الحالة. يلزم وجود حساب التزام نشط `2190` في دليل الحسابات وربطه كحساب GRNI. لا يجري هذا التطوير ترحيلاً تاريخياً تلقائياً للقيود القديمة؛ يجب مطابقة الأرصدة السابقة وتحويلها بخطة ترحيل معتمدة قبل التشغيل الفعلي.

**التحقق:** 314 اختبار pytest و291 اختبار unittest ناجحة. فحوص XML/XAML ومشروعات .NET تُسجل في تقرير المرحلة. لم يتوفر .NET SDK/MSBuild، لذلك لم يُنفذ بناء C# أو تشغيل WPF؛ ولا تعد هذه المرحلة اعتماداً إنتاجياً.

## تحديث 2026-11-07 — تأسيس تكامل الفوترة الإلكترونية ZATCA Phase 2

أضيفت مساحة `Monarch.Core.Zatca` لتأسيس TLV/Base64 QR، ومولد UBL 2.1، وسلسلة ICV/PIH ببصمات SHA-256، وسجل append-only وOutbox، وعميل OAuth2 Basic لـFATOORA مع مساري Clearance وReporting وعامل إرسال محدود الدفعات. أضيفت صلاحيات مستقلة `commercial.sales.manage` و`zatca.integration.manage`.

**حالة المرحلة:** الأساس البرمجي موجود، لكنه ليس اعتماداً أو تصريح امتثال رسمي. يدعم مولّد الفاتورة حالياً SAR والفواتير الضريبية القياسية/المبسطة فقط؛ الإشعارات الدائنة/المدينة والعملات الأجنبية مؤجلة. لا يوجد حتى الآن onboarding CSR/OTP/CSID أو مخزن أسرار آمن أو تنفيذ XAdES/ECDSA كامل؛ الفواتير المبسطة تتطلب مزود توقيع وختم XAdES يحقنه التطبيق قبل الإرسال. خدمة الهاش تستخدم تحويل C14N المتاح في .NET ويجب مقارنتها مع C14N 1.1 وZATCA SDK. كما لم يُربط DTO حتى الآن بمستندات المبيعات الحالية ولم تُنشأ شاشة WPF لإدارة EGS.

نتائج الاختبارات بعد المرحلة: **326 pytest** و**303 unittest** ناجحة. لم يُنفذ C# build أو Sandbox request لعدم توفر .NET SDK/MSBuild وعدم إعداد بيانات اعتماد EGS. راجع `docs/IMPLEMENTATION_REPORT_2026-11-07-ZATCA-PHASE2-FOUNDATION.md` و`docs/ZATCA_PHASE2_INTEGRATION.md` قبل أي محاولة تشغيل.

### تحديث 2026-11-07 — ZATCA Submission Operations
أضيفت واجهات Core لمركز متابعة Outbox الخاص بالفوترة الإلكترونية: `GetDashboard` لعدّ الحالات حسب الشركة والفرع، و`ListSubmissionHistory` لسجل محاولات محدود، و`RetryFailedSubmission` لإعادة إدراج حالات Failed فقط مع صلاحيات وتدقيق. أضيف حد محاولات افتراضي 8 (1–50). لا يسمح بإعادة إرسال حالة Rejected كما هي؛ يجب معالجة سبب الرفض وإصدار مستند صحيح. لا تزال شاشة WPF وEGS onboarding والتوقيع XAdES/C14N 1.1 ومصالحة نتائج timeout واختبارات Sandbox غير مكتملة. هذه إضافة تشغيلية تأسيسية وليست دليلاً على الامتثال أو الاعتماد الرسمي.

### ZATCA EGS onboarding registry
The ZATCA foundation now includes a tenant/branch-scoped EGS unit registry, lifecycle transition validation, and immutable lifecycle history. The registry deliberately stores metadata only: CSR fingerprints, OTP transaction references, CSID certificate metadata, and an external secret reference. Private keys, OTP values, and API client secrets must remain in an OS-backed secret vault through `IZatcaSecretStore`; no production vault provider or live FATOORA onboarding is claimed yet. Apply the additive schema through the explicit migration process in `database/commercial-data.sql`; startup does not silently migrate commercial data.


### ZATCA EGS readiness assessment
The EGS registry now exposes a tenant/branch-scoped, non-secret readiness assessment. It reports missing CSR fingerprint, OTP transaction reference, CSID serial, certificate thumbprint, external secret-store reference, and non-Active lifecycle state as explicit blockers. The assessment does not retrieve vault contents and is informational until wired to a tested submission/credential gate.


### ZATCA submission readiness enforcement
Outbox claiming and payload retrieval now both require a tenant/branch-matched EGS unit in `Active` state with CSR fingerprint, OTP transaction reference, CSID serial, certificate thumbprint, and an external secret reference. Unready items remain queued and are not handed to the HTTP client. This validates stored metadata only: it does not prove that the referenced secret exists, can be decrypted, or is accepted by FATOORA. A production OS-backed vault provider, credential resolution, timeout reconciliation, XAdES/C14N validation, and Sandbox verification remain required.


### ZATCA worker readiness and indeterminate submission handling (2026-11-07)

The `ZatcaSubmissionWorker` requires dependency injection of `ZatcaEgsRegistry` (there is no registry-free constructor). It calls `EvaluateReadiness` for queued invoices before claiming work and writes explicit `ZatcaEgsSubmissionBlocked` audit events with the blocking reasons. The SQL readiness predicates in `ClaimPending` and `GetSubmissionPayload` remain mandatory defense-in-depth. Configure the worker with the registry overload in the application composition root.

Transport exceptions and cancellation are treated as indeterminate outcomes, not proof of rejection: an audit event `ZatcaSubmissionOutcomeUnknown` is written and the outbox remains `Processing`. Stale `Processing` rows are no longer automatically reclaimed. An operator must reconcile the result before any authorized retry. The outbox claim index was added to the commercial provisioning schema.

Limitations: the current ZATCA API client has no implemented, verified platform-status lookup endpoint and the official endpoint's idempotency semantics have not been established here. Therefore no claim is made that a locally generated key can prevent duplicate acceptance at the remote platform. This release deliberately blocks blind resend instead. EGS readiness currently verifies persisted CSR/OTP/CSID metadata and secret-reference presence; it does not cryptographically validate certificate chain, expiry, revocation, or key usage. These require a production certificate provider and documented ZATCA status/reconciliation contract.

### Autonomous Agent foundation (2026-11-07)

`Monarch.Core/Autonomy` now contains deterministic decision-support primitives for cash forecasting, predictive reorder recommendations, financial outlier signals, month-close assessment, safe natural-language intent classification, circuit breaking and an approved-factor Green Ledger calculator. These components are advisory foundations: they do not autonomously post journals, issue purchase orders, close periods, declare fraud, change tax rules or submit ZATCA invoices. See `docs/IMPLEMENTATION_REPORT_2026-11-07-AUTONOMOUS-FOUNDATION.md` for scope and limitations.

## Autonomous workflow governance (2026-11-07)

The autonomy foundation now includes a draft-only procurement workflow contract, an RBAC-scoped conversational query router contract, effective-dated carbon/tax rule version selection, and optional ZATCA worker circuit-breaker integration. Production adapters must persist procurement drafts/manager queue/audit atomically, re-check RBAC in the query transaction, persist immutable compliance versions, and connect resilience alerts to the host notification service. No autonomous approval, GL posting, or unreviewed legal-rule activation is enabled.

### Autonomous procurement approval gate
An additive migration is available at `database/migrations/2026-11-07-autonomous-procurement-approval.sql`. It must be reviewed, backed up, and explicitly applied; it is not run during startup. The migration adds a dedicated purchasing approval permission and a durable approval queue. `ProcurementApprovalQueueStore` lists manager inbox items and records approval/rejection decisions transactionally with the PO status transition and audit event. Queued autonomous drafts cannot be directly approved without a matching queue decision. The end-to-end autonomous draft creation gateway remains a separate integration task.

### Versioned Green & Compliance Ledger (2026-11-07)

An explicit additive migration, `database/migrations/2026-11-07-versioned-green-compliance-ledger.sql`, adds durable carbon-factor versions, tax-rule versions and immutable document-level carbon snapshots. Approved versions and recorded snapshots are protected by SQLite triggers. The C# `PersistentGreenComplianceLedger` resolves an approved factor by the document transaction timestamp and records the selected version with the snapshot and audit event in one local transaction. The migration is intentionally not run at application startup. Tax-rule schema/version governance is present; production tax calculation integration and an authorized rule-approval UI remain follow-up work.

### Conversational ERP execution boundary
The conversational router now has a concrete `SqliteAuthorizedErpQueryExecutor` for the tenant-scoped ZATCA pending-invoice report. It revalidates active identity, company access, branch access, and `reports.read` inside the same SQLite transaction as the fixed, parameterized query. Unsupported intents fail closed; legacy non-tenant tables are deliberately not exposed through this executor. This is a read-only first integration, not a general-purpose natural-language SQL interface.

### Autonomous procurement draft persistence
`SqliteAutonomousProcurementDraftGateway` is the concrete SQLite adapter for the predictive procurement workflow. It persists the purchase-order draft, its lines and totals, the purchasing-manager approval queue entry, and the audit event in one transaction. It requires the explicit migration `database/migrations/2026-11-07-autonomous-procurement-approval.sql`; migrations are not auto-applied at startup. The autonomous gateway cannot approve or post an order. Human approval remains a separate permission-gated action.

### Purchase receipt → Green Ledger integration
The purchase-receipt posting transaction now optionally records carbon snapshots using the approved `PURCHASED_GOODS` factor effective at the receipt timestamp and matching the item's base unit. The snapshot, measurement-gap record (when no approved factor exists), and audit event are written in the same SQLite transaction as the receipt, stock movements, accounting outbox and purchase-order quantity updates. A missing factor never fabricates a zero-emission value and does not block legitimate receipt posting; it creates a durable pending measurement gap for later governance. Apply `database/migrations/2026-11-07-z-purchase-receipt-green-ledger-integration.sql` explicitly after the versioned Green Ledger migration. Existing receipt workflows remain operational before these optional migrations are applied.

### Predictive procurement analysis (2026-11-08)
`SqlitePredictiveProcurementAnalyzer` provides a read-only, tenant/branch/warehouse-scoped demand analysis using stock issues, transfer-outs and purchase returns, plus current stock balances and quantities outstanding on approved/partially received purchase orders. It calculates average daily demand, a lead-time reorder point, inventory position and suggested target-coverage quantity with an explainable rationale. It does not autonomously choose a supplier or commercial terms, create duplicate orders, approve, or post. Candidates can be passed through a reviewed host workflow to the existing draft-only procurement gateway. Apply `database/migrations/2026-11-08-predictive-procurement-analysis-indexes.sql` explicitly after backup; it is not run at startup. The analyzer is currently a domain adapter and the host must enforce the user's `reports.read`/procurement-analysis permission before invoking it.

### Predictive procurement draft orchestration
`PredictiveProcurementDraftOrchestrator` bridges the read-only SQLite demand analyzer to the existing draft-only procurement workflow. It requires explicit approved supplier, currency, unit cost, tax rate, and order-number terms per item. Missing terms produce a structured skip outcome; they are never guessed. Successful drafts are created through the atomic SQLite gateway and routed to the purchasing-manager approval queue. The orchestrator has no approval or GL-posting operation. Durable recommendation idempotency remains a follow-up because it must share a transaction boundary with draft creation.


### Durable predictive-procurement recommendation idempotency (2026-11-08)
Predictive draft requests now carry a deterministic SHA-256 recommendation key scoped to company, branch, warehouse, item, UTC analysis day, and the demand policy. The explicit additive migration `database/migrations/2026-11-08-durable-procurement-recommendation-idempotency.sql` creates a unique durable recommendation ledger. When applied, the SQLite gateway inserts the recommendation claim and the PO, lines, manager queue and audit in the same transaction; replay of an existing key returns the existing draft/queue rather than creating a second PO. A key cannot be rebound to another item in the same scope. The migration is opt-in and must be applied after backup. Concurrent first attempts are protected by SQLite uniqueness; a losing concurrent request may receive a uniqueness error and should be retried to retrieve the committed existing draft. Manual drafts with no recommendation key retain their prior schema requirements.

Limitations: supplier-specific lead times and price lists are not yet sourced from governed supplier-item master data; the orchestration still requires explicitly supplied approved terms. The WPF manager approval center and Windows/.NET integration tests remain pending.


### Supplier Intelligence (2026-11-08)

Added an explicit supplier-item commercial terms migration and tenant/branch-scoped `SupplierIntelligenceStore`. Terms require a source reference, effective dates, currency scale, unit cost, tax basis points, lead time, and minimum order quantity. Item options expose observed receipt lead-time averages and on-time rates where posted receipt evidence exists; absent history remains null rather than being inferred. Apply `database/migrations/2026-11-08-supplier-intelligence.sql` explicitly after backup. This stage provides the Core data service; the WPF manager approval screen and live notification delivery remain pending.

## مركز اعتماد المشتريات — واجهة المدير

أضيفت شاشة WPF مستقلة لصندوق اعتماد أوامر الشراء التنبؤية، لا تظهر إلا للمستخدم الذي يملك `commercial.purchases.approve`. تعرض الشاشة رقم الأمر والمورد والعملة والإجمالي وموعد التوريد ومبرر التوصية وتاريخ الإدراج، ضمن المنشأة والفرع النشطين. ينفذ الاعتماد أو الرفض عبر `ProcurementApprovalQueueStore.Decide` داخل معاملة SQLite مع إعادة فحص الصلاحية وتحديث حالة الأمر وسجل التدقيق. سبب الرفض إلزامي. لا يؤدي الاعتماد بذاته إلى استلام مخزني أو فاتورة أو قيد أستاذ عام. تعتمد الشاشة على ترحيلات المشتريات والاعتماد المطبقة مسبقاً صراحةً، ولا تنفذ أي ترحيل تلقائي.

### Procurement supplier intelligence advisor (2026-11-08)
`ProcurementSupplierIntelligenceAdvisor` consumes the governed supplier-item terms and receipt evidence exposed by `SupplierIntelligenceStore` to rank supplier options for a specific item and as-of date. The advisory score is explicitly weighted (40% price, 25% contractual lead time, 35% observed on-time delivery); missing delivery history is neutral rather than treated as perfect. Price comparisons are normalized only within the same currency and currency scale. Mixed-currency options are flagged as non-comparable, and evidence gaps or poor delivery performance produce explicit risk flags. This component is decision support only: it does not select terms for automatic order creation, create drafts, approve orders, or post accounting entries. The manager workflow must still present and obtain confirmation of approved commercial terms.

### Procurement approval supplier-intelligence integration (2026-11-08)
The manager approval inbox now has a read-only, line-level supplier evidence panel. `ProcurementApprovalIntelligenceService` first verifies that the selected queue entry is still pending for the current manager/company/branch, then reads the draft's actual supplier and item lines and obtains ranked alternatives from `ProcurementSupplierIntelligenceAdvisor`. The WPF approval screen displays the current supplier marker, alternative supplier prices/currencies/tax/lead times, verified receipt counts, observed on-time rate, score and risk flags. This is advisory only: it does not rewrite the selected PO supplier or its commercial terms, and approval remains a separate explicit manager decision. The user must have both `commercial.purchases.approve` and `reports.read` to see the combined inbox and evidence. No schema migration was added for this read-only integration.

### Procurement decision history and notification outbox

The explicit migration `2026-11-08-procurement-decision-notifications.sql` adds append-only manager decision snapshots and a tenant/branch-scoped notification outbox. Queue creation enqueues `ApprovalRequested` notifications for active users with the purchase-approval permission; an approval or rejection writes a snapshot (including rationale and commercial totals) and notifies the original draft creator in the same SQLite transaction as the decision. The outbox is durable and is not an assertion that email, push, or external delivery has occurred; a dispatcher and user-facing notification inbox remain follow-up work. Apply the migration manually after a verified backup.

### تحديث 2026-11-08 — مركز إشعارات المشتريات وسجل قرارات المدير
أضيف `ProcurementNotificationCenterStore` لعرض صندوق إشعارات المستخدم الحالي ضمن المنشأة والفرع النشطين، مع حالة مقروء/غير مقروء محفوظة في جدول مستقل `monarch_procurement_notification_reads` حتى لا تتداخل حالة القراءة مع حالة تسليم Outbox. يدعم تعليم إشعار واحد أو جميع إشعارات المستخدم كمقروءة، ويمنع الوصول إلى إشعار مستلم لمستخدم آخر أو من فرع/منشأة أخرى. كما يعرض سجل قرارات الاعتماد من `monarch_procurement_decision_history` بصلاحية `commercial.purchases.approve` فقط وبترتيب زمني تنازلي. أضيفت واجهة WPF لصندوق الإشعارات وسجل القرارات. يجب تطبيق `database/migrations/2026-11-08-procurement-notification-center.sql` يدوياً بعد النسخ الاحتياطي؛ لا يوجد ترحيل تلقائي. هذا المركز داخل التطبيق فقط؛ لم تتم إضافة موصل بريد/Push أو عامل تسليم خارجي، وحالة القراءة لا تغيّر حالة التسليم.

### 2026-11-08 — Procurement Analytics foundation
أضيف `ProcurementAnalyticsStore` كطبقة تقارير قراءة فقط، محمية بصلاحية `reports.read` والتحقق من عضوية المستخدم في المنشأة والفرع داخل معاملة SQLite. يعرض ملخص قرارات الاعتماد (الإجمالي، المعتمد، المرفوض، متوسط زمن القرار ومعدل الرفض)، وأداء الموردين من أوامر `Received` وإيصالاتها المنشورة (عدد الأوامر المكتملة، نسبة التسليم في الموعد عند توفر الموعد المتوقع، ومتوسط مدة الإكمال)، وأعلى الأصناف استهلاكاً من حركات `Issue` و`TransferOut` و`PurchaseReturn`. لا يجمع المبالغ المالية عبر العملات. لا يعرض دقة التنبؤ كرقم لأن سجل التوصيات الحالي لا يحتفظ بلقطة كمية التوقع؛ يصرح بذلك بدلاً من اختلاق دقة. أضيفت فهارس اختيارية في `database/migrations/2026-11-08-procurement-analytics-indexes.sql` ويجب تطبيقها يدوياً بعد نسخة احتياطية. هذه المرحلة توفر محرك Core؛ لوحة WPF الرسومية وربط لقطة التوقعات بالاستهلاك الفعلي ما زالا لاحقين.

## تحديث 2026-11-08 — حفظ التوقع وقياس دقته
- أضيف `ProcurementForecastSnapshot` لحفظ كمية الطلب المتوقعة لفترة تغطية محددة، ونافذة القياس وإصدار سياسة التوقع.
- يحفظ `SqliteAutonomousProcurementDraftGateway` لقطة التوقع داخل المعاملة نفسها التي تحفظ سجل التوصية وأمر الشراء وقائمة اعتماد المدير؛ لا توجد لقطة منفصلة يمكن أن تنجح دون المسودة أو العكس.
- أضيف تقرير WAPE (مجموع الأخطاء المطلقة ÷ مجموع الطلب الفعلي) للنوافذ المكتملة فقط، باستخدام حركات الصرف والتحويل للخارج ومرتجعات الشراء، وبنطاق المنشأة والفرع والمستودع والصنف.
- لا تظهر نسبة مئوية عند انعدام الطلب الفعلي، ولا تدخل النوافذ غير المكتملة في القياس.
- يتطلب التفعيل تطبيق `database/migrations/2026-11-08-procurement-forecast-snapshots.sql` يدوياً بعد ترحيل سجل التوصيات الدائم. لا تُنفذ الترحيلات تلقائياً.

### Procurement Executive Dashboard
The WPF client includes a read-only **لوحة المشتريات** tab for users holding `reports.read`. It presents approval/rejection KPIs, decision lead time, supplier on-time performance, top consumed items, and matured forecast WAPE for a selectable date range. All queries use the active company and branch context. Required procurement analytics and forecast snapshot migrations must be applied explicitly; startup does not auto-migrate the commercial schema. A Windows build and runtime smoke test are still required before treating the desktop dashboard as release-verified.

## تحديث 2026-11-08 — أداء المورد حسب الصنف
- أضيف استعلام `GetSupplierItemPerformance` للقراءة فقط، يستند إلى بنود الاستلام المرحّلة ويربط المورد بالصنف وأمر الشراء والفرع.
- يعرض الكمية المستلمة وعدد أوامر الشراء الممثلة ومتوسط تكلفة الوحدة المرجح بالكمية.
- يفصل النتائج حسب العملة؛ لا يجمع أسعار عملات مختلفة ولا يقدم ترتيباً سعرياً مضللاً.
- يفرض `reports.read` وعضوية المستخدم النشطة في المنشأة والفرع داخل معاملة SQLite، مع حد أعلى لحجم النتائج.
- أضيف فهرس اختياري في migration مستقلة لا تطبق تلقائياً. التفاصيل في `docs/IMPLEMENTATION_REPORT_2026-11-08-SUPPLIER-ITEM-PERFORMANCE.md`.

### Procurement forecast history (2026-11-08)
`ProcurementAnalyticsStore.GetForecastHistory` exposes matured immutable forecast snapshots by item/window with policy version, horizon, forecast quantity, actual demand and absolute error. Actual demand is recalculated from stock movements within the exact snapshot window and is scoped by company, branch, warehouse and item. Zero actual demand yields a null percentage. The query is read-only, requires `reports.read`, and bounds its result size. No schema migration was introduced. See `docs/IMPLEMENTATION_REPORT_2026-11-08-PROCUREMENT-FORECAST-HISTORY.md`.



### Supplier performance trend analysis
The read-only procurement analytics store compares receipt-backed supplier delivery outcomes across equal adjacent periods, applies minimum-sample safeguards, and surfaces on-time/lead-time deterioration indicators. See `docs/IMPLEMENTATION_REPORT_2026-11-08-SUPPLIER-PERFORMANCE-TRENDS.md`.

### 2026-11-08 — Procurement Analytics WPF expansion

The existing read-only **لوحة المشتريات** now also displays supplier/item performance (with currency-separated unit costs), supplier delivery trend alerts, and matured forecast history by item/window. The views call the existing `ProcurementAnalyticsStore` read models and pass the active user/company/branch context. The dashboard continues to require `reports.read`; it introduces no posting/approval actions and no automatic schema migration. Build/runtime verification still requires a Windows environment with the supported .NET toolchain.

### Procurement analytics CSV export

The procurement analytics dashboard provides separate CSV UTF-8 exports for supplier/item performance, supplier delivery trends, and matured forecast history. Export uses the active `reports.read` authorization and company/branch context, invariant numeric formatting, Excel-friendly UTF-8 BOM, quoted CSV cells, and spreadsheet formula-injection neutralization. The export path adds no NuGet dependency and does not write to business tables. See `docs/IMPLEMENTATION_REPORT_2026-11-08-PROCUREMENT-CSV-EXPORT.md`.

### Procurement analytics Excel export
The procurement analytics dashboard can export a single `.xlsx` workbook containing Supplier Items, Supplier Trends, and Forecast History worksheets. The export uses a dependency-free Open XML writer and requires `reports.read`; report retrieval remains tenant/branch scoped.

### Procurement analytics print report
- The procurement analytics dashboard can export a self-contained Arabic RTL HTML report covering supplier/item performance, supplier trends, and forecast history.
- The report is print-styled for A4 landscape and can be saved as PDF through a modern browser's Print → Save as PDF workflow. Direct native PDF generation is intentionally not claimed in this stage.
- Export rechecks `reports.read` and queries remain scoped to the active company and branch.

## تقارير المشتريات بهوية المنشأة والفرع
- تقرير الطباعة HTML يعرض الاسم الفعلي للمنشأة والفرع من `TenantAccountingSession` بدلاً من الاكتفاء بمعرفاتهما.
- يمكن إرفاق شعار PNG أو JPEG مضمّن داخل التقرير نفسه (حد أقصى 2 ميجابايت)، لذلك لا يعتمد التقرير المحفوظ على مسار صورة خارجي.
- يضاف وقت الإنشاء UTC وتذييل يحمل هوية المنشأة والفرع. تظل جميع النصوص القادمة من بيانات المنشأة مشفرة HTML، ويظل التصدير محكوماً بصلاحية `reports.read` ونطاق الشركة/الفرع النشط.
- لا يزال الناتج HTML جاهزاً للطباعة إلى PDF من المتصفح؛ لم يتم اعتماد مولّد PDF أصلي بعد، لأن دعم تشكيل العربية وتضمين الخطوط لم يخضع بعد لاختبار فعلي.


### Procurement report quality (2026-11-08)
The Arabic RTL print report now summarizes reliable supplier comparisons and critical/warning alert counts. Its footer stays in normal print flow to avoid covering long tables; repeated table headers and row break-avoidance remain enabled. This remains a browser-print HTML workflow, not a native PDF renderer. See `docs/IMPLEMENTATION_REPORT_2026-11-08-PROCUREMENT-REPORT-QUALITY.md`.

### Procurement report export audit
Successful procurement report saves (CSV, XLSX, HTML) are recorded in a local append-only SHA-256 hash-chained log under the current Windows user's LocalAppData `MONARCH ERP/Audit` directory. The log is tenant/branch/user scoped and includes report range, format, output path, size, and content digest. It is workstation-local; cross-process locking and centralized audit replication remain future work.

### Procurement export audit center
The procurement analytics area now includes a `تدقيق التصدير` tab for users with `reports.read`. It verifies the local hash chain before displaying records, scopes display and CSV export to the active company and branch, supports CSV/XLSX/HTML format filtering, and exports verified audit metadata with spreadsheet-formula protection. The log remains local to the Windows user profile and is not a centralized multi-device audit service.

### Tenant audit event journal foundation (2026-11-08)
Added `TenantAuditEventStore`, a reusable Core append-only event journal with SHA-256 hash chaining, actor/company/branch identity, UTC timestamps, entity references, bounded reads, and mandatory company/branch filters. It introduces no schema migration or package dependency. This is a foundation only: it is not yet integrated with login, user administration, accounting, inventory, purchasing, or permission changes, and it is not a centralized or multi-process-safe audit service. See `docs/IMPLEMENTATION_REPORT_2026-11-08-TENANT-AUDIT-EVENT-STORE.md`.

### Tenant identity administration audit (2026-11-08)
Added `TenantIdentityAuditStore` to write and query user-administration audit entries in the existing tenant company audit table. Operations require `users.manage`, and the actor must have active company and branch membership. Reads are tenant/branch scoped with bounded date/action filters. This is an explicit API: legacy global `IdentityStore` mutations do not automatically emit tenant events because they lack company/branch context. No schema migration or dependency was added. See `docs/IMPLEMENTATION_REPORT_2026-11-08-TENANT-IDENTITY-AUDIT.md`.

### Identity mutations with atomic tenant audit (2026-11-08)
`IdentityStore` now exposes explicit company/branch-scoped overloads for user creation and activation changes. They validate `users.manage`, verify active actor membership, and write the identity mutation plus legacy and tenant audit rows in one SQLite transaction. Existing unscoped overloads remain for compatibility; the desktop UI is not yet switched to the scoped overloads. Role reassignment and membership changes are not covered by this increment. No migration or package dependency was added. See `docs/IMPLEMENTATION_REPORT_2026-11-08-IDENTITY-ATOMIC-TENANT-AUDIT.md`.

### Identity administration audit wiring (2026-11-08)
The Windows user-administration screen now calls tenant-scoped user creation and activation/deactivation methods using the active company and branch. It also supports changing the selected user's global identity role through `IdentityStore.SetUserRole`, which validates both actor and target membership and writes legacy plus tenant audit records in the same SQLite transaction. The operation rejects self-role changes and unsupported roles. This does not yet change the company-specific access role or make company/branch membership grants atomic with user creation; those remain separate follow-up work. See `docs/IMPLEMENTATION_REPORT_2026-11-08-IDENTITY-WPF-ROLE-AUDIT.md`.

### 2026-11-08 — Company membership revocation audit
- Added `CompanyDirectoryStore.RevokeCompanyAccess` to revoke a user's company membership and all active branch grants in one SQLite transaction.
- Requires an active global administrator, rejects self-revocation, and prevents removing the last active company Administrator.
- Writes both company-scoped and general audit events in the same transaction; failed audit writes roll back the access changes.
- Added an explicit confirmation action to the Windows company directory administration screen.
- Revocation is a soft deactivation; historical membership and audit records remain available. Existing grant APIs and schema are preserved.
- Python structural tests cover the transactional and UI wiring contract. C# compilation and Windows runtime remain unverified in this environment.

## 2026-11-08 — Unified tenant audit viewer

- Added `TenantAuditLogReader`, a read-only query surface over `monarch_company_audit_log` for identity administrators.
- Every query requires `users.manage`, an active user-company membership, an active user-branch grant, and an active branch; results are constrained to the selected company and branch.
- Added optional UTC date range, action substring, entity type, and actor-user filters. All filters are parameterized and results are bounded to 5,000 rows in Core (1,000 in the WPF view).
- Added an Arabic WPF tab for reviewing audit events in the current tenant/branch. The view does not mutate audit records.
- Scope limitation: this viewer reads the SQLite company audit table in the current database only. It does not merge local file hash-chain journals or replicate records from other workstations; those remain separate audit stores.
- Validation in this package covers Python structural tests and project-file parsing. C# compilation and WPF runtime execution remain unverified where the .NET SDK/MSBuild are unavailable.

## تدقيق عمليات دفتر الأستاذ متعدد المنشآت

أصبحت عمليات `TenantLedgerStore` التالية تسجل أحداثها في `monarch_company_audit_log` داخل معاملة SQLite نفسها التي تحفظ التغيير: إنشاء حساب، إنشاء مسودة قيد، ترحيل قيد، وعكس قيد. يحمل كل حدث معرف المستخدم والمنشأة والفرع والكيان المتأثر وتوقيت UTC. إذا فشل إدراج سجل التدقيق، تفشل المعاملة ولا يعتمد تعديل دفتر الأستاذ. هذا الربط يخص مسار `TenantLedgerStore` فقط؛ ولا يعني أن كل تكاملات المحاسبة أو عمليات المخزون والمشتريات أصبحت مغطاة تلقائياً.


### Inventory operation audit (2026-11-08)
Stock movement creation, paired warehouse transfers, sales/purchase document posting, and sales/purchase return posting now write tenant/branch-scoped audit rows in the same SQLite transaction as their inventory mutations. The existing `monarch_company_audit_log` table is reused; no migration is introduced. This is local transactional audit coverage, not a centralized cross-device or cryptographically signed journal. See `docs/IMPLEMENTATION_REPORT_2026-11-08-INVENTORY-AUDIT.md`.


### Atomic inventory valuation audit (2026-11-08)
Persisted inventory valuation runs now append a tenant/branch-scoped audit row in the same SQLite transaction as the run, valuation entries, and remaining FIFO layers. The event includes the actor, warehouse, item, cost method, closing quantity/value, and movement count. If audit insertion fails, the valuation snapshot is rolled back. This does not post accounting adjustments and does not change the read-only nature of inventory-to-GL reconciliation. C# build/runtime verification remains pending where .NET SDK/MSBuild are unavailable.

### Atomic inventory-to-GL reconciliation audit (2026-11-08)
Each inventory-to-general-ledger reconciliation now records `InventoryGlReconciled` in the existing `monarch_company_audit_log` table, within the same SQLite transaction as the read-only comparison. The event captures the actor, company, branch, inventory account, cost method, UTC cutoff, item/warehouse count, total quantity, subledger and GL balances, variance, and balanced status. The reconciliation API now requires active tenant/branch access plus `reports.read`. The operation remains strictly read-only with respect to journals: it creates no adjustment, posting, or correction. Audit failure rolls back the reconciliation transaction. See `docs/IMPLEMENTATION_REPORT_2026-11-08-ATOMIC-INVENTORY-GL-RECONCILIATION-AUDIT.md`.


### Inventory operation authorization — 2026-11-08
Direct stock movement and warehouse transfer writes now require explicit `inventory.movements.manage` RBAC grants. Authorization is checked inside the same SQLite transaction as the mutation, and verifies active user, company, branch, and role permission. The default grant is Administrator-only; Accountant and Viewer receive `inventory.read` but cannot mutate stock by default. Fresh databases receive grants from `database/security.sql`; existing databases must apply `database/migrations/2026-11-08-inventory-operation-permissions.sql` explicitly. No migration runs automatically at startup. This increment does not claim that every legacy commercial CRUD API has completed RBAC conversion. See `docs/IMPLEMENTATION_REPORT_2026-11-08-INVENTORY-OPERATION-AUTHORIZATION.md`.

### Inventory master-data read RBAC — 2026-11-08
The inventory catalog now consistently uses `inventory.read` for viewing items, warehouses, item groups, and units. `CommercialStore.GetItems` validates active user/company membership and the RBAC grant inside the same SQLite read transaction; `GetWarehouses` validates active user/company/branch access and RBAC in the same transaction as its branch-scoped query. `InventoryMasterDataStore.GetUnits` and `GetItemGroups` use `inventory.read`, while all corresponding write operations continue to require `inventory.items.manage`. The WPF catalog is visible to inventory readers; group/unit edit controls remain restricted to master-data managers. No schema migration is required. Python structural tests do not replace C# build/runtime verification. See `docs/IMPLEMENTATION_REPORT_2026-11-08-INVENTORY-MASTER-DATA-READ-RBAC.md`.

### Legacy inventory master-data write hardening (2026-11-08)
The compatibility write methods in `CommercialStore` (`AddUnit`, `AddItem`, and `AddWarehouse`) now enforce granular RBAC permissions inside the same SQLite transaction as the write and append an audit event before commit. Unit/item writes require `inventory.items.manage`; warehouse creation requires `inventory.warehouses.manage` and active access to the selected branch. These methods remain available to preserve existing callers, but no longer rely on the legacy broad membership/Viewer check. No schema migration is required.


### Commercial document RBAC and atomic draft audit — 2026-11-08
`CommercialDocumentStore.CreateDraft` and `Post` now require the dedicated permission matching the document type: `commercial.sales.manage` for sales and `commercial.purchases.manage` for purchases. The permission query verifies active user, company membership, branch membership, active company/branch, and explicit role grant inside the same SQLite transaction as the document operation. Draft creation now appends `CommercialDocumentDraftCreated` to `monarch_company_audit_log` before commit; audit failure rolls back the draft and its lines. Posting retains its existing transactional inventory, cost allocation, accounting outbox, and audit behavior. Existing method signatures and commercial schema are unchanged; no migration is required. See `docs/IMPLEMENTATION_REPORT_2026-11-08-COMMERCIAL-DOCUMENT-RBAC-AUDIT.md`.

### Commercial payment RBAC and atomic audit — 2026-11-08
`CommercialPaymentStore.Post` now requires `commercial.sales.manage` for customer receipts and `commercial.purchases.manage` for supplier payments. Authorization verifies active user, company membership, branch membership, active company/branch, and an explicit role grant inside the same SQLite transaction as payment posting. The existing company audit log receives `CustomerReceiptPosted` or `SupplierPaymentPosted` before commit, including payment type, party, amount, currency, method, account code, and allocation count. Audit failure therefore rolls back the payment, allocations, and accounting outbox together. Unknown payment type/method enum values are rejected. Existing public method signatures and database schema are unchanged; no migration is required. Python tests here are structural checks, not C# execution tests. See `docs/IMPLEMENTATION_REPORT_2026-11-08-COMMERCIAL-PAYMENT-RBAC-AUDIT.md`.


### Commercial return RBAC and atomic audit — 2026-11-08
`CommercialReturnStore.CreateDraft` and `Post` now enforce type-specific permissions (`commercial.sales.manage` for sales returns and `commercial.purchases.manage` for purchase returns). The authorization query runs inside the same SQLite transaction and validates active user, company, company membership, branch membership, active branch, and explicit role grant. Draft creation now appends a `SalesReturnDraftCreated` or `PurchaseReturnDraftCreated` audit event before commit; posting retains its existing stock, return-cost allocation, state, accounting outbox, and audit transaction. Audit failure rolls back the complete operation. Undefined return types are rejected. No schema migration or public API change was introduced. See `docs/IMPLEMENTATION_REPORT_2026-11-08-COMMERCIAL-RETURN-RBAC-AUDIT.md`. Python structural tests do not substitute for C# build or Windows runtime validation.

### Commercial party master-data RBAC and atomic audit — 2026-11-08
The legacy `CommercialStore.AddParty` method now requires `commercial.sales.manage` for customers, `commercial.purchases.manage` for suppliers, and both grants for a party classified as `Both`. Authorization, party insertion, and the corresponding company audit event run in one SQLite transaction. Undefined party types and negative credit terms are rejected. Audit details are limited to party type and code rather than contact/tax fields. The existing public method signature and schema remain unchanged; no migration is required. Python structural tests do not prove C# compilation or runtime behavior. See `docs/IMPLEMENTATION_REPORT_2026-11-08-COMMERCIAL-PARTY-RBAC-AUDIT.md`.

### Commercial party read RBAC — 2026-11-08
`CommercialStore.GetParties` now exposes a tenant-scoped read path with type-specific authorization: customer queries require `commercial.sales.manage`, supplier queries require `commercial.purchases.manage`, and unfiltered/`Both` queries require both grants. Authorization and the parameterized company-scoped query share one SQLite transaction. The API supports active-only filtering and includes `Both` parties in customer/supplier-specific views. No schema migration or startup initialization is performed. See `docs/IMPLEMENTATION_REPORT_2026-11-08-COMMERCIAL-PARTY-READ-RBAC.md`.

### AR/AP report RBAC and branch isolation — 2026-11-09
`CommercialReceivablesPayablesReportStore` now requires the explicit `reports.read` grant in addition to active user, company, company-membership, branch-membership, and active-branch checks. Authorization and both aging/statement reads share one SQLite transaction. Aging payment allocations and statement entries are constrained to the selected company and branch; statement rows also verify the document party matches the selected party. Invalid balance-side enum values are rejected. The read-only connection, public API, schema, and migration policy are unchanged. Python tests validate SQL fixtures and source structure only; C# compilation and WPF runtime remain unverified. See `docs/IMPLEMENTATION_REPORT_2026-11-09-AR-AP-REPORT-RBAC.md`.

### Supplier invoice operational-read authorization — 2026-11-10
The supplier invoice workspace read models (`ListReceiptableLines` and `List`) now require `commercial.purchases.manage`, matching the purchase-domain authorization already used by invoice draft creation and posting and the WPF workspace gate. This prevents a user who has only the broad `reports.read` grant from reading supplier invoice operational details through the Core API. Authorization remains inside the same SQLite transaction as each branch-scoped read. No schema, migration, or public method signature changed. Python tests are structural checks; C# compilation and WPF runtime remain unverified without a working .NET toolchain.

### Supplier AP historical aging accuracy — 2026-11-10
`SupplierPayablesStore.GetAging` now calculates paid amounts as of the requested date by joining allocations to posted supplier payments and including only payments dated on or before `$asof`, within the same company and payable branch. Allocations with no matching posted payment in that branch/date scope do not reduce the historical balance. This corrects historical aging when payments are posted after the report cutoff. The open-invoice read remains available through the reports-read UI; payment posting continues to require `commercial.purchases.manage`. No schema, migration, or public API change was introduced. Structural regression coverage was added; C# compilation and WPF runtime remain unverified without .NET SDK/MSBuild. See `docs/IMPLEMENTATION_REPORT_2026-11-10-SUPPLIER-AP-HISTORICAL-AGING.md`.

### 2026-11-10 — Supplier payment allocation scope validation

- Hardened the supplier AP accounting outbox worker before GL payment posting: every allocation must resolve to a payable and posted supplier invoice in the same company and payment branch.
- Validated supplier identity, invoice/payable branch, currency code, and minor-unit scale against the payment; mismatched or orphaned allocations block posting through the existing outbox failure path.
- Preserved deterministic journal numbering, AP debit / cash-bank credit, public APIs, schema, and migration policy.
- Regression coverage: **521/521 pytest** and **330/330 unittest** passed. C# build and WPF runtime remain unverified because .NET SDK/MSBuild are unavailable.

### Supplier AP outbox concurrency guard — 2026-11-10
The supplier AP GL outbox worker now serializes processing for the same database/company/branch within a process. Deterministic journal numbers and the ledger's company-scoped unique journal-number constraint remain the cross-process duplicate guard. If journal posting commits but outbox acknowledgement fails, a retry validates and reuses the existing posted journal before acknowledging the outbox row. The worker still uses separate ledger and outbox transactions; this is recoverable idempotency, not a single atomic transaction. The in-memory gate does not serialize separate OS processes. No schema migration or automatic startup migration was added. Python checks are structural; C# compilation and runtime concurrency tests remain outstanding.

### Supplier AP durable outbox leases — 2026-11-10

- Supplier invoice/payment GL outbox rows are now claimed through durable SQLite lease tokens scoped to company and branch.
- Expired claims can be reclaimed after worker failure; stale workers are fenced from acknowledging or releasing a newer claim.
- Existing databases require the explicit one-time migration `database/migrations/2026-11-10-supplier-ap-outbox-leases.sql` after backup. It is never run automatically at startup.
- Initial lease duration is five minutes and active claims are renewed every minute by a token-fenced heartbeat. Expired claims cannot be resurrected. Acknowledgement and failure updates now also require an unexpired lease, so a worker that finishes after lease expiry cannot finalize the row even if no replacement worker has claimed it yet. See the implementation reports for runtime-test boundaries.


### Supplier AP durable lease heartbeat — 2026-11-10
The supplier invoice/payment accounting outbox worker now renews its claimed leases every minute while processing a batch, extending each still-active claim by five minutes. Renewal requires the same company, branch, lease token, an unprocessed row, and a lease that has not already expired. This prevents a delayed worker from resurrecting an expired claim or extending a newer worker's lease. Heartbeat database errors are deliberately non-authoritative: subsequent acknowledgement/failure remains token-fenced and deterministic journal identity protects retry behavior. The heartbeat is in-process and does not replace live multi-process integration testing. No new schema migration or public API change was introduced.


### Supplier AP lease takeover and crash-recovery contract — 2026-11-10
The supplier AP outbox lease contract has been tightened after the heartbeat stage. Both invoice and payment acknowledgement/failure updates now require the matching token **and** an expiry later than the update timestamp. This closes the gap where a worker could acknowledge an already-expired claim before another worker reclaimed it. Heartbeat renewal uses a monotonic expiry expression (`CASE`) so an overlapping, delayed callback cannot shorten a later renewal. SQLite integration-style tests exercise claim exclusion before expiry, takeover after expiry, stale-worker heartbeat/ack/fail rejection, expired-owner finalization rejection, current-owner renewal/acknowledgement, and monotonic expiry. These tests execute equivalent SQL against Python's SQLite engine; they do not execute the C# worker, `System.Threading.Timer`, multiple OS processes, or Windows runtime.

### Supplier AP worker health telemetry — 2026-11-10
The supplier invoice/payment GL outbox worker exposes a process-local `GetHealthSnapshot()` diagnostic with cumulative invoice/payment claims, heartbeat ticks/failures, successful lease renewals, lease ownership losses, acknowledgements, and failure updates. Counters use `Interlocked` operations for thread-safe observation. They are diagnostic only: they do not grant lease ownership, alter retry policy, persist telemetry across restarts, or replace token/expiry-fenced SQLite writes. A future operational dashboard should consume these metrics only after a durable monitoring/retention policy is designed.

### 2026-11-10 — Supplier AP durable worker diagnostics
- Added an explicit additive migration, `database/migrations/2026-11-10-supplier-ap-worker-diagnostics.sql`, for tenant/branch-scoped diagnostic events.
- Supplier AP worker now persists heartbeat exceptions and lease ownership-loss rejections as bounded event codes; raw exception messages and lease tokens are not written to this diagnostic table.
- Diagnostic writes are best-effort and never alter lease authority, journal idempotency, or posting decisions. Write failures are counted in the process-local health snapshot.
- `GetRecentDiagnostics` authorizes through the tenant ledger before reading and filters by both company and branch; the result limit is constrained to 1–500.
- The migration is explicit and is not applied automatically at startup. Until it is applied, diagnostic persistence fails closed and increments `DiagnosticWriteFailures`; accounting processing remains independent.
- The table is append-only in this stage. Automated retention/deletion and alert thresholds are intentionally not enabled until an operator retention policy is approved.

### Supplier AP worker recovery guidance — 2026-11-10
A pure `SupplierPayablesWorkerRecoveryPolicy` now classifies known transient SQLite/infrastructure failures, recommends bounded exponential backoff (15 seconds to 15 minutes), and signals operator attention for permanent/unclassified failures or repeated transient failures (default threshold 5). This is advisory only: it does not schedule retries, change leases, or alter accounting state. See `docs/IMPLEMENTATION_REPORT_2026-11-10-SUPPLIER-AP-RECOVERY-POLICY.md`.

### Supplier AP Operational Alert Center — 2026-11-10
The supplier AP worker now exposes a read-only operational alert projection over durable, tenant/branch-scoped diagnostics. Heartbeat failures are grouped over 15 minutes (Warning below the default threshold of three; Critical at or above it); lease ownership-loss events are Warning-level over 24 hours. `GetOperationalAlerts` reuses the authorized diagnostics reader, limits results to 1–500, and orders alerts deterministically. Process-local health counters are deliberately excluded from tenant alerts because they are not attributed to a specific company/branch. This stage adds no migration and does not retry work, change leases, acknowledge outbox events, or modify accounting. See `docs/IMPLEMENTATION_REPORT_2026-11-10-SUPPLIER-AP-OPERATIONAL-ALERT-CENTER.md`.

### Supplier AP operational alert lifecycle (2026-11-11)
- Added append-only, per-user `Viewed` and `Acknowledged` lifecycle markers for the two allowlisted operational alert summaries.
- Lifecycle identity includes company, branch, user, alert code, and the latest source-event timestamp; a newer recurrence is therefore tracked independently.
- Authorization is checked through `TenantLedgerStore.GetEntries(userId, companyId, branchId)` before lifecycle reads or writes. Reads are bounded to 500 alert summaries.
- SQLite migration adds uniqueness, scope indexes, allowlisted values, and triggers rejecting update/delete. Source diagnostics, leases, outbox, and accounting entries remain unchanged.
- This is a persistence/service foundation; no WPF alert-center screen or notification delivery is claimed.

### 2026-11-11 — Supplier AP operational alert center UI

- Added a dedicated Arabic RTL WPF tab for tenant/branch-scoped supplier AP operational alerts.
- The tab displays severity, summary, event count, latest event time, and user-specific viewed/acknowledged state.
- Explicit actions record `Viewed` and `Acknowledged` lifecycle events for the selected alert; both use the signed-in user and active company/branch context.
- The UI is gated by `reports.read`. Lifecycle persistence requires applying `database/migrations/2026-11-11-supplier-ap-alert-lifecycle.sql` before use.
- Acknowledgement is an operational record only; it does not retry work, alter leases, post journals, or change accounting state.
- C# compilation and WPF runtime validation remain pending on a .NET-enabled Windows environment.

### Supplier AP alert delivery planning and escalation — 2026-11-11
Added a deterministic advisory policy and tenant-scoped durable in-app delivery-intent store. Critical alerts are assigned escalation level 2 immediately; Warning alerts begin at level 1 and escalate to level 2 when at least 30 minutes old. Intent creation authorizes each recipient through `TenantLedgerStore` before writing, is idempotent per company/branch/recipient/alert occurrence/escalation/channel, and is protected by append-only database triggers. The explicit migration is `database/migrations/2026-11-11-supplier-ap-alert-delivery.sql`. This stage persists intents only: no email/SMS/push transport, background dispatcher, delivery receipt, or automatic retry is implemented. It does not alter worker leases, diagnostics, outbox state, journals, or accounting. See `docs/IMPLEMENTATION_REPORT_2026-11-11-SUPPLIER-AP-ALERT-DELIVERY.md`.

### Supplier AP Alert Dispatcher — 2026-11-11

Added a tenant-scoped durable in-app alert dispatcher queue. New delivery intents are automatically enqueued and existing intents are backfilled by `database/migrations/2026-11-11-supplier-ap-alert-dispatcher.sql`. `SupplierPayablesAlertDispatcher` authorizes the requesting user against the company/branch ledger scope before claiming or completing work and filters both claim and completion reads by `recipient_user_id`, preventing one branch user from claiming or completing another user’s intent. Python regression tests cover two recipients in the same branch. It supports bounded claims (1–100), expiring lease tokens (10–600 seconds), token/expiry fencing, immutable attempt history, bounded error codes, exponential retry delay capped at 15 minutes, and a maximum of eight completed attempts before DeadLetter. The dispatcher does not send messages or call external transports; a trusted in-app adapter must perform the actual UI delivery and report its outcome. Expired claims can be reclaimed without incrementing the completed-attempt counter. This queue does not change accounting, supplier AP worker leases, journals, or source alert records. Apply the migration explicitly after backup; no automatic migration is performed. See `docs/IMPLEMENTATION_REPORT_2026-11-11-SUPPLIER-AP-ALERT-DISPATCHER.md`.


### SQLite test resource cleanup — 2026-11-11

Added an autouse test fixture at `tests/conftest.py` that tracks SQLite connections created during each test and closes any remaining handles during teardown, including when assertions fail. This addresses a common Python SQLite pitfall: the connection context manager commits or rolls back but does not close the connection. The legacy migration backup helper now explicitly closes its temporary backup connection. Validation uses `python -m pytest -q -W error::ResourceWarning`; all tests must pass with resource warnings treated as errors. This fixture is test-only and does not alter runtime database behavior.

### Supplier AP in-app WPF delivery adapter (2026-11-11)
The supplier AP alert tab now includes a recipient-scoped in-app inbox backed by the durable dispatcher. It claims a bounded batch for the active user/company/branch, binds the batch to the WPF grid, and only then records delivery completion. A delivery receipt means the UI batch was prepared for display; it is not a read receipt. UI preparation failures are recorded with the bounded `UI_PRESENTATION_FAILED` code and use the dispatcher's existing retry/backoff policy. The adapter does not invoke the accounting outbox worker, post journals, or change supplier-payables balances. Python structural checks do not replace C# build or WPF runtime validation. See `docs/IMPLEMENTATION_REPORT_2026-11-11-SUPPLIER-AP-INAPP-WPF-ADAPTER.md`.

### Supplier AP persistent recipient inbox read state (2026-11-11)
A new additive migration, `database/migrations/2026-11-11-supplier-ap-alert-inbox-read-state.sql`, stores recipient-specific `Viewed` and `Acknowledged` events separately from dispatch delivery state. `SupplierPayablesAlertInboxStore` reads only successfully delivered intents for the authorized user/company/branch scope, with bounded results, and writes append-only idempotent read markers. Delivery remains a dispatcher concern; this store does not claim, retry, or alter accounting work. Apply the migration after the delivery and dispatcher migrations and after taking a database backup. The persistent read-state service and WPF read/ack actions are implemented. Operator-facing dead-letter inspection and audited manual requeue are documented in the 2026-11-11 dead-letter operations report and require the corresponding additive migration.


### Supplier AP persistent inbox WPF integration (2026-11-11)
The existing supplier AP inbox now loads its durable delivered-intent projection when the tab opens and after receiving a batch. Users with `reports.read` can refresh the persisted inbox, select a delivered notification, and record `Viewed` or `Acknowledged` independently. The grid exposes delivery, view, and acknowledgement timestamps/states; lifecycle writes remain recipient/company/branch scoped and append-only through `SupplierPayablesAlertInboxStore`. The UI does not expose dispatcher retry or alter accounting. Operator dead-letter inspection/retry remains a separate controlled follow-up.

### Supplier AP dead-letter operations (2026-11-11)

The Supplier AP alert tab now exposes a tenant-scoped dead-letter queue to users holding `users.manage`. Operators can inspect recipient, alert code/severity, current retry-cycle attempts, immutable historical attempt count, last error code, and update time. A selected dead-letter can be requeued only after an explicit confirmation; the operation is recorded in the append-only `monarch_supplier_ap_alert_dead_letter_actions` audit table with actor, company, branch, prior attempt count, timestamp, and reason code. The retry action only changes dispatch state from `DeadLetter` to `Pending`; it does not itself deliver the notification or touch accounting records.

The additive migration `database/migrations/2026-11-11-supplier-ap-alert-dead-letter-operations.sql` preserves existing attempt rows while allowing globally increasing attempt numbers across manually restarted retry cycles. Attempt history and administrative retry actions are protected against update/delete. Apply this migration after the Supplier AP delivery, dispatcher, and inbox-read-state migrations, and after taking a database backup. Python regression tests validate migration preservation, immutability, tenant scoping, and WPF permission/confirmation gates. C# compilation and WPF runtime behavior still require a Windows/.NET validation environment.

## 2026-11-12 — Supplier AP dispatch integrity hardening

- Added a unique per-intent attempt-sequence index, preserving historical attempts and preventing duplicate sequence numbers across manual retry cycles.
- Added a dead-letter action history lookup index.
- Repeated company, branch, and recipient scope in guarded claim and completion updates; completion also rechecks the active lease token and unexpired lease at update time.
- Added SQLite regression coverage for two retry cycles, immutable history, sequence uniqueness, and stale-lease fencing.
- Validation: **597 pytest tests** with `ResourceWarning` treated as errors; **365 unittest tests**. C# build and WPF runtime remain unverified because .NET SDK is unavailable in this environment.
- Apply `database/migrations/2026-11-12-supplier-ap-alert-dispatch-integrity.sql` after the four Supplier AP alert migrations dated 2026-11-11. Back up first; investigate duplicate sequence values if the unique-index preflight fails.


## 2026-11-12 — Supplier AP backup and competing-worker recovery

- Strengthened `BackupRecoveryService` validation: encrypted backup creation, backup verification, restore preflight, and post-restore validation now run both SQLite `integrity_check` and `foreign_key_check`. Orphaned rows are therefore rejected even when SQLite page integrity alone reports `ok`.
- Added SQLite backup/restore regression coverage proving dispatch attempts, dead-letter operator decisions, and recipient inbox events survive a consistent database copy.
- Added a file-backed competing-worker contention test using two independent SQLite connections and `BEGIN IMMEDIATE`; only one worker can claim the same due intent. This validates SQLite transaction semantics in Python, not the C# runtime implementation under Windows process scheduling.
- Added a regression proving `foreign_key_check` detects an orphaned dispatch attempt that `integrity_check` does not report.
- No schema migration was needed. Existing encrypted backup format and password compatibility remain unchanged.
- Validation: **601 pytest tests** with `ResourceWarning` treated as errors; **365 unittest tests**; 6 application XML/XAML/project files parsed successfully. C# build and Windows multi-process runtime remain unverified because .NET SDK is unavailable in this environment.


### 2026-11-12 — Backup restore failure-safety regression coverage

- Added test-only restore contract checks for wrong passwords, authenticated-payload tampering, authenticated but invalid SQLite content, successful restore, and preservation of the pre-restore safety copy.
- Added structural assertions that the C# restore path authenticates before writing its candidate, runs integrity/foreign-key preflight before safety backup and replacement, and retains rollback plus post-replacement integrity validation.
- The Python envelope is deliberately test-only and is not the production MONARCH encrypted-backup format. These tests do not execute C# restore code or prove Windows filesystem atomicity.
- No production backup format, migration, or database schema change was made in this stage.

## 2026-11-12 — Restore rollback hardening

- Hardened `RestoreEncryptedBackup` for the first-restore case: if the replacement reaches the live database path but post-replacement integrity verification fails and no prior live database existed, the unverified live file is removed.
- Existing-database rollback still restores the exact pre-operation file and retains the rollback copy until the move-back succeeds.
- Added Python regression models for post-replacement failure with and without a pre-existing live database, plus a C# source-structure assertion for the first-restore cleanup branch.
- These tests model the contract and inspect source structure; they do not execute the C# restore service. C#/.NET build and WPF runtime validation remain unperformed in this environment.

### Backup/restore cross-process serialization — 2026-11-12
Encrypted backup creation and restore now acquire the same path-scoped named OS mutex, derived from the normalized database path. The lock serializes participating MONARCH processes for up to 30 seconds; a timeout fails explicitly rather than proceeding concurrently, and an abandoned mutex is treated as acquired ownership after a prior process exits unexpectedly. Restore's safety-copy creation re-enters the same mutex on the owning thread. This coordination only covers MONARCH processes using this service and the same mutex naming algorithm; unrelated SQLite clients or older application builds do not honor it. SQLite/WAL activity from such clients can still conflict with restore, so all other database users must remain closed during restore. Python source assertions do not prove Windows named-mutex behavior. See `docs/IMPLEMENTATION_REPORT_2026-11-12-BACKUP-MULTIPROCESS-SERIALIZATION.md`.
Validation for this stage: **610 pytest tests passed** with `ResourceWarning` promoted to errors; **365 unittest tests passed**; **7** XAML/project/config XML files parsed successfully. `dotnet` is unavailable, so C# compilation and Windows/WPF runtime behavior remain unverified.


### 2026-11-12 — SQLite WAL sidecar-safe restore rollback

- Changed restore preparation to quarantine an existing database `-wal` and `-shm` sidecar beside the rollback database instead of deleting those files before replacement.
- If replacement or post-replacement integrity verification fails, the prior database file is restored and any quarantined WAL/SHM files are moved back to their original live names. If restore succeeds, the old database rollback file and quarantined sidecars are cleaned up.
- Added Python regression models for rollback of the database and both sidecars as a set, successful replacement cleanup, and a live SQLite WAL online-backup snapshot that includes committed WAL state. Added C# source-structure assertions for sidecar quarantine and rollback.
- The C# backup path continues to use SQLite `BackupDatabase` (online backup API), producing a consistent standalone database copy rather than copying the live database file and its sidecars independently.
- Restore still requires every process using the database to be closed. The named mutex coordinates participating MONARCH builds only; it cannot make renaming WAL/SHM safe against unrelated or older clients. Python tests do not establish Windows file-sharing or C# runtime behavior.
- Validation: 614 pytest tests and 365 unittest tests passed; XML/XAML/project parsing results are recorded in `docs/TEST_RESULTS_2026-11-12-SQLITE-WAL-SIDECAR-RESTORE.md`. No schema migration or encrypted-backup format change was made.

## تحديث 2026-11-12 — استرداد الاستعادة بعد الانقطاع المفاجئ

- أضيف سجل استعادة دائم بجوار قاعدة البيانات (`.restore-journal`) قبل نقل ملفات SQLite الجانبية أو استبدال قاعدة البيانات.
- يسجل السجل مرحلتي `prepared` و`committed`، ويُكتب عبر ملف مؤقت مع `Flush(true)` ثم استبدال ذري للملف قدر الإمكان ضمن نظام الملفات المحلي.
- بعد امتلاك قفل قاعدة البيانات المشترك بين العمليات، تفحص الخدمة وجود سجل غير مكتمل قبل تنفيذ أي عملية نسخ أو استعادة.
- في مرحلة `prepared`، تعيد الخدمة ملف قاعدة البيانات السابق وملفات WAL/SHM إن وُجدت؛ وفي الاستعادة الأولى تزيل قاعدة البيانات الجديدة غير المعتمدة.
- في مرحلة `committed`، تكمل الخدمة تنظيف ملفات التراجع دون إعادة إرفاق ملفات WAL/SHM القديمة بقاعدة البيانات الجديدة.
- أضيفت اختبارات نموذجية لحالات الانقطاع بعد عزل الملفات الجانبية، وبعد استبدال الملف الرئيسي، وأثناء الاستعادة الأولى، وبعد تثبيت حالة commit.
- **حدود التحقق:** الاختبارات الجديدة نموذج Python وفحوص بنيوية لمصدر C#، وليست اختبار قتل عملية Windows أو اختبار انقطاع طاقة/قرص. يجب إجراء اختبار تكامل فعلي على Windows قبل اعتماد الميزة إنتاجياً.

### 2026-11-12 — Restore journal rollback-path validation hardening

- Tightened crash-recovery journal validation: the rollback file must be in the database directory, use the exact database filename plus `.pre-restore-`, and end with a 32-character GUID in `N` format.
- Rejected prefix-sibling names, malformed GUID tokens, and unexpected rollback filenames before any recovery cleanup or file move is attempted.
- Added regression checks for valid and invalid rollback-name forms and retained all existing crash-state recovery coverage.
- This is defense-in-depth for local journal integrity; it does not authenticate the journal against a privileged local attacker and does not replace filesystem ACLs.
- Validation: 621 pytest tests and 365 unittest tests passed; 7 XML/XAML/project files parsed. C# build and Windows process-termination tests remain outstanding because the .NET toolchain is unavailable in this environment.


### 2026-11-12 — Restore journal recovery-state fail-closed checks
- Recovery now validates the main-database artifact state before cleanup or rollback: committed journals require a live database; prepared journals with a prior database require either the rollback file or a live database; first-time restores reject unexpected rollback main files.
- Ambiguous or inconsistent states stop database operations and preserve the journal/rollback artifacts for manual recovery instead of silently deleting recovery evidence.
- Added Python crash-state models and C# source-structure assertions for missing live files and inconsistent rollback artifacts. These tests model intended behavior and do not execute the C# implementation.
- No database schema, encrypted backup format, or module was removed or changed. Windows/.NET runtime validation remains outstanding.

Current validation boundary: 625 pytest and 365 unittest tests pass for the restore-journal fail-closed stage. Seven XML/XAML/project files parse. The .NET SDK is unavailable here, so no C# build or WPF runtime test is claimed.

#### Restore journal integrity framing (2026-11-12)

New restore transactions write a versioned `MONARCH-RESTORE-JOURNAL-V2` record with a SHA-256 checksum over its fields. Recovery validates the checksum and strict UTF-8 decoding before trusting the recorded rollback path. Existing three-line V1 journals remain readable so an upgrade does not strand an interrupted restore. The checksum detects accidental corruption and inconsistent edits; it is **not** a keyed authenticity mechanism and does not protect against a local actor who can rewrite both the journal and its checksum. C# / Windows crash-recovery integration remains pending.


### 2026-11-12 — V2 committed-phase recovery regression fix

- Corrected recovery dispatch to use the parsed `phase` value for both legacy V1 and checksummed V2 journals. V2 stores `hadPrevious` in field 3 and `phase` in field 4; comparing `lines[2]` to `committed` incorrectly bypassed the committed cleanup path for V2 records.
- Added regression assertions that a V2 committed record is parsed as committed and that C# recovery branches on the normalized phase rather than a version-specific array index.
- This is a source-level correction with Python regression coverage; C# compilation and Windows execution remain unverified in this environment.


Validation snapshot for the V2 committed-phase regression fix: 632 pytest tests and 365 unittest tests passed. These are Python tests and source assertions; they do not establish C# compilation or Windows runtime behavior.

## تحديث 2026-11-13 — قابلية استئناف تعافي سجل الاستعادة

- أضيفت اختبارات انحدار لمحاكاة إعادة تشغيل عملية التعافي بعد اكتمال استرجاع ملف قاعدة البيانات وقبل استرجاع ملفات WAL/SHM.
- أضيفت حالة توقف بعد استرجاع WAL وقبل SHM، للتحقق من أن المحاولة التالية لا تستبدل ملف WAL الذي عاد بالفعل.
- أضيفت حالة تكرار تنظيف سجل `committed` بعد حذف جزئي لملفات rollback، للتحقق من أن التنظيف قابل لإعادة المحاولة ولا يمس قاعدة البيانات الجديدة المتحقق منها.
- أضيف تحقق بنيوي من أن استرجاع sidecar لا ينفذ النقل إلا عند وجود ملف quarantine.
- هذه اختبارات Python لنموذج حالات التعافي وفحص بنية C#؛ لا تنفذ خدمة `BackupRecoveryService` نفسها ولا تثبت تحمل انقطاع الطاقة أو سلوك نظام الملفات على Windows.

نتائج هذه الحزمة: **636 اختبار pytest ناجحاً** و**365 اختبار unittest ناجحاً**. لم يتوفر `dotnet`، لذلك لم يُنفذ بناء C# أو WPF أو اختبارات تشغيل Windows.

### 2026-11-13 — مراجعة تدفق التعافي بعد إعادة التشغيل

- تمت مراجعة `BackupRecoveryService` من مسار كتابة سجل `prepared` حتى الاستعادة والتنظيف، بما يشمل استرداد `V1/V2`، والتحقق من مسار rollback، والتعامل مع WAL/SHM، وقفل العمليات.
- لم يظهر في المراجعة المكتبية عيب إنتاجي محدد يبرر تعديل منطق C# دون تشغيله على Windows؛ لذلك لم يُغيّر كود الخدمة الإنتاجي في هذه المرحلة.
- أضيفت فحوص بنيوية تؤكد أن استرجاع WAL وSHM يسبق حذف سجل التعافي، وأن مسار `committed` يتحقق من وجود قاعدة البيانات الحية قبل تنظيف آثار التراجع.
- تبقى مخاطر خارج نطاق قفل MONARCH قائمة مع عمليات SQLite غير المشاركة في mutex. كما أن SHA-256 غير المفتاحي للسجل يكشف التلف ولا يوفر مصادقة ضد كاتب محلي قادر على تعديل السجل والبصمة.
- لا تزال اختبارات قتل العملية، وانقطاع الطاقة، ومتانة `Flush(true)`/الاستبدال الذري، وملفات WAL/SHM الفعلية على Windows مطلوبة قبل اعتماد الإنتاج.

### 2026-11-13 — حماية آثار rollback في تعافي restore المعتمد

- أُضيف تحقق فعلي من `integrity_check` و`foreign_key_check` لقاعدة البيانات الحية عند استئناف سجل restore بحالة `committed`، وقبل حذف قاعدة rollback أو ملفات WAL/SHM أو سجل التعافي.
- إذا فشل التحقق، يتوقف التعافي برسالة واضحة ويُبقي جميع آثار rollback والسجل للمراجعة اليدوية بدلاً من إتلاف آخر نسخة احتياطية محلية متاحة.
- أضيف نموذج Python وفحص بنيوي لترتيب التحقق قبل التنظيف؛ لا ينفذ ذلك كود C# ولا يثبت سلوك Windows.
- لا تغيير في تنسيق النسخ الاحتياطية أو مخطط SQLite أو واجهة المستخدم.
- التحقق: نتائج هذه المرحلة موثقة في `docs/TEST_RESULTS_2026-11-13-COMMITTED-RECOVERY-INTEGRITY-GUARD.log`. بناء C# وتشغيل WPF واختبارات Windows الفعلية لم تُنفذ لعدم توفر .NET SDK.


### Restore integrity validation — result completeness
The restore/recovery integrity routine now requires `PRAGMA integrity_check` to return at least one result row. An empty result set is treated as an integrity-validation failure rather than silently accepted as `ok`. This is a fail-closed defensive guard; Python source-structure coverage does not replace executing the C# SQLite provider path.


## 2026-11-13 — SQLite integrity result cardinality guard

- `BackupRecoveryService.CheckIntegrity` now accepts a successful `PRAGMA integrity_check` only when the provider returns exactly one result row and that row is `ok`, matching SQLite's documented success shape.
- Empty results and anomalous multiple-success rows fail closed; error rows continue to be reported.
- Regression coverage is a Python source-structure assertion only. The compiled C# method and Windows SQLite provider have not been exercised in this environment.

## تحديث 2026-11-13 — حقن أعطال متتابعة في نموذج استعادة SQLite

- توسّع نموذج Python لاختبار استعادة حالة `prepared` بحيث يحقن توقفاً بعد كل تعديل ملفات على حدة: إزالة قاعدة البيانات غير المعتمدة، إعادة ملف قاعدة البيانات السابقة، ثم عمليتا استعادة WAL وSHM (بما فيهما نقاط حذف الوجهة قبل النقل).
- بعد كل توقف اصطناعي، يعاد تشغيل التعافي من الحالة المتبقية على القرص، ويُتحقق من استعادة قاعدة البيانات وملفي WAL/SHM القديمين دون فقد أو خلط.
- هذه اختبارات نموذج filesystem في Python وليست تنفيذاً لخدمة C# أو محاكاة لانقطاع طاقة فعلي؛ يلزم تشغيل اختبارات حقن الأعطال على Windows/.NET قبل اعتبار السلوك مثبتاً إنتاجياً.


## تحديث 2026-11-13 — استئناف تنظيف تعافي restore المعتمد بعد الأعطال

- توسعت اختبارات نموذج تعافي `committed` بحقن توقف العملية بعد كل حذف من حذوفات آثار rollback الثلاثة (قاعدة البيانات السابقة وملفا WAL وSHM).
- بعد كل توقف، يبدأ تشغيل تعافٍ جديد من حالة الملفات المتبقية؛ ويجب أن تبقى قاعدة البيانات الجديدة التي سبق التحقق منها هي القاعدة الحية، مع استكمال تنظيف الآثار المتبقية.
- لم يتغير منطق C# الإنتاجي؛ هذا توسيع لاختبار نموذج filesystem في Python فقط، ولا يثبت تنفيذ `BackupRecoveryService` أو سلوك Windows الفعلي.
- التحقق في هذه الحزمة: 644 اختبار pytest و365 اختبار unittest ناجحة؛ تفاصيل الحدود في سجل الاختبار المرفق.

## 2026-11-13 — Prepared recovery repeated-termination coverage

- Added a repeated-failure regression for the `prepared` rollback filesystem model: for each of the first five interruption points, recovery is interrupted again after its first subsequent filesystem mutation, then restarted a third time.
- The final restart must restore the original database and both quarantined SQLite sidecars, with no rollback artifacts left behind. This strengthens coverage beyond a single interruption followed by an uninterrupted retry.
- No production C# code, database schema, module, or UI behavior changed. This remains a Python filesystem-model test, not execution of `BackupRecoveryService` or a Windows power-loss test.

Validation snapshot: 645 pytest tests and 365 unittest tests passed; 7 XML/XAML/project files parsed with 0 errors. .NET SDK was unavailable, so C# build, WPF runtime, and Windows SQLite integration were not run.


## تحديث 2026-11-13 — التعافي من الانقطاع المتكرر في الاستعادة الأولى

- أضيف اختبار يغطي مسار `prepared` عندما لا توجد قاعدة بيانات سابقة (`hadPrevious=false`) مع وجود WAL/SHM معزولين من الحالة السابقة وملفات جانبية ناتجة عن قاعدة الاستعادة غير المعتمدة.
- يحقن الاختبار توقفاً أولاً عند كل نقطة من نقاط تعديل الملفات الخمس، ثم توقفاً ثانياً أثناء محاولة التعافي التالية، ثم يشغّل محاولة ثالثة حتى الاكتمال.
- يتحقق من حذف قاعدة البيانات غير المعتمدة، وإرجاع WAL وSHM المعزولين، وعدم ترك ملفات rollback جانبية معلقة.
- لا تعديل على كود C# الإنتاجي أو مخطط البيانات أو الوحدات أو واجهة المستخدم؛ الاختبار نموذج Python لنظام الملفات فقط.

نتائج هذه الحزمة: 646 اختبار pytest و365 اختبار unittest ناجحة. لم يتوفر .NET SDK؛ لم يُنفذ بناء C# أو تشغيل WPF أو اختبار Windows/SQLite Provider فعلي.

## تحديث 2026-11-13 — مصفوفة الانقطاع الثاني في الاستعادة الأولى

- توسع اختبار نموذج `prepared` للاستعادة الأولى (`hadPrevious=false`) إلى مصفوفة تجمع نقاط الانقطاع الأولى مع نقاط الانقطاع الثانية الممكنة أثناء محاولة التعافي التالية.
- بعد كل حالة، تنفذ محاولة نظيفة أخيرة وتتحقق من إزالة قاعدة البيانات غير المعتمدة، واستعادة WAL وSHM المعزولين، وعدم بقاء ملفات rollback.
- لم يتغير كود C# الإنتاجي أو مخطط البيانات أو الواجهة أو أي وحدة ERP. هذا اختبار نموذج ملفات Python فقط.
- التحقق: 647 اختبار pytest و365 اختبار unittest؛ فحص 7 ملفات XML/XAML ومشروعات دون أخطاء. لا يتوفر .NET SDK، لذلك لم يُنفذ بناء C# أو تشغيل WPF أو اختبار Windows/SQLite Provider فعلي.


## 2026-11-13 — Committed recovery artifact preservation and FK validation coverage

- Expanded the committed-recovery failure model to include both live WAL/SHM files and quarantined rollback WAL/SHM files. When the live database fails the integrity gate, every main/sidecar artifact must remain byte-for-byte available; recovery must not partially clean or replace any of them.
- Added a source-level regression assertion that the shared SQLite integrity routine executes both `PRAGMA integrity_check` and `PRAGMA foreign_key_check`, and reports foreign-key violations as integrity failures.
- No production C# logic, database schema, ERP module, or UI behavior changed. These additions are Python model/source assertions, not execution of the C# SQLite provider or Windows crash integration.


### 2026-11-13 — repeated interruption during committed cleanup

- Added a two-termination matrix for `committed` recovery cleanup. Each of the three first cleanup interruption points is paired with subsequent reachable second interruption points, followed by a clean third recovery attempt.
- The invariant is that the integrity-validated live database remains byte-for-byte authoritative while all remaining rollback database/WAL/SHM artifacts are eventually removed.
- This is a Python filesystem-model regression test; it does not execute `BackupRecoveryService`, the SQLite provider, or Windows crash/power-loss behavior. No production C# code, schema, ERP module, or UI behavior changed.


### 2026-11-13 — Committed recovery partial-cleanup idempotence

The committed restore-recovery model now covers all eight presence/absence combinations of the rollback database, quarantined WAL, and quarantined SHM artifacts. Each state is recovered twice to verify that cleanup is idempotent, the integrity-approved live database remains byte-for-byte unchanged, and no rollback sidecars are reintroduced. This remains Python filesystem-model coverage; it does not replace execution against the C# SQLite provider on Windows.

### 2026-11-13 — Committed recovery integrity-gate partial-state matrix

- Added coverage for all eight presence/absence combinations of rollback DB/WAL/SHM while the committed live database fails integrity validation.
- Repeats the failed recovery twice and verifies every existing live and rollback artifact remains byte-for-byte unchanged; then retries with a passing integrity gate and verifies only rollback artifacts are cleaned.
- This is Python filesystem-model coverage, not execution of the C# SQLite provider or Windows crash behavior. No production C# logic, schema, ERP module, or WPF behavior changed.

## 2026-11-13 — Strict committed-restore cleanup

- Fixed a recovery-journal lifecycle gap: committed recovery previously used best-effort deletion for rollback artifacts and could then delete the journal even when an artifact deletion failed.
- Committed recovery now uses strict, exception-propagating deletion for the rollback database, quarantined WAL/SHM, and only then the journal. A cleanup failure therefore leaves the committed journal available for a later retry.
- Added a simulated sharing-violation regression and structural checks for strict deletion ordering. No database schema, ERP module, or WPF behavior changed.
- Validation: 653 pytest tests and 365 unittest tests passed. These are Python/model and structural checks; no .NET build or Windows runtime test was available in this environment.

### 2026-11-13 — strict deletion must surface metadata/access failures

- Hardened committed restore cleanup further by removing the `File.Exists` pre-check from the strict deletion helper. `File.Delete` is idempotent for a missing file, while failures to delete an existing but inaccessible or shared file now propagate instead of being mistaken for absence by `File.Exists`.
- Added regression cases for failure at each rollback DB/WAL/SHM deletion point and a structural assertion that strict deletion does not gate on `File.Exists`.
- Validation: 657 pytest tests and 365 unittest tests passed; all 7 project/XAML/config XML files parsed. These checks do not compile or execute the C# service. No .NET build, WPF runtime, or Windows filesystem integration was performed.


### 2026-11-13 — direct restore committed-cleanup safety

- The successful restore path now switches to strict rollback-artifact deletion immediately after the `committed` journal is durably written. The journal is removed only after rollback DB/WAL/SHM deletion succeeds.
- A cleanup exception after commit is rethrown without entering the prepared-phase rollback branch, preserving the verified live database and committed journal for startup retry. Prepared-phase failures retain the existing rollback behavior.
- Added source-order/commit-boundary assertions and a three-point filesystem-model failure matrix for direct restore cleanup. No schema or ERP module was changed.
- Validation results are recorded in `TEST_RESULTS_2026-11-13-DIRECT-RESTORE-COMMITTED-CLEANUP.md`.


## استعادة النسخ الاحتياطية — إعادة محاولة تنظيف committed

مسار الاستعادة المباشر ومسار التعافي عند بدء التشغيل يحتفظان بسجل `committed` حتى يكتمل حذف ملفات rollback وقواعد WAL/SHM المعزولة. اختبارات النموذج تغطي فشل كل نقطة حذف في المسار المباشر ثم إعادة المحاولة، مع التأكد من بقاء قاعدة البيانات الجديدة المعتمدة دون تغيير. هذه اختبارات Python ونموذج ملفات؛ ولا تحل محل اختبار C# فعلي على Windows. راجع `IMPLEMENTATION-2026-11-13-DIRECT-RESTORE-COMMITTED-CLEANUP-RETRY.md` وسجل النتائج المقابل.

### 2026-11-13 — Direct restore journal-removal retry boundary

- Extended the direct committed-cleanup retry matrix to inject failure at the final journal-removal step, after rollback DB/WAL/SHM artifacts have already been removed.
- Verified the committed journal remains as the durable retry marker, the validated live database remains byte-for-byte unchanged, and a later cleanup pass safely removes the journal even when all rollback artifacts are already absent.
- Python filesystem-model coverage only; no production C# logic, schema, ERP module, or WPF behavior changed. Actual Windows/.NET filesystem and SQLite-provider execution remains outstanding.

### 2026-11-13 — Restore journal V2 corruption matrix
- Expanded journal validation regression coverage across every framed V2 field, including the version marker, rollback path, prior-database flag, phase, and checksum.
- Covered digest framing boundaries (empty, 63/65 characters, and non-hex input) and confirmed uppercase hexadecimal checksums remain accepted.
- Added source-level checks that the C# validator enforces a 64-character hexadecimal SHA-256 digest and compares the full digest without an early-exit character mismatch.
- This increment changes tests and documentation only; no production C# behavior or ERP module was modified.
- Validation results are recorded in `TEST_RESULTS_2026-11-13-RESTORE-JOURNAL-V2-CORRUPTION-MATRIX.log`.


## تحديث 2026-11-14 — التحقق الدلالي لسجل الاستعادة V1/V2

- أضيفت اختبارات رفض لقيم `hadPrevious` غير القياسية في سجل V2 حتى عندما تكون بصمة SHA-256 صحيحة.
- أضيفت اختبارات رفض لمراحل V2 غير المدعومة أو ذات اختلاف حالة الأحرف/المسافات مع بصمة صحيحة.
- أضيف اختبار قبول شامل للقيم القانونية (`true`/`false` و`prepared`/`committed`) واختبار صرامة مماثل لسجل V1 القديم.
- هذا التحديث يوسع التحقق الاختباري فقط؛ لم يتغير منطق C# الإنتاجي أو مخطط البيانات أو وحدات ERP.
- اختبارات Python لا تثبت وحدها تنفيذ C#؛ بناء .NET وWPF وتكامل SQLite على Windows ما زالت غير منفذة في بيئة لا يتوفر فيها .NET SDK.

## تحديث 2026-11-14 — إحكام مرجع ملف rollback في سجل الاستعادة

- أضيفت مصفوفة اختبار لمرجع قاعدة البيانات السابقة: يجب أن يكون في المجلد نفسه بعد تطبيع المسارات، وأن يطابق اسم قاعدة البيانات الحالية متبوعاً باللاحقة الدقيقة `.pre-restore-` ومعرّف GUID بصيغة `N` ذات 32 خانة.
- تغطي الحالات المرفوضة المجلدات الشقيقة/المتداخلة، واسم قاعدة مختلف، واللاحقات الزائدة، وصيغة GUID ذات الأقواس والواصلات، والمحارف غير السداسية.
- أضيف اختبار لقبول المسار الصحيح بعد تطبيع `..`، وفحص مصدر C# للتأكد من استمرار استخدام `Path.GetFullPath` ومقارنة المجلد دون حساسية لحالة الأحرف والتحقق الصريح من GUID.
- التغيير اختباري وتوثيقي فقط؛ لم يتغير منطق C# الإنتاجي أو قاعدة البيانات أو وحدات ERP أو WPF.
- نتائج التحقق: `pytest -q` = 693 ناجحاً؛ `unittest discover` = 365 ناجحاً. لا يتوفر .NET SDK، لذلك لم ينفذ بناء C# أو تشغيل WPF أو تكامل SQLite الفعلي على Windows.
- سجل التنفيذ: `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-ROLLBACK-PATH-MATRIX.md`؛ النتائج: `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-ROLLBACK-PATH-MATRIX.log`.

## Restore journal strict UTF-8 validation — 2026-11-14

Restore recovery reads journal text using strict UTF-8 decoding (`UTF8Encoding(false, true)`). The accompanying regression tests cover malformed leading bytes, invalid continuation bytes, and truncated multibyte sequences, and verify that malformed input is rejected before the test recovery flow changes the live database or rollback artifact. This is Python-model plus source-structure validation; execution against the compiled C# recovery service and Windows filesystem remains pending.

## Restore journal read I/O failure handling — 2026-11-14

Recovery must fail closed when the durable restore journal cannot be opened or read. Regression coverage now injects access-denied and sharing-violation-style read failures and verifies that the live database, rollback database, quarantined WAL/SHM artifacts, and journal remain byte-for-byte unchanged. A source-order check confirms strict journal reading precedes destructive recovery operations. These are Python fault-model and C# source-structure checks only; actual Windows ACL/sharing behavior against the compiled service remains pending. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-READ-IO-FAIL-CLOSED.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-READ-IO-FAIL-CLOSED.log`.


## Prepared restore filesystem I/O retry matrix — 2026-11-14

The prepared-journal recovery model now injects one-shot access failures at six database/WAL/SHM removal and rollback-move boundaries. Each case verifies that the durable journal remains available and that a later retry restores the prior database and sidecars byte-for-byte. A source-structure check covers the corresponding C# move and cleanup boundaries. This is Python fault-model and source inspection only; compiled C# and Windows filesystem behavior remain unverified. See `IMPLEMENTATION-2026-11-14-PREPARED-RECOVERY-FILESYSTEM-IO-RETRY.md` and `TEST_RESULTS_2026-11-14-PREPARED-RECOVERY-FILESYSTEM-IO-RETRY.log`.

### 2026-11-14 — Prepared recovery repeated I/O failure retry matrix
- [x] Inject two independent filesystem access/sharing failures across successive recovery attempts, at different mutation boundaries.
- [x] Cover retry sequences spanning main-database rollback, WAL restoration, and SHM restoration.
- [x] Verify the durable `prepared` journal remains present after both failed attempts and that a third attempt restores the original DB/WAL/SHM bytes exactly.
- [ ] Run equivalent repeated-failure scenarios against the compiled C# recovery service on supported Windows/.NET filesystems, including real ACL and sharing violations.

Validation: `pytest -q` — 710 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 passed; XML/XAML/project/config parsing — 7 parsed, 0 errors. See `TEST_RESULTS_2026-11-14-PREPARED-RECOVERY-REPEATED-IO-FAILURES.log`. No C# build or WPF runtime test was possible because the .NET SDK is unavailable.

## تحديث 2026-11-14 — حذف صارم لقاعدة البيانات غير المعتمدة في الاستعادة الأولى

- عولجت فجوة في مسار الاستعادة الأولى (دون قاعدة بيانات سابقة): كان حذف ملف قاعدة البيانات الجديدة غير المعتمدة يستخدم حذفاً best-effort، ثم يمكن متابعة استعادة الملفات الجانبية وإزالة سجل `prepared` رغم فشل الحذف.
- أصبح حذف قاعدة البيانات غير المعتمدة صارماً في مساري معالجة فشل الاستعادة المباشر واسترداد بدء التشغيل. عند فشل الوصول/الحذف، يتوقف المسار وتبقى حالة `prepared` والملفات الجانبية اللازمة للمحاولة التالية.
- أضيف اختبار fault-injection يحاكي قفل ملف قاعدة البيانات: يتحقق من بقاء قاعدة البيانات غير المعتمدة والسجل وملفات WAL/SHM دون تغيير عند الفشل، ثم يثبت نجاح إعادة المحاولة بعد زوال العطل.
- التحقق: `pytest -q` — **712 passed**؛ `python -m unittest discover -s tests -p 'test_*.py'` — **365 OK**؛ تحليل XML/XAML والمشروعات — **7 parsed, 0 errors**.
- لم يُنفذ بناء C# أو تشغيل WPF أو اختبار Windows ACL/SQLite فعلي؛ لا يتوفر .NET SDK/Windows runtime في بيئة التحقق.

### 2026-11-14 — First-restore sidecar retry matrix

Expanded first-time restore recovery tests beyond strict removal of the unverified main database. Four independent transient I/O failures now cover live WAL/SHM removal and quarantined WAL/SHM moves. Each case verifies that the durable `prepared` journal remains available and a later retry restores the original sidecar bytes. A C# source-order check confirms journal removal follows both sidecar restoration steps. This increment changes tests and documentation only; no production C# behavior or ERP module changed. See `IMPLEMENTATION-2026-11-14-FIRST-RESTORE-SIDECAR-RETRY-MATRIX.md` and its test log.

## First-restore journal cleanup retry — 2026-11-14

The first-restore recovery tests now cover termination after both quarantined sidecars have been restored but before the `prepared` journal is removed, plus an access-denied failure during journal cleanup. The retry path is checked for idempotence and byte-for-byte preservation of restored WAL/SHM files. A C# source-order check confirms WAL and SHM restoration precede best-effort journal deletion. This is Python fault-model and source-structure coverage only; no production C# logic was changed and compiled Windows behavior remains unverified. See `IMPLEMENTATION-2026-11-14-FIRST-RESTORE-JOURNAL-CLEANUP-RETRY.md` and `TEST_RESULTS_2026-11-14-FIRST-RESTORE-JOURNAL-CLEANUP-RETRY.log`.

## Abandoned restore-journal temporary cleanup — 2026-11-14

Startup recovery now removes abandoned journal publication temporary files left by a process termination between flushing the temporary journal and atomically publishing it. Cleanup runs under the existing database-operation mutex, is limited to the exact `.restore-journal.tmp-<32-hex-GUID-N>` naming pattern in the database directory, and uses strict deletion so access/sharing failures block further database work. The published journal remains authoritative and is processed normally; malformed or unrelated names are not deleted. Regression coverage: `pytest -q` — 724 passed; `unittest discover` — 365 passed; XML/XAML/project/config parsing — 7 parsed, 0 errors. The compiled C# service, WPF, and Windows/SQLite integration were not run because the .NET SDK/Windows runtime are unavailable. See `IMPLEMENTATION-2026-11-14-ABANDONED-RESTORE-JOURNAL-TEMP-CLEANUP.md` and `TEST_RESULTS_2026-11-14-ABANDONED-RESTORE-JOURNAL-TEMP-CLEANUP.log`.

## 2026-11-14 — Restore journal atomic-publication failure matrix

- Added Python fault-model coverage for initial journal `File.Move` publication failure and replacement `File.Replace` failure.
- Verified a failed replacement leaves the previously published journal byte-for-byte intact; a failed initial publication does not create an authoritative journal.
- Covered the combined publication/temporary-cleanup failure and verified startup cleanup removes the orphan GUID-N temporary file without changing the published journal.
- Added source-structure assertions for unique temporary naming, durable flush, atomic Move/Replace publication, and `finally` cleanup.
- No production C# or ERP module was changed. Validation: `pytest -q` — 728 passed; `unittest discover` — 365 passed; XML/XAML/project parsing — 7 parsed, 0 errors. Compiled C#, WPF, Windows filesystem and SQLite integration were not run because .NET/Windows tooling is unavailable. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-PUBLICATION-FAILURE-MATRIX.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-PUBLICATION-FAILURE-MATRIX.log`.

### 2026-11-14 — Restore journal abandoned-temp cleanup failure boundaries

- Extended the restore-journal fault model to cover strict deletion failure for an abandoned GUID-N publication temp. The failure propagates, preserving both the temp and the already-published journal; a later startup retry removes only the abandoned temp.
- Added a directory-enumeration denial case and verified startup cleanup fails before journal processing or any live-database mutation.
- Added a source-structure guard that the C# cleanup path uses top-directory enumeration and strict deletion without swallowing enumeration/deletion exceptions.
- No production C#, schema, WPF, or ERP module changes were made. Python model/source tests only; Windows filesystem behavior still requires execution on Windows.
- Validation: `pytest -q` — 731 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 tests OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. No .NET build or WPF runtime test was run because `dotnet` is unavailable.
- See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-TEMP-CLEANUP-FAILURE-BOUNDARIES.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-TEMP-CLEANUP-FAILURE-BOUNDARIES.log`.

### 2026-11-14 — Restore-journal streaming enumeration and retry coverage

Added regression coverage for a lazy directory enumeration that fails after yielding an abandoned journal temp: startup aborts with the published journal and live database preserved, and a later pass removes the remaining orphan. Added a namespace-isolation case proving cleanup for one database journal does not delete another database's temp file. A C# source guard verifies streaming enumeration is performed before journal processing. This increment changes tests and documentation only; production C#, schema, WPF, and ERP modules remain unchanged. Validation: `pytest -q` — 734 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. C# build, WPF, and Windows filesystem/SQLite integration were not run because .NET/Windows tooling is unavailable. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-STREAMING-ENUMERATION-RETRY.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-STREAMING-ENUMERATION-RETRY.log`.

### 2026-11-14 — Restore-journal temporary-name boundary coverage

Added regression coverage ensuring abandoned journal-temp cleanup accepts uppercase GUID-N suffixes while preserving malformed suffixes, similarly prefixed non-exact names, and directory entries that are not files. The Python cleanup model now mirrors the production file-enumeration boundary. `pytest -q` — 737 passed; Python unittest — 365 OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. No production C#, schema, WPF, or ERP module changed. Compiled C#, WPF, and Windows filesystem/SQLite integration remain unverified because the required toolchain is unavailable. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-TEMP-NAME-BOUNDARIES.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-TEMP-NAME-BOUNDARIES.log`.


## Restore-journal temporary symlink safety (2026-11-14)
The abandoned-temp cleanup regression suite now checks that a matching symbolic-link entry is unlinked without altering its target, and structurally guards the C# strict-delete helper against recursive directory deletion. This is Python filesystem-model coverage plus a C# source assertion; Windows reparse-point/ACL behavior and compiled C# execution remain pending. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-TEMP-SYMLINK-SAFETY.md`.

## Restore-journal temporary hard-link safety (2026-11-14)
Added a regression test proving that removing a matching GUID-N temporary hard-link entry preserves the separately retained file and its contents. This complements symbolic-link target-preservation coverage. Test/documentation-only increment; compiled C# and Windows filesystem behavior remain pending. Validation: `pytest -q` — 740 passed; Python unittest — 365 OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-HARDLINK-SAFETY.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-HARDLINK-SAFETY.log`.

## Restore-journal cross-directory hard-link cleanup safety (2026-11-14)
Added a filesystem-model regression test placing the abandoned GUID-N hard-link entry in the journal directory and its retained name in a separate same-filesystem directory. Cleanup must unlink only the temporary name, preserve retained bytes, and decrement the inode link count by one. This is Python model coverage, not a Windows/C# runtime test. Validation: `pytest -q` — 741 passed; Python unittest — 365 OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. No production C#, WPF, or ERP module changed. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-CROSS-DIRECTORY-HARDLINK.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-CROSS-DIRECTORY-HARDLINK.log`.

## Restore-journal concurrent temp disappearance (2026-11-14)
Added a regression case for an abandoned GUID-N temp that disappears after enumeration but before cleanup deletion. The test verifies idempotent missing-file deletion behavior, while a C# source guard protects the direct `File.Delete` contract without a lossy `File.Exists` preflight. Test/documentation-only increment; no production C#, schema, WPF, or ERP module changed. This remains a Python model/source assertion, not a Windows multi-process test. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-CONCURRENT-TEMP-DISAPPEARANCE.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-CONCURRENT-TEMP-DISAPPEARANCE.log`.


## تحديث 2026-11-14 — سباق تغيّر نوع مدخل ملف سجل الاستعادة المؤقت

- أضيف اختبار لحالة TOCTOU يتحول فيها مسار ملف مؤقت مطابق GUID-N إلى مجلد بعد أن تعيده عملية التعداد وقبل الحذف.
- يتحقق الاختبار من فشل الحذف الصارم بصورة مغلقة، وبقاء المجلد ومحتواه دون تغيير، وعدم التحول إلى حذف تكراري، ثم نجاح محاولة لاحقة بعد إزالة التعارض وعودة المسار إلى ملف عادي.
- أضيف حارس بنيوي يؤكد استمرار التعداد على مستوى المجلد الأعلى واستخدام حذف ملف مفرد.
- هذا اختبار نموذج Python وفحص مصدر C# فقط؛ لم يُبنَ C# ولم تُختبر منافسة الاستبدال فعلياً على Windows/NTFS. لم يتغير منطق C# الإنتاجي أو مخطط قاعدة البيانات أو WPF أو وحدات ERP.

التحقق في هذه الحزمة: `pytest -q` — **745 ناجحاً**؛ `python -m unittest discover -s tests -p 'test_*.py'` — **365 ناجحاً**.

### 2026-11-14 — Restore-journal directory-symlink race safety

Added a focused filesystem-model regression for a matching abandoned journal-temp path that is replaced by a directory symbolic link after enumeration. The test verifies cleanup fails closed, does not recurse into or modify the link target, and can clean a regular temp on a later retry. A C# source guard preserves the single-entry `File.Delete` contract and rejects recursive-directory fallback. Validation: `pytest -q` — 747 passed; Python unittest — 365 tests OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. This is Python filesystem-model and source-structure coverage only; no .NET build, WPF runtime, or Windows/NTFS reparse-point integration was run. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-DIRECTORY-SYMLINK-RACE.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-DIRECTORY-SYMLINK-RACE.log`.


## Restore-journal dangling symbolic-link cleanup (2026-11-14)
Added regression coverage for a matching GUID-N abandoned-temp entry that is a dangling symbolic link. The test verifies that cleanup unlinks the directory entry without following or creating its missing target, and that repeated cleanup is harmless. A C# source guard retains direct `File.Delete` semantics without a `File.Exists` preflight. This is Python filesystem-model and source-structure coverage only; Windows reparse-point behavior and compiled C# execution remain unverified. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-DANGLING-SYMLINK.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-DANGLING-SYMLINK.log`.

## Restore-journal symlink target-creation race (2026-11-14)
Added a regression case where a matching GUID-N abandoned-temp symlink is enumerated while dangling, then its target is created before cleanup removes the link. The test verifies that cleanup unlinks only the symlink entry and preserves the newly created target and contents. A C# source guard requires direct `File.Delete` semantics without resolving the link target or recursively deleting directories. This increment changes tests and documentation only. Validation: `pytest -q` — 751 passed; Python unittest — 365 OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. No C# build, WPF runtime, or Windows/NTFS integration was run. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-SYMLINK-TARGET-CREATION-RACE.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-SYMLINK-TARGET-CREATION-RACE.log`.

### 2026-11-14 — Restore-journal file-symlink replacement race

Added a regression for a matching GUID-N temporary path enumerated as a regular file and replaced before deletion by a symbolic link to an existing regular file. The cleanup model must unlink only the link entry and preserve the target's exact bytes. A C# source guard retains direct `File.Delete` semantics and rejects link resolution, `File.Exists` preflight, and recursive directory deletion. Tests/documentation only; no production C#, schema, WPF, installer, or ERP module changed. Validation: `pytest -q` — 753 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. No .NET build, WPF runtime, or Windows/NTFS integration was run. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-FILE-SYMLINK-REPLACEMENT-RACE.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-FILE-SYMLINK-REPLACEMENT-RACE.log`.

## تحديث 2026-11-14 — سباق استبدال ملف المؤقت برابط صلب

أضيف اختبار يحاكي تعداد ملف مؤقت صالح ثم استبدال مدخله برابط صلب إلى ملف آخر محفوظ قبل التنظيف. يتحقق الاختبار من حذف اسم الرابط المؤقت فقط، وبقاء الاسم الآخر ومحتوى الملف، وانخفاض عدد الروابط بمقدار واحد. أضيف أيضاً حارس بنيوي يحافظ على حذف C# لمدخل واحد دون فحص مسبق للوجود أو حذف مجلدات تكرارياً.

هذا اختبار نموذج Python وفحص مصدر C# فقط؛ لم يُبنَ C# ولم تُشغّل خدمة الاستعادة على Windows/NTFS.

### 2026-11-14 — Restore-journal temporary-name collision safety

Added a regression proving that exclusive creation refuses an unexpected pre-existing journal-temp name without overwriting its bytes or publishing a journal. A C# source guard requires `FileMode.CreateNew` with `FileShare.None` and rejects the truncating `FileMode.Create` mode. Validation: `pytest -q` — 757 passed; Python unittest — 365 OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. Tests/documentation only; no production C#, schema, WPF, or ERP module changed. Compiled C#, WPF, and Windows/NTFS/SQLite integration remain unverified. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-TEMP-NAME-COLLISION.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-TEMP-NAME-COLLISION.log`.


### 2026-11-14 — Restore journal temp collision cleanup ownership
Fixed a cleanup ownership defect: when exclusive `CreateNew` failed because a journal-temp name already existed, unconditional `finally` cleanup could delete that pre-existing entry. `WriteRestoreJournal` now tracks whether this invocation successfully created the temporary file and only cleans up an owned entry. Added regression tests and source guards. Validation: `pytest -q` — 759 passed; Python unittest — 365 OK. .NET build, WPF runtime, and Windows/NTFS/SQLite integration were not run. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-COLLISION-CLEANUP-OWNERSHIP.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-COLLISION-CLEANUP-OWNERSHIP.log`.


### 2026-11-14 — Restore-journal partial-write cleanup ownership
Added a regression for a disk-write failure after exclusive temporary-file creation. It verifies that an owned partial temp is cleaned and no journal is published; a C# source-order guard checks ownership is set only after `CreateNew` and cleanup remains ownership-gated after write/publication. Test/documentation-only increment. Compiled C#, WPF, and Windows/NTFS/SQLite integration remain unverified. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-PARTIAL-WRITE-CLEANUP-OWNERSHIP.md`.

### 2026-11-14 — Restore-journal published-temp ownership
After `File.Move`/`File.Replace` publishes the completed journal, the writer now marks the former temp pathname as no longer owned. The `finally` cleanup therefore does not remove a different entry created later at that pathname. Failed pre-publication writes still clean up the invocation-owned temp. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-PUBLISHED-TEMP-OWNERSHIP.md` and its test log.


### 2026-11-14 — Restore-journal publication model ownership matrix
The publication test model now mirrors exclusive temporary-file creation and the separate created/published ownership states. A regression covers both initial `Move` and replacement `Replace`, including reuse of the former temporary pathname after publication. No production C# or ERP module changed. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-PUBLICATION-MODEL-OWNERSHIP-MATRIX.md`. Python tests do not replace compiled Windows/NTFS verification.

### 2026-11-15 — Restore-journal publication crash window
Added a crash-window regression for process termination immediately after atomic journal publication via `File.Move` or `File.Replace`, before the in-memory publication flag is set. Both initial publication and replacement cases verify the durable V2 journal contents and SHA-256 checksum remain complete, and the temporary pathname has moved away. Test-only change; no production C# or ERP module changed. Validation: `pytest -q` — 765 passed; Python unittest — 365 OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. No .NET build, WPF runtime, Windows/NTFS, or SQLite integration was run. See `IMPLEMENTATION-2026-11-15-RESTORE-JOURNAL-PUBLICATION-CRASH-WINDOW.md` and `TEST_RESULTS_2026-11-15-RESTORE-JOURNAL-PUBLICATION-CRASH-WINDOW.log`.

### 2026-11-15 — Restore-journal restart recovery after publication

Extended the publication crash-window tests to cover restart consumption of a durable V2 journal. A strict test decoder checks framing, state fields, and SHA-256 before the recovery model runs. New prepared and committed restart cases verify rollback to the previous database or completion of committed cleanup, respectively; a tampered checksum is rejected. Validation: targeted journal suite — 154 passed; `pytest -q` — 768 passed; Python unittest — 365 passed; XML/XAML/project/config parsing — 7 parsed, 0 errors. These are Python model tests and source guards, not execution of compiled C#. `dotnet` was unavailable; .NET build, WPF, Windows/NTFS, and SQLite integration were not run. See `IMPLEMENTATION-2026-11-15-RESTORE-JOURNAL-RESTART-RECOVERY-AFTER-PUBLICATION.md` and `TEST_RESULTS_2026-11-15-RESTORE-JOURNAL-RESTART-RECOVERY-AFTER-PUBLICATION.log`.
