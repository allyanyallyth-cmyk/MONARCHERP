# Restore-journal publication crash window — 2026-11-15

## Change
Added a regression model for process termination immediately after atomic publication of the restore journal (`File.Move` or `File.Replace`) but before the in-memory `publishedTemporary` flag is assigned.

The test exercises both first-time publication and replacement of an existing journal. It verifies that the published journal is complete, its V2 SHA-256 checksum matches its four data fields, and the former temporary pathname is absent. This captures the important process-crash distinction: after the atomic rename/replace has completed, a terminated process does not execute its `finally` block, while the durable journal must remain available to recovery.

## Scope
- Test-only change; no production C# logic, database schema, WPF, installer, or ERP module changed.
- The existing source guard continues to verify that `publishedTemporary` is assigned only after the publication calls.
- No files or modules were removed.

## Validation
- `pytest -q`: 765 passed.
- `python -m unittest discover -s tests -p 'test_*.py'`: 365 tests OK.
- XML/XAML/project/config parsing: 7 parsed, 0 errors.
- No .NET build, WPF runtime, Windows/NTFS integration, or SQLite integration was run. The Python filesystem model is not a substitute for those execution tests.
