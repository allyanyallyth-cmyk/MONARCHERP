# Restore-journal hard-link replacement race — 2026-11-14

## Change

Added a focused filesystem-model regression test for an abandoned restore-journal temp path that was enumerated as a regular file and then replaced with a hard link to a separately retained file before cleanup.

The test verifies that cleanup unlinks only the candidate directory entry: the retained name and exact file bytes survive, and the inode link count decreases by exactly one. A source-structure guard preserves the C# single-entry `File.Delete(path)` contract and rejects metadata preflight or recursive directory deletion in the strict-delete helper.

## Scope

- Tests and documentation only; no production C# logic, database schema, WPF, or ERP module changes.
- The test skips when the host filesystem cannot create hard links.
- This models the replacement ordering in Python; it is not execution of the compiled C# recovery service on Windows/NTFS.

## Validation

See `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-HARDLINK-REPLACEMENT-RACE.log` for exact commands and results.
