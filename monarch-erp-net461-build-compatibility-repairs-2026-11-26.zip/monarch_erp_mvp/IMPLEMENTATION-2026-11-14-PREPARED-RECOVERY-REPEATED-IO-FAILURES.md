# MONARCH ERP — Prepared Recovery Repeated I/O Failure Retry Matrix

Date: 2026-11-14

## Scope

Extended `tests/test_backup_restore_crash_recovery_journal.py` with a parametrized matrix that injects two independent, one-shot filesystem I/O failures during two consecutive prepared-recovery attempts. A third attempt runs without injected failures.

The three sequences span:

1. Live database removal, followed by rollback-WAL move.
2. Rollback database move, followed by rollback-SHM move.
3. Live-WAL removal, followed by rollback-SHM move.

For each sequence, the test verifies that the durable prepared journal remains present after both failures, and that the final retry restores the original database, WAL, and SHM bytes exactly. It also verifies that rollback artifacts are consumed only after successful restoration.

## Production-code impact

No C# production logic, database schema, WPF code, or ERP module was changed. This is an extension of the Python filesystem fault model plus existing source-level checks. It does not establish actual .NET or Windows filesystem behavior.

## Validation

- `pytest -q`: **710 passed**.
- `python -m unittest discover -s tests -p 'test_*.py'`: **365 tests, OK**.
- XML/XAML/project/config parsing: **7 parsed, 0 errors**.
- C# build: **not run** — .NET SDK unavailable.
- WPF runtime and Windows ACL/sharing integration: **not run** — Windows/.NET runtime unavailable.
- SQLite provider integration and real process-kill/power-loss testing: **not run**.

See `TEST_RESULTS_2026-11-14-PREPARED-RECOVERY-REPEATED-IO-FAILURES.log` for the validation record.
