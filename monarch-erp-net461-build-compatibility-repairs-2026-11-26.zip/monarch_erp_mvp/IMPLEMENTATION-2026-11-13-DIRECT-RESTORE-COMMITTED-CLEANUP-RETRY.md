# Direct restore committed-cleanup retry matrix

Extended the direct restore committed-cleanup failure coverage. For each rollback database/WAL/SHM deletion point, the test injects a failure, confirms that the committed journal and verified live database remain intact, then retries cleanup. The retry tolerates artifacts already removed during the first attempt and removes the journal only after all remaining artifacts are gone.

No production C# logic, database schema, ERP module, or WPF code was changed. This is a Python filesystem-model regression matrix plus existing C# source-order assertions; actual Windows/.NET provider and sharing-violation execution remains outstanding.
