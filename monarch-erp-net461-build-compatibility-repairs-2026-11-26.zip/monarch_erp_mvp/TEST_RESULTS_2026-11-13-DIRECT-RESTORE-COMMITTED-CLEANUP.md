# Test results — direct restore committed-cleanup safety

Date: 2026-11-13

## Changes under test

- Direct `RestoreEncryptedBackupCore` path now uses strict deletion for rollback DB, quarantined WAL, quarantined SHM, then the committed journal.
- A cleanup exception after the durable `committed` journal write is rethrown without entering prepared-phase rollback, preserving the verified live database and retry journal.
- Added source-order/commit-boundary checks and a three-point filesystem-model failure matrix; updated the earlier sidecar assertion to require strict cleanup.

## Executed checks

- `pytest -q`: 661 passed.
- `python -m unittest discover -s tests -p 'test_*.py'`: 365 tests passed.
- XML/XAML/project/config parsing: 7 files parsed, 0 errors.

## Not executed

- .NET/C# build and WPF runtime: not run; `dotnet` availability is checked separately.
- Real Microsoft.Data.Sqlite provider integration, Windows ACL/sharing-violation tests, process termination, and power-loss durability: not run.

Python filesystem-model and source-structure tests do not prove the actual C# runtime behavior. Windows validation remains required.
