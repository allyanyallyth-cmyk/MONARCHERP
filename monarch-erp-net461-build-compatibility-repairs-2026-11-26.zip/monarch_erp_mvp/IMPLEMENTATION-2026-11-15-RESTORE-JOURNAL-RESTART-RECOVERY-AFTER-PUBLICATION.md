# Restore Journal Restart Recovery After Publication — 2026-11-15

## Scope

Extended the restore-journal crash-window test coverage from checking that a published V2 journal survives an immediate process termination to checking the modeled restart path that consumes that durable journal.

## Changes

- Added a strict test-only V2 journal decoder that validates the five-line framing, phase and `hadPrevious` values, and SHA-256 checksum before returning recovery inputs.
- Added a prepared-phase restart regression: after a durable prepared journal is present, the recovery model restores the previous database and preserves the journal for the recovery protocol's subsequent completion.
- Added a committed-phase restart regression: the recovery model retains the verified new database and finishes rollback-file cleanup.
- Added a tampered-checksum regression proving the test decoder fails closed.
- Updated README, root ROADMAP, and docs/ROADMAP with the new coverage and its limitations.

## Validation

- `pytest -q`: **768 passed**.
- `python -m unittest discover -s tests -p 'test_*.py'`: **365 tests passed**.
- XML/XAML/project/config parsing: **7 parsed, 0 errors**.
- Targeted restore-journal suite: **154 passed**.

## Limitations

The new restart path is a Python filesystem/recovery model plus existing C# source guards. It does not execute the compiled C# recovery service. `dotnet` is unavailable in this environment; no .NET build, WPF runtime, Windows/NTFS, or SQLite integration test was performed. This is not a release-readiness certification.
