# Restore-journal symlink target-creation race — 2026-11-14

## Scope
Added a regression for a matching GUID-N abandoned journal-temp symbolic link whose target is missing when the entry is enumerated, but is created by another actor before cleanup unlinks the link.

## Expected safety properties
- Cleanup removes only the captured symbolic-link directory entry.
- A target created during the race remains present with its exact contents.
- Cleanup does not resolve or traverse the target before unlinking the link.
- A source-structure guard keeps the C# strict-delete helper on direct single-entry `File.Delete` semantics, without link resolution or recursive directory deletion.

## Change boundary
Tests and documentation only. No production C#, database schema, WPF, installer, or ERP module was changed.

## Validation limits
The filesystem behavior is exercised by the Python model on the current host. The C# assertion inspects source structure only. This does not establish Windows/NTFS reparse-point semantics, compiled C# behavior, WPF runtime behavior, or ACL/sharing-violation behavior. Those remain explicit Windows validation tasks.
