# Restore journal read I/O failure boundary — 2026-11-14

## Change

Extended the restore-recovery regression suite to cover failures while opening/reading the durable restore journal, including access-denied and sharing-violation style `OSError` conditions. The model verifies that the live database, rollback database, quarantined WAL/SHM files, and journal remain byte-for-byte unchanged when the journal cannot be read.

Added a source-structure assertion that `BackupRecoveryService.RecoverInterruptedRestore` performs the strict journal read before any rollback move or committed-artifact deletion, and does not swallow an earlier read exception and continue recovery.

## Scope and limitations

This is test and documentation coverage only. No production C# logic, database schema, ERP module, or WPF UI was modified. The injected Python I/O failures and source inspection do not execute the compiled C# service and are not substitutes for Windows ACL/sharing-mode integration tests.

## Validation

- `pytest -q`: 700 passed.
- `python -m unittest discover -s tests -p 'test_*.py'`: 365 tests passed.
- XML/XAML/project/config parsing: 7 parsed, 0 errors.
- .NET SDK unavailable: no C# build, WPF runtime, or Windows SQLite/filesystem integration test was performed.
