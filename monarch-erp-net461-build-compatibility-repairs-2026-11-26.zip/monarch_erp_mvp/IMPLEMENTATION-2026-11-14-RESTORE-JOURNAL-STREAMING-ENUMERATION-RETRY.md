# Restore-journal streaming enumeration and retry coverage — 2026-11-14

## Scope

Extended the Python restore-journal fault model and C# source-structure guards for startup cleanup of abandoned journal publication temporary files.

## Changes

- Added a lazy-enumeration fault scenario that yields and deletes one abandoned temp, then raises a directory enumeration error before yielding the next entry.
- Verified the partial cleanup is safe: startup aborts, the published journal and live database remain byte-for-byte unchanged, and a subsequent startup pass removes the remaining orphan.
- Added a namespace-isolation case proving cleanup for one database journal does not remove a GUID-N temp belonging to another database journal in the same directory.
- Added a source guard that the C# implementation uses streaming `foreach` enumeration before journal existence/read processing and does not materialize the enumeration into a list.

## Production impact

No production C# code, database schema, WPF code, or ERP module was changed. This increment adds Python fault-model tests and source-structure assertions only. It does not establish real Windows filesystem behavior.
