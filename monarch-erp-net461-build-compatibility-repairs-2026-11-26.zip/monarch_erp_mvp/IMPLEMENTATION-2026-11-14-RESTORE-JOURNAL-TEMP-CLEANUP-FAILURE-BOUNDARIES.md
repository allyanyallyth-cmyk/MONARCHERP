# Restore journal temp-cleanup failure boundaries

Date: 2026-11-14

## Scope

This increment hardens the regression model around abandoned temporary restore-journal files. It does not change production C# logic, journal format, database schema, WPF, or business modules.

## Cases added

1. **Strict temp deletion failure:** simulate a sharing/permission failure while deleting an exact GUID-N abandoned temp. The exception must propagate; the temp and previously published journal remain byte-for-byte intact. A subsequent cleanup retry removes the orphan temp while preserving the published journal.
2. **Directory enumeration failure:** simulate access denial while enumerating the journal directory. Cleanup must stop immediately; the published journal, orphan temp, and live database remain unchanged.
3. **C# source guard:** assert the production cleanup routine enumerates only the top directory, uses strict deletion, and does not swallow enumeration/deletion exceptions.

## Validation

- Focused restore-journal tests: 117 passed.
- Full `pytest -q`: 731 passed.
- `python -m unittest discover -s tests -p 'test_*.py'`: 365 tests OK.
- XML/XAML/project/config parsing: 7 parsed, 0 errors.
- No production C# or WPF code was modified.

## Limitations

These are Python fault-model and C# source-structure checks, not execution of the compiled C# service. .NET build, WPF runtime, Windows ACL/sharing behavior, and Windows SQLite integration were not run because the environment has no `dotnet` SDK or Windows runtime.
