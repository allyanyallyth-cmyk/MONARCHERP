# Direct restore committed journal-removal retry boundary

Extended the direct restore committed-cleanup retry matrix with the final deletion boundary: failure to remove the committed journal after rollback DB/WAL/SHM artifacts have already been deleted.

The regression verifies that:
- the committed journal remains available as the durable retry marker;
- the integrity-approved live database remains byte-for-byte unchanged;
- all rollback artifacts may already be absent when journal deletion fails; and
- a later cleanup attempt is idempotent and removes the journal without requiring rollback artifacts to exist.

No production C# logic, database schema, ERP module, or WPF code changed. This is a Python filesystem-model regression test; it does not execute the compiled recovery service, actual Windows filesystem ACL/sharing semantics, or SQLite provider.
