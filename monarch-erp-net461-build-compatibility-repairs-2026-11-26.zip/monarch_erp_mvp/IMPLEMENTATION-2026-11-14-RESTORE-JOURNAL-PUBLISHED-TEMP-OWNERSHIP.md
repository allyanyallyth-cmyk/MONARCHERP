# Restore journal published-temp ownership — 2026-11-14

## Change
Hardened `WriteRestoreJournal` cleanup ownership across successful atomic publication. Once `File.Replace` or `File.Move` publishes the completed journal, the former temporary pathname is no longer owned by this invocation. A `publishedTemporary` state now prevents the `finally` block from deleting a new, unrelated entry that may later appear at that pathname. Failed writes/publications still clean up the invocation-owned temporary entry.

## Regression coverage
- Model atomic movement of the completed temp into the journal path, followed by another actor creating a new entry at the old temp pathname; verify cleanup preserves that unrelated entry.
- Guard the C# writer for explicit publication state and cleanup gated by both creation ownership and non-publication.

## Scope and validation limits
This increment changes the C# restore-journal writer, one Python regression-test file, and project documentation. Python filesystem modeling and source guards do not replace compiled C# execution. No .NET build, WPF runtime, or Windows/NTFS/SQLite integration was run.
