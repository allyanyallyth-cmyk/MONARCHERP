# MONARCH ERP — First-Restore Sidecar Retry Matrix

Date: 2026-11-14

## Scope

Extended the first-time restore (`hadPrevious == false`) recovery fault model after the unverified live database has been removed strictly. The durable `prepared` journal must remain available until both quarantined SQLite sidecars have been restored.

## Coverage added

Four one-shot I/O failure points are exercised independently:

1. Removal of the unverified live WAL sidecar.
2. Move of the quarantined prior WAL sidecar into the live path.
3. Removal of the unverified live SHM sidecar.
4. Move of the quarantined prior SHM sidecar into the live path.

Each case verifies that the already-completed strict removal of the unverified main database is not mistaken for transaction completion, that the prepared journal remains byte-for-byte present after the sidecar failure, and that a subsequent recovery attempt restores the original WAL and SHM bytes exactly. A source-order assertion verifies that C# first-restore recovery restores WAL, then SHM, and only then attempts journal removal.

## Production changes

No C# production logic, schema, ERP module, or WPF behavior changed. This increment adds Python filesystem fault-model coverage and source-order verification only.

## Validation

See `TEST_RESULTS_2026-11-14-FIRST-RESTORE-SIDECAR-RETRY-MATRIX.log` for exact commands and outcomes. These model/structural checks do not replace compiled C# execution on Windows.
