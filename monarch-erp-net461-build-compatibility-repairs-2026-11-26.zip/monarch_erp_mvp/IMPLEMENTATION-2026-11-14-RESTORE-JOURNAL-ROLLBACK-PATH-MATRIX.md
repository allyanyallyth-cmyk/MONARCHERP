# Implementation record — 2026-11-14

## Restore journal rollback-path reference matrix

Extended `tests/test_backup_restore_crash_recovery_journal.py` with a filesystem-path validation model matching the C# recovery contract:

- Normalize both database and rollback paths to absolute paths.
- Require the rollback file's parent directory to equal the live database parent directory (case-insensitive comparison, matching the C# `OrdinalIgnoreCase` contract).
- Require the exact live database filename plus `.pre-restore-` and a 32-character GUID `N` token.
- Reject sibling/nested directories, mismatched database names, extra suffixes, braced/hyphenated GUIDs, and non-hexadecimal tokens.
- Accept a valid same-directory reference after `..` path normalization.
- Assert the C# source retains `Path.GetFullPath`, same-parent comparison, and `Guid.TryParseExact(..., "N", ...)` validation.

This increment modifies tests and documentation only. No production C# logic, schema, ERP module, or WPF behavior was changed. The Python model and source assertions do not substitute for execution against the compiled service on Windows.
