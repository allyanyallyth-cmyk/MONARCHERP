# Restore-journal temporary-name boundary coverage — 2026-11-14

## Scope

Extended the Python recovery fault-model tests for abandoned restore-journal publication temporary files. The cleanup model now mirrors the production `Directory.EnumerateFiles` behavior by considering file entries, rather than directories, and adds regression cases for:

- malformed GUID-N suffixes (invalid hexadecimal, too short, and too long) being preserved;
- uppercase hexadecimal GUID-N suffixes being accepted and cleaned;
- directory entries matching the temporary-name shape being left untouched, including their contents;
- similarly prefixed but non-exact temporary names being preserved.

The production C# implementation, database schema, WPF UI, and ERP modules were not modified. This increment adds Python model coverage and documentation only. It does not establish compiled C# or Windows filesystem behavior.

## Validation

- `pytest -q`: 737 passed.
- `python -m unittest discover -s tests -p 'test_*.py'`: 365 tests OK.
- XML/XAML/project/config parsing: 7 parsed, 0 errors.
- C#/.NET build, WPF runtime, and Windows filesystem/SQLite integration: not run; the required .NET/Windows toolchain is unavailable in this environment.
