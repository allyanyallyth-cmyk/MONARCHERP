# MONARCH ERP implementation record — 2026-11-13
## Strict committed cleanup: do not hide access failures behind File.Exists

### Defect addressed
The strict deletion helper used `File.Exists(path)` before `File.Delete(path)`. On .NET, `File.Exists` can return `false` when an error occurs while checking a path, including access-related failures. Treating that result as proof that the file is absent could allow committed recovery to proceed to journal deletion while a rollback artifact remained.

### Change
- Changed `DeleteIfExistsStrict` to call `File.Delete(path)` directly.
- A missing file remains an idempotent no-op under the .NET `File.Delete` contract.
- I/O, sharing, and authorization failures are allowed to propagate, stopping cleanup before the journal is deleted.
- Added failure-injection coverage at each of the rollback DB, WAL, and SHM deletion positions, plus a structural assertion that the strict helper does not gate on `File.Exists`.

### Scope
- Modified: `src/Monarch.Core/Backup/BackupRecoveryService.cs`.
- Modified: `tests/test_backup_restore_crash_recovery_journal.py`.
- Updated: `README.md`, `ROADMAP.md`.
- No database schema, ERP module, or WPF behavior changed. No prior project files were intentionally removed.

### Validation
- `pytest -q`: 657 passed.
- `python -m unittest discover -s tests -p 'test_*.py'`: 365 tests OK.
- XML/XAML/project/config parse: 7 parsed, 0 errors.
- The Python tests model failures and assert source structure; they do not execute the compiled C# service or prove Windows filesystem semantics.
- .NET SDK unavailable; no C# build, WPF runtime test, Windows ACL/sharing-violation integration, or real SQLite crash/restart test was run.
