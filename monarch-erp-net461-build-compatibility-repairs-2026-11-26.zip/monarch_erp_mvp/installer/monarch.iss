#ifndef AppVersion
  #define AppVersion "0.1.0"
#endif
#ifndef RepoRoot
  #define RepoRoot ".."
#endif

[Setup]
AppId={{8B46D7D3-37E7-4E4B-9E34-7F6E5D92A7C1}
AppName=MONARCH ERP
AppVersion={#AppVersion}
AppPublisher=MONARCH
DefaultDirName={autopf}\MONARCH ERP
DefaultGroupName=MONARCH ERP
OutputDir={#RepoRoot}\artifacts\release
OutputBaseFilename=monarch-erp-{#AppVersion}-setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64
UninstallDisplayIcon={app}\MONARCH\Monarch.Desktop.exe
DisableProgramGroupPage=yes

[Languages]
Name: "arabic"; MessagesFile: "compiler:Languages\Arabic.isl"

[Tasks]
Name: "desktopicon"; Description: "إنشاء اختصار على سطح المكتب"; GroupDescription: "اختصارات إضافية:"; Flags: unchecked

[Files]
Source: "{#RepoRoot}\artifacts\desktop-net461\*"; DestDir: "{app}\MONARCH"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#RepoRoot}\artifacts\recovery-net461\*"; DestDir: "{app}\Recovery"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#RepoRoot}\tools\*"; DestDir: "{app}\MigrationTools"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#RepoRoot}\database\*"; DestDir: "{app}\DatabaseSchemas"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#RepoRoot}\README.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#RepoRoot}\docs\SECURITY.md"; DestDir: "{app}"; DestName: "SECURITY.md"; Flags: ignoreversion

[Icons]
Name: "{group}\MONARCH ERP"; Filename: "{app}\MONARCH\Monarch.Desktop.exe"; WorkingDir: "{app}\MONARCH"
Name: "{autodesktop}\MONARCH ERP"; Filename: "{app}\MONARCH\Monarch.Desktop.exe"; WorkingDir: "{app}\MONARCH"; Tasks: desktopicon
Name: "{group}\أداة استعادة MONARCH"; Filename: "{app}\Recovery\Monarch.Recovery.exe"; WorkingDir: "{app}\Recovery"

[Run]
Filename: "{app}\MONARCH\Monarch.Desktop.exe"; Description: "تشغيل MONARCH ERP"; Flags: postinstall nowait skipifsilent

[Code]
function IsNet461OrLaterInstalled: Boolean;
var
  ReleaseValue: Cardinal;
begin
  Result := RegQueryDWordValue(HKLM,
    'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full', 'Release', ReleaseValue)
    and (ReleaseValue >= 394254);
end;

function InitializeSetup: Boolean;
begin
  Result := IsNet461OrLaterInstalled;
  if not Result then
    MsgBox('يتطلب MONARCH ERP تثبيت .NET Framework 4.6.1 أو أحدث. ثبّت المتطلب ثم أعد تشغيل المثبت.',
      mbCriticalError, MB_OK);
end;
