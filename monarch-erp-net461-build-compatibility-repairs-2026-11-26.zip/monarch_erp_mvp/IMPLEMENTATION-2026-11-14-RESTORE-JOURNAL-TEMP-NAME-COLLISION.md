# Restore-journal temporary-name collision safety (2026-11-14)

Added a regression proving that an unexpected pre-existing journal-temp entry is not overwritten when exclusive creation encounters a name collision. The existing entry's bytes remain intact and no journal is published. A C# source guard verifies `FileMode.CreateNew` with exclusive sharing and rejects truncating `FileMode.Create` in the journal writer.

This is a Python filesystem-model test and source-structure assertion only. No production C#, schema, WPF, or ERP module changed; compiled C# and Windows filesystem behavior remain unverified.
