# Restore journal collision cleanup ownership guard — 2026-11-14

## Finding
`WriteRestoreJournal` used `FileMode.CreateNew`, correctly refusing an existing temporary-name collision, but its unconditional `finally { TryDelete(temporary); }` could then delete the pre-existing entry even though this invocation had not created it.

## Change
Track ownership with `createdTemporary`. Set it only after the exclusive `FileStream` constructor succeeds, and run best-effort cleanup only when this invocation owns the temporary file. The atomic `File.Move`/`File.Replace` publication and durable flush remain unchanged.

## Scope
Production change is limited to temporary-file ownership cleanup in `BackupRecoveryService.WriteRestoreJournal`. Added regression coverage for collision preservation and a C# source guard; updated the existing publication guard to require ownership-aware cleanup. No database schema, WPF, or ERP module changes.

## Validation
- `pytest -q`: 759 passed.
- `python -m unittest discover -s tests -p 'test_*.py'`: 365 tests OK.
- XML/XAML/project/config parsing: recorded separately in the accompanying test log.
- .NET build, WPF runtime, and Windows/NTFS/SQLite integration were not run in this environment.
