# Implementation Record — Restore Journal V2 Corruption Matrix

**Date:** 2026-11-13  
**Baseline:** `monarch-erp-direct-restore-journal-removal-retry.zip`  
**Scope:** Test and documentation hardening only.

## Change

Expanded `tests/test_backup_restore_crash_recovery_journal.py` to exercise tampering in each of the five V2 journal lines: version marker, rollback path, prior-database flag, phase, and checksum. Added digest framing cases for empty, 63-character, 65-character, and non-hexadecimal values, and verified uppercase hexadecimal SHA-256 remains accepted. Added source-level assertions for the C# validator's 64-character digest constraint, hexadecimal validation, and full-length XOR comparison.

No production C# source, database schema, WPF view, or ERP module was changed.

## Validation performed

- `pytest -q`: **672 passed**.
- `python -m unittest discover -s tests -p 'test_*.py'`: **365 tests passed**.
- XML/XAML/project/config parsing: **7 parsed, 0 errors**.
- .NET SDK was unavailable. No C# build, WPF runtime, compiled SQLite-provider integration, Windows ACL/sharing-violation test, or process/power-loss test was performed.

## Cumulative integrity

The package was derived directly from the 494-file journal-removal-retry baseline. Final archive manifest comparison is recorded in the delivery response and was generated from the two ZIP manifests. No baseline files were deleted.
