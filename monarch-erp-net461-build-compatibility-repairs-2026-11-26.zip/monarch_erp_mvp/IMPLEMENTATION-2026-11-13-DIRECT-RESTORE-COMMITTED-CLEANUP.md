# Implementation report — direct restore committed-cleanup safety

## Problem

The startup recovery path already used strict deletion for committed rollback artifacts, but the direct successful-restore path still used best-effort `TryDelete`. Its encompassing catch block also treated cleanup exceptions like pre-commit restore failures and could attempt to roll back after the new database had been durably committed.

## Implementation

- Added an explicit `restoreCommitted` boundary, set only after the committed journal write succeeds.
- Replaced best-effort cleanup of rollback DB/WAL/SHM and the journal with strict, ordered deletion.
- If cleanup fails after commit, the exception now exits without executing prepared-phase rollback or deleting the committed journal. The verified live database remains authoritative and startup recovery can retry cleanup.
- Prepared-phase failures continue through the existing rollback path.
- Updated the structural regression assertion and added a three-point filesystem-model failure matrix.

## Scope

Changed C# production code only in `Monarch.Core/Backup/BackupRecoveryService.cs`; updated Python tests, `README.md`, `ROADMAP.md`, and added this report and its test record. No database schema, ERP module, or WPF UI was changed.

## Validation

- pytest: 661 passed.
- unittest: 365 passed.
- XML/XAML/project/config parse: 7 parsed, 0 errors.
- .NET SDK unavailable; C# build, WPF runtime, real SQLite-provider integration, and Windows filesystem/crash tests were not run.
