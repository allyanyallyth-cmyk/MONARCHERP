# Abandoned restore-journal temporary cleanup — 2026-11-14

## Problem

`WriteRestoreJournal` writes and flushes a uniquely named temporary file before atomically publishing it as the durable `.restore-journal`. A process termination between the flush and the final `File.Move`/`File.Replace` can leave an orphan temporary file. The temporary file is not authoritative: restore mutations are started only after the prepared journal has been published. Previously, startup recovery did not sweep these abandoned files.

## Change

- Startup recovery now invokes `CleanupAbandonedRestoreJournalTemps` while holding the existing per-database operation mutex and before checking/reading the published journal.
- The cleanup enumerates only files matching the exact journal basename plus `.tmp-*` in the database directory.
- It deletes only candidates whose suffix is exactly 32 hexadecimal characters and parses as GUID format `N`.
- Deletion is strict. An access/sharing failure propagates and blocks further database work instead of silently leaving ambiguous cleanup state.
- Malformed names and unrelated files are not deleted.
- The durable published journal is never treated as a temporary file.

## Validation scope

Python regression tests model abandoned-temp cleanup, preserve a published prepared journal, and ensure malformed temp names are retained. A source-structure test checks that C# cleanup runs before journal existence/read handling and validates the exact GUID-N filter and strict deletion call.

This does not constitute execution of the compiled C# service. .NET SDK was unavailable; no C# build, WPF runtime, Windows ACL/sharing test, or SQLite integration test was performed.
