# Restore-journal publication ownership model matrix
Date: 2026-11-14

## Scope

Corrected the Python publication model so it mirrors the production writer's ownership transitions instead of unconditionally deleting any entry found at the former temporary pathname in `finally`.

## Changes

- The model now creates the temp entry exclusively (`xb`) and records ownership only after successful creation.
- It records successful atomic `move`/`replace` publication separately.
- Cleanup is limited to an entry still owned before publication; a path reused after publication is not deleted.
- Added a two-mode regression covering both initial `Move` and replacement `Replace`: each mode publishes the journal, then creates an unrelated entry at the old temp pathname and verifies that the entry survives.
- Existing publication-failure and cleanup-failure cases continue to exercise pre-publication cleanup and startup retry behavior.
- No production C# logic, database schema, WPF UI, or ERP business module was changed.

## Validation

- `pytest -q`: 764 passed.
- `python -m unittest discover -s tests -p 'test_*.py'`: 365 tests, OK.
- XML/XAML/project/config parsing: 7 parsed, 0 errors.
- ZIP integrity: verified after packaging.

Python filesystem models and C# source guards are not compiled C# or platform integration tests. `dotnet` is unavailable in this environment; WPF runtime and Windows/NTFS/SQLite integration were not run.
