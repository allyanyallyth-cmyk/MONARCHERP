#!/usr/bin/env python3
"""Decrypt and integrity-check a MONARCH pre-migration AES-GCM backup."""
import argparse, getpass, hashlib, os, sqlite3, sys
from pathlib import Path
from migrate_legacy_ledger import BACKUP_MAGIC

def main():
    p=argparse.ArgumentParser(); p.add_argument('--input',required=True); p.add_argument('--output',required=True); p.add_argument('--passphrase',default=os.environ.get('MONARCH_BACKUP_PASSPHRASE')); a=p.parse_args()
    if not a.passphrase: a.passphrase=getpass.getpass('Backup passphrase: ')
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        blob=Path(a.input).read_bytes()
        if not blob.startswith(BACKUP_MAGIC) or len(blob)<len(BACKUP_MAGIC)+28: raise ValueError('Unknown or truncated backup format')
        off=len(BACKUP_MAGIC); salt=blob[off:off+16]; nonce=blob[off+16:off+28]; encrypted=blob[off+28:]
        key=hashlib.pbkdf2_hmac('sha256',a.passphrase.encode(),salt,600_000,32)
        raw=AESGCM(key).decrypt(nonce,encrypted,BACKUP_MAGIC)
        out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True)
        if out.exists(): raise ValueError(f'Refusing to overwrite existing output: {out}')
        out.write_bytes(raw)
        c=sqlite3.connect(str(out)); result=c.execute('PRAGMA integrity_check').fetchone()[0]; c.close()
        if result!='ok': out.unlink(missing_ok=True); raise ValueError('Decrypted database failed SQLite integrity_check')
        print(f'Restored verified SQLite backup: {out} ({len(raw)} bytes)')
    except Exception as e:
        print(f'BACKUP DECRYPTION FAILED: {e}',file=sys.stderr); return 2
    return 0
if __name__=='__main__': raise SystemExit(main())
