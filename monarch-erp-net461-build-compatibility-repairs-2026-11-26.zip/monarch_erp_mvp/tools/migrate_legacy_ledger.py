#!/usr/bin/env python3
"""Safe, explicit, one-time migration from legacy ledger tables to tenant tables.

Requires Python 3.10+ and `cryptography` for encrypted pre-migration backups.
The source legacy tables are never modified or dropped.
"""
from __future__ import annotations
import argparse, getpass, hashlib, json, os, secrets, sqlite3, sys, tempfile, uuid
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

MIGRATION_ID = "legacy-ledger-to-tenant-v1"
BACKUP_MAGIC = b"MONARCH-ENC-BACKUP-1\0"


def connect(path: Path) -> sqlite3.Connection:
    c = sqlite3.connect(str(path), timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA busy_timeout=30000")
    return c


def table_exists(c, name):
    return c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone() is not None


def encrypted_backup(c: sqlite3.Connection, destination: Path, passphrase: str) -> dict:
    if len(passphrase) < 12: raise RuntimeError("Backup passphrase must contain at least 12 characters")
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError as e:
        raise RuntimeError("Encrypted backup requires: python -m pip install -r tools/requirements.txt") from e
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists(): raise RuntimeError(f"Backup destination already exists; refusing overwrite: {destination}")
    fd, tmp_name = tempfile.mkstemp(prefix="monarch-pre-migration-", suffix=".sqlite", dir=str(destination.parent))
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        with closing(sqlite3.connect(str(tmp))) as target:
            c.backup(target)
        raw = tmp.read_bytes()
        salt, nonce = secrets.token_bytes(16), secrets.token_bytes(12)
        key = hashlib.pbkdf2_hmac("sha256", passphrase.encode("utf-8"), salt, 600_000, dklen=32)
        ciphertext = AESGCM(key).encrypt(nonce, raw, BACKUP_MAGIC)
        payload = BACKUP_MAGIC + salt + nonce + ciphertext
        destination.write_bytes(payload)
        try: os.chmod(destination, 0o600)
        except OSError: pass
        return {"path": str(destination), "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest(), "algorithm": "AES-256-GCM", "kdf": "PBKDF2-HMAC-SHA256/600000"}
    finally:
        try: tmp.unlink()
        except FileNotFoundError: pass


def inspect(c, company_id, branch_id):
    integrity = c.execute("PRAGMA integrity_check").fetchone()[0]
    if integrity != "ok": raise RuntimeError(f"SQLite integrity_check failed: {integrity}")
    foreign_key_errors = c.execute("PRAGMA foreign_key_check").fetchall()
    if foreign_key_errors: raise RuntimeError(f"SQLite foreign_key_check found {len(foreign_key_errors)} violation(s)")
    required = ["monarch_currencies", "monarch_company_settings", "monarch_accounts", "monarch_journals", "monarch_journal_lines", "monarch_companies", "monarch_branches", "monarch_tenant_accounts", "monarch_tenant_journals", "monarch_tenant_journal_lines"]
    missing = [t for t in required if not table_exists(c, t)]
    if missing: raise RuntimeError("Missing required schema tables: " + ", ".join(missing))
    company = c.execute("SELECT * FROM monarch_companies WHERE id=? AND is_active=1", (company_id,)).fetchone()
    branch = c.execute("SELECT * FROM monarch_branches WHERE id=? AND company_id=? AND is_active=1", (branch_id, company_id)).fetchone()
    if not company: raise RuntimeError("Target company is missing or inactive")
    if not branch: raise RuntimeError("Target branch is missing, inactive, or belongs to another company")
    legacy_currency = c.execute("SELECT base_currency_code FROM monarch_company_settings WHERE id=1").fetchone()
    if not legacy_currency: raise RuntimeError("Legacy base currency is not configured")
    if legacy_currency[0] != company["base_currency_code"]:
        raise RuntimeError(f"Currency mismatch: legacy={legacy_currency[0]}, target={company['base_currency_code']}; automatic conversion is forbidden")
    exp = c.execute("SELECT minor_unit_exponent FROM monarch_currencies WHERE code=? AND is_active=1", (legacy_currency[0],)).fetchone()
    if not exp: raise RuntimeError("Legacy currency exponent is missing or inactive")
    accounts = c.execute("SELECT * FROM monarch_accounts ORDER BY code").fetchall()
    journals = c.execute("SELECT * FROM monarch_journals ORDER BY business_date,number").fetchall()
    lines = c.execute("SELECT l.* FROM monarch_journal_lines l JOIN monarch_journals j ON j.id=l.journal_id ORDER BY j.id,l.id").fetchall()
    if c.execute("SELECT COUNT(*) FROM monarch_tenant_accounts WHERE company_id=?", (company_id,)).fetchone()[0] or c.execute("SELECT COUNT(*) FROM monarch_tenant_journals WHERE company_id=?", (company_id,)).fetchone()[0]:
        raise RuntimeError("Target company already contains tenant ledger data; refusing merge")
    account_ids = {r["id"] for r in accounts}
    journal_ids = {r["id"] for r in journals}
    errors=[]
    for entity_type, identifiers in (("account", account_ids), ("journal", journal_ids)):
        for identifier in identifiers:
            try: uuid.UUID(identifier)
            except (ValueError, TypeError, AttributeError): errors.append(f"Legacy {entity_type} ID is not a GUID: {identifier}")
    if errors: raise RuntimeError("Dry-run validation failed: " + "; ".join(errors))
    for account_id in account_ids:
        if c.execute("SELECT 1 FROM monarch_tenant_accounts WHERE id=?", (account_id,)).fetchone():
            raise RuntimeError("Legacy account ID collides with an existing tenant account in another company")
    for journal_id in journal_ids:
        if c.execute("SELECT 1 FROM monarch_tenant_journals WHERE id=?", (journal_id,)).fetchone():
            raise RuntimeError("Legacy journal ID collides with an existing tenant journal in another company")
    for j in journals:
        if j["reversal_of_id"] and j["reversal_of_id"] not in journal_ids: errors.append(f"Journal {j['id']} references missing reversal target")
        if j["status"] not in ("Draft", "Posted", "Reversed"): errors.append(f"Journal {j['id']} has unsupported status")
        if j["status"] == "Reversed" and not any(x["reversal_of_id"] == j["id"] and x["status"] == "Posted" for x in journals): errors.append(f"Reversed journal {j['id']} has no posted inverse")
    for l in lines:
        if l["account_id"] not in account_ids: errors.append(f"Line {l['id']} references missing account")
        if l["debit_minor"] < 0 or l["credit_minor"] < 0 or ((l["debit_minor"] > 0) == (l["credit_minor"] > 0)): errors.append(f"Line {l['id']} has invalid debit/credit")
    line_by_journal={j["id"]:[] for j in journals}
    for l in lines: line_by_journal[l["journal_id"]].append(l)
    for j in journals:
        ls=line_by_journal[j["id"]]
        if j["status"] in ("Posted", "Reversed"):
            if len(ls)<2 or sum(x["debit_minor"] for x in ls)!=sum(x["credit_minor"] for x in ls): errors.append(f"Posted journal {j['id']} is not balanced")
    # A reversal must exactly invert the referenced entry, by account.
    by_id={j["id"]:j for j in journals}
    for j in journals:
        if j["reversal_of_id"]:
            orig=by_id[j["reversal_of_id"]]
            def sums(jid):
                d={}
                for x in line_by_journal[jid]:
                    a=d.setdefault(x["account_id"],[0,0]); a[0]+=x["debit_minor"]; a[1]+=x["credit_minor"]
                return d
            a,b=sums(j["id"]),sums(orig["id"])
            for aid in set(a)|set(b):
                x,y=a.get(aid,[0,0]),b.get(aid,[0,0])
                if x != [y[1],y[0]]: errors.append(f"Reversal {j['id']} does not exactly invert {orig['id']} by account"); break
    # Account balances for all posted and not subsequently reversed journals.
    legacy_bal={r[0]:(r[1] or 0,r[2] or 0) for r in c.execute("""SELECT l.account_id,SUM(l.debit_minor),SUM(l.credit_minor)
        FROM monarch_journal_lines l JOIN monarch_journals j ON j.id=l.journal_id WHERE j.status='Posted' GROUP BY l.account_id""")}
    return {"company":dict(company),"branch":dict(branch),"currency":legacy_currency[0],"currency_exponent":exp[0],"accounts":accounts,"journals":journals,"lines":lines,"line_by_journal":line_by_journal,"errors":errors,"legacy_balances":legacy_bal,
            "counts":{"accounts":len(accounts),"journals":len(journals),"lines":len(lines)},"debit_minor":sum(x["debit_minor"] for x in lines if by_id_status(journals,x["journal_id"]) in ("Posted","Reversed")),"credit_minor":sum(x["credit_minor"] for x in lines if by_id_status(journals,x["journal_id"]) in ("Posted","Reversed"))}


def by_id_status(journals, jid):
    for j in journals:
        if j["id"]==jid: return j["status"]
    return None


def run(args):
    db=Path(args.database).resolve()
    if not db.is_file(): raise RuntimeError(f"Database does not exist: {db}")
    c=connect(db)
    try:
        if table_exists(c, "monarch_migration_history") and c.execute("SELECT 1 FROM monarch_migration_history WHERE migration_id=?", (MIGRATION_ID,)).fetchone():
            raise RuntimeError("Migration already completed; refusing duplicate import")
        info=inspect(c,args.company_id,args.branch_id)
        report={"migration_id":MIGRATION_ID,"mode":"dry-run" if args.dry_run else "import","generated_utc":datetime.now(timezone.utc).isoformat(),"database":str(db),"target_company_id":args.company_id,"target_branch_id":args.branch_id,"currency":info["currency"],"currency_exponent":info["currency_exponent"],"counts":info["counts"],"posted_and_reversed_minor_totals":{"debit":info["debit_minor"],"credit":info["credit_minor"]},"validation_errors":info["errors"],"legacy_tables_preserved":True}
        if info["errors"]: raise RuntimeError("Dry-run validation failed: " + "; ".join(info["errors"]))
        if args.dry_run:
            write_report(report,args.report); return report
        if not args.backup_passphrase: raise RuntimeError("--backup-passphrase or MONARCH_BACKUP_PASSPHRASE is required for encrypted pre-migration backup")
        backup_path=Path(args.backup or (str(db)+".pre-tenant-migration.monarchbak")).resolve()
        report["encrypted_backup"]=encrypted_backup(c,backup_path,args.backup_passphrase)
        c.execute("BEGIN IMMEDIATE")
        c.execute("CREATE TABLE IF NOT EXISTS monarch_migration_history (migration_id TEXT PRIMARY KEY, company_id TEXT NOT NULL, branch_id TEXT NOT NULL, completed_utc TEXT NOT NULL, report_json TEXT NOT NULL)")
        if c.execute("SELECT 1 FROM monarch_migration_history WHERE migration_id=?",(MIGRATION_ID,)).fetchone(): raise RuntimeError("Migration already completed; refusing duplicate import")
        for a in info["accounts"]:
            c.execute("INSERT INTO monarch_tenant_accounts(id,company_id,code,name,account_type,is_active,created_utc) VALUES(?,?,?,?,?,?,?)",(a["id"],args.company_id,a["code"],a["name"],a["account_type"],a["is_active"],datetime.now(timezone.utc).isoformat()))
        pending={j["id"]:j for j in info["journals"]}
        done=set()
        # Repeatedly import journals whose reversal target is already posted in tenant ledger.
        while pending:
            progressed=False
            for jid,j in list(pending.items()):
                target=j["reversal_of_id"]
                if target and c.execute("SELECT 1 FROM monarch_tenant_journals WHERE company_id=? AND id=? AND status='Posted'",(args.company_id,target)).fetchone() is None: continue
                c.execute("INSERT INTO monarch_tenant_journals(id,company_id,branch_id,number,business_date,description,status,reversal_of_id,posted_at_utc,created_utc) VALUES(?,?,?,?,?,?,'Draft',?,?,?)",(j["id"],args.company_id,args.branch_id,j["number"],j["business_date"],j["description"],target,j["posted_at_utc"],j["created_utc"]))
                for l in info["line_by_journal"][jid]: c.execute("INSERT INTO monarch_tenant_journal_lines(company_id,journal_id,account_id,debit_minor,credit_minor) VALUES(?,?,?,?,?)",(args.company_id,jid,l["account_id"],l["debit_minor"],l["credit_minor"]))
                if j["status"] in ("Posted","Reversed"):
                    c.execute("UPDATE monarch_tenant_journals SET status='Posted' WHERE company_id=? AND id=?",(args.company_id,jid))
                done.add(jid); del pending[jid]; progressed=True
            if not progressed: raise RuntimeError("Cannot resolve reversal dependency chain; cycle, missing target, or invalid status")
        # Legacy Reversed marks the original entry; its posted inverse is the child row.
        for j in info["journals"]:
            if j["status"] == "Reversed":
                inverse = c.execute("SELECT 1 FROM monarch_tenant_journals WHERE company_id=? AND reversal_of_id=? AND status='Posted'",(args.company_id,j["id"])).fetchone()
                if not inverse: raise RuntimeError(f"Legacy journal {j['id']} is Reversed but has no posted inverse")
                c.execute("UPDATE monarch_tenant_journals SET status='Reversed' WHERE company_id=? AND id=? AND status='Posted'",(args.company_id,j["id"]))
        # Verify exact counts and per-account posted balances.
        got={"accounts":c.execute("SELECT COUNT(*) FROM monarch_tenant_accounts WHERE company_id=?",(args.company_id,)).fetchone()[0],"journals":c.execute("SELECT COUNT(*) FROM monarch_tenant_journals WHERE company_id=?",(args.company_id,)).fetchone()[0],"lines":c.execute("SELECT COUNT(*) FROM monarch_tenant_journal_lines WHERE company_id=?",(args.company_id,)).fetchone()[0]}
        if got != info["counts"]: raise RuntimeError(f"Count mismatch: expected {info['counts']}, got {got}")
        for source in info["journals"]:
            target = c.execute("SELECT status,branch_id FROM monarch_tenant_journals WHERE company_id=? AND id=?",(args.company_id,source["id"])).fetchone()
            expected_status = source["status"]
            if target is None or target["status"] != expected_status or target["branch_id"] != args.branch_id:
                raise RuntimeError(f"Journal header verification mismatch: {source['id']}")
            source_total = (sum(x["debit_minor"] for x in info["line_by_journal"][source["id"]]), sum(x["credit_minor"] for x in info["line_by_journal"][source["id"]]))
            target_total = c.execute("SELECT COALESCE(SUM(debit_minor),0),COALESCE(SUM(credit_minor),0) FROM monarch_tenant_journal_lines WHERE company_id=? AND journal_id=?",(args.company_id,source["id"])).fetchone()
            if source_total != (target_total[0],target_total[1]): raise RuntimeError(f"Journal line totals mismatch: {source['id']}")
        tenant_bal={r[0]:(r[1] or 0,r[2] or 0) for r in c.execute("""SELECT l.account_id,SUM(l.debit_minor),SUM(l.credit_minor) FROM monarch_tenant_journal_lines l JOIN monarch_tenant_journals j ON j.company_id=l.company_id AND j.id=l.journal_id WHERE l.company_id=? AND j.status='Posted' GROUP BY l.account_id""",(args.company_id,))}
        # Legacy rows marked Reversed are not part of posted balance; target original changes to Reversed in tenant too.
        legacy_effective={}
        for aid in {a["id"] for a in info["accounts"]}:
            d=cr=0
            for j in info["journals"]:
                if j["status"]=="Posted":
                    for l in info["line_by_journal"][j["id"]]:
                        if l["account_id"]==aid: d+=l["debit_minor"]; cr+=l["credit_minor"]
            legacy_effective[aid]=(d,cr)
        if tenant_bal != {k:v for k,v in legacy_effective.items() if v!=(0,0)}: raise RuntimeError("Post-migration per-account balance mismatch")
        report["imported_counts"]=got
        report["verification"]={"counts_match":True,"per_journal_totals_and_status_match":True,"per_account_posted_balances_match":True,"sqlite_integrity_check":"ok","legacy_tables_preserved":True}
        c.execute("INSERT INTO monarch_migration_history(migration_id,company_id,branch_id,completed_utc,report_json) VALUES(?,?,?,?,?)",(MIGRATION_ID,args.company_id,args.branch_id,datetime.now(timezone.utc).isoformat(),json.dumps(report,ensure_ascii=False,sort_keys=True)))
        c.commit()
        report["mode"]="import-complete"
        write_report(report,args.report)
        return report
    except Exception:
        if c.in_transaction: c.rollback()
        raise
    finally: c.close()


def write_report(report,path):
    if path:
        p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str)+"\n",encoding="utf-8")


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--database",required=True)
    p.add_argument("--company-id",required=True)
    p.add_argument("--branch-id",required=True)
    p.add_argument("--dry-run",action="store_true",help="Validate and write a report without modifying the database")
    p.add_argument("--backup")
    p.add_argument("--backup-passphrase",default=os.environ.get("MONARCH_BACKUP_PASSPHRASE"))
    p.add_argument("--report",default="migration-report.json")
    a=p.parse_args()
    if not a.dry_run and not a.backup_passphrase:
        a.backup_passphrase = getpass.getpass("Encrypted backup passphrase (12+ characters): ")
        if a.backup_passphrase != getpass.getpass("Confirm passphrase: "):
            print("MIGRATION FAILED: passphrases do not match", file=sys.stderr); return 2
    try:
        r=run(a); print(json.dumps(r,ensure_ascii=False,indent=2,default=str)); return 0
    except Exception as e:
        print(f"MIGRATION FAILED: {e}",file=sys.stderr); return 2

if __name__=="__main__": raise SystemExit(main())
