# MONARCH ERP — .NET Framework build-compatibility repair

Date: 2026-11-26

## Source baseline

- Input archive: `monarch-erp-restore-journal-restart-recovery-after-publication.zip`
- Baseline file count: 558
- Baseline SHA-256: `b30adea8ad52a465a50befb7a407a4a65710f0678195db3dc68bb4fa1f6bedf6`
- Archive integrity: ZIP CRC validation passed; no unsafe member paths found.

## Defects addressed in source

The GitHub Actions Windows build log for run `45584518806` (job `139102600522`) reported 39 compiler-error instances, including repeated diagnostics for multi-target builds. The underlying compatibility defects addressed in this source update are:

1. Replaced generic `Enum.Parse<T>(...)` calls with the framework-compatible `Enum.Parse(typeof(T), ...)` form and explicit casts.
2. Added `DateOnly.ToString(string)` and `DateOnly.FromDateTime(DateTime)` support to the `NET461` compatibility shim; also added a current-culture parameterless `ToString()` override.
3. Replaced the .NET 6 one-argument `Enumerable.Zip` overload with the selector overload available to the legacy target.
4. Replaced the eight-argument `Tuple.Create` row with a named private record, avoiding the special `TRest` nesting for the eighth tuple value.
5. Removed assignment of the `void` result from `RequireBaseCurrency`; the validation guard is now invoked directly.
6. Updated the source-level procurement integration assertion to track the named row property.
7. Added focused regression tests for these compatibility fixes.

These are source-level corrections based on the recorded compiler diagnostics. A new C# build has **not** been run in this environment, so the corrections are not yet compiler-verified.

## Verification performed in this environment

- `pytest -q`: **773 passed**.
- `python -m unittest discover -s tests -v`: **365 passed**.
- XML/XAML/project/config parsing: **7/7 passed**.
- ZIP CRC validation on the input archive: passed.
- .NET SDK/compiler availability: unavailable (`dotnet`, `csc`, `mcs`, `msbuild`, `mono`, and PowerShell are not installed/accessible here).

## Not yet verified

- Full `MonarchERP.sln` restore/build for `net8.0` and `net461`.
- C# smoke tests.
- WPF launch and interaction on Windows 10/11.
- Installer build, upgrade, uninstall, and backup/restore on Windows/NTFS.
- Actual SQLite/.NET provider integration under the Windows runtime.

## Release decision

**Not ready for client/commercial deployment.** The Python and structural checks pass, but a successful Windows/.NET build and runtime validation remain mandatory.

## Cumulative manifest

Compared with the exact uploaded baseline archive:

- Baseline: 558 files
- Updated package: 560 files
- Added: 2 files
- Modified: 16 files
- Deleted: **0 files**
- Unchanged: 542 files

Added:
- `IMPLEMENTATION-2026-11-26-NET461-BUILD-COMPATIBILITY-REPAIRS.md`
- `tests/test_net461_compile_compatibility.py`

Modified:
- `README.md`
- `ROADMAP.md`
- `docs/ROADMAP.md`
- `src/Monarch.Core/Accounting/SqliteLedgerStore.cs`
- `src/Monarch.Core/Accounting/TenantLedgerStore.cs`
- `src/Monarch.Core/Autonomy/ProcurementApprovalIntelligenceService.cs`
- `src/Monarch.Core/Commercial/CommercialDocumentStore.cs`
- `src/Monarch.Core/Commercial/CommercialStore.cs`
- `src/Monarch.Core/Commercial/InventoryGlReconciliationStore.cs`
- `src/Monarch.Core/Commercial/InventoryValuationStore.cs`
- `src/Monarch.Core/Commercial/SupplierPayablesAccountingOutboxWorker.cs`
- `src/Monarch.Core/Commercial/SupplierPayablesAlertDeliveryStore.cs`
- `src/Monarch.Core/Compatibility/NetFrameworkCompat.cs`
- `src/Monarch.Core/Zatca/ZatcaEgsRegistry.cs`
- `src/Monarch.Core/Zatca/ZatcaSubmissionWorker.cs`
- `tests/test_procurement_approval_intelligence_integration.py`
