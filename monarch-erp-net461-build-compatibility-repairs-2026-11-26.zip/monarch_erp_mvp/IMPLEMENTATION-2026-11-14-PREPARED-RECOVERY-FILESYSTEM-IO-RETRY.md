# 2026-11-14 — Prepared restore filesystem I/O retry matrix

## Scope

Extended the Python crash-recovery fault model for failures while restoring a `prepared` journal. The change is test-only; production C# logic, database schema, WPF screens, and ERP modules were not modified.

## Coverage added

A six-point one-shot filesystem failure matrix injects `PermissionError` at:

1. Removing the uncommitted live database before moving the rollback database.
2. Moving the rollback database into the live database path.
3. Removing the replacement live WAL before restoring the quarantined WAL.
4. Moving the quarantined WAL into the live WAL path.
5. Removing the replacement live SHM before restoring the quarantined SHM.
6. Moving the quarantined SHM into the live SHM path.

Each case verifies that the durable prepared journal remains present after the injected failure, then retries recovery with normal filesystem operations and verifies byte-exact restoration of the prior database, WAL, and SHM artifacts. The test also checks that rollback artifact names are absent after successful retry.

A source-structure regression check confirms that the C# recovery path retains the expected database and sidecar moves, the sidecar helper's move ordering, and strict deletion for committed rollback cleanup. This is not execution of the compiled C# service.

## Validation

- `pytest -q`: 707 passed.
- `python -m unittest discover -s tests -p 'test_*.py'`: 365 tests passed.
- XML/XAML/project/config parsing: 7 parsed, 0 errors.
- ZIP integrity: checked after packaging.

## Limitations

No .NET SDK was available. No C# build, WPF runtime test, actual Windows ACL/sharing-violation test, or SQLite provider integration test was performed. Python fault injection and source inspection do not establish runtime behavior of the compiled service.
