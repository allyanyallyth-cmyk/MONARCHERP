# MONARCH ERP — Restore Journal Temporary Symlink Safety

## Scope
Added regression coverage for symbolic-link entries that match the exact abandoned restore-journal temporary naming convention. The model verifies that cleanup unlinks the matching directory entry while preserving the linked target bytes. A source guard verifies that the production strict-delete helper uses single-entry `File.Delete` and does not recursively delete directories.

## Production changes
No C# production logic, database schema, WPF UI, or ERP module was changed. This is a regression-test and source-contract addition only.

## Validation boundary
The symbolic-link behavior was exercised by the Python filesystem model on the current host. The C# source assertion is structural; it is not a compiled Windows test. Windows reparse-point behavior, ACLs, and sharing semantics still require execution against the compiled service on Windows.
