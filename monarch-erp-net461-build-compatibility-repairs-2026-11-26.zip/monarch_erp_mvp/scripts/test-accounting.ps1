[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$launcher = Get-Command py -ErrorAction SilentlyContinue
if ($launcher) {
    & py -3 -m unittest discover -s tests -v
} else {
    $python = Get-Command python -ErrorAction SilentlyContinue
    if (-not $python) {
        throw 'Python 3 غير موجود. ثبّت Python 3 أو شغّل: py -3 -m unittest discover -s tests -v'
    }
    & python -m unittest discover -s tests -v
}
if ($LASTEXITCODE -ne 0) { throw 'فشلت اختبارات سلامة القيود.' }
Write-Host 'نجحت اختبارات سلامة القيود.' -ForegroundColor Green
