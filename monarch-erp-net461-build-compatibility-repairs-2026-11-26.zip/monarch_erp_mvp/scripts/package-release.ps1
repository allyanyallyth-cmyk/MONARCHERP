[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][ValidatePattern('^[0-9A-Za-z][0-9A-Za-z._+-]{0,39}$')][string]$Version
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$desktop = Join-Path $root 'artifacts/desktop-net461'
$recovery = Join-Path $root 'artifacts/recovery-net461'
foreach ($path in @($desktop, $recovery)) {
    if (-not (Test-Path $path -PathType Container)) { throw "مجلد النشر غير موجود: $path. شغّل scripts/build-windows.ps1 أولاً." }
}
if (-not (Test-Path (Join-Path $desktop 'Monarch.Desktop.exe'))) { throw 'ملف Monarch.Desktop.exe غير موجود.' }
if (-not (Test-Path (Join-Path $recovery 'Monarch.Recovery.exe'))) { throw 'ملف Monarch.Recovery.exe غير موجود.' }
$release = Join-Path $root 'artifacts/release'
New-Item -ItemType Directory -Force -Path $release | Out-Null
$stage = Join-Path $root "artifacts/stage/monarch-erp-$Version"
if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Force -Path $stage | Out-Null
Copy-Item $desktop (Join-Path $stage 'MONARCH') -Recurse
Copy-Item $recovery (Join-Path $stage 'Recovery') -Recurse
Copy-Item (Join-Path $root 'tools') (Join-Path $stage 'MigrationTools') -Recurse
Copy-Item (Join-Path $root 'database') (Join-Path $stage 'DatabaseSchemas') -Recurse
Copy-Item (Join-Path $root 'README.md') $stage
Copy-Item (Join-Path $root 'docs/SECURITY.md') (Join-Path $stage 'SECURITY.md')
@"
MONARCH ERP $Version

Desktop: MONARCH/Monarch.Desktop.exe
Recovery utility: Recovery/Monarch.Recovery.exe
Migration tools: MigrationTools/

Requirements:
- Windows desktop with .NET Framework 4.6.1 or later.
- Python 3.10+ only for the legacy database migration utility.
- Review README.md and migration dry-run report before importing existing data.

This bundle is an unsigned portable build, not an MSI installer. Back up the database
before first launch. Do not use production financial data until Windows runtime,
restore, and migration acceptance tests have passed.
"@ | Set-Content -Encoding UTF8 (Join-Path $stage 'RELEASE-NOTES.txt')
$zip = Join-Path $release "monarch-erp-$Version-windows-portable.zip"
if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip -CompressionLevel Optimal
$hash = (Get-FileHash -Path $zip -Algorithm SHA256).Hash.ToLowerInvariant()
"$hash  $(Split-Path $zip -Leaf)" | Set-Content -Encoding ASCII "$zip.sha256"
Write-Host "Release bundle: $zip" -ForegroundColor Green
Write-Host "SHA-256: $hash" -ForegroundColor Cyan
