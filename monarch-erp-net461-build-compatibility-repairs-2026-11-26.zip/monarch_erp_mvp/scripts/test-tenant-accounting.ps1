$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
try {
    py -3 -m unittest discover -s tests -p 'test_tenant_accounting_schema.py' -v
    if ($LASTEXITCODE -ne 0) { throw 'MONARCH tenant accounting schema tests failed.' }
    if (Get-Command dotnet -ErrorAction SilentlyContinue) {
        dotnet run --project (Join-Path $root 'tests/Monarch.Core.SmokeTests/Monarch.Core.SmokeTests.csproj') --configuration Release
        if ($LASTEXITCODE -ne 0) { throw 'MONARCH C# accounting and tenant smoke tests failed.' }
    } else {
        Write-Warning '.NET SDK not found; C# smoke tests were not run.'
    }
}
finally { Pop-Location }
