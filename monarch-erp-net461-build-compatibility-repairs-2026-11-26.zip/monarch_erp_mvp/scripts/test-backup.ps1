$ErrorActionPreference = "Stop"
$project = Join-Path $PSScriptRoot "../tests/Monarch.Core.SmokeTests/Monarch.Core.SmokeTests.csproj"
dotnet run --project $project --configuration Release
if ($LASTEXITCODE -ne 0) { throw "MONARCH backup/recovery smoke tests failed." }
