[CmdletBinding()]
param([Parameter(Mandatory = $true)][ValidatePattern('^[0-9A-Za-z][0-9A-Za-z._+-]{0,39}$')][string]$Version)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$release = Join-Path $root 'artifacts/release'
$zip = Join-Path $release "monarch-erp-$Version-windows-portable.zip"
$setup = Join-Path $release "monarch-erp-$Version-setup.exe"
$required = @($zip, "$zip.sha256", $setup, "$setup.sha256")
foreach ($path in $required) {
    if (-not (Test-Path $path -PathType Leaf)) { throw "ملف إصدار مطلوب غير موجود: $path" }
}
foreach ($artifact in @($zip, $setup)) {
    $sidecar = "$artifact.sha256"
    $line = (Get-Content -LiteralPath $sidecar -Raw).Trim()
    if ($line -notmatch '^([0-9a-fA-F]{64})\s+(.+)$') { throw "صيغة SHA-256 غير صحيحة: $sidecar" }
    $expected = $Matches[1].ToLowerInvariant()
    $actual = (Get-FileHash -LiteralPath $artifact -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($expected -ne $actual) { throw "فشل التحقق من SHA-256: $artifact" }
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::OpenRead($zip)
try {
    $names = @($archive.Entries | ForEach-Object { $_.FullName })
    foreach ($entry in @('MONARCH/Monarch.Desktop.exe', 'Recovery/Monarch.Recovery.exe', 'README.md', 'SECURITY.md')) {
        if ($names -notcontains $entry) { throw "ملف أساسي مفقود من Portable ZIP: $entry" }
    }
} finally { $archive.Dispose() }
Write-Host 'Windows release verification passed.' -ForegroundColor Green
Write-Host "Portable: $zip"
Write-Host "Installer: $setup"
