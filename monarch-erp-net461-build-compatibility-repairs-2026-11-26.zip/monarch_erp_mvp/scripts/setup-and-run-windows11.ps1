[CmdletBinding()]
param(
    [switch]$InstallSdk,
    [ValidateSet('Debug','Release')][string]$Configuration = 'Debug'
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

Write-Host 'MONARCH ERP - Windows 11 setup' -ForegroundColor Cyan

function Test-DotNet8 {
    $cmd = Get-Command dotnet -ErrorAction SilentlyContinue
    if (-not $cmd) { return $false }
    $sdks = & dotnet --list-sdks 2>$null
    return [bool]($sdks | Where-Object { $_ -match '^8\.' })
}

if (-not (Test-DotNet8)) {
    if (-not $InstallSdk) {
        Write-Host 'لم يتم العثور على .NET 8 SDK.' -ForegroundColor Yellow
        Write-Host 'أعد تشغيل السكربت مع -InstallSdk لتثبيته عبر winget، أو ثبّته يدوياً من:'
        Write-Host 'https://dotnet.microsoft.com/en-us/download/dotnet/8.0'
        exit 2
    }
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        throw 'winget غير متوفر. ثبّت .NET 8 SDK يدوياً من موقع Microsoft ثم أعد المحاولة.'
    }
    winget install --id Microsoft.DotNet.SDK.8 --exact --source winget --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) { throw 'فشل تثبيت .NET SDK بواسطة winget. ثبّته يدوياً ثم أعد المحاولة.' }
    Write-Host 'أُرسل طلب تثبيت .NET 8 SDK. أغلق PowerShell وافتحه مجدداً ثم شغّل السكربت دون -InstallSdk.' -ForegroundColor Green
    exit 0
}

$desktop = Join-Path $root 'src/Monarch.Desktop/Monarch.Desktop.csproj'
Write-Host 'SDKs المثبتة:' -ForegroundColor Cyan
& dotnet --list-sdks
& dotnet restore $desktop
if ($LASTEXITCODE -ne 0) { throw 'فشل استرجاع الحزم.' }
& dotnet build $desktop --configuration $Configuration --no-restore
if ($LASTEXITCODE -ne 0) { throw 'فشل بناء تطبيق Windows. أرسل نص الخطأ كاملاً للمراجعة.' }

$out = Join-Path $root 'artifacts/desktop-net461'
& dotnet publish $desktop --configuration $Configuration --no-restore --output $out
if ($LASTEXITCODE -ne 0) { throw 'فشل نشر تطبيق Windows.' }
$exe = Join-Path $out 'Monarch.Desktop.exe'
if (-not (Test-Path $exe)) { throw "لم يتم العثور على ملف التشغيل: $exe" }
Write-Host 'تم النشر. بدء تشغيل MONARCH ERP...' -ForegroundColor Green
Start-Process -FilePath $exe -WorkingDirectory $out
