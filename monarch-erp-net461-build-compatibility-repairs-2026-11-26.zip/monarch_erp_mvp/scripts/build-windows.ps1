[CmdletBinding()]
param([ValidateSet('Debug','Release')][string]$Configuration = 'Release')
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$sln = Join-Path $root 'MonarchERP.sln'
Write-Host 'MONARCH ERP - Windows build and verification' -ForegroundColor Cyan
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw 'ثبّت .NET 8 SDK على جهاز التطوير.' }
$sdks = @(& dotnet --list-sdks)
if ($LASTEXITCODE -ne 0 -or -not ($sdks | Where-Object { $_ -match '^8\.' })) { throw 'يلزم .NET 8 SDK للبناء.' }
if (-not (Get-Command python -ErrorAction SilentlyContinue)) { throw 'Python 3 مطلوب لتشغيل اختبارات SQLite والترحيل.' }
Push-Location $root
try {
    python -m pip install -r tools/requirements.txt
    if ($LASTEXITCODE -ne 0) { throw 'فشل تثبيت متطلبات أدوات الترحيل.' }
    python -m unittest discover -s tests -v
    if ($LASTEXITCODE -ne 0) { throw 'فشلت اختبارات Python/SQLite.' }
    dotnet restore $sln
    if ($LASTEXITCODE -ne 0) { throw 'فشل استرجاع حزم NuGet.' }
    dotnet build $sln --configuration $Configuration --no-restore
    if ($LASTEXITCODE -ne 0) { throw 'فشل بناء الحل.' }
    dotnet run --project (Join-Path $root 'tests/Monarch.Core.SmokeTests/Monarch.Core.SmokeTests.csproj') --configuration $Configuration
    if ($LASTEXITCODE -ne 0) { throw 'فشلت اختبارات C# الدخانية.' }
    $desktop = Join-Path $root 'src/Monarch.Desktop/Monarch.Desktop.csproj'
    $out = Join-Path $root 'artifacts/desktop-net461'
    if (Test-Path $out) { Remove-Item $out -Recurse -Force }
    dotnet publish $desktop --configuration $Configuration --no-restore --output $out
    if ($LASTEXITCODE -ne 0) { throw 'فشل نشر تطبيق Windows.' }
    $recovery = Join-Path $root 'src/Monarch.Recovery/Monarch.Recovery.csproj'
    $recoveryOut = Join-Path $root 'artifacts/recovery-net461'
    if (Test-Path $recoveryOut) { Remove-Item $recoveryOut -Recurse -Force }
    dotnet publish $recovery --configuration $Configuration --no-restore --output $recoveryOut
    if ($LASTEXITCODE -ne 0) { throw 'فشل نشر أداة الاستعادة.' }
    foreach ($exe in @((Join-Path $out 'Monarch.Desktop.exe'), (Join-Path $recoveryOut 'Monarch.Recovery.exe'))) {
        if (-not (Test-Path $exe)) { throw "ملف التشغيل المتوقع غير موجود: $exe" }
    }
    Write-Host "اكتمل نشر واجهة Windows: $out" -ForegroundColor Green
    Write-Host "اكتمل نشر أداة الاستعادة: $recoveryOut" -ForegroundColor Green
    Write-Host 'النشر Portable وغير موقّع؛ يتطلب .NET Framework 4.6.1 أو أحدث، ولم يُنشأ MSI.' -ForegroundColor Yellow
} finally { Pop-Location }
