# First-restore journal cleanup retry — 2026-11-14

Extended the first-restore crash-recovery matrix to cover the final boundary after both quarantined sidecars have been restored but before the prepared journal is removed. The tests now model process termination after the SHM move, verify that a subsequent recovery pass is idempotent when no quarantined sidecars remain, and inject an access-denied failure while removing the journal. In both cases the durable journal remains available until cleanup can be retried, while restored WAL/SHM bytes remain unchanged.

A source-structure check verifies that C# restores WAL and SHM before best-effort journal deletion, and that `TryDelete` does not mask the primary recovery operation. This increment changes tests and documentation only; no production C# logic, schema, WPF UI, or ERP module was changed.

Validation results are recorded in `TEST_RESULTS_2026-11-14-FIRST-RESTORE-JOURNAL-CLEANUP-RETRY.log`. Python fault-model and source-structure checks do not constitute compiled C# or Windows runtime validation.
