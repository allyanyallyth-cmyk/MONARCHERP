# Implementation report — committed recovery integrity-gate partial-state matrix

## Scope
This increment strengthens regression coverage for the committed restore-recovery integrity gate. It deliberately leaves production C# code, database schema, ERP modules, and WPF behavior unchanged.

## Added coverage
The test crosses all eight possible presence/absence combinations of the rollback database, quarantined WAL, and quarantined SHM. For each state it:

1. Creates a live database and live WAL/SHM payloads.
2. Creates the selected subset of rollback artifacts.
3. Runs committed recovery twice with live integrity rejected, requiring fail-closed behavior and byte-for-byte preservation of every extant artifact.
4. Retries with integrity accepted, requiring rollback artifact cleanup while preserving the live database and live WAL/SHM payloads.

## Validation boundary
The test runs against the Python filesystem recovery model. It does not execute `BackupRecoveryService`, a compiled C# binary, the production SQLite provider, WPF, or Windows crash/power-loss behavior. Those remain explicit follow-up validation items.
