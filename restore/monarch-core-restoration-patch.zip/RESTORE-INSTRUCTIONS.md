# MONARCH ERP — Monarch.Core source restoration

Extract this archive at the root of the MONARCHERP repository. It restores the original 81 files under `postgresql-overlay/monarch_erp_mvp/src/Monarch.Core/`.

The patch is sourced from the cumulative `monarch-erp-dotnet-windows-release-gate-audit.zip` archive (SHA-256 recorded in `RESTORE-MANIFEST.json`). The archive's `Monarch.Core` directory contains the project file and original accounting, autonomy, backup, commercial, compatibility, models, organizations, security, services, and ZATCA source.

**Preservation requirement:** do not delete or replace the existing overlay-specific `src/Monarch.Core/Abstractions/IGeneralLedgerStore.cs` file. It is intentionally not present in the source patch and must remain alongside the restored files.

After extraction, verify `src/Monarch.Core/Monarch.Core.csproj` exists, confirm all 81 manifest entries and SHA-256 values, then run the API publish build in CI. This patch does not claim that the resulting application has built or run successfully.
