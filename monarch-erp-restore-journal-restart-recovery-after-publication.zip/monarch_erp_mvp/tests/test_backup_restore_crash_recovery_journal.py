"""Crash-state model and structural checks for durable restore recovery journaling.

The Python model validates the intended recovery protocol; it does not execute C#.
"""
from pathlib import Path
import hashlib
import re

ROOT = Path(__file__).resolve().parents[1]


def _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
             had_previous, phase, live_integrity_ok=True, crash_after=None):
    mutation_count = 0

    def mutate(action):
        nonlocal mutation_count
        action()
        mutation_count += 1
        if crash_after == mutation_count:
            raise RuntimeError("simulated process termination after filesystem mutation")

    previous_exists = previous.exists()
    live_exists = live.exists()
    if phase == "committed":
        if not live_exists:
            raise ValueError("committed journal without live database")
        if not live_integrity_ok:
            raise ValueError("committed live database failed integrity validation")
        mutate(lambda: previous.unlink(missing_ok=True))
        mutate(lambda: previous_wal.unlink(missing_ok=True))
        mutate(lambda: previous_shm.unlink(missing_ok=True))
        return
    if had_previous and not previous_exists and not live_exists:
        raise ValueError("prepared journal without prior or live database")
    if not had_previous and previous_exists:
        raise ValueError("first restore unexpectedly has rollback database")
    if previous_exists:
        mutate(lambda: live.unlink(missing_ok=True))
        mutate(lambda: previous.replace(live))
    elif not had_previous:
        mutate(lambda: live.unlink(missing_ok=True))
    for quarantined, active in ((previous_wal, live_wal), (previous_shm, live_shm)):
        if quarantined.exists():
            mutate(lambda: active.unlink(missing_ok=True))
            mutate(lambda: quarantined.replace(active))


def _cleanup_abandoned_journal_temps(journal_path, *, enumerate_fn=None, delete_fn=None):
    """Model strict startup cleanup; enumeration/deletion errors must propagate."""
    prefix = journal_path.name + ".tmp-"
    enumerate_candidates = enumerate_fn or (lambda: (candidate for candidate in journal_path.parent.glob(prefix + "*") if candidate.is_file()))
    delete_candidate = delete_fn or (lambda candidate: candidate.unlink())
    for candidate in enumerate_candidates():
        token = candidate.name[len(prefix):]
        if candidate.name.startswith(prefix) and re.fullmatch(r"[0-9a-fA-F]{32}", token):
            delete_candidate(candidate)


def _paths(tmp_path):
    return tuple(tmp_path / name for name in (
        "live.db", "previous.db", "live.db-wal", "previous.db-wal",
        "live.db-shm", "previous.db-shm"))


def test_crash_after_sidecar_quarantine_restores_original_sidecars(tmp_path):
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    live.write_bytes(b"old-db")
    previous_wal.write_bytes(b"old-wal")
    previous_shm.write_bytes(b"old-shm")
    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, True, "prepared")
    assert live.read_bytes() == b"old-db"
    assert live_wal.read_bytes() == b"old-wal"
    assert live_shm.read_bytes() == b"old-shm"


def test_crash_after_main_database_replace_rolls_back_complete_old_set(tmp_path):
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    live.write_bytes(b"new-db")
    previous.write_bytes(b"old-db")
    previous_wal.write_bytes(b"old-wal")
    previous_shm.write_bytes(b"old-shm")
    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, True, "prepared")
    assert live.read_bytes() == b"old-db"
    assert live_wal.read_bytes() == b"old-wal"
    assert live_shm.read_bytes() == b"old-shm"


def test_first_restore_crash_removes_uncommitted_database(tmp_path):
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    live.write_bytes(b"unverified-new-db")
    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, False, "prepared")
    assert not live.exists()


def test_committed_crash_finishes_cleanup_without_restoring_old_sidecars(tmp_path):
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    live.write_bytes(b"verified-new-db")
    previous.write_bytes(b"old-db")
    previous_wal.write_bytes(b"old-wal")
    previous_shm.write_bytes(b"old-shm")
    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, True, "committed")
    assert live.read_bytes() == b"verified-new-db"
    assert not previous.exists() and not previous_wal.exists() and not previous_shm.exists()
    assert not live_wal.exists() and not live_shm.exists()


def test_csharp_restore_persists_prepared_and_committed_journal_and_recovers_under_mutex():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    assert 'var restoreJournal = _databasePath + ".restore-journal";' in source
    assert 'WriteRestoreJournal(restoreJournal, previous, hadPrevious, "prepared")' in source
    assert 'WriteRestoreJournal(restoreJournal, previous, hadPrevious, "committed")' in source
    assert 'RecoverInterruptedRestore();' in source
    assert 'if (phase == "committed")' in source
    assert 'stream.Flush(true);' in source
    assert 'var expectedRollbackPrefix = Path.GetFileName(_databasePath) + ".pre-restore-";' in source
    assert 'Guid.TryParseExact(rollbackToken, "N", out rollbackId)' in source
    assert 'rollbackToken.Length != 32' in source
    assert 'Path.GetDirectoryName(previous), Path.GetDirectoryName(_databasePath)' in source
    assert source.index('RecoverInterruptedRestore();') < source.index('return operation();')


def _is_expected_rollback_name(database_name, candidate_name):
    import uuid
    prefix = database_name + ".pre-restore-"
    if not candidate_name.startswith(prefix):
        return False
    token = candidate_name[len(prefix):]
    if len(token) != 32:
        return False
    try:
        return uuid.UUID(hex=token).hex == token.lower()
    except ValueError:
        return False


def test_journal_rollback_path_validation_rejects_prefix_sibling_names():
    assert not _is_expected_rollback_name("ledger.db", "ledger.db.pre-restore-evil\\..\\other.db")
    assert not _is_expected_rollback_name("ledger.db", "ledger.db.pre-restore-" + "a" * 31)
    assert not _is_expected_rollback_name("ledger.db", "ledger.db.pre-restore-" + "z" * 32)


def test_journal_rollback_path_validation_accepts_only_guid_n_suffix():
    assert _is_expected_rollback_name("ledger.db", "ledger.db.pre-restore-0123456789abcdef0123456789abcdef")
    assert not _is_expected_rollback_name("ledger.db", "other.db.pre-restore-0123456789abcdef0123456789abcdef")


def test_prepared_journal_with_missing_live_and_rollback_files_fails_closed(tmp_path):
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    previous_wal.write_bytes(b"preserve-wal")
    try:
        _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, True, "prepared")
    except ValueError:
        pass
    else:
        raise AssertionError("ambiguous prepared recovery state must fail closed")
    assert previous_wal.read_bytes() == b"preserve-wal"


def test_committed_journal_without_live_database_preserves_rollback_artifacts(tmp_path):
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    previous.write_bytes(b"rollback-db")
    previous_wal.write_bytes(b"rollback-wal")
    try:
        _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, True, "committed")
    except ValueError:
        pass
    else:
        raise AssertionError("committed recovery without live DB must fail closed")
    assert previous.read_bytes() == b"rollback-db"
    assert previous_wal.read_bytes() == b"rollback-wal"


def test_first_restore_journal_with_unexpected_rollback_database_fails_closed(tmp_path):
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    previous.write_bytes(b"unexpected")
    try:
        _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, False, "prepared")
    except ValueError:
        pass
    else:
        raise AssertionError("first restore must not accept a rollback DB")
    assert previous.read_bytes() == b"unexpected"


def test_csharp_recovery_fails_closed_for_missing_or_inconsistent_main_file_state():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    assert 'if (!liveExists)' in source
    assert 'if (hadPrevious && !previousExists && !liveExists)' in source
    assert 'if (!hadPrevious && previousExists)' in source
    assert 'Recovery artifacts were preserved for manual recovery.' in source


def _journal_v2_fields(previous_path, had_previous, phase):
    import hashlib
    fields = ["MONARCH-RESTORE-JOURNAL-V2", str(previous_path),
              "true" if had_previous else "false", phase]
    checksum = hashlib.sha256("\n".join(fields).encode("utf-8")).hexdigest()
    return fields + [checksum]


def _validate_journal_lines(lines):
    import hashlib
    if len(lines) == 3:  # backward compatibility with the original journal format
        path, had_previous, phase = lines
        if had_previous not in ("true", "false") or phase not in ("prepared", "committed"):
            raise ValueError("invalid legacy journal")
        return path, had_previous == "true", phase
    if len(lines) != 5 or lines[0] != "MONARCH-RESTORE-JOURNAL-V2":
        raise ValueError("invalid journal format")
    expected = hashlib.sha256("\n".join(lines[:4]).encode("utf-8")).hexdigest()
    if not __import__("hmac").compare_digest(expected, lines[4].lower()):
        raise ValueError("journal checksum mismatch")
    if lines[2] not in ("true", "false") or lines[3] not in ("prepared", "committed"):
        raise ValueError("invalid journal fields")
    return lines[1], lines[2] == "true", lines[3]


def test_restore_journal_v2_checksum_accepts_unchanged_record(tmp_path):
    previous = tmp_path / "ledger.db.pre-restore-0123456789abcdef0123456789abcdef"
    lines = _journal_v2_fields(previous, True, "prepared")
    assert _validate_journal_lines(lines) == (str(previous), True, "prepared")


def test_restore_journal_v2_checksum_rejects_modified_path(tmp_path):
    previous = tmp_path / "ledger.db.pre-restore-0123456789abcdef0123456789abcdef"
    lines = _journal_v2_fields(previous, True, "prepared")
    lines[1] = str(tmp_path / "other.db")
    try:
        _validate_journal_lines(lines)
    except ValueError as exc:
        assert "checksum" in str(exc)
    else:
        raise AssertionError("modified journal path must fail checksum validation")


def test_restore_journal_v2_checksum_rejects_truncation_and_invalid_phase(tmp_path):
    previous = tmp_path / "ledger.db.pre-restore-0123456789abcdef0123456789abcdef"
    lines = _journal_v2_fields(previous, True, "prepared")
    try:
        _validate_journal_lines(lines[:-1])
    except ValueError:
        pass
    else:
        raise AssertionError("truncated journal must be rejected")
    invalid = _journal_v2_fields(previous, True, "unknown")
    try:
        _validate_journal_lines(invalid)
    except ValueError:
        pass
    else:
        raise AssertionError("unsupported journal phase must be rejected")


def test_restore_journal_v1_remains_readable_for_upgrade_recovery(tmp_path):
    previous = tmp_path / "ledger.db.pre-restore-0123456789abcdef0123456789abcdef"
    assert _validate_journal_lines([str(previous), "true", "committed"]) == (
        str(previous), True, "committed")


def test_csharp_restore_journal_v2_checksum_is_written_and_validated_with_legacy_support():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    assert '"MONARCH-RESTORE-JOURNAL-V2"' in source
    assert 'IsValidJournalChecksum(lines)' in source
    assert 'ComputeJournalChecksum(fields)' in source
    assert 'stream.Flush(true);' in source
    assert 'if (lines.Length == 3)' in source  # v1 compatibility
    assert 'var checksum = ComputeJournalChecksum(fields);' in source


def test_csharp_committed_recovery_uses_parsed_phase_for_v1_and_v2():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    assert 'if (phase == "committed")' in source
    assert 'if (lines[2] == "committed")' not in source
    assert 'phase = lines[3];' in source  # V2 phase is the fourth field


def test_v2_committed_journal_phase_is_not_confused_with_had_previous(tmp_path):
    previous = tmp_path / "ledger.db.pre-restore-0123456789abcdef0123456789abcdef"
    lines = _journal_v2_fields(previous, True, "committed")
    path, had_previous, phase = _validate_journal_lines(lines)
    assert path == str(previous)
    assert had_previous is True
    assert phase == "committed"


def test_prepared_recovery_is_restart_safe_after_database_rollback_before_sidecars(tmp_path):
    """A second process can resume recovery after the main-file move already completed."""
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    live.write_bytes(b"restored-old-db")
    previous_wal.write_bytes(b"old-wal")
    previous_shm.write_bytes(b"old-shm")

    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, True, "prepared")
    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, True, "prepared")

    assert live.read_bytes() == b"restored-old-db"
    assert live_wal.read_bytes() == b"old-wal"
    assert live_shm.read_bytes() == b"old-shm"
    assert not previous.exists() and not previous_wal.exists() and not previous_shm.exists()


def test_prepared_recovery_is_restart_safe_after_wal_restore_before_shm(tmp_path):
    """A completed WAL move is preserved while a later recovery resumes the SHM move."""
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    live.write_bytes(b"old-db")
    live_wal.write_bytes(b"old-wal-already-restored")
    previous_shm.write_bytes(b"old-shm-pending")

    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, True, "prepared")
    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, True, "prepared")

    assert live.read_bytes() == b"old-db"
    assert live_wal.read_bytes() == b"old-wal-already-restored"
    assert live_shm.read_bytes() == b"old-shm-pending"
    assert not previous.exists() and not previous_wal.exists() and not previous_shm.exists()


def test_committed_cleanup_is_restart_safe_after_partial_rollback_artifact_deletion(tmp_path):
    """Committed recovery can be retried when cleanup stopped between artifact deletions."""
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    live.write_bytes(b"verified-new-db")
    previous_wal.write_bytes(b"stale-old-wal")
    previous_shm.write_bytes(b"stale-old-shm")

    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, True, "committed")
    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, True, "committed")

    assert live.read_bytes() == b"verified-new-db"
    assert not previous.exists() and not previous_wal.exists() and not previous_shm.exists()
    assert not live_wal.exists() and not live_shm.exists()



def test_prepared_recovery_resumes_after_crash_at_each_filesystem_mutation(tmp_path):
    """Every completed rollback mutation is safe to encounter again after restart."""
    for crash_after in range(1, 7):
        case = tmp_path / str(crash_after)
        case.mkdir()
        live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(case)
        live.write_bytes(b"uncommitted-new-db")
        previous.write_bytes(b"old-db")
        previous_wal.write_bytes(b"old-wal")
        previous_shm.write_bytes(b"old-shm")

        try:
            _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                     True, "prepared", crash_after=crash_after)
        except RuntimeError as exc:
            assert "simulated process termination" in str(exc)
        else:
            raise AssertionError("fault injection did not interrupt recovery")

        # A fresh process repeats recovery from the on-disk state left by the crash.
        _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                 True, "prepared")
        assert live.read_bytes() == b"old-db"
        assert live_wal.read_bytes() == b"old-wal"
        assert live_shm.read_bytes() == b"old-shm"
        assert not previous.exists() and not previous_wal.exists() and not previous_shm.exists()



def test_prepared_recovery_survives_two_consecutive_process_terminations(tmp_path):
    """A second crash during recovery must not prevent a later clean restart."""
    for first_crash in range(1, 6):
        case = tmp_path / f"double-crash-{first_crash}"
        case.mkdir()
        live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(case)
        live.write_bytes(b"uncommitted-new-db")
        previous.write_bytes(b"old-db")
        previous_wal.write_bytes(b"old-wal")
        previous_shm.write_bytes(b"old-shm")

        try:
            _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                     True, "prepared", crash_after=first_crash)
        except RuntimeError:
            pass
        else:
            raise AssertionError("first injected termination did not occur")

        try:
            _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                     True, "prepared", crash_after=1)
        except RuntimeError as exc:
            assert "simulated process termination" in str(exc)
        else:
            raise AssertionError("second injected termination did not occur")

        _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                 True, "prepared")
        assert live.read_bytes() == b"old-db"
        assert live_wal.read_bytes() == b"old-wal"
        assert live_shm.read_bytes() == b"old-shm"
        assert not previous.exists() and not previous_wal.exists() and not previous_shm.exists()



def test_first_restore_recovery_survives_two_terminations_with_quarantined_sidecars(tmp_path):
    """Without a prior DB, recovery removes the uncommitted DB and restores old sidecars."""
    for first_crash in range(1, 6):
        case = tmp_path / f"first-restore-double-crash-{first_crash}"
        case.mkdir()
        live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(case)
        live.write_bytes(b"unverified-first-db")
        live_wal.write_bytes(b"new-wal")
        live_shm.write_bytes(b"new-shm")
        previous_wal.write_bytes(b"quarantined-old-wal")
        previous_shm.write_bytes(b"quarantined-old-shm")

        try:
            _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                     False, "prepared", crash_after=first_crash)
        except RuntimeError as exc:
            assert "simulated process termination" in str(exc)
        else:
            raise AssertionError("first-restore recovery was not interrupted")

        try:
            _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                     False, "prepared", crash_after=1)
        except RuntimeError as exc:
            assert "simulated process termination" in str(exc)
        else:
            raise AssertionError("repeated first-restore recovery was not interrupted")

        _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                 False, "prepared")
        assert not live.exists()
        assert live_wal.read_bytes() == b"quarantined-old-wal"
        assert live_shm.read_bytes() == b"quarantined-old-shm"
        assert not previous.exists()
        assert not previous_wal.exists()
        assert not previous_shm.exists()



def test_first_restore_recovery_survives_exhaustive_second_termination_points(tmp_path):
    """Explore every reachable second-crash mutation after each first-crash point."""
    injected_second_crashes = 0
    for first_crash in range(1, 6):
        for second_crash in range(1, 6):
            case = tmp_path / f"matrix-{first_crash}-{second_crash}"
            case.mkdir()
            live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(case)
            live.write_bytes(b"unverified-first-db")
            live_wal.write_bytes(b"new-wal")
            live_shm.write_bytes(b"new-shm")
            previous_wal.write_bytes(b"old-wal")
            previous_shm.write_bytes(b"old-shm")

            try:
                _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                         False, "prepared", crash_after=first_crash)
            except RuntimeError:
                pass
            else:
                raise AssertionError("first injected termination did not occur")

            try:
                _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                         False, "prepared", crash_after=second_crash)
            except RuntimeError as exc:
                injected_second_crashes += 1
                assert "simulated process termination" in str(exc)

            # Whether the selected second point was reachable or beyond the
            # remaining mutations, a clean third process must finish recovery.
            _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                     False, "prepared")
            assert not live.exists()
            assert live_wal.read_bytes() == b"old-wal"
            assert live_shm.read_bytes() == b"old-shm"
            assert not previous.exists()
            assert not previous_wal.exists()
            assert not previous_shm.exists()

    assert injected_second_crashes >= 10


def test_committed_cleanup_resumes_after_crash_at_each_artifact_deletion(tmp_path):
    """A verified new DB remains authoritative while committed cleanup is retried."""
    for crash_after in range(1, 4):
        case = tmp_path / f"committed-{crash_after}"
        case.mkdir()
        live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(case)
        live.write_bytes(b"verified-new-db")
        previous.write_bytes(b"old-db")
        previous_wal.write_bytes(b"old-wal")
        previous_shm.write_bytes(b"old-shm")

        try:
            _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                     True, "committed", crash_after=crash_after)
        except RuntimeError as exc:
            assert "simulated process termination" in str(exc)
        else:
            raise AssertionError("fault injection did not interrupt committed cleanup")

        # A fresh process must finish cleanup without rolling back the verified DB.
        _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                 True, "committed")
        assert live.read_bytes() == b"verified-new-db"
        assert not previous.exists()
        assert not previous_wal.exists()
        assert not previous_shm.exists()


def test_csharp_sidecar_recovery_is_guarded_by_quarantine_existence():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    helper = source[source.index("private static void RestoreSidecar"):source.index("private static void CreateConsistentSqliteCopy")]
    assert "if (!wasMoved || !File.Exists(quarantinedPath)) return;" in helper
    assert "File.Move(quarantinedPath, livePath);" in helper


def test_csharp_prepared_recovery_restores_sidecars_before_removing_journal():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    recovery = source[source.index("private void RecoverInterruptedRestore()"):source.index("private static void WriteRestoreJournal")]
    wal_restore = recovery.index("RestoreSidecar(previousWal, liveWal, File.Exists(previousWal));")
    shm_restore = recovery.index("RestoreSidecar(previousShm, liveShm, File.Exists(previousShm));")
    journal_delete = recovery.index("TryDelete(journal);", shm_restore)
    assert wal_restore < shm_restore < journal_delete


def test_csharp_committed_recovery_checks_live_database_before_cleanup():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    recovery = source[source.index('if (phase == "committed")'):source.index("// Validate the transaction's main-file state")]
    assert recovery.index("if (!liveExists)") < recovery.index("DeleteIfExistsStrict(previous);")
    assert recovery.index("DeleteIfExistsStrict(previousWal);") < recovery.index("DeleteIfExistsStrict(journal);")


def test_committed_recovery_preserves_all_database_artifacts_when_live_integrity_fails(tmp_path):
    """A failed committed integrity gate must not mutate live or rollback sidecars."""
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    live.write_bytes(b"corrupted-live-db")
    live_wal.write_bytes(b"live-wal")
    live_shm.write_bytes(b"live-shm")
    previous.write_bytes(b"last-known-good-db")
    previous_wal.write_bytes(b"last-known-good-wal")
    previous_shm.write_bytes(b"last-known-good-shm")

    try:
        _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                 True, "committed", live_integrity_ok=False)
    except ValueError as exc:
        assert "integrity" in str(exc)
    else:
        raise AssertionError("committed recovery must not clean rollback artifacts for an invalid live DB")

    assert live.read_bytes() == b"corrupted-live-db"
    assert live_wal.read_bytes() == b"live-wal"
    assert live_shm.read_bytes() == b"live-shm"
    assert previous.read_bytes() == b"last-known-good-db"
    assert previous_wal.read_bytes() == b"last-known-good-wal"
    assert previous_shm.read_bytes() == b"last-known-good-shm"


def test_csharp_integrity_validation_includes_foreign_key_check():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    checker = source[source.index("private static string CheckIntegrity"):source.index("private static byte[] Encrypt")]
    assert 'command.CommandText = "PRAGMA integrity_check;";' in checker
    assert 'command.CommandText = "PRAGMA foreign_key_check;";' in checker
    assert 'integrityIssues.Add("foreign_key_check: table="' in checker


def test_csharp_committed_recovery_validates_integrity_before_deleting_rollback_artifacts():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    recovery = source[source.index('if (phase == "committed")'):source.index("// Validate the transaction's main-file state")]
    integrity_check = recovery.index("CheckIntegrity(_databasePath)")
    integrity_guard = recovery.index('committedIntegrity, "ok"')
    rollback_delete = recovery.index("DeleteIfExistsStrict(previous);")
    assert integrity_check < integrity_guard < rollback_delete
    assert "Rollback artifacts were preserved for manual recovery." in recovery


def test_csharp_integrity_check_rejects_an_empty_result_set():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    checker = source[source.index("private static string CheckIntegrity"):source.index("private static byte[] Encrypt")]
    assert "var integrityResultCount = 0;" in checker
    assert "integrityResultCount++;" in checker
    assert "if (integrityResultCount == 0)" in checker
    assert 'integrity_check returned no result rows' in checker


def test_csharp_integrity_check_requires_exactly_one_ok_result_row():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    checker = source[source.index("private static string CheckIntegrity"):source.index("private static byte[] Encrypt")]
    assert "var integrityOkResultCount = 0;" in checker
    assert "integrityOkResultCount++;" in checker
    assert "integrityResultCount != 1 || integrityOkResultCount != 1" in checker
    assert "did not return exactly one successful result row" in checker


def test_committed_recovery_survives_two_terminations_during_rollback_cleanup(tmp_path):
    """A verified live DB and remaining rollback artifacts survive two cleanup crashes."""
    injected_second_crashes = 0
    for first_crash in range(1, 4):
        for second_crash in range(1, 4):
            case = tmp_path / f"committed-double-crash-{first_crash}-{second_crash}"
            case.mkdir()
            live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(case)
            live.write_bytes(b"verified-new-db")
            previous.write_bytes(b"last-known-good-db")
            previous_wal.write_bytes(b"last-known-good-wal")
            previous_shm.write_bytes(b"last-known-good-shm")

            try:
                _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                         True, "committed", crash_after=first_crash)
            except RuntimeError as exc:
                assert "simulated process termination" in str(exc)
            else:
                raise AssertionError("first committed-cleanup termination was not injected")

            try:
                _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                         True, "committed", crash_after=second_crash)
            except RuntimeError as exc:
                injected_second_crashes += 1
                assert "simulated process termination" in str(exc)

            _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                     True, "committed")
            assert live.read_bytes() == b"verified-new-db"
            assert not previous.exists()
            assert not previous_wal.exists()
            assert not previous_shm.exists()
            assert not live_wal.exists()
            assert not live_shm.exists()

    assert injected_second_crashes >= 3


def test_committed_recovery_is_idempotent_for_every_partial_cleanup_subset(tmp_path):
    """Every partially deleted rollback set can be cleaned repeatedly without touching live DB."""
    import itertools

    for present in itertools.product((False, True), repeat=3):
        case = tmp_path / ("partial-" + "".join("1" if item else "0" for item in present))
        case.mkdir()
        live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(case)
        live.write_bytes(b"verified-live-database")
        rollback_artifacts = (previous, previous_wal, previous_shm)
        payloads = (b"rollback-db", b"rollback-wal", b"rollback-shm")
        for exists, path, payload in zip(present, rollback_artifacts, payloads):
            if exists:
                path.write_bytes(payload)

        # Repeated recovery must be safe even when an earlier process removed
        # any subset of the rollback artifacts before terminating.
        _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                 True, "committed")
        _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                 True, "committed")

        assert live.read_bytes() == b"verified-live-database"
        assert all(not path.exists() for path in rollback_artifacts)
        assert not live_wal.exists() and not live_shm.exists()


def test_committed_recovery_integrity_gate_preserves_every_partial_rollback_state(tmp_path):
    """An integrity failure preserves each partial rollback set until a valid retry."""
    import itertools

    for present in itertools.product((False, True), repeat=3):
        case = tmp_path / ("integrity-gate-" + "".join("1" if item else "0" for item in present))
        case.mkdir()
        live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(case)
        live_payload = b"untrusted-live-database"
        live_wal_payload = b"live-wal-preserve"
        live_shm_payload = b"live-shm-preserve"
        live.write_bytes(live_payload)
        live_wal.write_bytes(live_wal_payload)
        live_shm.write_bytes(live_shm_payload)

        rollback_paths = (previous, previous_wal, previous_shm)
        rollback_payloads = (b"known-good-rollback-db", b"known-good-rollback-wal", b"known-good-rollback-shm")
        expected_rollback = {}
        for exists, path, payload in zip(present, rollback_paths, rollback_payloads):
            if exists:
                path.write_bytes(payload)
                expected_rollback[path] = payload

        for _ in range(2):
            try:
                _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                         True, "committed", live_integrity_ok=False)
            except ValueError as exc:
                assert "integrity" in str(exc)
            else:
                raise AssertionError("integrity failure must fail closed for every partial rollback state")

            assert live.read_bytes() == live_payload
            assert live_wal.read_bytes() == live_wal_payload
            assert live_shm.read_bytes() == live_shm_payload
            assert {path: path.read_bytes() for path in expected_rollback} == expected_rollback
            assert all(path.exists() == (path in expected_rollback) for path in rollback_paths)

        # Once integrity validation succeeds, the same partial state is safe to clean.
        _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                 True, "committed", live_integrity_ok=True)
        assert live.read_bytes() == live_payload
        assert not any(path.exists() for path in rollback_paths)
        assert live_wal.read_bytes() == live_wal_payload
        assert live_shm.read_bytes() == live_shm_payload


def test_committed_cleanup_failure_keeps_journal_for_retry(tmp_path):
    """A failed rollback deletion must leave the committed journal as retry state."""
    import os

    rollback_db = tmp_path / "ledger.db.pre-restore-db"
    rollback_wal = tmp_path / "ledger.db.pre-restore-wal"
    rollback_shm = tmp_path / "ledger.db.pre-restore-shm"
    journal = tmp_path / "ledger.db.restore-journal"
    for path in (rollback_db, rollback_wal, rollback_shm, journal):
        path.write_bytes(path.name.encode("utf-8"))

    deleted = []
    def strict_delete(path):
        if path.name == rollback_wal.name:
            raise PermissionError("simulated sharing violation")
        path.unlink(missing_ok=True)
        deleted.append(path)

    try:
        for path in (rollback_db, rollback_wal, rollback_shm):
            strict_delete(path)
        strict_delete(journal)
    except PermissionError:
        pass
    else:
        raise AssertionError("cleanup failure must propagate")

    assert deleted == [rollback_db]
    assert not rollback_db.exists()
    assert rollback_wal.exists() and rollback_shm.exists() and journal.exists()


def test_csharp_committed_cleanup_uses_strict_deletion_before_journal_removal():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    recovery = source[source.index('if (phase == "committed")'):source.index("// Validate the transaction's main-file state")]
    assert recovery.index("DeleteIfExistsStrict(previous);") < recovery.index("DeleteIfExistsStrict(previousWal);")
    assert recovery.index("DeleteIfExistsStrict(previousWal);") < recovery.index("DeleteIfExistsStrict(previousShm);")
    assert recovery.index("DeleteIfExistsStrict(previousShm);") < recovery.index("DeleteIfExistsStrict(journal);")
    assert "TryDelete(" not in recovery
    helper = source[source.index("private static void DeleteIfExistsStrict"):source.index("private static void TryDelete")]
    assert "File.Delete(path);" in helper
    assert "File.Exists(path)" not in helper
    assert "catch" not in helper


import pytest


@pytest.mark.parametrize("failure_name", [
    "ledger.db.pre-restore-db",
    "ledger.db.pre-restore-wal",
    "ledger.db.pre-restore-shm",
])
def test_committed_cleanup_preserves_journal_for_each_artifact_failure(tmp_path, failure_name):
    """Any rollback artifact deletion failure must stop cleanup before journal deletion."""
    rollback_paths = [
        tmp_path / "ledger.db.pre-restore-db",
        tmp_path / "ledger.db.pre-restore-wal",
        tmp_path / "ledger.db.pre-restore-shm",
    ]
    journal = tmp_path / "ledger.db.restore-journal"
    for path in rollback_paths + [journal]:
        path.write_bytes(path.name.encode("utf-8"))

    deleted = []
    def strict_delete(path):
        if path.name == failure_name:
            raise PermissionError("simulated access/sharing failure")
        path.unlink(missing_ok=True)
        deleted.append(path.name)

    with pytest.raises(PermissionError):
        for path in rollback_paths:
            strict_delete(path)
        strict_delete(journal)

    assert failure_name not in deleted
    assert journal.exists(), "journal must remain available for retry"
    assert all(path.exists() for path in rollback_paths if path.name == failure_name or rollback_paths.index(path) >= rollback_paths.index(next(p for p in rollback_paths if p.name == failure_name)))


def test_csharp_strict_delete_does_not_gate_on_file_exists():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    helper = source[source.index("private static void DeleteIfExistsStrict"):source.index("private static void TryDelete")]
    assert "File.Delete(path);" in helper
    assert "File.Exists(path)" not in helper


def test_restore_success_path_uses_strict_cleanup_after_durable_commit():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    restore = source[source.index("private RestoreResult RestoreEncryptedBackupCore"):source.index("/// <summary>\n    /// Serializes MONARCH backup")]
    committed_write = restore.index('WriteRestoreJournal(restoreJournal, previous, hadPrevious, "committed");')
    committed_flag = restore.index("restoreCommitted = true;", committed_write)
    strict_db = restore.index("DeleteIfExistsStrict(previous);", committed_flag)
    strict_wal = restore.index("DeleteIfExistsStrict(previousWal);", strict_db)
    strict_shm = restore.index("DeleteIfExistsStrict(previousShm);", strict_wal)
    strict_journal = restore.index("DeleteIfExistsStrict(restoreJournal);", strict_shm)
    assert committed_write < committed_flag < strict_db < strict_wal < strict_shm < strict_journal
    catch = restore[restore.index("            catch", strict_journal):]
    assert "if (restoreCommitted) throw;" in catch
    assert catch.index("if (restoreCommitted) throw;") < catch.index("File.Move(previous, _databasePath)")
    assert "TryDelete(restoreJournal)" in catch  # prepared-phase rollback still clears its journal


@pytest.mark.parametrize("failure_index", [0, 1, 2])
def test_direct_committed_cleanup_failure_keeps_committed_journal_and_live_db(tmp_path, failure_index):
    live = tmp_path / "ledger.db"
    rollback = [tmp_path / "ledger.db.pre-restore-db", tmp_path / "ledger.db.pre-restore-wal", tmp_path / "ledger.db.pre-restore-shm"]
    journal = tmp_path / "ledger.db.restore-journal"
    live.write_bytes(b"verified-new-live-db")
    for path in rollback:
        path.write_bytes(path.name.encode())
    journal.write_text("committed", encoding="utf-8")

    deleted = []
    def strict_delete(path, index):
        if index == failure_index:
            raise PermissionError("simulated cleanup failure")
        path.unlink(missing_ok=True)
        deleted.append(index)

    with pytest.raises(PermissionError):
        for index, path in enumerate(rollback):
            strict_delete(path, index)
        strict_delete(journal, 3)

    assert live.read_bytes() == b"verified-new-live-db"
    assert journal.read_text(encoding="utf-8") == "committed"
    assert all(rollback[i].exists() for i in range(failure_index, 3))
    assert deleted == list(range(failure_index))


@pytest.mark.parametrize("failure_index", [0, 1, 2, 3])
def test_direct_committed_cleanup_retry_after_each_failure_preserves_live_database(tmp_path, failure_index):
    """A later startup can finish direct-path cleanup after any artifact deletion fails."""
    live = tmp_path / "ledger.db"
    rollback = [
        tmp_path / "ledger.db.pre-restore-db",
        tmp_path / "ledger.db.pre-restore-wal",
        tmp_path / "ledger.db.pre-restore-shm",
    ]
    journal = tmp_path / "ledger.db.restore-journal"
    live.write_bytes(b"verified-committed-database")
    for path in rollback:
        path.write_bytes(path.name.encode("utf-8"))
    journal.write_text("committed", encoding="utf-8")

    def delete_if_exists_strict(path):
        # File.Delete semantics: absence is harmless; real filesystem errors propagate.
        if path.exists():
            path.unlink()

    def cleanup(fail_at=None):
        for index, path in enumerate(rollback):
            if index == fail_at:
                raise PermissionError("simulated direct-cleanup interruption")
            delete_if_exists_strict(path)
        if fail_at == len(rollback):
            raise PermissionError("simulated journal-removal interruption")
        delete_if_exists_strict(journal)

    with pytest.raises(PermissionError):
        cleanup(failure_index)

    assert journal.read_text(encoding="utf-8") == "committed"
    assert live.read_bytes() == b"verified-committed-database"
    # If journal removal itself fails, all rollback artifacts may already be gone;
    # the committed journal remains the durable retry marker until a later pass.
    assert all(not path.exists() for path in rollback[:failure_index])
    if failure_index == len(rollback):
        assert not any(path.exists() for path in rollback)

    # Startup retry is idempotent even for artifacts removed before the failure.
    cleanup()
    assert not journal.exists()
    assert not any(path.exists() for path in rollback)
    assert live.read_bytes() == b"verified-committed-database"


@pytest.mark.parametrize("field_index, replacement", [
    (0, "MONARCH-RESTORE-JOURNAL-V3"),
    (1, "C:/unexpected/location/ledger.db.pre-restore-0123456789abcdef0123456789abcdef"),
    (2, "false"),
    (3, "prepared"),
    (4, "0" * 64),
])
def test_restore_journal_v2_rejects_tampering_in_every_framed_field(tmp_path, field_index, replacement):
    """Every V2 field, including the digest itself, is covered by validation."""
    previous = tmp_path / "ledger.db.pre-restore-0123456789abcdef0123456789abcdef"
    original = _journal_v2_fields(previous, True, "committed")
    tampered = list(original)
    tampered[field_index] = replacement
    with pytest.raises(ValueError):
        _validate_journal_lines(tampered)


def test_restore_journal_v2_accepts_uppercase_hex_checksum_but_rejects_bad_digest_framing(tmp_path):
    previous = tmp_path / "ledger.db.pre-restore-0123456789abcdef0123456789abcdef"
    lines = _journal_v2_fields(previous, True, "committed")
    uppercase = lines[:4] + [lines[4].upper()]
    assert _validate_journal_lines(uppercase) == (str(previous), True, "committed")

    for malformed in ("", "0" * 63, "0" * 65, "g" * 64):
        invalid = lines[:4] + [malformed]
        with pytest.raises(ValueError):
            _validate_journal_lines(invalid)


def test_csharp_restore_journal_checksum_enforces_digest_shape_and_compares_without_early_exit():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    validator = source[source.index("private static bool IsValidJournalChecksum"):source.index("private static string ComputeJournalChecksum")]
    assert 'lines[4].Length != 64' in validator
    assert 'Uri.IsHexDigit(lines[4][i])' in validator
    assert 'difference |= char.ToUpperInvariant(expected[i]) ^ char.ToUpperInvariant(lines[4][i]);' in validator
    assert 'return difference == 0;' in validator

@pytest.mark.parametrize("had_previous", ["TRUE", "False", "yes", "1", "", " true "])
def test_restore_journal_v2_rejects_noncanonical_boolean_even_with_valid_checksum(tmp_path, had_previous):
    """A matching digest must not make a non-canonical state flag acceptable."""
    import hashlib
    previous = tmp_path / "ledger.db.pre-restore-0123456789abcdef0123456789abcdef"
    fields = ["MONARCH-RESTORE-JOURNAL-V2", str(previous), had_previous, "committed"]
    lines = fields + [hashlib.sha256("\n".join(fields).encode("utf-8")).hexdigest()]
    with pytest.raises(ValueError):
        _validate_journal_lines(lines)


@pytest.mark.parametrize("phase", ["COMMITTED", "Prepared", "pending", "", " committed "])
def test_restore_journal_v2_rejects_noncanonical_phase_even_with_valid_checksum(tmp_path, phase):
    """A correctly checksummed but unsupported phase must fail closed."""
    import hashlib
    previous = tmp_path / "ledger.db.pre-restore-0123456789abcdef0123456789abcdef"
    fields = ["MONARCH-RESTORE-JOURNAL-V2", str(previous), "true", phase]
    lines = fields + [hashlib.sha256("\n".join(fields).encode("utf-8")).hexdigest()]
    with pytest.raises(ValueError):
        _validate_journal_lines(lines)


def test_restore_journal_v2_accepts_only_canonical_state_and_phase_values(tmp_path):
    previous = tmp_path / "ledger.db.pre-restore-0123456789abcdef0123456789abcdef"
    for had_previous in (True, False):
        for phase in ("prepared", "committed"):
            assert _validate_journal_lines(_journal_v2_fields(previous, had_previous, phase)) == (
                str(previous), had_previous, phase)


def test_restore_journal_v1_rejects_noncanonical_boolean_and_phase_values(tmp_path):
    previous = tmp_path / "ledger.db.pre-restore-0123456789abcdef0123456789abcdef"
    for had_previous, phase in (("TRUE", "committed"), ("yes", "prepared"),
                                ("true", "COMMITTED"), ("false", "pending")):
        with pytest.raises(ValueError):
            _validate_journal_lines([str(previous), had_previous, phase])


def _is_expected_rollback_reference(database_path, previous_path):
    """Mirror the recovery service's full-path, same-directory, GUID-N gate."""
    import os
    database_full = os.path.abspath(str(database_path))
    previous_full = os.path.abspath(str(previous_path))
    if os.path.dirname(database_full).casefold() != os.path.dirname(previous_full).casefold():
        return False
    return _is_expected_rollback_name(os.path.basename(database_full), os.path.basename(previous_full))


@pytest.mark.parametrize("candidate", [
    "elsewhere/ledger.db.pre-restore-0123456789abcdef0123456789abcdef",
    "nested/ledger.db.pre-restore-0123456789abcdef0123456789abcdef",
    "ledger-copy.db.pre-restore-0123456789abcdef0123456789abcdef",
    "ledger.db.pre-restore-0123456789abcdef0123456789abcdef.extra",
    "ledger.db.pre-restore-{01234567-89ab-cdef-0123-456789abcdef}",
    "ledger.db.pre-restore-0123456789abcdef0123456789abcdeg",
])
def test_restore_journal_rejects_rollback_reference_outside_exact_sibling_guid_contract(tmp_path, candidate):
    database = tmp_path / "ledger.db"
    assert not _is_expected_rollback_reference(database, tmp_path / candidate)


def test_restore_journal_accepts_normalized_same_directory_guid_n_reference(tmp_path):
    database = tmp_path / "ledger.db"
    previous = tmp_path / "ledger.db.pre-restore-0123456789abcdef0123456789abcdef"
    assert _is_expected_rollback_reference(database, previous)
    assert _is_expected_rollback_reference(database, tmp_path / "unused" / ".." / previous.name)


def test_csharp_recovery_compares_normalized_rollback_parent_and_exact_guid_token():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    assert 'var previous = Path.GetFullPath(previousPath);' in source
    assert 'Path.GetDirectoryName(previous), Path.GetDirectoryName(_databasePath)' in source
    assert 'StringComparison.OrdinalIgnoreCase' in source
    assert 'Guid.TryParseExact(rollbackToken, "N", out rollbackId)' in source


@pytest.mark.parametrize("malformed", [b"\xff", b"\xc3\x28", b"\xe2\x82"])
def test_restore_journal_invalid_utf8_fails_closed_before_artifact_mutation(tmp_path, malformed):
    """Malformed journal bytes must fail during strict decoding, before recovery mutates files."""
    journal = tmp_path / "ledger.db.restore-journal"
    live = tmp_path / "ledger.db"
    rollback = tmp_path / "ledger.db.pre-restore-0123456789abcdef0123456789abcdef"
    live.write_bytes(b"verified-live-database")
    rollback.write_bytes(b"preserved-rollback-database")
    journal.write_bytes(malformed)

    with pytest.raises(UnicodeDecodeError):
        journal.read_bytes().decode("utf-8", errors="strict")

    assert live.read_bytes() == b"verified-live-database"
    assert rollback.read_bytes() == b"preserved-rollback-database"
    assert journal.read_bytes() == malformed


def test_csharp_restore_journal_uses_strict_utf8_decode_before_recovery_mutations():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index('private void RecoverInterruptedRestore()')
    end = source.index('private static void WriteRestoreJournal(', start)
    recovery = source[start:end]
    strict_read = 'File.ReadAllLines(journal, new UTF8Encoding(false, true))'
    assert strict_read in recovery
    assert recovery.index(strict_read) < recovery.index('DeleteIfExistsStrict(previous)')
    assert recovery.index(strict_read) < recovery.index('File.Move(previous, _databasePath)')


def _read_restore_journal_with_injected_io(journal_path, read_bytes):
    """Model the journal's all-or-nothing read boundary before recovery mutations."""
    raw = read_bytes(journal_path)
    return raw.decode("utf-8", errors="strict").splitlines()


@pytest.mark.parametrize("failure", [PermissionError("access denied"), OSError("sharing violation")])
def test_restore_journal_io_read_failure_preserves_all_recovery_artifacts(tmp_path, failure):
    journal = tmp_path / "ledger.db.restore-journal"
    live = tmp_path / "ledger.db"
    previous = tmp_path / "ledger.db.pre-restore-0123456789abcdef0123456789abcdef"
    previous_wal = Path(str(previous) + "-wal")
    previous_shm = Path(str(previous) + "-shm")
    live.write_bytes(b"verified-live-db")
    previous.write_bytes(b"rollback-db")
    previous_wal.write_bytes(b"rollback-wal")
    previous_shm.write_bytes(b"rollback-shm")
    journal.write_bytes(b"valid-looking-journal")
    before = {path: path.read_bytes() for path in (live, previous, previous_wal, previous_shm, journal)}

    def unreadable(_path):
        raise failure

    with pytest.raises(type(failure)):
        _read_restore_journal_with_injected_io(journal, unreadable)

    assert {path: path.read_bytes() for path in before} == before


def test_csharp_journal_io_read_is_a_fail_closed_boundary_before_any_recovery_mutation():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private void RecoverInterruptedRestore()")
    end = source.index("private static void WriteRestoreJournal(", start)
    recovery = source[start:end]
    read = "File.ReadAllLines(journal, new UTF8Encoding(false, true))"
    assert read in recovery
    assert recovery.index(read) < recovery.index("File.Move(previous, _databasePath)")
    assert recovery.index(read) < recovery.index("DeleteIfExistsStrict(previous)")
    # The journal read is not wrapped in a catch that would continue recovery on IO failure.
    assert "catch" not in recovery[:recovery.index(read)]


@pytest.mark.parametrize("failure_point", [
    "remove-live-db",
    "move-rollback-db",
    "remove-live-wal",
    "move-rollback-wal",
    "remove-live-shm",
    "move-rollback-shm",
])
def test_prepared_recovery_filesystem_io_failure_preserves_retry_state(tmp_path, monkeypatch, failure_point):
    """A one-shot filesystem failure must leave enough journal/artifacts for retry."""
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    journal = tmp_path / "live.db.restore-journal"
    live.write_bytes(b"uncommitted-new-db")
    previous.write_bytes(b"known-good-old-db")
    live_wal.write_bytes(b"new-wal")
    previous_wal.write_bytes(b"known-good-old-wal")
    live_shm.write_bytes(b"new-shm")
    previous_shm.write_bytes(b"known-good-old-shm")
    journal.write_bytes(b"durable-prepared-journal")

    original_unlink = Path.unlink
    original_replace = Path.replace
    failed = {"value": False}
    unlink_targets = {
        "remove-live-db": live.name,
        "remove-live-wal": live_wal.name,
        "remove-live-shm": live_shm.name,
    }
    replace_targets = {
        "move-rollback-db": previous.name,
        "move-rollback-wal": previous_wal.name,
        "move-rollback-shm": previous_shm.name,
    }

    def injected_unlink(path, *args, **kwargs):
        if not failed["value"] and failure_point in unlink_targets and path.name == unlink_targets[failure_point]:
            failed["value"] = True
            raise PermissionError("simulated access denied during recovery cleanup")
        return original_unlink(path, *args, **kwargs)

    def injected_replace(path, target):
        if not failed["value"] and failure_point in replace_targets and path.name == replace_targets[failure_point]:
            failed["value"] = True
            raise PermissionError("simulated sharing violation during recovery move")
        return original_replace(path, target)

    monkeypatch.setattr(Path, "unlink", injected_unlink)
    monkeypatch.setattr(Path, "replace", injected_replace)
    with pytest.raises(PermissionError):
        _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, True, "prepared")
    assert failed["value"] is True
    assert journal.read_bytes() == b"durable-prepared-journal"

    # Retry with the real filesystem methods, as would happen on a later startup.
    monkeypatch.setattr(Path, "unlink", original_unlink)
    monkeypatch.setattr(Path, "replace", original_replace)
    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, True, "prepared")

    assert live.read_bytes() == b"known-good-old-db"
    assert live_wal.read_bytes() == b"known-good-old-wal"
    assert live_shm.read_bytes() == b"known-good-old-shm"
    assert previous.exists() is False
    assert previous_wal.exists() is False
    assert previous_shm.exists() is False
    assert journal.read_bytes() == b"durable-prepared-journal"


def test_csharp_prepared_recovery_uses_propagating_file_moves_and_strict_deletes():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private void RecoverInterruptedRestore()")
    end = source.index("private static void WriteRestoreJournal(", start)
    recovery = source[start:end]
    assert "File.Move(previous, _databasePath);" in recovery
    sidecar = source[source.index("private static void RestoreSidecar("):source.index("private static void CreateConsistentSqliteCopy(")]
    assert "File.Move(quarantinedPath, livePath);" in sidecar
    assert "if (File.Exists(livePath)) File.Delete(livePath);" in sidecar
    assert "TryDelete(_databasePath);" in recovery
    assert "DeleteIfExistsStrict(previous);" in recovery
    assert "DeleteIfExistsStrict(previousWal);" in recovery
    assert "DeleteIfExistsStrict(previousShm);" in recovery
    assert "catch" not in recovery


@pytest.mark.parametrize("first_failure,second_failure", [
    ("remove-live-db", "move-rollback-wal"),
    ("move-rollback-db", "move-rollback-shm"),
    ("remove-live-wal", "move-rollback-shm"),
])
def test_prepared_recovery_survives_two_separate_io_failures_across_three_attempts(
    tmp_path, monkeypatch, first_failure, second_failure
):
    """Two independent transient I/O failures must retain enough state for a third startup."""
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    journal = tmp_path / "live.db.restore-journal"
    expected = {
        live: b"known-good-old-db",
        live_wal: b"known-good-old-wal",
        live_shm: b"known-good-old-shm",
    }
    live.write_bytes(b"uncommitted-new-db")
    previous.write_bytes(expected[live])
    previous_wal.write_bytes(expected[live_wal])
    previous_shm.write_bytes(expected[live_shm])
    live_wal.write_bytes(b"uncommitted-new-wal")
    live_shm.write_bytes(b"uncommitted-new-shm")
    journal.write_bytes(b"durable-prepared-journal")

    original_unlink = Path.unlink
    original_replace = Path.replace
    failed_points = set()
    unlink_targets = {
        "remove-live-db": live.name,
        "remove-live-wal": live_wal.name,
        "remove-live-shm": live_shm.name,
    }
    replace_targets = {
        "move-rollback-db": previous.name,
        "move-rollback-wal": previous_wal.name,
        "move-rollback-shm": previous_shm.name,
    }

    def inject(point, message):
        if point in (first_failure, second_failure) and point not in failed_points:
            failed_points.add(point)
            raise PermissionError(message)

    def injected_unlink(path, *args, **kwargs):
        for point, filename in unlink_targets.items():
            if path.name == filename:
                inject(point, "simulated repeated-recovery delete denial")
        return original_unlink(path, *args, **kwargs)

    def injected_replace(path, target):
        for point, filename in replace_targets.items():
            if path.name == filename:
                inject(point, "simulated repeated-recovery move denial")
        return original_replace(path, target)

    monkeypatch.setattr(Path, "unlink", injected_unlink)
    monkeypatch.setattr(Path, "replace", injected_replace)

    for expected_failure in (first_failure, second_failure):
        with pytest.raises(PermissionError):
            _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, True, "prepared")
        assert expected_failure in failed_points
        assert journal.read_bytes() == b"durable-prepared-journal"

    monkeypatch.setattr(Path, "unlink", original_unlink)
    monkeypatch.setattr(Path, "replace", original_replace)
    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm, True, "prepared")

    assert live.read_bytes() == expected[live]
    assert live_wal.read_bytes() == expected[live_wal]
    assert live_shm.read_bytes() == expected[live_shm]
    assert not previous.exists() and not previous_wal.exists() and not previous_shm.exists()
    assert journal.read_bytes() == b"durable-prepared-journal"


def test_first_restore_recovery_preserves_journal_when_unverified_live_delete_fails(
    tmp_path, monkeypatch
):
    """A locked first-restore DB must not be silently accepted after cleanup failure."""
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    journal = tmp_path / "live.db.restore-journal"
    live.write_bytes(b"unverified-new-db")
    previous_wal.write_bytes(b"original-wal")
    previous_shm.write_bytes(b"original-shm")
    journal.write_bytes(b"durable-prepared-journal")

    original_unlink = Path.unlink
    failed = False

    def fail_first_live_delete(path, *args, **kwargs):
        nonlocal failed
        if path == live and not failed:
            failed = True
            raise PermissionError("simulated locked unverified database")
        return original_unlink(path, *args, **kwargs)

    monkeypatch.setattr(Path, "unlink", fail_first_live_delete)
    import pytest
    with pytest.raises(PermissionError):
        _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                 False, "prepared")

    assert live.read_bytes() == b"unverified-new-db"
    assert previous_wal.read_bytes() == b"original-wal"
    assert previous_shm.read_bytes() == b"original-shm"
    assert journal.read_bytes() == b"durable-prepared-journal"

    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
             False, "prepared")
    assert not live.exists()
    assert live_wal.read_bytes() == b"original-wal"
    assert live_shm.read_bytes() == b"original-shm"
    assert not previous_wal.exists() and not previous_shm.exists()
    assert journal.read_bytes() == b"durable-prepared-journal"


def test_csharp_first_restore_unverified_database_deletion_is_strict_in_both_paths():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    assert source.count("DeleteIfExistsStrict(_databasePath);") >= 2
    restore_start = source.index("public RestoreResult Restore")
    recovery_start = source.index("private void RecoverInterruptedRestore()")
    recovery_end = source.index("private static void WriteRestoreJournal(", recovery_start)
    restore = source[restore_start:recovery_start]
    recovery = source[recovery_start:recovery_end]
    assert "else if (!hadPrevious)" in restore
    assert "else if (!hadPrevious)" in recovery
    assert "DeleteIfExistsStrict(_databasePath);" in restore
    assert "DeleteIfExistsStrict(_databasePath);" in recovery


@pytest.mark.parametrize("failure_point", [
    "remove-live-wal",
    "move-previous-wal",
    "remove-live-shm",
    "move-previous-shm",
])
def test_first_restore_recovery_sidecar_io_failure_keeps_journal_for_retry(
    tmp_path, monkeypatch, failure_point
):
    """After strict first-restore DB removal, sidecar failures remain restartable."""
    import pytest

    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    journal = tmp_path / "live.db.restore-journal"
    live.write_bytes(b"unverified-first-restore-db")
    live_wal.write_bytes(b"new-wal")
    previous_wal.write_bytes(b"original-wal")
    live_shm.write_bytes(b"new-shm")
    previous_shm.write_bytes(b"original-shm")
    journal.write_bytes(b"durable-prepared-journal")

    original_unlink = Path.unlink
    original_replace = Path.replace
    failed = False

    def fail_once_unlink(path, *args, **kwargs):
        nonlocal failed
        target = ((failure_point == "remove-live-wal" and path == live_wal)
                  or (failure_point == "remove-live-shm" and path == live_shm))
        if target and not failed:
            failed = True
            raise PermissionError("simulated first-restore sidecar delete denial")
        return original_unlink(path, *args, **kwargs)

    def fail_once_replace(path, target, *args, **kwargs):
        nonlocal failed
        expected = ((failure_point == "move-previous-wal" and path == previous_wal)
                    or (failure_point == "move-previous-shm" and path == previous_shm))
        if expected and not failed:
            failed = True
            raise PermissionError("simulated first-restore sidecar move denial")
        return original_replace(path, target, *args, **kwargs)

    monkeypatch.setattr(Path, "unlink", fail_once_unlink)
    monkeypatch.setattr(Path, "replace", fail_once_replace)
    with pytest.raises(PermissionError):
        _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                 False, "prepared")

    assert failed
    assert not live.exists()  # strict first-restore DB removal already completed
    assert journal.read_bytes() == b"durable-prepared-journal"
    assert previous_wal.exists() or live_wal.exists()
    assert previous_shm.exists() or live_shm.exists()

    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
             False, "prepared")
    assert not live.exists()
    assert live_wal.read_bytes() == b"original-wal"
    assert live_shm.read_bytes() == b"original-shm"
    assert not previous_wal.exists() and not previous_shm.exists()
    assert journal.read_bytes() == b"durable-prepared-journal"


def test_csharp_first_restore_sidecar_recovery_keeps_journal_removal_after_both_moves():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private void RecoverInterruptedRestore()")
    end = source.index("private static void WriteRestoreJournal(", start)
    recovery = source[start:end]
    first_restore = recovery.index("else if (!hadPrevious)")
    strict_delete = recovery.index("DeleteIfExistsStrict(_databasePath);", first_restore)
    restore_wal = recovery.index("RestoreSidecar(previousWal, liveWal", strict_delete)
    restore_shm = recovery.index("RestoreSidecar(previousShm, liveShm", restore_wal)
    journal_delete = recovery.index("TryDelete(journal);", restore_shm)
    assert strict_delete < restore_wal < restore_shm < journal_delete


def test_first_restore_crash_after_both_sidecars_restored_keeps_journal_for_idempotent_restart(tmp_path):
    """A crash after the final sidecar move leaves only journal cleanup for restart."""
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    journal = tmp_path / "live.db.restore-journal"
    live.write_bytes(b"unverified-first-db")
    live_wal.write_bytes(b"new-wal")
    live_shm.write_bytes(b"new-shm")
    previous_wal.write_bytes(b"original-wal")
    previous_shm.write_bytes(b"original-shm")
    journal.write_bytes(b"durable-prepared-journal")

    # First-restore recovery has five mutations: remove DB, remove/move WAL,
    # then remove/move SHM. Termination after mutation five precedes journal cleanup.
    try:
        _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
                 False, "prepared", crash_after=5)
    except RuntimeError as exc:
        assert "simulated process termination" in str(exc)
    else:
        raise AssertionError("recovery did not terminate after the final sidecar move")

    assert not live.exists()
    assert live_wal.read_bytes() == b"original-wal"
    assert live_shm.read_bytes() == b"original-shm"
    assert not previous_wal.exists() and not previous_shm.exists()
    assert journal.read_bytes() == b"durable-prepared-journal"

    # A fresh process sees no quarantined sidecars, so the retry is idempotent.
    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
             False, "prepared")
    assert live_wal.read_bytes() == b"original-wal"
    assert live_shm.read_bytes() == b"original-shm"
    assert journal.read_bytes() == b"durable-prepared-journal"
    journal.unlink()
    assert not journal.exists()


def test_first_restore_journal_cleanup_access_failure_is_retryable(tmp_path, monkeypatch):
    """Best-effort journal deletion failure must leave a harmless retry marker."""
    live, previous, live_wal, previous_wal, live_shm, previous_shm = _paths(tmp_path)
    journal = tmp_path / "live.db.restore-journal"
    live.write_bytes(b"unverified-first-db")
    live_wal.write_bytes(b"new-wal")
    live_shm.write_bytes(b"new-shm")
    previous_wal.write_bytes(b"original-wal")
    previous_shm.write_bytes(b"original-shm")
    journal.write_bytes(b"durable-prepared-journal")

    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
             False, "prepared")
    original_unlink = Path.unlink
    failed = False

    def fail_journal_once(path, *args, **kwargs):
        nonlocal failed
        if path == journal and not failed:
            failed = True
            raise PermissionError("simulated journal cleanup access denial")
        return original_unlink(path, *args, **kwargs)

    monkeypatch.setattr(Path, "unlink", fail_journal_once)
    try:
        journal.unlink()
    except PermissionError:
        pass
    else:
        raise AssertionError("journal deletion fault was not injected")

    assert failed and journal.read_bytes() == b"durable-prepared-journal"
    assert not live.exists()
    assert live_wal.read_bytes() == b"original-wal"
    assert live_shm.read_bytes() == b"original-shm"

    _recover(live, previous, live_wal, previous_wal, live_shm, previous_shm,
             False, "prepared")
    journal.unlink()
    assert not journal.exists()
    assert live_wal.read_bytes() == b"original-wal"
    assert live_shm.read_bytes() == b"original-shm"


def test_csharp_first_restore_journal_cleanup_is_after_sidecars_and_best_effort():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private void RecoverInterruptedRestore()")
    end = source.index("private static void WriteRestoreJournal(", start)
    recovery = source[start:end]
    wal = recovery.index("RestoreSidecar(previousWal, liveWal")
    shm = recovery.index("RestoreSidecar(previousShm, liveShm", wal)
    journal_cleanup = recovery.index("TryDelete(journal);", shm)
    try_delete = source[source.index("private static void TryDelete("):]
    assert wal < shm < journal_cleanup
    assert "catch { /* best-effort cleanup; never mask primary operation */ }" in try_delete


def test_abandoned_restore_journal_temp_is_removed_without_a_published_journal(tmp_path):
    journal = tmp_path / "live.db.restore-journal"
    abandoned = tmp_path / (journal.name + ".tmp-" + "a" * 32)
    abandoned.write_bytes(b"complete-but-unpublished-journal")
    _cleanup_abandoned_journal_temps(journal)
    assert not abandoned.exists()
    assert not journal.exists()


def test_abandoned_restore_journal_temp_is_removed_while_published_prepared_journal_is_preserved(tmp_path):
    journal = tmp_path / "live.db.restore-journal"
    journal.write_bytes(b"durable-prepared-journal")
    abandoned = tmp_path / (journal.name + ".tmp-" + "b" * 32)
    abandoned.write_bytes(b"unpublished-committed-journal")
    _cleanup_abandoned_journal_temps(journal)
    assert journal.read_bytes() == b"durable-prepared-journal"
    assert not abandoned.exists()


def test_malformed_restore_journal_temp_name_is_not_deleted(tmp_path):
    journal = tmp_path / "live.db.restore-journal"
    malformed = tmp_path / (journal.name + ".tmp-not-a-guid")
    malformed.write_bytes(b"unrecognized-file")
    _cleanup_abandoned_journal_temps(journal)
    assert malformed.read_bytes() == b"unrecognized-file"


def test_csharp_recovery_cleans_only_exact_guid_temps_before_reading_journal():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    recovery = source[source.index("private void RecoverInterruptedRestore()"):source.index("private static void CleanupAbandonedRestoreJournalTemps")]
    cleanup = source[source.index("private static void CleanupAbandonedRestoreJournalTemps"):source.index("private static void WriteRestoreJournal")]
    assert recovery.index("CleanupAbandonedRestoreJournalTemps(journal);") < recovery.index("File.Exists(journal)")
    assert 'Path.GetFileName(journalPath) + ".tmp-*"' in cleanup
    assert 'token.Length != 32 || !Guid.TryParseExact(token, "N", out temporaryId)' in cleanup
    assert "DeleteIfExistsStrict(candidate);" in cleanup


def _publish_restore_journal_model(journal, temporary, payload, publish_mode,
                                   fail_publish=False, fail_temp_cleanup=False,
                                   after_publish=None):
    """Model exclusive temp ownership and atomic Move/Replace publication."""
    created_temporary = False
    published_temporary = False
    try:
        with temporary.open("xb") as stream:
            created_temporary = True
            stream.write(payload)
            stream.flush()
        if fail_publish:
            raise OSError("simulated atomic journal publication failure")
        if publish_mode == "replace":
            temporary.replace(journal)
        elif publish_mode == "move":
            temporary.rename(journal)
        else:
            raise ValueError("unsupported publication mode")
        published_temporary = True
        if after_publish is not None:
            after_publish()
    finally:
        if created_temporary and not published_temporary and temporary.exists():
            if fail_temp_cleanup:
                raise PermissionError("simulated temporary cleanup failure")
            temporary.unlink()


def test_failed_atomic_replace_preserves_published_journal_and_cleans_temp(tmp_path):
    journal = tmp_path / "live.db.restore-journal"
    temporary = tmp_path / (journal.name + ".tmp-" + "c" * 32)
    journal.write_bytes(b"previous-durable-prepared-journal")

    try:
        _publish_restore_journal_model(
            journal, temporary, b"new-committed-journal", "replace", fail_publish=True)
    except OSError:
        pass
    else:
        raise AssertionError("replace publication failure was not injected")

    assert journal.read_bytes() == b"previous-durable-prepared-journal"
    assert not temporary.exists()


def test_failed_initial_atomic_move_leaves_no_published_journal(tmp_path):
    journal = tmp_path / "live.db.restore-journal"
    temporary = tmp_path / (journal.name + ".tmp-" + "d" * 32)

    try:
        _publish_restore_journal_model(
            journal, temporary, b"prepared-journal", "move", fail_publish=True)
    except OSError:
        pass
    else:
        raise AssertionError("move publication failure was not injected")

    assert not journal.exists()
    assert not temporary.exists()


def test_failed_replace_and_temp_cleanup_is_recovered_on_next_startup(tmp_path):
    journal = tmp_path / "live.db.restore-journal"
    temporary = tmp_path / (journal.name + ".tmp-" + "e" * 32)
    journal.write_bytes(b"durable-prepared-journal")

    try:
        _publish_restore_journal_model(
            journal, temporary, b"unpublished-committed-journal", "replace",
            fail_publish=True, fail_temp_cleanup=True)
    except PermissionError:
        pass
    else:
        raise AssertionError("temporary cleanup failure was not injected")

    assert journal.read_bytes() == b"durable-prepared-journal"
    assert temporary.read_bytes() == b"unpublished-committed-journal"

    _cleanup_abandoned_journal_temps(journal)
    assert journal.read_bytes() == b"durable-prepared-journal"
    assert not temporary.exists()


def test_successful_move_and_replace_preserve_reused_former_temp_path(tmp_path):
    """Neither publication mode may clean a new entry at the former temp name."""
    for mode in ("move", "replace"):
        case = tmp_path / mode
        case.mkdir()
        journal = case / "live.db.restore-journal"
        temporary = case / (journal.name + ".tmp-" + ("a" if mode == "move" else "b") * 32)
        unrelated = b"created-after-atomic-publication"

        def reuse_former_temp_name():
            temporary.write_bytes(unrelated)

        _publish_restore_journal_model(
            journal, temporary, (mode + "-journal").encode("ascii"), mode,
            after_publish=reuse_former_temp_name)

        assert journal.read_bytes() == (mode + "-journal").encode("ascii")
        assert temporary.read_bytes() == unrelated


def test_csharp_journal_publication_uses_durable_temp_and_atomic_move_or_replace():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private static void WriteRestoreJournal(")
    end = source.index("private static bool IsValidJournalChecksum(", start)
    writer = source[start:end]
    assert 'journalPath + ".tmp-" + Guid.NewGuid().ToString("N")' in writer
    assert "stream.Flush(true);" in writer
    assert "if (File.Exists(journalPath)) File.Replace(temporary, journalPath, null);" in writer
    assert "else File.Move(temporary, journalPath);" in writer
    assert "if (createdTemporary && !publishedTemporary) TryDelete(temporary);" in writer


# Startup temp-cleanup failure boundaries: a failure must stop recovery before
# the journal is read or any database/sidecar mutation is attempted.
def test_abandoned_temp_delete_failure_is_strict_and_retryable(tmp_path):
    journal = tmp_path / "live.db.restore-journal"
    journal.write_bytes(b"durable-prepared-journal")
    temporary = tmp_path / (journal.name + ".tmp-" + "f" * 32)
    temporary.write_bytes(b"orphan-temp")

    def deny_delete(_candidate):
        raise PermissionError("simulated sharing violation")

    try:
        _cleanup_abandoned_journal_temps(journal, delete_fn=deny_delete)
    except PermissionError:
        pass
    else:
        raise AssertionError("strict abandoned-temp deletion failure was swallowed")

    assert journal.read_bytes() == b"durable-prepared-journal"
    assert temporary.read_bytes() == b"orphan-temp"

    _cleanup_abandoned_journal_temps(journal)
    assert journal.read_bytes() == b"durable-prepared-journal"
    assert not temporary.exists()


def test_abandoned_temp_enumeration_failure_stops_before_recovery_mutations(tmp_path):
    journal = tmp_path / "live.db.restore-journal"
    journal.write_bytes(b"durable-prepared-journal")
    temporary = tmp_path / (journal.name + ".tmp-" + "1" * 32)
    temporary.write_bytes(b"orphan-temp")
    live = tmp_path / "live.db"
    live.write_bytes(b"live-database")

    def deny_enumeration():
        raise PermissionError("simulated directory enumeration denial")

    try:
        _cleanup_abandoned_journal_temps(journal, enumerate_fn=deny_enumeration)
    except PermissionError:
        pass
    else:
        raise AssertionError("directory enumeration failure was swallowed")

    assert journal.read_bytes() == b"durable-prepared-journal"
    assert temporary.read_bytes() == b"orphan-temp"
    assert live.read_bytes() == b"live-database"


def test_csharp_abandoned_temp_cleanup_propagates_enumeration_and_delete_errors():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private static void CleanupAbandonedRestoreJournalTemps(")
    end = source.index("private static void WriteRestoreJournal(", start)
    cleanup = source[start:end]
    assert "Directory.EnumerateFiles(directory, pattern, SearchOption.TopDirectoryOnly)" in cleanup
    assert "DeleteIfExistsStrict(candidate);" in cleanup
    assert "catch" not in cleanup


def test_partial_temp_enumeration_failure_is_fail_closed_and_retryable(tmp_path):
    """A lazy directory scan may fail after yielding entries; retry cleans the remainder."""
    journal = tmp_path / "live.db.restore-journal"
    journal.write_bytes(b"durable-prepared-journal")
    first = tmp_path / (journal.name + ".tmp-" + "2" * 32)
    second = tmp_path / (journal.name + ".tmp-" + "3" * 32)
    first.write_bytes(b"first-orphan")
    second.write_bytes(b"second-orphan")
    live = tmp_path / "live.db"
    live.write_bytes(b"live-database")

    def fail_after_first():
        yield first
        raise PermissionError("simulated mid-enumeration directory failure")

    try:
        _cleanup_abandoned_journal_temps(journal, enumerate_fn=fail_after_first)
    except PermissionError:
        pass
    else:
        raise AssertionError("mid-enumeration failure was swallowed")

    # The yielded item may already be removed, but startup must abort before
    # journal processing; the not-yet-yielded item remains for the next pass.
    assert not first.exists()
    assert second.read_bytes() == b"second-orphan"
    assert journal.read_bytes() == b"durable-prepared-journal"
    assert live.read_bytes() == b"live-database"

    _cleanup_abandoned_journal_temps(journal)
    assert not second.exists()
    assert journal.read_bytes() == b"durable-prepared-journal"
    assert live.read_bytes() == b"live-database"


def test_temp_cleanup_does_not_touch_another_database_journal_namespace(tmp_path):
    journal = tmp_path / "live.db.restore-journal"
    other_journal = tmp_path / "archive.db.restore-journal"
    target_temp = tmp_path / (journal.name + ".tmp-" + "4" * 32)
    other_temp = tmp_path / (other_journal.name + ".tmp-" + "5" * 32)
    target_temp.write_bytes(b"target-orphan")
    other_temp.write_bytes(b"other-database-orphan")

    _cleanup_abandoned_journal_temps(journal)

    assert not target_temp.exists()
    assert other_temp.read_bytes() == b"other-database-orphan"



def test_temp_cleanup_preserves_malformed_guid_suffixes(tmp_path):
    journal = tmp_path / "live.db.restore-journal"
    malformed = [
        tmp_path / (journal.name + ".tmp-" + "g" * 32),
        tmp_path / (journal.name + ".tmp-short"),
        tmp_path / (journal.name + ".tmp-" + "a" * 31),
        tmp_path / (journal.name + ".tmp-" + "a" * 33),
    ]
    for index, candidate in enumerate(malformed):
        candidate.write_bytes(f"preserve-{index}".encode())

    _cleanup_abandoned_journal_temps(journal)

    assert [candidate.read_bytes() for candidate in malformed] == [
        b"preserve-0", b"preserve-1", b"preserve-2", b"preserve-3"
    ]


def test_temp_cleanup_accepts_uppercase_guid_n_and_preserves_non_file_entries(tmp_path):
    journal = tmp_path / "live.db.restore-journal"
    valid_uppercase = tmp_path / (journal.name + ".tmp-" + "ABCDEF0123456789ABCDEF0123456789")
    valid_uppercase.write_bytes(b"orphan")
    directory_entry = tmp_path / (journal.name + ".tmp-" + "6" * 32)
    directory_entry.mkdir()
    marker = directory_entry / "keep.txt"
    marker.write_bytes(b"directory-content")

    _cleanup_abandoned_journal_temps(journal)

    assert not valid_uppercase.exists()
    assert directory_entry.is_dir()
    assert marker.read_bytes() == b"directory-content"


def test_temp_cleanup_does_not_delete_similarly_prefixed_other_journal_files(tmp_path):
    journal = tmp_path / "live.db.restore-journal"
    exact = tmp_path / (journal.name + ".tmp-" + "7" * 32)
    similar = tmp_path / (journal.name + ".tmp-extra-" + "8" * 32)
    exact.write_bytes(b"exact-orphan")
    similar.write_bytes(b"not-an-exact-guid-temp")

    _cleanup_abandoned_journal_temps(journal)

    assert not exact.exists()
    assert similar.read_bytes() == b"not-an-exact-guid-temp"

def test_csharp_temp_cleanup_uses_streaming_enumeration_before_journal_processing():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    recovery_start = source.index("private void RecoverInterruptedRestore()")
    cleanup_start = source.index("private static void CleanupAbandonedRestoreJournalTemps(")
    writer_start = source.index("private static void WriteRestoreJournal(")
    recovery = source[recovery_start:cleanup_start]
    cleanup = source[cleanup_start:writer_start]
    assert "CleanupAbandonedRestoreJournalTemps(journal);" in recovery
    assert recovery.index("CleanupAbandonedRestoreJournalTemps(journal);") < recovery.index("File.Exists(journal)")
    assert "foreach (var candidate in Directory.EnumerateFiles(directory, pattern, SearchOption.TopDirectoryOnly))" in cleanup
    assert "ToArray(" not in cleanup and "ToList(" not in cleanup


def test_temp_cleanup_removes_matching_file_symlink_without_touching_target(tmp_path):
    """Deleting an orphan temp link must unlink only the entry, never its target."""
    journal = tmp_path / "live.db.restore-journal"
    target = tmp_path / "important-outside-artifact.bin"
    target.write_bytes(b"do-not-delete-or-modify")
    link = tmp_path / (journal.name + ".tmp-" + "8" * 32)
    try:
        link.symlink_to(target)
    except (OSError, NotImplementedError) as exc:
        import pytest
        pytest.skip(f"symbolic links are unavailable in this environment: {exc}")

    _cleanup_abandoned_journal_temps(journal)

    assert not link.is_symlink()
    assert target.read_bytes() == b"do-not-delete-or-modify"


def test_temp_cleanup_unlinks_matching_hardlink_without_affecting_original(tmp_path):
    """Removing the temp directory entry must not damage another hard link."""
    journal = tmp_path / "live.db.restore-journal"
    original = tmp_path / "retained-artifact.bin"
    original.write_bytes(b"shared-inode-content")
    link = tmp_path / (journal.name + ".tmp-" + "9" * 32)
    try:
        link.hardlink_to(original)
    except (OSError, NotImplementedError) as exc:
        import pytest
        pytest.skip(f"hard links are unavailable in this environment: {exc}")

    assert link.read_bytes() == original.read_bytes()
    _cleanup_abandoned_journal_temps(journal)

    assert not link.exists()
    assert original.read_bytes() == b"shared-inode-content"


def test_temp_cleanup_hardlink_in_another_directory_decrements_only_link_count(tmp_path):
    """Unlinking an orphan hard link must preserve an external same-volume name."""
    journal_dir = tmp_path / "database"
    retained_dir = tmp_path / "retained"
    journal_dir.mkdir()
    retained_dir.mkdir()
    journal = journal_dir / "live.db.restore-journal"
    original = retained_dir / "important-artifact.bin"
    original.write_bytes(b"externally-retained-inode")
    link = journal_dir / (journal.name + ".tmp-" + "a" * 32)
    try:
        link.hardlink_to(original)
    except (OSError, NotImplementedError) as exc:
        import pytest
        pytest.skip(f"cross-directory hard links are unavailable in this environment: {exc}")

    import os
    before = os.stat(original).st_nlink
    assert before >= 2
    _cleanup_abandoned_journal_temps(journal)

    assert not link.exists()
    assert original.read_bytes() == b"externally-retained-inode"
    assert os.stat(original).st_nlink == before - 1


def test_temp_cleanup_tolerates_candidate_disappearing_after_enumeration(tmp_path):
    """A temp removed by a concurrent actor after enumeration remains an idempotent delete."""
    journal = tmp_path / "live.db.restore-journal"
    candidate = tmp_path / (journal.name + ".tmp-" + "b" * 32)
    candidate.write_bytes(b"orphan-temp")

    def enumerate_then_yield():
        # The path is captured as if Directory.EnumerateFiles had already yielded it.
        yield candidate

    def delete_if_present(path):
        # Model File.Delete semantics: deleting a missing file is a no-op.
        path.unlink(missing_ok=True)

    # Simulate another process removing the entry between enumeration and our delete.
    candidate.unlink()
    _cleanup_abandoned_journal_temps(
        journal, enumerate_fn=enumerate_then_yield, delete_fn=delete_if_present
    )
    assert not candidate.exists()


def test_csharp_strict_delete_retains_idempotent_file_delete_contract():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private static void DeleteIfExistsStrict(")
    end = source.index("private static void TryDelete(", start)
    strict_delete = source[start:end]
    assert "File.Delete(path);" in strict_delete
    assert "File.Exists(path)" not in strict_delete


def test_csharp_strict_temp_deletion_is_single_entry_file_delete():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private static void DeleteIfExistsStrict(")
    end = source.index("private static void TryDelete(", start)
    strict_delete = source[start:end]
    assert "File.Delete(path);" in strict_delete
    assert "Directory.Delete" not in strict_delete
    assert "DirectoryInfo" not in strict_delete


def test_temp_cleanup_fails_closed_if_candidate_becomes_directory_after_enumeration(tmp_path):
    """A file-to-directory race must not turn strict file cleanup into recursion."""
    import pytest

    journal = tmp_path / "live.db.restore-journal"
    candidate = tmp_path / (journal.name + ".tmp-" + "c" * 32)
    captured = [candidate]
    candidate.mkdir()
    protected = candidate / "keep.bin"
    protected.write_bytes(b"preserve-directory-and-content")

    def enumerate_captured_path():
        # Directory.EnumerateFiles yielded this path before another actor replaced it.
        yield captured[0]

    def strict_file_delete(path):
        # Model File.Delete's refusal to delete a directory; never recurse.
        if path.is_dir():
            raise IsADirectoryError(str(path))
        path.unlink()

    with pytest.raises(IsADirectoryError):
        _cleanup_abandoned_journal_temps(
            journal, enumerate_fn=enumerate_captured_path, delete_fn=strict_file_delete
        )

    assert candidate.is_dir()
    assert protected.read_bytes() == b"preserve-directory-and-content"

    # Once the racing directory is removed, a later retry can clean the regular file.
    protected.unlink()
    candidate.rmdir()
    candidate.write_bytes(b"orphan-temp-after-race")
    _cleanup_abandoned_journal_temps(
        journal,
        enumerate_fn=lambda: iter([candidate]),
        delete_fn=strict_file_delete,
    )
    assert not candidate.exists()


def test_csharp_temp_cleanup_keeps_file_only_delete_and_does_not_recurse_on_race():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private static void CleanupAbandonedRestoreJournalTemps(")
    end = source.index("\n    private ", start + 1)
    cleanup = source[start:end]
    assert "Directory.EnumerateFiles(directory, pattern, SearchOption.TopDirectoryOnly)" in cleanup
    assert "DeleteIfExistsStrict(candidate);" in cleanup
    assert "Directory.Delete" not in cleanup
    assert "SearchOption.AllDirectories" not in cleanup


def test_temp_cleanup_fails_closed_if_candidate_becomes_directory_symlink_after_enumeration(tmp_path):
    """A raced directory symlink must not cause recursive deletion of its target."""
    import pytest

    journal = tmp_path / "live.db.restore-journal"
    target_dir = tmp_path / "protected-target"
    target_dir.mkdir()
    protected = target_dir / "keep.bin"
    protected.write_bytes(b"preserve-symlink-target-and-content")
    candidate = tmp_path / (journal.name + ".tmp-" + "d" * 32)

    try:
        candidate.symlink_to(target_dir, target_is_directory=True)
    except (OSError, NotImplementedError) as exc:
        pytest.skip(f"directory symbolic links are unavailable in this environment: {exc}")

    def enumerate_captured_path():
        # Simulate a file path already yielded before it was replaced by a directory link.
        yield candidate

    def strict_file_delete(path):
        # File-only cleanup must not follow a directory link or recurse into its target.
        if path.is_dir():
            raise IsADirectoryError(str(path))
        path.unlink()

    with pytest.raises(IsADirectoryError):
        _cleanup_abandoned_journal_temps(
            journal, enumerate_fn=enumerate_captured_path, delete_fn=strict_file_delete
        )

    assert candidate.is_symlink()
    assert target_dir.is_dir()
    assert protected.read_bytes() == b"preserve-symlink-target-and-content"

    # Remove only the raced link, then prove a normal orphan file is retry-cleanable.
    candidate.unlink()
    candidate.write_bytes(b"regular-temp-after-reparse-race")
    _cleanup_abandoned_journal_temps(
        journal,
        enumerate_fn=lambda: iter([candidate]),
        delete_fn=strict_file_delete,
    )
    assert not candidate.exists()
    assert protected.read_bytes() == b"preserve-symlink-target-and-content"


def test_csharp_temp_cleanup_does_not_add_directory_symlink_recursive_fallback():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private static void DeleteIfExistsStrict(")
    end = source.index("private static void TryDelete(", start)
    strict_delete = source[start:end]
    assert "File.Delete(path);" in strict_delete
    assert "Directory.Delete" not in strict_delete
    assert "SearchOption.AllDirectories" not in source


def test_temp_cleanup_unlinks_dangling_symlink_entry_and_is_idempotent(tmp_path):
    """A matching dangling symlink is an entry to unlink, not a target to follow."""
    import pytest

    journal = tmp_path / "live.db.restore-journal"
    candidate = tmp_path / (journal.name + ".tmp-" + "e" * 32)
    missing_target = tmp_path / "target-that-must-remain-missing"
    try:
        candidate.symlink_to(missing_target)
    except (OSError, NotImplementedError) as exc:
        pytest.skip(f"symbolic links are unavailable in this environment: {exc}")

    assert candidate.is_symlink()
    assert not missing_target.exists()

    # Directory.EnumerateFiles reports the directory entry; File.Delete removes the link.
    enumerate_entry = lambda: iter([candidate])
    _cleanup_abandoned_journal_temps(
        journal,
        enumerate_fn=enumerate_entry,
        delete_fn=lambda path: path.unlink(),
    )
    assert not candidate.is_symlink()
    assert not missing_target.exists()

    # A repeated cleanup after the entry is gone remains harmless.
    _cleanup_abandoned_journal_temps(
        journal,
        enumerate_fn=lambda: iter([candidate]),
        delete_fn=lambda path: path.unlink(missing_ok=True),
    )
    assert not candidate.exists()
    assert not missing_target.exists()


def test_csharp_temp_cleanup_keeps_direct_file_delete_for_dangling_symlink_entries():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private static void DeleteIfExistsStrict(")
    end = source.index("private static void TryDelete(", start)
    strict_delete = source[start:end]
    assert "File.Delete(path);" in strict_delete
    assert "File.Exists(path)" not in strict_delete
    assert "Directory.Delete" not in strict_delete


def test_temp_cleanup_unlinks_symlink_even_if_missing_target_appears_after_enumeration(tmp_path):
    """A target created during the race must remain untouched when its link is removed."""
    import pytest

    journal = tmp_path / "live.db.restore-journal"
    candidate = tmp_path / (journal.name + ".tmp-" + "f" * 32)
    target = tmp_path / "target-created-during-cleanup-race.bin"
    try:
        candidate.symlink_to(target)
    except (OSError, NotImplementedError) as exc:
        pytest.skip(f"symbolic links are unavailable in this environment: {exc}")

    assert candidate.is_symlink()
    assert not target.exists()

    def create_target_then_unlink_link(path):
        # Simulate another actor creating the previously missing target after
        # enumeration captured the link but before strict deletion runs.
        target.write_bytes(b"created-after-enumeration")
        path.unlink()

    _cleanup_abandoned_journal_temps(
        journal,
        enumerate_fn=lambda: iter([candidate]),
        delete_fn=create_target_then_unlink_link,
    )

    assert not candidate.is_symlink()
    assert target.read_bytes() == b"created-after-enumeration"


def test_csharp_temp_cleanup_does_not_resolve_symlink_target_before_unlinking():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private static void DeleteIfExistsStrict(")
    end = source.index("private static void TryDelete(", start)
    strict_delete = source[start:end]
    assert "File.Delete(path);" in strict_delete
    assert "FileInfo" not in strict_delete
    assert "ResolveLinkTarget" not in strict_delete
    assert "Directory.Delete" not in strict_delete


def test_temp_cleanup_unlinks_file_symlink_replacement_without_touching_existing_target(tmp_path):
    """A raced file symlink is removed as one entry while its existing target survives."""
    import pytest

    journal = tmp_path / "live.db.restore-journal"
    candidate = tmp_path / (journal.name + ".tmp-" + "1" * 32)
    target = tmp_path / "retained-target-file.bin"
    target.write_bytes(b"preserve-existing-target-bytes")

    # Model a regular temp returned by enumeration and then replaced by a file symlink.
    candidate.write_bytes(b"enumerated-temp")
    captured = candidate
    candidate.unlink()
    try:
        candidate.symlink_to(target)
    except (OSError, NotImplementedError) as exc:
        pytest.skip(f"symbolic links are unavailable in this environment: {exc}")

    assert captured.is_symlink()
    assert captured.read_bytes() == b"preserve-existing-target-bytes"

    def strict_file_delete(path):
        # A file symlink is not a directory; unlink removes the link, not its target.
        if path.is_dir():
            raise IsADirectoryError(str(path))
        path.unlink()

    _cleanup_abandoned_journal_temps(
        journal,
        enumerate_fn=lambda: iter([captured]),
        delete_fn=strict_file_delete,
    )

    assert not candidate.is_symlink()
    assert not candidate.exists()
    assert target.read_bytes() == b"preserve-existing-target-bytes"


def test_csharp_temp_cleanup_preserves_single_entry_delete_for_file_symlink_replacement():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private static void DeleteIfExistsStrict(")
    end = source.index("private static void TryDelete(", start)
    strict_delete = source[start:end]
    assert "File.Delete(path);" in strict_delete
    assert "File.Exists(path)" not in strict_delete
    assert "ResolveLinkTarget" not in strict_delete
    assert "Directory.Delete" not in strict_delete


def test_temp_cleanup_unlinks_hardlink_replacement_without_touching_retained_name(tmp_path):
    """A temp replaced by a hard link is removed by name, not by inode contents."""
    import os
    import pytest

    journal = tmp_path / "live.db.restore-journal"
    candidate = tmp_path / (journal.name + ".tmp-" + "2" * 32)
    retained = tmp_path / "retained-hardlink-target.bin"
    retained.write_bytes(b"preserve-hardlinked-inode-content")

    # Model enumeration of a regular temp followed by replacement with a hard link.
    candidate.write_bytes(b"enumerated-temp")
    captured = candidate
    candidate.unlink()
    try:
        candidate.hardlink_to(retained)
    except (OSError, NotImplementedError) as exc:
        pytest.skip(f"hard links are unavailable in this environment: {exc}")

    before = os.stat(retained).st_nlink
    assert before >= 2
    assert captured.read_bytes() == b"preserve-hardlinked-inode-content"

    _cleanup_abandoned_journal_temps(
        journal,
        enumerate_fn=lambda: iter([captured]),
        delete_fn=lambda path: path.unlink(),
    )

    assert not candidate.exists()
    assert retained.read_bytes() == b"preserve-hardlinked-inode-content"
    assert os.stat(retained).st_nlink == before - 1


def test_csharp_temp_cleanup_keeps_single_entry_delete_for_hardlink_replacement():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private static void DeleteIfExistsStrict(")
    end = source.index("private static void TryDelete(", start)
    strict_delete = source[start:end]
    assert "File.Delete(path);" in strict_delete
    assert "File.Exists(path)" not in strict_delete
    assert "FileInfo" not in strict_delete
    assert "Directory.Delete" not in strict_delete


def test_restore_journal_temp_name_collision_never_overwrites_existing_entry(tmp_path):
    """CreateNew semantics must preserve an unexpected pre-existing temp entry."""
    journal = tmp_path / "live.db.restore-journal"
    temporary = tmp_path / (journal.name + ".tmp-" + "f" * 32)
    temporary.write_bytes(b"pre-existing-untrusted-temp")

    try:
        with temporary.open("xb") as stream:
            stream.write(b"new-journal-content")
    except FileExistsError:
        pass
    else:
        raise AssertionError("exclusive temp creation must reject a name collision")

    assert temporary.read_bytes() == b"pre-existing-untrusted-temp"
    assert not journal.exists()


def test_csharp_restore_journal_temp_creation_is_exclusive_and_does_not_truncate():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private static void WriteRestoreJournal(")
    end = source.index("private static bool IsValidJournalChecksum(", start)
    writer = source[start:end]
    assert "new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None)" in writer
    assert "FileMode.Create," not in writer


def test_csharp_restore_journal_collision_cleanup_only_deletes_owned_temp():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private static void WriteRestoreJournal(")
    end = source.index("private static bool IsValidJournalChecksum(", start)
    writer = source[start:end]
    assert "var createdTemporary = false;" in writer
    assert writer.index("createdTemporary = true;") > writer.index("new FileStream(temporary, FileMode.CreateNew")
    assert "if (createdTemporary && !publishedTemporary) TryDelete(temporary);" in writer
    assert "finally { TryDelete(temporary); }" not in writer


def test_restore_journal_collision_preserves_entry_when_creation_fails(tmp_path):
    journal = tmp_path / "live.db.restore-journal"
    temporary = tmp_path / (journal.name + ".tmp-" + "a" * 32)
    original = b"pre-existing-entry-owned-by-another-operation"
    temporary.write_bytes(original)
    created_temporary = False
    try:
        with temporary.open("xb") as stream:
            created_temporary = True
            stream.write(b"replacement")
    except FileExistsError:
        pass
    finally:
        if created_temporary:
            temporary.unlink(missing_ok=True)
    assert temporary.read_bytes() == original
    assert not journal.exists()


def test_restore_journal_owned_temp_is_cleaned_after_partial_write_failure(tmp_path):
    """A temp created by this invocation is removed when writing fails mid-stream."""
    journal = tmp_path / "live.db.restore-journal"
    temporary = tmp_path / (journal.name + ".tmp-" + "b" * 32)
    created_temporary = False
    try:
        with temporary.open("xb") as stream:
            created_temporary = True
            stream.write(b"partial-journal")
            raise OSError("simulated disk-full during journal write")
    except OSError as exc:
        assert "disk-full" in str(exc)
    finally:
        if created_temporary:
            temporary.unlink(missing_ok=True)

    assert not temporary.exists()
    assert not journal.exists()


def test_csharp_restore_journal_ownership_guard_covers_write_and_publish_failures():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private static void WriteRestoreJournal(")
    end = source.index("private static bool IsValidJournalChecksum(", start)
    writer = source[start:end]
    create = writer.index("new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None)")
    ownership = writer.index("createdTemporary = true;", create)
    write = writer.index("writer.WriteLine(field);", ownership)
    publish = writer.index("File.Replace(temporary, journalPath, null)", write)
    published = writer.index("publishedTemporary = true;", publish)
    cleanup = writer.index("if (createdTemporary && !publishedTemporary) TryDelete(temporary);", published)
    assert create < ownership < write < publish < published < cleanup
    assert writer.rfind("finally", 0, cleanup) >= publish


def test_restore_journal_successful_publication_does_not_cleanup_reused_temp_name(tmp_path):
    """After publication the temp pathname is no longer owned by this writer."""
    journal = tmp_path / "live.db.restore-journal"
    temporary = tmp_path / (journal.name + ".tmp-" + "c" * 32)
    created_temporary = True
    published_temporary = False
    temporary.write_bytes(b"complete-journal")

    # Model the atomic move: the original temp entry becomes the journal.
    temporary.replace(journal)
    published_temporary = True
    # Another actor may now create a new entry at the former temp pathname.
    temporary.write_bytes(b"new-unrelated-entry")
    if created_temporary and not published_temporary:
        temporary.unlink(missing_ok=True)

    assert journal.read_bytes() == b"complete-journal"
    assert temporary.read_bytes() == b"new-unrelated-entry"


def test_csharp_restore_journal_does_not_cleanup_temp_path_after_publication():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    start = source.index("private static void WriteRestoreJournal(")
    end = source.index("private static bool IsValidJournalChecksum(", start)
    writer = source[start:end]
    assert "var publishedTemporary = false;" in writer
    replace = writer.index("File.Replace(temporary, journalPath, null)")
    move = writer.index("File.Move(temporary, journalPath)")
    published = writer.index("publishedTemporary = true;", max(replace, move))
    cleanup = writer.index("if (createdTemporary && !publishedTemporary) TryDelete(temporary);", published)
    assert replace < published and move < published < cleanup


def test_restore_journal_publication_survives_crash_before_published_flag(tmp_path):
    """A process crash after atomic publication must leave a complete recoverable journal."""
    import os

    fields = ["MONARCH-RESTORE-JOURNAL-V2", str(tmp_path / ("live.db.pre-restore-" + "d" * 32)), "true", "prepared"]
    checksum = hashlib.sha256("\n".join(fields).encode("utf-8")).hexdigest()
    payload = ("\n".join(fields + [checksum]) + "\n").encode("utf-8")

    for replace_existing in (False, True):
        case = tmp_path / ("replace" if replace_existing else "move")
        case.mkdir()
        journal = case / "live.db.restore-journal"
        temporary = case / (journal.name + ".tmp-" + "e" * 32)
        if replace_existing:
            journal.write_bytes(b"old-journal")
        temporary.write_bytes(payload)

        # Atomic publication succeeds; simulate termination before the in-memory
        # publishedTemporary flag can be assigned. A terminated process runs no finally.
        if replace_existing:
            os.replace(temporary, journal)
        else:
            os.rename(temporary, journal)

        lines = journal.read_text(encoding="utf-8").splitlines()
        assert lines[:4] == fields
        assert lines[4] == hashlib.sha256("\n".join(lines[:4]).encode("utf-8")).hexdigest()
        assert not temporary.exists()



def _read_v2_journal_for_restart(journal_path):
    """Strict test decoder for the durable V2 journal after process restart."""
    lines = journal_path.read_text(encoding="utf-8").splitlines()
    if len(lines) != 5 or lines[0] != "MONARCH-RESTORE-JOURNAL-V2":
        raise ValueError("invalid restore journal framing")
    expected = hashlib.sha256("\n".join(lines[:4]).encode("utf-8")).hexdigest()
    if not re.fullmatch(r"[0-9a-f]{64}", lines[4]) or lines[4] != expected:
        raise ValueError("invalid restore journal checksum")
    if lines[2] not in ("true", "false") or lines[3] not in ("prepared", "committed"):
        raise ValueError("invalid restore journal state")
    return Path(lines[1]), lines[2] == "true", lines[3]


def test_restart_consumes_published_prepared_journal_and_rolls_back_after_crash(tmp_path):
    live = tmp_path / "live.db"
    previous = tmp_path / ("live.db.pre-restore-" + "f" * 32)
    journal = tmp_path / "live.db.restore-journal"
    live.write_bytes(b"new-uncommitted-db")
    previous.write_bytes(b"old-database")
    fields = ["MONARCH-RESTORE-JOURNAL-V2", str(previous), "true", "prepared"]
    checksum = hashlib.sha256("\n".join(fields).encode("utf-8")).hexdigest()
    journal.write_text("\n".join(fields + [checksum]) + "\n", encoding="utf-8")

    recovered_previous, had_previous, phase = _read_v2_journal_for_restart(journal)
    assert recovered_previous == previous and had_previous and phase == "prepared"
    live_wal = tmp_path / "live.db-wal"
    previous_wal = tmp_path / "previous.db-wal"
    live_shm = tmp_path / "live.db-shm"
    previous_shm = tmp_path / "previous.db-shm"
    _recover(live, recovered_previous, live_wal, previous_wal, live_shm,
             previous_shm, had_previous, phase)

    assert live.read_bytes() == b"old-database"
    assert not previous.exists()
    assert journal.read_bytes().startswith(b"MONARCH-RESTORE-JOURNAL-V2\n")


def test_restart_consumes_published_committed_journal_and_finishes_cleanup(tmp_path):
    live = tmp_path / "live.db"
    previous = tmp_path / ("live.db.pre-restore-" + "1" * 32)
    journal = tmp_path / "live.db.restore-journal"
    live.write_bytes(b"verified-new-database")
    previous.write_bytes(b"old-database")
    fields = ["MONARCH-RESTORE-JOURNAL-V2", str(previous), "true", "committed"]
    checksum = hashlib.sha256("\n".join(fields).encode("utf-8")).hexdigest()
    journal.write_text("\n".join(fields + [checksum]) + "\n", encoding="utf-8")

    recovered_previous, had_previous, phase = _read_v2_journal_for_restart(journal)
    assert recovered_previous == previous and had_previous and phase == "committed"
    _recover(live, recovered_previous, tmp_path / "live.db-wal",
             tmp_path / "previous.db-wal", tmp_path / "live.db-shm",
             tmp_path / "previous.db-shm", had_previous, phase,
             live_integrity_ok=True)

    assert live.read_bytes() == b"verified-new-database"
    assert not previous.exists()
    assert journal.read_bytes().startswith(b"MONARCH-RESTORE-JOURNAL-V2\n")


def test_restart_v2_journal_decoder_fails_closed_on_checksum_tampering(tmp_path):
    journal = tmp_path / "live.db.restore-journal"
    fields = ["MONARCH-RESTORE-JOURNAL-V2", str(tmp_path / ("live.db.pre-restore-" + "2" * 32)), "true", "prepared"]
    checksum = hashlib.sha256("\n".join(fields).encode("utf-8")).hexdigest()
    journal.write_text("\n".join(fields + [checksum[:-1] + ("0" if checksum[-1] != "0" else "1")]) + "\n", encoding="utf-8")
    import pytest
    with pytest.raises(ValueError, match="checksum"):
        _read_v2_journal_for_restart(journal)
