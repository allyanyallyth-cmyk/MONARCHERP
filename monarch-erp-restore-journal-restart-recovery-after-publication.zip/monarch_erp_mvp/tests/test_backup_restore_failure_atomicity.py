"""Backup restore safety regressions.

SQLite tests model the required preflight/replace contract. They do not execute
BackupRecoveryService; C# source-order assertions are structural only.
"""
import hashlib
import hmac
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _package(database_bytes: bytes, password: str) -> bytes:
    # Test-only authenticated envelope; intentionally not MONARCH's production format.
    key = hashlib.sha256(password.encode("utf-8")).digest()
    tag = hmac.new(key, database_bytes, hashlib.sha256).digest()
    return database_bytes + tag


def _restore_model(live_path: Path, package: bytes, password: str, safety_path: Path, fail_post_replace=False):
    key = hashlib.sha256(password.encode("utf-8")).digest()
    payload, supplied = package[:-32], package[-32:]
    expected = hmac.new(key, payload, hashlib.sha256).digest()
    if not hmac.compare_digest(expected, supplied):
        raise ValueError("authentication failed")

    candidate = live_path.with_suffix(".restore-candidate.db")
    candidate.write_bytes(payload)
    replaced = False
    try:
        with sqlite3.connect(candidate) as db:
            if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise ValueError("integrity failed")
            if db.execute("PRAGMA foreign_key_check").fetchall():
                raise ValueError("foreign key failure")
        if live_path.exists():
            safety_path.write_bytes(live_path.read_bytes())
        had_previous = live_path.exists()
        previous = live_path.with_suffix(".pre-restore.db")
        previous_wal = Path(str(previous) + "-wal")
        previous_shm = Path(str(previous) + "-shm")
        live_wal = Path(str(live_path) + "-wal")
        live_shm = Path(str(live_path) + "-shm")
        moved_wal = moved_shm = False
        if had_previous:
            previous.write_bytes(live_path.read_bytes())
        if live_wal.exists():
            live_wal.replace(previous_wal)
            moved_wal = True
        if live_shm.exists():
            live_shm.replace(previous_shm)
            moved_shm = True
        candidate.replace(live_path)
        replaced = True
        try:
            if fail_post_replace:
                raise RuntimeError("simulated post-replacement verification failure")
            with sqlite3.connect(live_path) as db:
                if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise ValueError("post-replacement integrity failed")
            previous.unlink(missing_ok=True)
            previous_wal.unlink(missing_ok=True)
            previous_shm.unlink(missing_ok=True)
        except Exception:
            if had_previous and previous.exists():
                live_path.unlink(missing_ok=True)
                previous.replace(live_path)
            elif not had_previous:
                live_path.unlink(missing_ok=True)
            if moved_wal and previous_wal.exists():
                live_wal.unlink(missing_ok=True)
                previous_wal.replace(live_wal)
            if moved_shm and previous_shm.exists():
                live_shm.unlink(missing_ok=True)
                previous_shm.replace(live_shm)
            raise
    finally:
        candidate.unlink(missing_ok=True)


def _db_bytes(path: Path, value: str) -> bytes:
    with sqlite3.connect(path) as db:
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("CREATE TABLE IF NOT EXISTS sentinel(value TEXT NOT NULL)")
        db.execute("DELETE FROM sentinel")
        db.execute("INSERT INTO sentinel VALUES(?)", (value,))
    return path.read_bytes()


def test_wrong_password_or_tampering_leaves_live_database_unchanged(tmp_path):
    live = tmp_path / "live.db"
    _db_bytes(live, "original-live-state")
    before = live.read_bytes()
    valid = _package(_db_bytes(tmp_path / "source.db", "backup-state"), "correct-password")
    tampered = valid[:-1] + bytes([valid[-1] ^ 0x01])

    for candidate, password in ((valid, "wrong-password"), (tampered, "correct-password")):
        try:
            _restore_model(live, candidate, password, tmp_path / "safety.db")
        except ValueError:
            pass
        else:
            raise AssertionError("invalid backup unexpectedly restored")
        assert live.read_bytes() == before


def test_authenticated_but_corrupt_sqlite_payload_is_rejected_before_live_replace(tmp_path):
    live = tmp_path / "live.db"
    _db_bytes(live, "original-live-state")
    before = live.read_bytes()
    package = _package(b"not a sqlite database", "correct-password")
    try:
        _restore_model(live, package, "correct-password", tmp_path / "safety.db")
    except sqlite3.DatabaseError:
        pass
    else:
        raise AssertionError("corrupt SQLite payload unexpectedly restored")
    assert live.read_bytes() == before
    assert not (tmp_path / "safety.db").exists()


def test_successful_restore_keeps_pre_restore_safety_copy(tmp_path):
    live = tmp_path / "live.db"
    source = tmp_path / "source.db"
    safety = tmp_path / "safety.db"
    original = _db_bytes(live, "original-live-state")
    replacement = _db_bytes(source, "verified-backup-state")

    _restore_model(live, _package(replacement, "correct-password"), "correct-password", safety)

    assert safety.read_bytes() == original
    with sqlite3.connect(live) as db:
        assert db.execute("SELECT value FROM sentinel").fetchone()[0] == "verified-backup-state"
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"


def test_csharp_restore_authenticates_and_preflights_before_safety_backup_or_replace():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    restore = source.split("public RestoreResult RestoreEncryptedBackup", 1)[1].split("private static void CreateConsistentSqliteCopy", 1)[0]
    assert restore.index("Decrypt(encrypted, password)") < restore.index("File.WriteAllBytes(restoreTemp, plaintext)")
    assert restore.index("CheckIntegrity(restoreTemp)") < restore.index("CreateEncryptedBackup(safetyBackupPath")
    assert restore.index("CheckIntegrity(restoreTemp)") < restore.index("File.Replace(restoreTemp, _databasePath, previous)")
    assert "File.Move(previous, _databasePath)" in restore
    assert "CheckIntegrity(_databasePath)" in restore


def test_post_replace_failure_rolls_back_existing_live_database(tmp_path):
    live = tmp_path / "live.db"
    source = tmp_path / "source.db"
    original = _db_bytes(live, "original-live-state")
    replacement = _db_bytes(source, "replacement-state")
    try:
        _restore_model(live, _package(replacement, "pw"), "pw", tmp_path / "safety.db", fail_post_replace=True)
    except RuntimeError:
        pass
    else:
        raise AssertionError("simulated post-replacement failure was not raised")
    assert live.read_bytes() == original


def test_failed_first_time_restore_does_not_leave_unverified_live_database(tmp_path):
    live = tmp_path / "new-live.db"
    source = tmp_path / "source.db"
    replacement = _db_bytes(source, "replacement-state")
    try:
        _restore_model(live, _package(replacement, "pw"), "pw", tmp_path / "safety.db", fail_post_replace=True)
    except RuntimeError:
        pass
    else:
        raise AssertionError("simulated post-replacement failure was not raised")
    assert not live.exists()


def test_csharp_restore_removes_unverified_database_when_no_previous_file_existed():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    restore = source.split("public RestoreResult RestoreEncryptedBackup", 1)[1].split("private static void CreateConsistentSqliteCopy", 1)[0]
    assert "else if (!hadPrevious)" in restore
    assert "TryDelete(_databasePath);" in restore


def test_restore_failure_rolls_back_database_and_wal_sidecars_together(tmp_path):
    live = tmp_path / "live.db"
    source = tmp_path / "source.db"
    original = _db_bytes(live, "original-live-state")
    replacement = _db_bytes(source, "replacement-state")
    wal = Path(str(live) + "-wal")
    shm = Path(str(live) + "-shm")
    wal.write_bytes(b"previous-wal-state")
    shm.write_bytes(b"previous-shm-state")

    try:
        _restore_model(live, _package(replacement, "pw"), "pw", tmp_path / "safety.db", fail_post_replace=True)
    except RuntimeError:
        pass
    else:
        raise AssertionError("simulated post-replacement failure was not raised")

    assert live.read_bytes() == original
    assert wal.read_bytes() == b"previous-wal-state"
    assert shm.read_bytes() == b"previous-shm-state"


def test_successful_restore_discards_old_wal_sidecars(tmp_path):
    live = tmp_path / "live.db"
    source = tmp_path / "source.db"
    _db_bytes(live, "old-state")
    replacement = _db_bytes(source, "replacement-state")
    wal = Path(str(live) + "-wal")
    shm = Path(str(live) + "-shm")
    wal.write_bytes(b"stale-wal")
    shm.write_bytes(b"stale-shm")

    _restore_model(live, _package(replacement, "pw"), "pw", tmp_path / "safety.db")

    assert not wal.exists()
    assert not shm.exists()
    with sqlite3.connect(live) as db:
        assert db.execute("SELECT value FROM sentinel").fetchone()[0] == "replacement-state"


def test_csharp_restore_quarantines_and_restores_wal_sidecars_on_failure():
    source = (ROOT / "src/Monarch.Core/Backup/BackupRecoveryService.cs").read_text(encoding="utf-8")
    restore = source.split("private RestoreResult RestoreEncryptedBackupCore", 1)[1].split("private T ExecuteWithDatabaseMutex", 1)[0]
    assert 'var previousWal = previous + "-wal";' in restore
    assert 'var previousShm = previous + "-shm";' in restore
    assert "File.Move(liveWal, previousWal)" in restore
    assert "File.Move(liveShm, previousShm)" in restore
    assert "RestoreSidecar(previousWal, liveWal, movedWal)" in restore
    assert "RestoreSidecar(previousShm, liveShm, movedShm)" in restore
    assert "DeleteIfExistsStrict(previousWal)" in restore and "DeleteIfExistsStrict(previousShm)" in restore
