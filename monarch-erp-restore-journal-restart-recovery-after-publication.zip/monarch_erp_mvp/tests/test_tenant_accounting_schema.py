import pathlib
import re
import sqlite3
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]


class TenantAccountingTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.db.execute("PRAGMA foreign_keys=ON")
        for name in ("ledger-storage.sql", "security.sql", "tenancy.sql", "tenant-accounting.sql"):
            self.db.executescript((ROOT / "database" / name).read_text(encoding="utf-8"))
        self.company("c2", "CO2")
        self.branch("b2", "c2", "HQ")
        self.db.execute("INSERT INTO monarch_users(id,username,display_name,password_salt,password_hash,password_iterations,is_active,created_utc) VALUES('u1','user1','User 1',?,?,210000,1,'now')", (b's'*16,b'h'*32))
        self.db.execute("INSERT INTO monarch_users(id,username,display_name,password_salt,password_hash,password_iterations,is_active,created_utc) VALUES('u2','user2','User 2',?,?,210000,1,'now')", (b't'*16,b'i'*32))
        self.account("a1", "00000000-0000-0000-0000-000000000001", "1000")
        self.account("e1", "00000000-0000-0000-0000-000000000001", "3000", "Equity")
        self.account("a2", "c2", "1000")
        self.account("e2", "c2", "3000", "Equity")

    def tearDown(self):
        self.db.close()

    def company(self, cid, code):
        self.db.execute("""INSERT INTO monarch_companies
(id,code,legal_name,display_name,country_code,base_currency_code,time_zone_id,created_utc)
VALUES(?,?,?,?,'SA','SAR','Asia/Riyadh','now')""", (cid, code, code, code))

    def branch(self, bid, cid, code):
        self.db.execute("INSERT INTO monarch_branches(id,company_id,code,name,created_utc) VALUES(?,?,?,?, 'now')",
                        (bid, cid, code, code))

    def account(self, aid, cid, code, kind="Asset"):
        self.db.execute("""INSERT INTO monarch_tenant_accounts
(id,company_id,code,name,account_type,is_active,created_utc) VALUES(?,?,?,?,?,1,'now')""",
                        (aid, cid, code, aid, kind))

    def journal(self, jid, cid="00000000-0000-0000-0000-000000000001", bid="00000000-0000-0000-0000-000000000002", number="JV-1", reversal=None):
        self.db.execute("""INSERT INTO monarch_tenant_journals
(id,company_id,branch_id,number,business_date,description,status,reversal_of_id,created_utc)
VALUES(?,?,?,?,?,'test','Draft',?,'now')""", (jid, cid, bid, number, "2026-01-01", reversal))

    def lines(self, jid, cid="00000000-0000-0000-0000-000000000001", debit_account="a1", credit_account="e1", debit=10000, credit=10000):
        self.db.executemany("""INSERT INTO monarch_tenant_journal_lines
(company_id,journal_id,account_id,debit_minor,credit_minor) VALUES(?,?,?,?,?)""",
                            [(cid, jid, debit_account, debit, 0), (cid, jid, credit_account, 0, credit)])

    def test_same_account_codes_allowed_in_separate_companies(self):
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM monarch_tenant_accounts WHERE code='1000'").fetchone()[0], 2)

    def test_same_journal_numbers_allowed_in_separate_companies(self):
        self.journal("j1")
        self.journal("j2", "c2", "b2")
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM monarch_tenant_journals WHERE number='JV-1'").fetchone()[0], 2)

    def test_account_from_another_company_cannot_be_used(self):
        self.journal("j1")
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("INSERT INTO monarch_tenant_journal_lines(company_id,journal_id,account_id,debit_minor,credit_minor) VALUES('00000000-0000-0000-0000-000000000001','j1','a2',100,0)")

    def test_branch_from_another_company_cannot_be_used(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.journal("bad", "00000000-0000-0000-0000-000000000001", "b2")

    def test_balanced_journal_posts(self):
        self.journal("j1"); self.lines("j1")
        self.db.execute("UPDATE monarch_tenant_journals SET status='Posted' WHERE company_id='00000000-0000-0000-0000-000000000001' AND id='j1'")
        self.assertEqual(self.db.execute("SELECT status FROM monarch_tenant_journals WHERE id='j1'").fetchone()[0], "Posted")

    def test_unbalanced_journal_cannot_post(self):
        self.journal("j1"); self.lines("j1", credit=9999)
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("UPDATE monarch_tenant_journals SET status='Posted' WHERE id='j1'")

    def test_journal_number_is_unique_inside_company(self):
        self.journal("j1")
        with self.assertRaises(sqlite3.IntegrityError):
            self.journal("j2", number="jv-1")

    def test_reports_can_be_scoped_by_company(self):
        self.journal("j1"); self.lines("j1")
        self.journal("j2", "c2", "b2"); self.lines("j2", "c2", "a2", "e2", 25000, 25000)
        self.db.execute("UPDATE monarch_tenant_journals SET status='Posted'")
        company_one = self.db.execute("""SELECT SUM(l.debit_minor) FROM monarch_tenant_journal_lines l
JOIN monarch_tenant_journals j ON j.company_id=l.company_id AND j.id=l.journal_id
WHERE l.company_id='00000000-0000-0000-0000-000000000001' AND j.status IN ('Posted','Reversed')""").fetchone()[0]
        company_two = self.db.execute("""SELECT SUM(l.debit_minor) FROM monarch_tenant_journal_lines l
JOIN monarch_tenant_journals j ON j.company_id=l.company_id AND j.id=l.journal_id
WHERE l.company_id='c2' AND j.status IN ('Posted','Reversed')""").fetchone()[0]
        self.assertEqual((company_one, company_two), (10000, 25000))

    def test_cross_company_reversal_target_rejected(self):
        self.journal("j1"); self.lines("j1")
        self.db.execute("UPDATE monarch_tenant_journals SET status='Posted' WHERE id='j1'")
        with self.assertRaises(sqlite3.IntegrityError):
            self.journal("j2", "c2", "b2", "REV-1", "j1")

    def test_posted_lines_are_immutable(self):
        self.journal("j1"); self.lines("j1")
        self.db.execute("UPDATE monarch_tenant_journals SET status='Posted' WHERE id='j1'")
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("DELETE FROM monarch_tenant_journal_lines WHERE journal_id='j1'")

    def test_posted_journal_header_is_immutable(self):
        self.journal("j1"); self.lines("j1")
        self.db.execute("UPDATE monarch_tenant_journals SET status='Posted' WHERE id='j1'")
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("UPDATE monarch_tenant_journals SET description='tampered' WHERE id='j1'")

    def test_line_cannot_be_moved_into_posted_journal(self):
        self.journal("j1"); self.lines("j1")
        self.journal("j2", number="JV-2")
        self.lines("j2")
        self.db.execute("UPDATE monarch_tenant_journals SET status='Posted' WHERE id='j1'")
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("UPDATE monarch_tenant_journal_lines SET journal_id='j1' WHERE journal_id='j2' LIMIT 1")

    def test_inactive_company_cannot_create_account(self):
        self.db.execute("UPDATE monarch_companies SET is_active=0 WHERE id='c2'")
        with self.assertRaises(sqlite3.IntegrityError):
            self.account("x", "c2", "9999")

    def test_inactive_branch_cannot_create_journal(self):
        self.db.execute("UPDATE monarch_branches SET is_active=0 WHERE id='b2'")
        with self.assertRaises(sqlite3.IntegrityError):
            self.journal("j2", "c2", "b2")

    def test_branch_access_requires_company_membership(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("INSERT INTO monarch_user_branch_access(user_id,company_id,branch_id) VALUES('u1','00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002')")

    def test_branch_access_cannot_cross_company(self):
        self.db.execute("INSERT INTO monarch_user_company_access(user_id,company_id,role_code,granted_utc) VALUES('u1','00000000-0000-0000-0000-000000000001','Accountant','now')")
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("INSERT INTO monarch_user_branch_access(user_id,company_id,branch_id) VALUES('u1','00000000-0000-0000-0000-000000000001','b2')")

    def test_exact_core_branch_authorization_query_enforces_scope(self):
        source = (ROOT / "src/Monarch.Core/Accounting/TenantLedgerStore.cs").read_text(encoding="utf-8")
        match = re.search(r'command\.CommandText = @"(SELECT a\.role_code,.*?);";', source, re.S)
        self.assertIsNotNone(match, "branch authorization SQL must remain an explicit query")
        query = match.group(1)
        default_company = "00000000-0000-0000-0000-000000000001"
        default_branch = "00000000-0000-0000-0000-000000000002"
        self.db.execute("INSERT INTO monarch_user_company_access(user_id,company_id,role_code,granted_utc) VALUES('u1',?,'Accountant','now')", (default_company,))
        self.db.execute("INSERT INTO monarch_user_branch_access(user_id,company_id,branch_id) VALUES('u1',?,?)", (default_company, default_branch))
        self.db.execute("INSERT INTO monarch_branches(id,company_id,code,name,created_utc) VALUES('b3',?,'OPS','Operations','now')", (default_company,))
        allowed = self.db.execute(query, {"user": "u1", "company": default_company, "branch": default_branch}).fetchone()
        self.assertEqual(tuple(allowed), ("Accountant", 1))
        unassigned = self.db.execute(query, {"user": "u1", "company": default_company, "branch": "b3"}).fetchone()
        self.assertEqual(tuple(unassigned), ("Accountant", 0))
        wrong_company_branch = self.db.execute(query, {"user": "u1", "company": default_company, "branch": "b2"}).fetchone()
        self.assertIsNone(wrong_company_branch)
        self.db.execute("UPDATE monarch_users SET is_active=0 WHERE id='u1'")
        inactive = self.db.execute(query, {"user": "u1", "company": default_company, "branch": default_branch}).fetchone()
        self.assertIsNone(inactive)

    def test_store_enforces_user_company_and_branch_access(self):
        source = (ROOT / "src/Monarch.Core/Accounting/TenantLedgerStore.cs").read_text(encoding="utf-8")
        for fragment in ("GetAccounts(Guid userId, Guid companyId, Guid branchId)",
                         "GetEntries(Guid userId, Guid companyId, Guid branchId)",
                         "RequireBranchAccess(connection, transaction, userId, companyId, branchId",
                         "JOIN monarch_users u ON u.id=a.user_id AND u.is_active=1",
                         "JOIN monarch_branches b ON b.id=$branch AND b.company_id=c.id AND b.is_active=1",
                         "UnauthorizedAccessException", "Company role does not permit accounting changes."):
            self.assertIn(fragment, source)
        self.assertNotIn("GetAccounts(Guid userId, Guid companyId)", source)
        self.assertNotIn("AddAccount(Guid userId, Guid companyId, Account account)", source)
        directory = (ROOT / "src/Monarch.Core/Organizations/CompanyDirectoryStore.cs").read_text(encoding="utf-8")
        self.assertIn("GrantBranchAccess", directory)


if __name__ == "__main__":
    unittest.main()
