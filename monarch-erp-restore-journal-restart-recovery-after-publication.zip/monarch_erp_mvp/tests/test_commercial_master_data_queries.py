from contextlib import closing
from pathlib import Path
import sqlite3, tempfile, unittest
ROOT = Path(__file__).resolve().parents[1]
CS = (ROOT / 'src/Monarch.Core/Commercial/CommercialStore.cs').read_text()

class CommercialMasterDataQueryTests(unittest.TestCase):
    def test_item_listing_is_company_scoped_and_supports_inactive_filter(self):
        self.assertIn('GetItems(Guid userId, Guid companyId, bool activeOnly = true)', CS)
        self.assertIn('WHERE company_id=$co AND ($active=0 OR is_active=1)', CS)
        self.assertIn('RequireCompanyRead(c, tx, userId, companyId)', CS)
        self.assertIn('cmd.Transaction = tx;', CS)

    def test_warehouse_listing_is_branch_scoped_and_authorized(self):
        self.assertIn('GetWarehouses(Guid userId, Guid companyId, Guid branchId, bool activeOnly = true)', CS)
        self.assertIn('RequireBranch(c, tx, userId, companyId, branchId, false)', CS)
        self.assertIn('cmd.Transaction = tx;', CS)
        self.assertIn('WHERE company_id=$co AND branch_id=$br AND ($active=0 OR is_active=1)', CS)

    def test_listing_methods_are_read_only_and_do_not_initialize_schema(self):
        for name in ('GetItems(', 'GetWarehouses('):
            start = CS.index(name)
            end = CS.find('\n    public ', start + 10)
            body = CS[start:end if end != -1 else len(CS)]
            self.assertNotIn('INSERT ', body.upper())
            self.assertNotIn('UPDATE ', body.upper())
            self.assertNotIn('Initialize(', body)

    def test_sql_scope_pattern_excludes_other_company_and_branch(self):
        with tempfile.NamedTemporaryFile() as f:
            with closing(sqlite3.connect(f.name)) as c:
                c.executescript('CREATE TABLE monarch_warehouses(company_id TEXT,id TEXT,branch_id TEXT,code TEXT,name TEXT,is_active INTEGER);')
                c.executemany('INSERT INTO monarch_warehouses VALUES(?,?,?,?,?,?)', [
                    ('co1','w1','b1','A','Allowed',1), ('co1','w2','b2','B','Other branch',1), ('co2','w3','b1','C','Other company',1)])
                rows = c.execute('SELECT id FROM monarch_warehouses WHERE company_id=? AND branch_id=? AND (?=0 OR is_active=1)', ('co1','b1',1)).fetchall()
                self.assertEqual([('w1',)], rows)

if __name__ == '__main__': unittest.main()
