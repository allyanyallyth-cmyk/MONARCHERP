from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SERVICE = ROOT / "src/Monarch.Core/Autonomy/ProcurementApprovalIntelligenceService.cs"
UI = ROOT / "src/Monarch.Desktop/MainWindow.xaml.cs"


def test_pending_approval_evidence_is_scoped_and_read_only():
    text = SERVICE.read_text(encoding="utf-8")
    assert "_queue.ListPending(managerUserId, companyId, branchId)" in text
    assert "Approval item is not pending in the current company and branch" in text
    assert "po.company_id=$co AND po.branch_id=$br AND po.id=$po AND po.status='Draft'" in text
    assert "_advisor.Compare(managerUserId, companyId, branchId, line.Item1, asOfDate)" in text
    assert "UPDATE monarch_purchase_orders" not in text
    assert "INSERT INTO monarch_purchase_orders" not in text


def test_manager_approval_screen_shows_supplier_comparison_without_changing_order():
    text = UI.read_text(encoding="utf-8")
    assert "LoadProcurementApprovalIntelligence()" in text
    assert "ProcurementApprovalIntelligenceService" in text
    assert "المورد_المختار_حاليا" in text
    assert "التزام_بالموعد" in text or "الالتزام_بالموعد" in text
    assert "لا تغيّر هذه المقارنة المورد أو شروط أمر الشراء" in text
