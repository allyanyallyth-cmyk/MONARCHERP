
### 2026-11-08 — Procurement forecast history
- Added a read-only history query for matured forecast snapshots, grouped as individual item/window observations.
- Exposes policy version, horizon, forecast and actual demand, absolute error and APE when actual demand is non-zero.
- Recomputes actual demand from the exact forecast window and scopes it by company, branch, warehouse and item.
- Enforces `reports.read`, date validation and a bounded result count. No migration or write path was added.
- Remaining: expose the history in WPF with filters and CSV export, and validate the C# build on Windows/.NET.



- [x] Supplier performance trend service: equal-period delivery comparison, minimum sample safeguards, and deterioration classifications (read-only; `reports.read`).

## 2026-11-08 — Procurement analytics desktop views
- [x] Expose supplier/item performance in the WPF procurement dashboard.
- [x] Expose adjacent-period supplier delivery trend alerts.
- [x] Expose matured forecast history by item and forecast window.
- [x] Preserve read-only behavior and tenant/company/branch scoping.
- [ ] Validate full .NET Framework 4.6.1 build and WPF runtime on Windows.
- [ ] Add tested CSV/Excel/PDF export after validating target-framework-compatible dependencies and output encoding/layout.

## 2026-11-08 — Procurement analytics CSV export
- [x] Add typed CSV exports for supplier/item performance, supplier trend alerts, and matured forecast history.
- [x] Add UTF-8 BOM, invariant numeric formatting, quoted fields, CRLF records, and spreadsheet formula-injection mitigation.
- [x] Expose three WPF Save As actions with `reports.read` and active tenant/branch context.
- [x] Avoid new package dependencies and database migrations.
- [ ] Validate export files in Excel/LibreOffice and build/run WPF on supported Windows/.NET Framework targets.
- [ ] Evaluate XLSX/PDF export only after target-framework-compatible libraries and deployment footprint are verified.

- [x] Procurement analytics multi-sheet XLSX export (dependency-free Open XML; three worksheets; tenant-scoped read-only retrieval).
- [ ] Validate generated workbook by opening it in Excel/LibreOffice and complete a Windows WPF build/runtime test when .NET tooling is available.
- [ ] Arabic PDF report generation with verified embedded fonts and layout.

### Procurement analytics reporting — next increment
- [x] Arabic RTL, self-contained, print-ready HTML report for supplier/item performance, supplier trends, and forecast history.
- [x] WPF export action with `reports.read` revalidation and active company/branch scope.
- [ ] Native PDF generation with a verified Arabic shaping/font pipeline and PDF reader validation.
- [ ] Add company logo and configurable legal/company header after tenant branding metadata is available.

### 2026-11-08 — Procurement report tenant branding
- [x] Include the active tenant's display name and branch name in the print-ready report.
- [x] Add optional embedded PNG/JPEG logo support (2 MB cap; signature validation; no external image path dependency).
- [x] Add UTC generation timestamp and branded report footer for audit/context.
- [x] Keep HTML encoding for all tenant-controlled text and retain read-only `reports.read` export flow.
- [ ] Native PDF output remains deferred until Arabic shaping, font embedding, and PDF-reader validation are available.
- [ ] Complete .NET Framework 4.6.1 build and Windows WPF runtime validation.


### Procurement report quality follow-up
- [x] Add executive counts for reliable supplier comparisons and alert severity.
- [x] Prevent fixed-footer overlap in browser print layout.
- [ ] Validate pagination and Arabic font rendering in supported Windows browsers.
- [ ] Evaluate a native PDF renderer only after verifying Arabic shaping, embedded fonts, and deployment compatibility.

- [x] Record successful procurement report exports (CSV/XLSX/HTML) in a local tenant/branch/user-scoped SHA-256 hash-chained audit log.
- [ ] Add cross-process locking and centralized audit replication for multi-workstation deployments.
- [ ] Compile and exercise the export audit flow on supported Windows/.NET targets.

- [x] Procurement report export audit center: verified read/filter/export UI, active tenant/branch scope, and formula-safe CSV archival.
- [ ] Harden audit persistence for concurrent MONARCH processes with an inter-process lock or transactional local store; evaluate signed/centralized tamper-evident archival before production multi-device use.

### Unified tenant audit journal — foundation
- [x] Add a generic tenant/branch-scoped append-only event journal with SHA-256 chain verification.
- [x] Add bounded, time-range and event-type reads with mandatory company/branch scope.
- [ ] Integrate audit events into user/role administration with atomic write + audit semantics.
- [ ] Integrate accounting posting, inventory movements, and procurement lifecycle events without duplicating existing transactional audit logs.
- [ ] Add cross-process locking and central replication/signing before multi-workstation production use.
- [ ] Compile and execute Core/Desktop on supported Windows/.NET targets.

### Tenant identity audit integration (2026-11-08)
- [x] Add an explicit tenant-scoped identity audit API backed by `monarch_company_audit_log`.
- [x] Require `users.manage` and active actor membership in the requested company and branch.
- [x] Add bounded tenant/branch reads with date and action filters.
- [ ] Wire company/branch-aware user creation, activation, deactivation, and role changes so mutation and audit commit atomically.
- [ ] Add integration/runtime tests on the supported .NET targets and Windows desktop.
- [ ] Extend the same transactional audit pattern to accounting, inventory, and procurement lifecycle events.

## 2026-11-08 — Identity tenant audit transaction integration
- [x] Add company/branch-scoped `CreateUser` overload with active membership validation and atomic tenant audit.
- [x] Add company/branch-scoped `SetUserActive` overload with active membership validation and atomic tenant audit.
- [x] Keep legacy unscoped APIs for compatibility; document that they do not create tenant-scoped events.
- [ ] Migrate WPF user administration to pass active company/branch context and use scoped overloads.
- [ ] Add tenant-scoped role reassignment and membership mutation APIs with atomic audit.
- [ ] Validate C# build and WPF runtime on Windows.

### 2026-11-08 — WPF identity administration audit wiring
- [x] Switch WPF user creation and activation/deactivation to company/branch-scoped atomic audit overloads.
- [x] Add tenant-scoped global identity-role reassignment with actor/target membership checks and atomic legacy + tenant audit writes.
- [x] Add role-change control to the Windows user administration screen.
- [x] Preserve existing unscoped APIs for compatibility; no schema migration or new package.
- [ ] Add dedicated company-role and branch/company membership mutation APIs with atomic audit semantics.
- [ ] Restrict user-list visibility to authorized tenant memberships and add a tenant identity audit viewer.
- [ ] Compile and run the WPF application on supported Windows/.NET Framework targets.

### 2026-11-08 — Company membership revocation
- [x] Add atomic company membership revocation with deactivation of all branch grants.
- [x] Require active global administrator and prevent self-revocation.
- [x] Protect the last active company Administrator from revocation.
- [x] Write general and tenant audit events in the same transaction.
- [x] Add confirmation control to the WPF company directory screen.
- [ ] Add tenant-scoped audit history viewer for company membership changes.
- [ ] Validate behavior through .NET integration tests and Windows WPF runtime.

### 2026-11-08 — Unified tenant audit viewer
- [x] Add a read-only unified reader for tenant audit rows with mandatory active company/branch membership checks.
- [x] Add parameterized filters for date range, action, entity type, and actor user; cap Core reads at 5,000 rows.
- [x] Add an Arabic WPF audit viewer restricted to users with `users.manage` and the current tenant/branch.
- [ ] Add a central, multi-device audit transport with authenticated replication and conflict handling.
- [ ] Merge file-based hash-chain journals into a verifiable cross-store audit view without implying a single global chain.
- [ ] Compile Core/Desktop and execute authorization/runtime tests on supported Windows/.NET targets.

### 2026-11-08 — Atomic tenant ledger audit
- [x] Record tenant account creation and journal draft creation in `monarch_company_audit_log`.
- [x] Record journal posting and reversal with actor, company, branch, entity ID, and UTC timestamp.
- [x] Insert audit rows inside the same SQLite transaction as ledger persistence so audit failure rolls back the ledger mutation.
- [x] Reuse the existing audit table; no schema migration or external dependency added.
- [ ] Extend equivalent atomic audit coverage to stock movement, returns, transfers, and valuation operations.
- [ ] Extend coverage to procurement invoices, receipts, and payment allocation paths where audit gaps remain.
- [ ] Add executable .NET integration tests and validate WPF/Core builds on Windows.


## Completed — Inventory operation audit (2026-11-08)
- [x] Audit direct stock movements within the movement transaction.
- [x] Audit both branch-scoped legs of warehouse transfers within the paired transaction.
- [x] Audit purchase/sales posting and sales/purchase return posting in their existing SQLite transactions.
- [ ] Extend audit coverage to inventory master-data edits, manual valuation adjustments, and reconciliation workers.
- [ ] Add runtime C# integration tests and cross-device audit replication after build infrastructure is available.


### 2026-11-08 — Atomic inventory valuation audit
- [x] Record each persisted valuation run in `monarch_company_audit_log` with actor, tenant, branch, warehouse, item, cost method, closing quantity/value, and movement count.
- [x] Persist the valuation snapshot and audit row in the same SQLite transaction; audit failure rolls back the snapshot.
- [ ] Add executable .NET tests for rollback-on-audit-failure and authorization on Windows/.NET.
- [ ] Add audit coverage for inventory-to-GL reconciliation execution and review/approval workflow; reconciliation remains read-only.

### 2026-11-08 — Atomic inventory-to-GL reconciliation audit
- [x] Record each read-only inventory/GL reconciliation in the existing tenant audit table within the same SQLite transaction.
- [x] Capture actor, company, branch, account, cost method, cutoff, item/warehouse count, quantity, both balances, variance, and balanced status.
- [x] Require `reports.read` in addition to active company/branch membership.
- [x] Preserve strict read-only behavior for general-ledger journals; no automatic adjustment or posting is created.
- [ ] Add executable .NET integration coverage for audit-failure rollback and authorization on supported Windows/.NET targets.
- [ ] Add an explicit, separately authorized review/approval workflow for variance correction; never auto-post reconciliation differences.


### 2026-11-08 — Inventory operation RBAC hardening
- [x] Require explicit `inventory.movements.manage` permission for direct stock movements and both warehouse-transfer legs.
- [x] Perform direct movement authorization inside the same SQLite transaction as stock mutation and audit.
- [x] Verify active user, company, branch, membership, and RBAC role grant.
- [x] Add `inventory.read` and Administrator-only default stock mutation grant to fresh-schema seed and explicit existing-database migration.
- [ ] Add C# integration tests for permission-denied and authorization-race scenarios on supported .NET targets.
- [ ] Review and migrate remaining legacy `CommercialStore` party/unit/item/warehouse convenience APIs to explicit permission-checked transactions or deprecate them in favor of `InventoryMasterDataStore`.

### 2026-11-08 — Inventory master-data read RBAC alignment
- [x] Align item-group and unit read methods with `inventory.read`; retain `inventory.items.manage` for all writes.
- [x] Move item and warehouse read authorization into the same SQLite transaction as each query.
- [x] Require active user, company membership, active company, and RBAC grant for company-scoped item reads.
- [x] Preserve branch-level authorization and branch filtering for warehouse reads.
- [x] Show the WPF inventory catalog to `inventory.read` users and keep group/unit mutation controls manager-only.
- [ ] Review remaining legacy `CommercialStore` write convenience methods and migrate/deprecate unsafe paths without breaking supported callers.
- [ ] Add executable C# integration tests and validate WPF/Core builds on supported Windows targets.

## 2026-11-08 — Legacy inventory write-path authorization
- [x] Harden `CommercialStore.AddUnit` and `AddItem` with transactional `inventory.items.manage` checks and same-transaction audit events.
- [x] Harden `CommercialStore.AddWarehouse` with transactional `inventory.warehouses.manage`, active branch membership, and same-transaction audit.
- [x] Preserve legacy method signatures for caller compatibility; no schema migration introduced.
- [ ] Continue auditing other legacy commercial write APIs (parties and non-inventory master data) for granular RBAC and atomic audit.
- [ ] Run .NET build and WPF integration tests on a Windows runner before release.


### 2026-11-08 — Commercial document permission and draft audit hardening
- [x] Require `commercial.sales.manage` for sales draft creation and posting.
- [x] Require `commercial.purchases.manage` for purchase draft creation and posting.
- [x] Validate active user, tenant, branch, and explicit RBAC grant inside the mutation transaction.
- [x] Record draft creation in the existing company audit log before commit; audit failure rolls back draft creation.
- [x] Preserve posting stock movements, cost allocations, accounting outbox, and existing public API signatures.
- [ ] Review payment posting and legacy party master-data write APIs for transactional granular RBAC and audit.
- [ ] Add executable .NET integration tests and validate Core/WPF builds on supported Windows targets.

### 2026-11-08 — Commercial payment RBAC and atomic audit
- [x] Replace broad role-name payment authorization with `commercial.sales.manage` / `commercial.purchases.manage` grants matching payment type.
- [x] Enforce active user, company, branch, memberships, and role grant inside the payment transaction.
- [x] Write customer-receipt/supplier-payment audit events in the same transaction before commit.
- [x] Preserve payment allocations, accounting outbox, schema, and public API signatures; no migration required.
- [x] Reject undefined payment type/method enum values.
- [ ] Add executable C# integration tests for authorization denial and audit-failure rollback on supported .NET targets.
- [ ] Continue review of `CommercialReturnStore` and legacy party master-data write paths for granular RBAC and atomic audit.


### 2026-11-08 — Commercial return RBAC and atomic audit
- [x] Require `commercial.sales.manage` for sales-return draft creation and posting.
- [x] Require `commercial.purchases.manage` for purchase-return draft creation and posting.
- [x] Validate active user, company, branch, memberships, and explicit role grant inside each SQLite transaction.
- [x] Record draft creation and posting audit events before commit; audit failure rolls back the complete operation.
- [x] Preserve stock movements, return-cost allocations, accounting outbox, schema, and public API signatures.
- [ ] Add executable .NET integration tests for denied access and audit-failure rollback.
- [ ] Continue auditing legacy party/master-data write APIs and validate Core/WPF builds on supported Windows targets.

### 2026-11-08 — Commercial party master-data RBAC and atomic audit
- [x] Require `commercial.sales.manage` for customer creation.
- [x] Require `commercial.purchases.manage` for supplier creation; require both grants for `PartyType.Both`.
- [x] Validate active user/company membership and explicit role grant inside the party insert transaction.
- [x] Record party creation in the existing company audit log before commit; audit failure rolls back the insert.
- [x] Preserve API signature and schema; avoid logging tax/contact fields in audit details.
- [ ] Review any additional party update/activation/deactivation endpoints and apply the same controls where present.
- [ ] Add executable .NET integration tests and validate Core/WPF builds on supported Windows targets.

### Commercial party read RBAC — 2026-11-08
- [x] Add company-scoped `GetParties` read API with active-only filtering.
- [x] Require sales permission for customer views and purchase permission for supplier views.
- [x] Require both grants for unfiltered and `PartyType.Both` queries to avoid cross-domain disclosure.
- [x] Perform authorization and read query in the same SQLite transaction; include `Both` parties in customer/supplier views.
- [x] Preserve schema and avoid automatic migration or initialization.
- [ ] Add executable .NET integration tests and validate Core/WPF builds on supported Windows targets.

### 2026-11-09 — AR/AP report authorization and branch isolation
- [x] Require `reports.read` with active user, company, company membership, branch membership, and active branch validation.
- [x] Execute authorization and AR/AP report reads in the same SQLite transaction.
- [x] Restrict aging allocations and statement documents/payments to the selected company and branch.
- [x] Validate statement party consistency and reject undefined balance-side enum values.
- [x] Preserve read-only mode, public signatures, schema, and explicit migration policy.
- [ ] Add executable C# integration tests and validate Core/WPF builds on supported Windows targets.

### 2026-11-10 — Supplier invoice operational-read RBAC alignment
- [x] Require `commercial.purchases.manage` for supplier invoice list and receiptable-line reads, matching the WPF purchase workspace gate.
- [x] Keep authorization and each company/branch-scoped read in the same SQLite transaction.
- [x] Preserve invoice creation/posting behavior, schema, migrations, and public signatures.
- [x] Add structural regression checks that reject the broader `reports.read` grant for operational invoice reads.
- [ ] Add executable C# integration tests for purchase-read denial, branch isolation, and cross-tenant invoice IDs.
- [ ] Validate Core and WPF builds/runtime on supported Windows environments.

### 2026-11-10 — Supplier AP historical aging cutoff
- [x] Join payment allocations to posted supplier payments when calculating historical AP aging.
- [x] Exclude payments dated after the report's `asOfDate`.
- [x] Enforce same-company and same-branch matching for payment contributions.
- [x] Add structural regression coverage for the historical cutoff and branch condition.
- [x] Preserve the existing report API, operational payment permission, schema, and migration policy.
- [ ] Add executable C# integration fixtures for backdated/as-of payment scenarios and cross-branch isolation.
- [ ] Validate Core and WPF build/runtime on supported Windows environments.

### 2026-11-10 — Supplier payment allocation scope validation
- [x] Validate every payment allocation against its payable and posted source invoice before GL posting.
- [x] Enforce same-company, same-branch, same-supplier, same-currency, and same-currency-scale invariants.
- [x] Block posting when any allocation is orphaned, cross-branch, cross-supplier, cross-currency, or references a non-posted invoice.
- [x] Preserve deterministic journal identity, accounting direction, schema, and public API signatures.
- [x] Add structural regression coverage for allocation-scope checks.
- [ ] Add executable C# integration tests for corrupted cross-branch/cross-supplier allocation fixtures and concurrent worker execution.
- [ ] Review transactional outbox claim/acknowledgement strategy for multiple simultaneous worker instances.
- [ ] Validate Core/WPF build and runtime on supported Windows environments.
- [x] Serialize supplier AP outbox processing by database/company/branch within a process and retain deterministic journal retry safety.
- [ ] Add durable cross-process outbox claiming/leases with an explicit migration and crash-recovery tests before enabling multiple independent worker processes.
- [ ] Run C# concurrency and post-commit/acknowledgement failure integration tests on a .NET-enabled Windows CI agent.

### 2026-11-10 — Supplier AP durable outbox leases
- [x] Add durable lease token/expiry fields to fresh commercial schemas and an explicit additive migration for existing databases.
- [x] Atomically claim eligible invoice/payment events with conditional SQLite updates scoped by company and branch.
- [x] Fence acknowledgement and failure updates with the current lease token; recover expired leases after worker/process loss.
- [x] Retain deterministic journal identity and same-process serialization as defense in depth.
- [x] Add a one-minute lease heartbeat that extends active claims by five minutes with token and unexpired-lease fencing.
- [ ] Run live multi-process SQLite contention and crash-recovery integration tests on a .NET-enabled Windows CI agent.
- [ ] Validate migration against a copy of a representative customer database before release.
- [ ] Validate Core/WPF build and runtime on supported Windows environments.


### 2026-11-10 — Supplier AP lease finalization and takeover hardening
- [x] Require an unexpired lease as well as the exact token/company/branch/unprocessed row for invoice and payment acknowledgement.
- [x] Apply the same expiry fence to failure/release updates; an expired worker cannot clear a replacement worker's lease.
- [x] Make heartbeat expiry monotonic so overlapping callbacks cannot shorten a more recent renewal.
- [x] Add executable SQLite SQL-contract coverage for pre-expiry exclusion, post-expiry takeover, stale-worker fencing, expired-owner rejection, and current-owner completion.
- [ ] Execute real C# worker/timer and multi-process crash-recovery tests on a .NET-enabled Windows CI agent.
- [ ] Add operational heartbeat-failure telemetry and validate the migration against a backed-up customer database.

### 2026-11-10 — Supplier AP worker health telemetry
- [x] Expose a thread-safe process-local health snapshot for invoice/payment claims, heartbeat activity/failures, lease renewals, ownership losses, acknowledgements, and failure updates.
- [x] Keep counters diagnostic-only; SQLite token/expiry fences and deterministic journal identity remain authoritative.
- [x] Add structural regression tests for metric exposure and counter coverage.
- [ ] Add durable telemetry persistence, alert thresholds, and operational dashboard only after retention/privacy and tenant-scoping requirements are defined.
- [ ] Execute worker/timer telemetry tests and .NET build on a .NET-enabled Windows CI agent.

### 2026-11-10 — Supplier AP durable worker diagnostics
- [x] Add explicit tenant/branch-scoped SQLite diagnostics migration for heartbeat failures and lease ownership-loss rejections.
- [x] Persist only bounded event/detail codes and entity references; do not persist lease tokens or raw exception messages in the diagnostics table.
- [x] Add authorized, company-and-branch-filtered recent diagnostics reader with bounded result count.
- [x] Keep diagnostics best-effort and independent from accounting/lease authority; expose diagnostic write failures in the health snapshot.
- [ ] Define and approve operational retention/deletion policy before enabling automated cleanup.
- [ ] Add alert thresholds and an operational dashboard after live worker telemetry validation.
- [ ] Execute C# worker, authorization, and SQLite concurrency tests on a .NET-enabled Windows CI agent.

### 2026-11-10 — Supplier AP worker recovery guidance
- [x] Add pure classification for SQLite BUSY/LOCKED/IOERR, timeout, and I/O failures.
- [x] Recommend capped exponential backoff from 15 seconds to 15 minutes without executing retries.
- [x] Recommend operator alerting for permanent/unclassified failures and repeated transient failures (default threshold 5).
- [x] Reject invalid attempt/failure/threshold inputs; preserve durable lease and deterministic journal authority.
- [ ] Add executable C# policy tests and wire a future durable retry scheduler only after retry-state semantics and operator controls are specified.
- [ ] Validate Core/WPF builds and live worker behavior on a .NET-enabled Windows CI agent.

### 2026-11-10 — Supplier AP Operational Alert Center
- [x] Add read-only operational alert projection over existing durable worker diagnostics.
- [x] Classify repeated heartbeat failures (15-minute window; default Critical threshold 3) and lease ownership-loss events (24-hour Warning window).
- [x] Reuse tenant/branch-authorized diagnostic access; bound output to 1–500 and keep ordering deterministic.
- [x] Keep process-local global health counters separate from tenant-attributed alerts.
- [x] Preserve accounting, outbox, and lease authority; add no migration or automatic retry behavior.
- [ ] Add alert acknowledgement, delivery, and retention only after operator workflow and retention policy are specified.
- [ ] Execute C# build and live worker tests on a .NET-enabled Windows CI agent.

### Completed — Supplier AP operational alert lifecycle (2026-11-11)
- Persisted user-specific viewed/acknowledged markers for operational alert summaries, scoped by company and branch.
- Added append-only database enforcement and idempotent lifecycle actions; recurring alerts with a new source timestamp receive a new lifecycle.
- Remaining: WPF lifecycle UI, explicit alert acknowledgement permissions if separated from existing ledger access, and live C# integration testing.

### 2026-11-11 — Supplier AP operational alert center UI
- [x] Add an Arabic WPF alert tab gated by `reports.read`.
- [x] Read alerts and lifecycle states using the active user/company/branch context.
- [x] Add explicit viewed and acknowledged actions with append-only persistence.
- [x] Display lifecycle state alongside severity, event count, and last occurrence.
- [x] Keep acknowledgement separate from worker execution, leases, outbox, and accounting.
- [ ] Validate migration rollout, C# build, and WPF interaction on a .NET-enabled Windows CI agent.

### 2026-11-11 — Supplier AP alert delivery planning and escalation
- [x] Add deterministic severity/age-based escalation planning (Critical => level 2 immediately; Warning => level 2 after 30 minutes).
- [x] Add explicit tenant/branch-scoped, recipient-specific in-app delivery-intent migration.
- [x] Enforce per-recipient authorization before intent creation; bound recipient and alert batches.
- [x] Add idempotency across company, branch, recipient, alert occurrence, escalation level, and channel.
- [x] Enforce immutable delivery intents with SQLite triggers.
- [x] Implement a separate durable dispatcher with bounded attempts, lease fencing, immutable attempt history, and dead-letter handling (see Dispatcher stage below).
- [ ] Add the WPF delivery adapter, user-visible delivery receipts, and operator-controlled retry semantics.
- [ ] Add email/SMS/push providers only after consent, secret management, rate limiting, and data-retention controls are defined.
- [ ] Run C# build and live Windows integration tests on a .NET-enabled CI agent.

### 2026-11-11 — Supplier AP Alert Dispatcher
- [x] Durable tenant/branch-scoped dispatch queue for in-app alert intents.
- [x] Restrict claim and completion to the intent recipient, in addition to authorized company/branch scope.
- [x] Atomic claim with expiring lease token and stale-owner fencing.
- [x] Immutable delivery-attempt history and bounded error codes.
- [x] Exponential retry scheduling capped at 15 minutes; dead-letter after 8 completed failures.
- [ ] WPF in-app delivery adapter and visible delivered/failed status.
- [ ] Runtime multi-process contention tests on supported Windows/.NET targets.
- [ ] Optional external provider integrations only after credentials, consent, and transport security are designed.

### 2026-11-11 — SQLite test resource cleanup
- [x] Add per-test SQLite connection tracking and teardown closure to eliminate leaked test connections, including assertion-failure paths.
- [x] Explicitly close temporary SQLite backup connections in the legacy migration utility.
- [x] Verify the complete pytest suite with `ResourceWarning` promoted to errors.

### 2026-11-11 — Supplier AP in-app WPF delivery adapter
- [x] Add a recipient-scoped in-app inbox to the existing supplier AP alert tab.
- [x] Claim bounded batches using the active user/company/branch context and the dispatcher's recipient fence.
- [x] Bind claimed rows before recording successful in-app delivery completion.
- [x] Keep delivery receipt distinct from user-read state.
- [x] Record bounded UI-presentation failure outcomes and rely on the durable retry/lease-expiry recovery path.
- [x] Keep the adapter separate from accounting posting and supplier-payables mutation.
- [ ] Build Core/Desktop on a .NET-enabled Windows CI agent and execute WPF interaction tests.
- [ ] Validate user-switch behavior and lease-expiry recovery with a live SQLite database on Windows.
- [ ] Decide whether a persistent read-state/history model is required beyond immutable delivery-attempt history.

### 2026-11-11 — Supplier AP persistent inbox read state
- [x] Additive SQLite migration for recipient-specific `Viewed` and `Acknowledged` inbox events.
- [x] Enforce immutable event history, unique action per intent/recipient, and recipient/company/branch indexes.
- [x] Add bounded delivered-inbox projection and tenant-authorized read/acknowledgement service.
- [x] Keep delivery receipts distinct from read/acknowledgement events; only delivered intents can receive read markers.
- [x] Keep read-state service isolated from dispatcher retry, worker leases, journals, and accounting outbox.
- [x] Wire persistent inbox projection and read/acknowledgement actions into WPF UI; refresh on tab load and after delivery.
- [ ] Add operator-authorized dead-letter inspection and audited manual retry workflow without resetting immutable attempt history.
- [ ] Build Core/Desktop and run WPF integration tests on a .NET-enabled Windows agent.


### 2026-11-11 — Supplier AP persistent inbox WPF integration
- [x] Load durable delivered inbox entries on tab activation and after receiving new in-app notifications.
- [x] Add explicit refresh, mark-viewed, and acknowledge-selected-notification actions.
- [x] Display independent delivery/view/acknowledgement states and timestamps.
- [x] Enforce `reports.read` in the WPF actions and retain active user/company/branch scope in store calls.
- [x] Keep read/acknowledgement events append-only and separate from delivery retry and accounting.
- [ ] Add operator-authorized dead-letter inspection and audited manual retry without erasing prior attempt history.
- [ ] Build Core/Desktop and run WPF integration tests on a .NET-enabled Windows agent.

### 2026-11-11 — Supplier AP dead-letter operator controls
- [x] Additive migration to preserve immutable delivery-attempt history while allowing monotonic attempt numbering across manual retry cycles.
- [x] Add append-only, tenant-scoped audit records for manual dead-letter retry decisions.
- [x] Add `users.manage`-gated dead-letter inspection and explicit-confirmation manual requeue in WPF.
- [x] Keep manual requeue separate from actual delivery, accounting workers, journals, and supplier-payment operations.
- [x] Add regression coverage for migration preservation, audit immutability, authorization, and WPF confirmation.
- [ ] Build Core/Desktop on Windows for both declared target frameworks and run WPF interaction tests against a migrated database.
- [ ] Validate repeated manual retry cycles and lease recovery under concurrent dispatcher activity on Windows.

### 2026-11-12 — Supplier AP dispatch integrity hardening
- [x] Enforce unique immutable attempt sequence numbers per delivery intent across manual retry cycles.
- [x] Add operator-action history lookup index.
- [x] Revalidate company, branch, recipient, lease token, and lease expiry in guarded dispatcher state updates.
- [x] Add SQLite regression tests for repeated manual retry cycles and stale-lease fencing.
- [ ] Run multi-process SQLite contention tests and C# integration tests on Windows/.NET; Python structural/SQLite checks do not replace runtime validation.
- [ ] Build Core/Desktop for declared target frameworks and exercise WPF flows on supported Windows versions.


### 2026-11-12 — Supplier AP backup and competing-worker recovery
- [x] Extend encrypted backup, verification, and restore integrity validation with SQLite `foreign_key_check` in addition to `integrity_check`.
- [x] Verify consistent database copies preserve dispatch attempt history, dead-letter operator audit, and recipient inbox lifecycle events.
- [x] Add file-backed two-connection SQLite contention regression: a due intent is claimed by only one competing worker.
- [x] Verify orphaned dispatch history is detected by foreign-key validation even when page integrity reports `ok`.
- [x] Preserve the existing backup format and avoid an unnecessary schema migration.
- [ ] Build and execute C# backup/recovery and dispatcher tests on Windows with .NET installed; Python SQLite tests are not a substitute.
- [ ] Validate actual multi-process WPF/dispatcher behavior and restore workflow on supported Windows installations.


### 2026-11-12 — Backup restore failure-safety
- [x] Add regression model for wrong-password and tampered-backup rejection without changing the live database.
- [x] Verify authenticated invalid SQLite payload is rejected before safety-copy creation or live replacement.
- [x] Verify successful restore preserves a pre-restore safety copy.
- [x] Add structural checks for C# authentication/preflight/replace/rollback ordering.
- [ ] Execute actual encrypted restore, injected post-replacement failure, rollback, and sidecar/WAL handling tests on Windows with the supported .NET targets.
- [ ] Validate C# build and WPF recovery workflow on Windows; Python model and source assertions are not runtime evidence.

### 2026-11-12 — Backup restore rollback hardening
- [x] Remove a newly restored live database if post-replacement verification fails and there was no pre-existing database to roll back to.
- [x] Preserve exact rollback behavior for an existing live database; retain the rollback file until restoration succeeds.
- [x] Add regression coverage for both post-replacement failure branches and a structural C# guard.
- [ ] Execute `BackupRecoveryService` integration tests and build the Core/Desktop targets with the supported .NET toolchain.
- [ ] Exercise restore failure scenarios on supported Windows versions, including Windows 7 SP1 where applicable.

### 2026-11-12 — Backup/restore cross-process serialization
- [x] Serialize encrypted backup creation and restore through a path-scoped named OS mutex shared by participating MONARCH processes.
- [x] Use a bounded 30-second wait; fail closed on timeout rather than running backup/restore concurrently.
- [x] Recover ownership after an abandoned mutex and always release ownership in a `finally` path.
- [x] Keep restore safety-copy creation re-entrant under the same process/thread mutex.
- [x] Document the cooperation boundary: unrelated SQLite clients and older builds are not protected by this mutex.
- [ ] Build Core/Desktop and verify named mutex acquisition, timeout, abandonment recovery, and nested restore safety-copy behavior on supported Windows/.NET targets.
- [ ] Run live multi-process backup/restore contention and WAL-sidecar tests; do not treat Python structural tests as runtime proof.


### 2026-11-12 — SQLite WAL sidecar-safe restore rollback
- [x] Quarantine the prior live database WAL and SHM sidecars before replacing the database, rather than deleting them before replacement.
- [x] Restore the prior database and its quarantined sidecars together when replacement or post-replacement verification fails.
- [x] Remove the old database rollback file and quarantined sidecars only after successful post-restore integrity verification.
- [x] Add Python regression models for sidecar rollback/cleanup and a live-WAL online-backup snapshot; add C# source-structure assertions.
- [ ] Run C# backup/restore integration tests, Windows file-sharing tests, and injected failures between each sidecar move and database replacement.
- [ ] Validate active WAL/SHM handle behavior and restore workflow on supported Windows versions, including Windows 7 SP1 where applicable.

## 2026-11-12 — SQLite restore crash-recovery journal
- [x] Persist a `prepared` restore journal before moving live SQLite sidecars or replacing the database.
- [x] Persist a `committed` marker after post-restore integrity verification and before rollback-artifact cleanup.
- [x] Recover interrupted restore transactions under the per-database inter-process mutex before the next backup/restore operation.
- [x] Roll back the previous database and quarantined WAL/SHM set for an uncommitted restore; remove an unverified first-time restore.
- [x] Finish cleanup without reattaching old sidecars when the journal records a committed restore.
- [x] Add Python crash-state model tests and C# source-structure assertions.
- [ ] Execute process-termination and power-loss integration tests on Windows across each restore transition.
- [ ] Validate journal durability and atomic rename/replace semantics on each supported filesystem and Windows target.
- [ ] Build all C# targets and run WPF/.NET Framework compatibility tests on Windows.

### 2026-11-12 — Restore journal rollback-path validation hardening
- [x] Require rollback journal paths to resolve to the live database directory and exact database-specific rollback filename prefix.
- [x] Require the rollback suffix to be a 32-character GUID in `N` format before recovery can move or delete rollback artifacts.
- [x] Add regression checks for malformed, prefix-sibling, and valid rollback filenames.
- [ ] Add authenticated journal integrity or an equivalent tamper-evident design if the threat model includes untrusted local writers; retain filesystem ACL protection.
- [ ] Build and execute C# journal recovery tests on Windows, including process termination at each transition and filesystem durability checks.


### 2026-11-12 — Restore journal recovery-state validation
- [x] Fail closed when a committed journal has no live database, preserving rollback artifacts.
- [x] Fail closed when a prepared journal with a prior database has neither a rollback nor live main file.
- [x] Reject an unexpected rollback main file for a first-time restore.
- [x] Add crash-state regression models and source-structure assertions.
- [ ] Execute process-termination and recovery tests against the C# service on supported Windows versions.

### 2026-11-12 — Restore journal integrity framing
- [x] Write new restore journals in versioned V2 format with a SHA-256 checksum over the journal fields.
- [x] Validate V2 checksum and strict UTF-8 decoding before using a journal path or changing recovery artifacts.
- [x] Preserve recovery compatibility with the existing three-line V1 journals so interrupted upgrades remain recoverable.
- [x] Add regression coverage for checksum validation, modified fields, truncation, invalid phases, and V1 compatibility.
- [ ] Treat the checksum as corruption detection only; add a Windows-protected keyed integrity mechanism only after a compatible key-protection design is validated.
- [ ] Execute C# and process-termination recovery tests on supported Windows versions.


### 2026-11-12 — V2 committed-phase recovery regression fix
- [x] Dispatch committed recovery using the normalized parsed phase for both V1 and V2 journal formats.
- [x] Add regression coverage for the V2 field layout (`hadPrevious` at index 2; `phase` at index 3).
- [ ] Build and execute the C# recovery path on supported Windows versions; Python source assertions do not replace runtime tests.

Validation snapshot (2026-11-12): 632 pytest and 365 unittest tests passed for the V2 committed-phase regression fix. Windows/.NET runtime verification remains open.

### 2026-11-13 — Restore recovery restartability regression coverage
- [x] Add a recovery-restart regression after the prior main database has been restored but before WAL/SHM sidecars are fully restored.
- [x] Add a partial-sidecar recovery regression proving a previously restored WAL remains intact while SHM recovery resumes.
- [x] Add idempotent committed-cleanup regression coverage after partial rollback-artifact deletion.
- [x] Assert C# sidecar recovery is guarded by quarantine-file existence.
- [ ] Execute the actual C# recovery service with injected process termination between each filesystem operation on Windows.
- [ ] Validate atomic replacement, directory-entry durability, and WAL/SHM behavior on supported Windows filesystems.

Validation snapshot (2026-11-13): 636 pytest tests and 365 unittest tests passed. No .NET SDK was available; C# build, WPF runtime, and Windows crash/power-loss integration remain unverified.

### 2026-11-13 — مراجعة تدفق التعافي بعد إعادة التشغيل
- [x] مراجعة مسار `BackupRecoveryService` من سجل `prepared` إلى `committed`، مع التحقق من التوافق V1/V2 ومسار rollback وWAL/SHM وقفل العمليات.
- [x] إضافة فحوص بنيوية لترتيب استرجاع sidecars قبل حذف journal، وللتحقق من وجود قاعدة البيانات الحية قبل تنظيف حالة `committed`.
- [x] الإبقاء على منطق C# الإنتاجي دون تغيير لعدم ثبوت عيب محدد يمكن التحقق منه في بيئة لا تتوفر فيها .NET/Windows.
- [ ] تنفيذ اختبارات C# فعلية مع حقن توقف العملية بين كل عمليات الملفات على Windows.
- [ ] التحقق من ديمومة الدليل/الملفات وسلوك `File.Replace` و`Flush(true)` على أنظمة الملفات وإصدارات Windows المستهدفة.
- [ ] اختبار التداخل مع عملاء SQLite غير المشاركين في mutex؛ قفل MONARCH لا يمنعهم.

حدود التهديد: بصمة SHA-256 غير المفتاحية لسجل التعافي مخصصة لكشف التلف/التعديل غير المتسق، وليست إثبات أصالة ضد كاتب محلي يستطيع تعديل السجل والبصمة معاً.

### 2026-11-13 — Committed restore recovery integrity guard
- [x] Re-run SQLite `integrity_check` and `foreign_key_check` on the live database when resuming a `committed` restore journal.
- [x] Preserve the prior database, quarantined WAL/SHM sidecars, and journal when the committed live database fails integrity validation.
- [x] Add Python crash-state regression coverage and a C# source-order assertion proving integrity validation precedes rollback-artifact cleanup.
- [ ] Execute corrupted-live-database recovery against the actual C# service on Windows and verify preserved artifacts can be manually recovered.
- [ ] Build Core/Desktop and run WPF recovery tests on supported Windows/.NET targets; Python models and source assertions are not runtime evidence.


### 2026-11-13 — Restore integrity-check result completeness
- [x] Fail closed if SQLite `PRAGMA integrity_check` unexpectedly returns zero rows; an empty result set must not be treated as a verified database.
- [x] Add a structural regression assertion for the required result-row guard.
- [ ] Execute the guard through the compiled C# service and real SQLite provider on Windows/.NET.


### 2026-11-13 — SQLite integrity result cardinality
- [x] Require exactly one `ok` result row from `PRAGMA integrity_check` before treating the database as verified.
- [x] Reject empty result sets and anomalous multiple result rows, even if every returned row says `ok`.
- [x] Add a structural regression assertion for the exact-success cardinality rule.
- [ ] Verify provider behavior and execute committed-recovery tests using the compiled C# service on Windows.
- [ ] Run the complete Windows crash/restart and WAL/SHM integration matrix; Python structural checks are not runtime proof.

### 2026-11-13 — Prepared recovery filesystem fault-injection model
- [x] Add deterministic crash injection after each of the six filesystem mutations in the prepared rollback model (main-file removal/restore and WAL/SHM destination removal/move).
- [x] Restart the recovery model from each interrupted on-disk state and assert the original database plus both sidecars are restored without losing rollback artifacts.
- [x] Keep production C# logic unchanged; the new evidence is confined to the Python filesystem model.
- [ ] Port the same fault points to an executable C# integration harness and run on supported Windows filesystems; Python model tests are not C# runtime proof.


### 2026-11-13 — Committed recovery cleanup fault-injection model
- [x] Inject simulated process termination after each of the three committed rollback-artifact deletions.
- [x] Restart committed recovery after each interrupted cleanup state and assert the verified live database remains authoritative.
- [x] Verify all remaining rollback database/WAL/SHM artifacts are eventually cleaned on retry.
- [ ] Port committed cleanup fault points to the executable C# integration harness and run on supported Windows filesystems.
- [ ] Validate actual SQLite provider integrity checks and process termination behavior on Windows/.NET.

Validation snapshot (2026-11-13): 644 pytest and 365 unittest tests passed. No .NET SDK was available; C# build, WPF runtime, and Windows integration remain unverified.

### 2026-11-13 — Repeated interruption during prepared recovery
- [x] Inject a first process termination at each of the first five prepared-recovery filesystem mutation points.
- [x] Inject a second termination during the subsequent recovery attempt, then verify a third restart completes rollback of the original database and WAL/SHM sidecars.
- [x] Preserve all production C# logic and existing modules; this increment adds Python filesystem-model coverage only.
- [ ] Execute equivalent repeated-termination cases against `BackupRecoveryService` with real SQLite files on supported Windows/.NET targets.

Validation snapshot (2026-11-13): 645 pytest and 365 unittest tests passed; 7 XML/XAML/project files parsed with 0 errors. No .NET SDK was available; C# build, WPF runtime, and Windows integration remain unverified.


## تحديث 2026-11-13 — التعافي من الانقطاع المتكرر في الاستعادة الأولى

- أضيف اختبار يغطي مسار `prepared` عندما لا توجد قاعدة بيانات سابقة (`hadPrevious=false`) مع وجود WAL/SHM معزولين من الحالة السابقة وملفات جانبية ناتجة عن قاعدة الاستعادة غير المعتمدة.
- يحقن الاختبار توقفاً أولاً عند كل نقطة من نقاط تعديل الملفات الخمس، ثم توقفاً ثانياً أثناء محاولة التعافي التالية، ثم يشغّل محاولة ثالثة حتى الاكتمال.
- يتحقق من حذف قاعدة البيانات غير المعتمدة، وإرجاع WAL وSHM المعزولين، وعدم ترك ملفات rollback جانبية معلقة.
- لا تعديل على كود C# الإنتاجي أو مخطط البيانات أو الوحدات أو واجهة المستخدم؛ الاختبار نموذج Python لنظام الملفات فقط.

نتائج هذه الحزمة: 646 اختبار pytest و365 اختبار unittest ناجحة. لم يتوفر .NET SDK؛ لم يُنفذ بناء C# أو تشغيل WPF أو اختبار Windows/SQLite Provider فعلي.

### 2026-11-13 — First-restore second-termination matrix
- [x] Explore the first-restore recovery model across first interruption points and reachable second interruption points during the next recovery attempt.
- [x] Verify a final clean retry removes the unverified live DB, restores quarantined WAL/SHM sidecars, and leaves no rollback artifacts.
- [x] Preserve all existing modules and production C# behavior; this increment adds Python model coverage only.
- [ ] Execute the same interruption matrix against `BackupRecoveryService` with real SQLite files on supported Windows/.NET targets.

Validation snapshot (2026-11-13): 647 pytest and 365 unittest tests passed; 7 XML/XAML/project/config files parsed with 0 errors. .NET SDK unavailable; C# build, WPF runtime, and Windows SQLite integration were not run.


### 2026-11-13 — Committed recovery preservation and FK integrity coverage
- [x] Extend the committed-recovery failure model to assert preservation of the live database, live WAL/SHM, rollback database, and quarantined WAL/SHM when integrity validation fails.
- [x] Assert structurally that the shared C# integrity routine runs `integrity_check` and `foreign_key_check`.
- [ ] Execute foreign-key-corruption and artifact-preservation cases through the compiled C# SQLite provider on supported Windows/.NET targets.
- [ ] Run process-termination and filesystem durability tests against the actual recovery service.


### Restore recovery — committed cleanup repeated-termination matrix
- [x] Exercise a second process termination at reachable cleanup points after each first termination point in `committed` recovery.
- [x] Verify the validated live database remains authoritative and rollback DB/WAL/SHM artifacts are eventually cleaned by a third recovery attempt.
- [ ] Port the crash matrix to Windows/.NET integration tests against the actual SQLite provider and filesystem operations.
- [ ] Validate process-kill and power-loss durability behavior on supported Windows versions.


### 2026-11-13 — Committed recovery partial-cleanup idempotence
- [x] Cover all eight possible presence/absence combinations for the rollback DB/WAL/SHM artifacts after partial committed cleanup.
- [x] Run recovery twice for each state and verify the integrity-approved live DB remains byte-for-byte unchanged.
- [ ] Execute these cases through `BackupRecoveryService` and the actual SQLite provider on Windows/.NET.

Validation for this increment is recorded in `TEST_RESULTS_2026-11-13-COMMITTED-RECOVERY-PARTIAL-CLEANUP-IDEMPOTENCE.log`.

### 2026-11-13 — Committed recovery integrity-gate partial-state matrix
- [x] Cross all eight rollback DB/WAL/SHM presence combinations with a failed committed-live integrity gate.
- [x] Repeat fail-closed recovery twice and verify all extant live and rollback artifacts remain byte-for-byte unchanged.
- [x] Retry with integrity approved and verify rollback artifacts are removed while the live DB and its WAL/SHM remain unchanged.
- [ ] Execute equivalent cases through `BackupRecoveryService` and the real SQLite provider on supported Windows/.NET targets.

Validation is recorded in `TEST_RESULTS_2026-11-13-COMMITTED-RECOVERY-INTEGRITY-GATE-PARTIAL-MATRIX.log`.

### 2026-11-13 — Committed restore cleanup failure must retain journal
- [x] Replace best-effort deletion in committed recovery with strict deletion that propagates filesystem failures.
- [x] Delete the committed journal only after rollback DB/WAL/SHM cleanup succeeds, preserving retry state after sharing violations or access errors.
- [x] Add regression coverage for a simulated deletion failure and structural ordering of the C# cleanup calls.
- [ ] Run real sharing-violation/ACL tests against `BackupRecoveryService` on supported Windows/.NET targets.
- [ ] Execute full C# build, WPF smoke tests, and SQLite crash-recovery integration on Windows.

Validation snapshot (2026-11-13): 653 pytest tests passed; 365 unittest tests passed. No .NET SDK was available; C# compilation and Windows runtime behavior remain unverified.

### 2026-11-13 — strict cleanup must not hide File.Exists errors
- [x] Use `File.Delete` directly in strict committed cleanup; missing files remain an idempotent no-op while real I/O/access/sharing failures propagate.
- [x] Cover failure at each rollback DB/WAL/SHM deletion point and assert the committed journal remains available for retry.
- [x] Assert the strict helper does not use `File.Exists` as a precondition.
- [ ] Validate missing-file and denied-access semantics with the actual .NET runtime on supported Windows versions, including ACL and sharing-violation cases.
- [ ] Build the full solution and run WPF smoke tests plus SQLite recovery integration on Windows.

Validation is recorded in `TEST_RESULTS_2026-11-13-COMMITTED-RECOVERY-STRICT-DELETE-ACCESS-FAILURE.log`.


### 2026-11-13 — Direct restore committed cleanup boundary
- [x] Apply strict DB/WAL/SHM/journal deletion to the direct successful-restore path, not only startup recovery.
- [x] Prevent exceptions after durable `committed` from entering rollback logic; retain live DB and journal for retry.
- [x] Add a three-point cleanup-failure matrix and source-level ordering checks.
- [ ] Run real ACL/sharing-violation tests and process interruption against the compiled service on supported Windows/.NET targets.

Validation: see `TEST_RESULTS_2026-11-13-DIRECT-RESTORE-COMMITTED-CLEANUP.md`.


### 2026-11-13 — Direct restore committed-cleanup retry matrix
- [x] Exercise a second cleanup attempt after each of the three direct-path rollback artifact deletion failures.
- [x] Assert the committed journal remains available after the first failure and is removed only after retry completes.
- [x] Assert the verified live database remains byte-for-byte unchanged across failure and retry.
- [ ] Execute equivalent fault-injection and restart tests against the compiled C# service on supported Windows filesystems.

Validation: see `TEST_RESULTS_2026-11-13-DIRECT-RESTORE-COMMITTED-CLEANUP-RETRY.log`.

### 2026-11-13 — Direct restore journal-removal retry boundary
- [x] Inject a failure at committed journal deletion after all rollback DB/WAL/SHM artifacts have been removed.
- [x] Verify the committed journal remains for startup retry and the verified live database is byte-for-byte unchanged.
- [x] Verify a subsequent cleanup pass removes the journal idempotently with all rollback artifacts already absent.
- [ ] Exercise journal-removal access/sharing failures and restart behavior against the compiled C# service on supported Windows/.NET filesystems.

Validation: see `TEST_RESULTS_2026-11-13-DIRECT-RESTORE-JOURNAL-REMOVAL-RETRY.log`.

### 2026-11-13 — Restore journal V2 corruption matrix
- [x] Exercise tampering in every V2 journal field, including version, path, prior-database flag, phase, and checksum.
- [x] Cover malformed digest lengths and non-hexadecimal digest characters while preserving uppercase-hex compatibility.
- [x] Assert the C# checksum validator enforces digest shape and performs a full-length comparison.
- [ ] Execute malformed-journal recovery against the compiled C# service on supported Windows/.NET targets and verify startup remains fail-closed without altering database artifacts.

Validation: see `TEST_RESULTS_2026-11-13-RESTORE-JOURNAL-V2-CORRUPTION-MATRIX.log`.

### 2026-11-14 — Restore journal rollback-path reference matrix
- [x] Cover same-directory enforcement after full-path normalization.
- [x] Reject sibling/nested directories, mismatched database names, suffix extensions, non-N GUID forms, and non-hexadecimal tokens.
- [x] Assert the C# recovery source retains normalized path, case-insensitive parent comparison, and exact GUID-N validation.
- [ ] Run equivalent path/adversarial cases against the compiled C# recovery service on Windows, including filesystem ACL and reparse-point behavior.

Validation: `pytest -q` — 693 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 passed. See `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-ROLLBACK-PATH-MATRIX.log`.

### 2026-11-14 — Restore journal strict UTF-8 corruption boundary
- [x] Add malformed UTF-8 byte-sequence cases (invalid lead byte, invalid continuation, and truncated multibyte sequence).
- [x] Verify strict decoding rejects malformed journal bytes before the test recovery flow can alter live or rollback database artifacts.
- [x] Assert the C# recovery service reads the journal with strict UTF-8 decoding before destructive recovery operations.
- [ ] Execute malformed-byte journal cases against the compiled C# service on Windows and verify exact artifact preservation under real filesystem access/sharing conditions.

Validation: see `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-STRICT-UTF8.log`.

### 2026-11-14 — Restore journal read I/O fail-closed boundary
- [x] Inject access-denied and sharing-violation-style read failures at the journal-read boundary.
- [x] Verify live DB, rollback DB, quarantined WAL/SHM, and journal bytes remain unchanged when the journal cannot be read.
- [x] Assert strict C# journal reading occurs before rollback moves and committed cleanup, without swallowing a read failure and continuing.
- [ ] Run equivalent ACL and file-sharing tests against the compiled recovery service on supported Windows/.NET filesystems.

Validation: `pytest -q` — 700 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 passed; XML/XAML/project/config parsing — 7 parsed, 0 errors. See `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-READ-IO-FAIL-CLOSED.log`. No C# build or WPF runtime test was possible because the .NET SDK is unavailable.


### 2026-11-14 — Prepared recovery filesystem I/O retry matrix
- [x] Inject one-shot access failures at live DB/WAL/SHM removal and rollback DB/WAL/SHM moves.
- [x] Verify the prepared journal survives each failure and retry restores prior DB/WAL/SHM bytes exactly.
- [x] Add C# source-structure checks for database and sidecar recovery operations.
- [ ] Run equivalent fault-injection cases against the compiled service on supported Windows filesystems, including ACL and sharing violations.

Validation: `pytest -q` — 707 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 passed; XML/XAML/project/config parsing — 7 parsed, 0 errors. See `TEST_RESULTS_2026-11-14-PREPARED-RECOVERY-FILESYSTEM-IO-RETRY.log`. No C# build or WPF runtime test was possible because the .NET SDK is unavailable.

### 2026-11-14 — Prepared recovery repeated I/O failure retry matrix
- [x] Inject two independent transient filesystem failures at distinct mutation points over two consecutive recovery attempts.
- [x] Cover failure sequences across database rollback, WAL restoration, and SHM restoration.
- [x] Preserve the prepared journal after both failures and prove a third retry restores the original database and sidecar bytes exactly.
- [ ] Execute the repeated-failure matrix against the compiled C# service on Windows with real ACL/sharing violations and process restarts.

Validation: `pytest -q` — 710 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 passed; XML/XAML/project/config parsing — 7 parsed, 0 errors. C# build, WPF runtime, and Windows SQLite integration were not run because the .NET SDK/Windows runtime are unavailable in this environment.

### 2026-11-14 — Strict deletion of unverified first-restore database
- [x] Replace best-effort deletion with strict deletion when startup recovery encounters an uncommitted first-restore live database.
- [x] Apply the same strict deletion boundary in the direct restore failure handler so a locked unverified DB cannot be followed by sidecar/journal cleanup.
- [x] Inject a locked-file deletion failure; verify the prepared journal, unverified DB, and quarantined sidecars remain intact, then verify retry removes the unverified DB and restores the original sidecars.
- [ ] Execute the scenario against the compiled C# service on Windows with real ACL denial, sharing violations, and SQLite handles.

Validation: `pytest -q` — 712 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 passed; XML/XAML/project parsing — 7 parsed, 0 errors. C# build/WPF/Windows SQLite integration were not run because .NET SDK and Windows runtime are unavailable.

### 2026-11-14 — First-restore sidecar retry matrix
- [x] Inject transient failures at live WAL/SHM deletion and quarantined WAL/SHM move boundaries after strict first-restore database removal.
- [x] Verify the durable `prepared` journal survives each sidecar failure and retry restores original sidecar bytes exactly.
- [x] Verify C# source ordering places journal removal after both sidecar restoration operations.
- [ ] Execute equivalent cases against the compiled C# recovery service on Windows with real ACL/sharing violations and process restarts.

Validation: see `TEST_RESULTS_2026-11-14-FIRST-RESTORE-SIDECAR-RETRY-MATRIX.log`. Python fault-model and source-structure checks only; no .NET build or Windows runtime execution was available.

### 2026-11-14 — First-restore journal cleanup retry
- [x] Model process termination after the final SHM restoration and before prepared-journal cleanup.
- [x] Verify a subsequent recovery pass is idempotent when both quarantined sidecars have already moved to their live paths.
- [x] Inject journal deletion access denial; verify the prepared journal remains and a later cleanup retry succeeds without changing restored WAL/SHM bytes.
- [x] Verify C# source ordering restores WAL and SHM before best-effort journal deletion.
- [ ] Execute equivalent crash and sharing/ACL scenarios against the compiled C# service on Windows.

Validation: `pytest -q` — 720 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 passed; XML/XAML/project/config parsing — 7 parsed, 0 errors. Python fault-model and source-structure checks only; .NET build, WPF runtime, and Windows SQLite integration were not run because the required .NET/Windows environment is unavailable. See `IMPLEMENTATION-2026-11-14-FIRST-RESTORE-JOURNAL-CLEANUP-RETRY.md` and `TEST_RESULTS_2026-11-14-FIRST-RESTORE-JOURNAL-CLEANUP-RETRY.log`.

### 2026-11-14 — Abandoned restore-journal temporary cleanup
- [x] Clean up abandoned journal publication temp files during startup recovery under the database-operation mutex.
- [x] Restrict cleanup to exact 32-hex GUID-N suffixes for the current database journal in the database directory.
- [x] Use strict deletion so cleanup access/sharing failures fail closed; preserve malformed/unrelated files and the published journal.
- [x] Add regression tests for no-published-journal, published-prepared-journal, and malformed-temp-name states.
- [ ] Run equivalent process-termination and filesystem-sharing tests against the compiled C# service on Windows.

Validation: `pytest -q` — 724 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 passed; XML/XAML/project/config parsing — 7 parsed, 0 errors. No C# build/WPF/Windows SQLite integration was run because the .NET SDK and Windows runtime are unavailable. See `TEST_RESULTS_2026-11-14-ABANDONED-RESTORE-JOURNAL-TEMP-CLEANUP.log`.

### 2026-11-14 — Restore journal atomic-publication failure matrix
- [x] Model initial journal publication failure through the `File.Move` path and verify no published journal is left behind.
- [x] Model replacement publication failure through the `File.Replace` path and preserve the previously published journal byte-for-byte.
- [x] Cover publication failure combined with temp cleanup failure, then verify startup cleanup removes the orphan GUID-N temp without touching the durable journal.
- [x] Assert source-level durable flush, atomic publication branches, and finally cleanup.
- [ ] Execute these cases against the compiled C# writer on Windows and verify real filesystem atomicity, ACL, sharing, and process-termination behavior.

Validation: `pytest -q` — 728 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 passed; XML/XAML/project parsing — 7 parsed, 0 errors. No .NET build, WPF runtime, or Windows SQLite/filesystem integration was available. See `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-PUBLICATION-FAILURE-MATRIX.log`.

### 2026-11-14 — Restore journal temp-cleanup failure boundaries
- [x] Model strict deletion denial for an abandoned GUID-N journal temp; preserve the published journal and orphan temp on failure, then prove a later retry succeeds.
- [x] Model directory-enumeration denial and verify cleanup aborts before journal processing or live database mutation.
- [x] Add C# source guard for strict deletion and uncaught enumeration/deletion errors.
- [ ] Run real directory ACL, file-sharing, and retry tests against the compiled C# service on Windows.

Validation: `pytest -q` — 731 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 tests OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. C# build, WPF runtime, and Windows filesystem/SQLite integration were not run because .NET/Windows tooling is unavailable. See `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-TEMP-CLEANUP-FAILURE-BOUNDARIES.log`.

### 2026-11-14 — Restore-journal streaming enumeration and retry coverage
- [x] Inject a lazy directory enumeration failure after one abandoned temp has been yielded; verify startup aborts and the published journal/live DB remain unchanged.
- [x] Verify a subsequent startup pass removes the remaining abandoned temp after the partial enumeration failure.
- [x] Verify cleanup is scoped to the current database journal namespace and preserves another database's GUID-N temp.
- [x] Guard the C# source for streaming top-directory enumeration before journal processing.
- [ ] Execute mid-enumeration ACL/sharing failures against the compiled C# service on Windows.

Validation: `pytest -q` — 734 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 tests OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. No C# build, WPF runtime, or Windows filesystem/SQLite integration was run because .NET/Windows tooling is unavailable. See `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-STREAMING-ENUMERATION-RETRY.log`.

### 2026-11-14 — Restore-journal temporary-name boundary matrix
- [x] Preserve malformed GUID-N suffixes (non-hexadecimal, short, and long) during abandoned-temp cleanup.
- [x] Verify uppercase GUID-N suffixes are accepted and cleaned.
- [x] Verify directory entries with a temporary-file-like name and their contents are not removed.
- [x] Preserve similarly prefixed but non-exact temporary names.
- [ ] Run the same naming and filesystem-entry cases against the compiled C# service on Windows.

Validation: `pytest -q` — 737 passed; Python unittest — 365 tests OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. No C# build, WPF runtime, or Windows filesystem/SQLite integration was run because the required .NET/Windows toolchain is unavailable. See `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-TEMP-NAME-BOUNDARIES.log`.


### 2026-11-14 — Restore-journal temporary symlink safety
- [x] Verify cleanup unlinks an exact-name temporary symbolic-link entry without changing or deleting its target.
- [x] Add a source guard that strict cleanup uses single-entry `File.Delete`, not recursive directory deletion.
- [ ] Execute equivalent reparse-point and ACL cases against the compiled C# recovery service on Windows.

Validation: see `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-TEMP-SYMLINK-SAFETY.log`. Python filesystem-model and C# source-structure checks only; no C# build or Windows runtime test was available.

### 2026-11-14 — Restore-journal temporary hard-link safety
- [x] Verify cleanup unlinks an exact-name abandoned temp hard-link entry while preserving the separately retained file's contents.
- [ ] Execute equivalent hard-link and filesystem semantics against the compiled C# recovery service on Windows.

Validation: `pytest -q` — 740 passed; Python unittest — 365 tests OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. No .NET build, WPF runtime, or Windows filesystem/SQLite integration was available. See `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-HARDLINK-SAFETY.log`.

### 2026-11-14 — Restore-journal cross-directory hard-link safety
- [x] Verify an abandoned GUID-N hard-link temp in the journal directory can be unlinked while its retained same-filesystem name is in a separate directory.
- [x] Verify retained bytes remain unchanged and the inode link count decreases by exactly one.
- [ ] Execute the equivalent behavior against the compiled C# recovery service on Windows/NTFS, including ACL and sharing-violation cases.

Validation: `pytest -q` — 741 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 tests OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. No .NET build, WPF runtime, or Windows filesystem/SQLite integration was run. See `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-CROSS-DIRECTORY-HARDLINK.log`.

### 2026-11-14 — Restore-journal concurrent temp disappearance
- [x] Model a matching GUID-N temp disappearing after enumeration and before strict deletion; verify cleanup remains idempotent.
- [x] Guard the C# strict-delete helper against a `File.Exists` preflight that could mask metadata-access failures.
- [ ] Run a real concurrent delete/enumeration race against the compiled C# service on Windows/NTFS.

Validation: results are recorded in `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-CONCURRENT-TEMP-DISAPPEARANCE.log`. Python model/source assertions only; C# build, WPF runtime, and Windows filesystem/SQLite integration remain unverified.


### 2026-11-14 — Restore-journal temp entry-type race
- [x] Model a matching GUID-N temp path changing from a file to a directory after enumeration and before deletion.
- [x] Verify strict cleanup fails closed and preserves the directory and child content without recursive deletion.
- [x] Verify a later retry succeeds after the conflicting directory is removed and a regular temp file is present.
- [x] Guard C# source for top-directory file enumeration and strict single-entry deletion.
- [ ] Execute real concurrent file-to-directory replacement, ACL, and sharing-violation tests against the compiled C# service on Windows/NTFS.

Validation: `pytest -q` — 745 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 tests OK. Python filesystem model and C# source assertions only; no C# build, WPF runtime, or Windows filesystem integration was run. See `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-TEMP-ENTRY-TYPE-RACE.log`.

### 2026-11-14 — Restore-journal directory-symlink race safety
- [x] Model a matching GUID-N temp entry being replaced by a directory symbolic link after enumeration.
- [x] Verify cleanup fails closed without recursively deleting or modifying the symlink target.
- [x] Verify a later retry can remove a regular abandoned temp after the raced link is removed.
- [x] Guard the C# strict-delete helper against recursive-directory fallback.
- [ ] Execute equivalent reparse-point replacement and ACL/sharing tests against the compiled recovery service on Windows/NTFS.

Validation: `pytest -q` — 747 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 tests OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. These are Python model and C# source-structure tests; no C# build, WPF runtime, or Windows filesystem integration was run. See `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-DIRECTORY-SYMLINK-RACE.log`.


### 2026-11-14 — Restore-journal dangling symbolic-link cleanup
- [x] Model a matching GUID-N abandoned-temp entry whose symbolic-link target is missing.
- [x] Verify cleanup unlinks only the symbolic-link entry and leaves the missing target absent.
- [x] Verify repeated cleanup remains harmless when the captured entry has already disappeared.
- [x] Guard the C# strict-delete helper against `File.Exists` preflight and recursive-directory fallback.
- [ ] Execute dangling/reparse-point cleanup against the compiled recovery service on Windows/NTFS with real ACL and sharing behavior.

Validation: `pytest -q` — 749 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 tests OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. Python filesystem-model and C# source-structure checks only; no C# build, WPF runtime, or Windows filesystem integration was run. See `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-DANGLING-SYMLINK.log`.

### 2026-11-14 — Restore-journal symlink target-creation race
- [x] Model a matching GUID-N temporary symlink whose target is absent at enumeration time and created before the link is unlinked.
- [x] Verify cleanup removes only the symlink entry and preserves the target created during the race and its bytes.
- [x] Guard C# strict cleanup against link-target resolution and recursive directory deletion while retaining direct `File.Delete`.
- [ ] Execute equivalent reparse-point race, ACL, sharing, and concurrent-process tests against the compiled recovery service on Windows/NTFS.

Validation: `pytest -q` — 751 passed; `python -m unittest discover -s tests -p 'test_*.py'` — 365 tests OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. Tests and documentation only; no C# build, WPF runtime, or Windows filesystem/SQLite integration was run. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-SYMLINK-TARGET-CREATION-RACE.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-SYMLINK-TARGET-CREATION-RACE.log`.

### 2026-11-14 — Restore-journal file-symlink replacement race
- [x] Model a GUID-N temp path enumerated as a regular file and replaced by a symlink to an existing regular file before deletion.
- [x] Verify cleanup removes only the symlink entry and preserves the existing target's exact bytes.
- [x] Guard the C# strict-delete source against link resolution, `File.Exists` preflight, and recursive directory deletion.
- [ ] Execute equivalent reparse-point replacement, ACL, and sharing-violation tests against the compiled recovery service on Windows/NTFS.

Validation: `pytest -q` — 753 passed; Python unittest — 365 tests OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. Python filesystem-model and C# source-structure tests only; no C# build, WPF runtime, or Windows filesystem/SQLite integration was run. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-FILE-SYMLINK-REPLACEMENT-RACE.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-FILE-SYMLINK-REPLACEMENT-RACE.log`.

### 2026-11-14 — Restore-journal hard-link replacement race
- [x] Model a GUID-N temp path enumerated as a regular file and replaced with a hard link to a separately retained file before cleanup.
- [x] Verify cleanup unlinks only the candidate name, preserves the retained name and exact bytes, and decrements the inode link count by one.
- [x] Guard the C# strict-delete helper against metadata preflight and recursive deletion, retaining single-entry `File.Delete` semantics.
- [ ] Execute equivalent concurrent hard-link replacement and cleanup tests against the compiled recovery service on Windows/NTFS.

Validation: see `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-HARDLINK-REPLACEMENT-RACE.log`. Python filesystem model and C# source-structure checks only; no C# build, WPF runtime, or Windows filesystem integration was run.

### 2026-11-14 — Restore-journal temporary-name collision safety
- [x] Model exclusive creation collision against a pre-existing journal-temp entry.
- [x] Verify existing temp bytes remain unchanged and no journal is published.
- [x] Guard the C# writer for `FileMode.CreateNew` and `FileShare.None`.
- [ ] Execute collision and sharing behavior against the compiled recovery service on Windows/NTFS.

Validation: `pytest -q` — 757 passed; Python unittest — 365 tests OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. Tests/documentation only; no production C#, WPF runtime, or Windows filesystem/SQLite integration was run. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-TEMP-NAME-COLLISION.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-TEMP-NAME-COLLISION.log`.


### 2026-11-14 — Restore journal temp collision cleanup ownership
Fixed a cleanup ownership defect: when exclusive `CreateNew` failed because a journal-temp name already existed, unconditional `finally` cleanup could delete that pre-existing entry. `WriteRestoreJournal` now tracks whether this invocation successfully created the temporary file and only cleans up an owned entry. Added regression tests and source guards. Validation: `pytest -q` — 759 passed; Python unittest — 365 OK. .NET build, WPF runtime, and Windows/NTFS/SQLite integration were not run. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-COLLISION-CLEANUP-OWNERSHIP.md` and `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-COLLISION-CLEANUP-OWNERSHIP.log`.


### 2026-11-14 — Restore-journal partial-write cleanup ownership
Added a regression for a disk-write failure after exclusive temporary-file creation. It verifies that an owned partial temp is cleaned and no journal is published; a C# source-order guard checks ownership is set only after `CreateNew` and cleanup remains ownership-gated after write/publication. Test/documentation-only increment. Compiled C#, WPF, and Windows/NTFS/SQLite integration remain unverified. See `IMPLEMENTATION-2026-11-14-RESTORE-JOURNAL-PARTIAL-WRITE-CLEANUP-OWNERSHIP.md`.

### 2026-11-14 — Restore-journal published-temp ownership
- [x] Track successful atomic publication separately from temporary-file creation ownership.
- [x] Prevent finally cleanup from deleting a new unrelated entry at the former temp pathname after publication.
- [x] Add filesystem-model regression and C# source guard.
- [ ] Verify the publication/rename and concurrent-name-reuse behavior against the compiled recovery service on Windows/NTFS.

Validation: see `TEST_RESULTS_2026-11-14-RESTORE-JOURNAL-PUBLISHED-TEMP-OWNERSHIP.log`. Python filesystem model and C# source-structure checks do not constitute a .NET build, WPF runtime, or Windows/NTFS/SQLite integration test.


### 2026-11-14 — Restore-journal publication model ownership matrix
- [x] Align the publication filesystem model with exclusive temp creation and explicit created/published ownership states.
- [x] Cover successful initial Move and replacement Replace when the old temp pathname is reused immediately after publication.
- [ ] Run the equivalent compiled writer matrix on Windows/NTFS.

Validation: `pytest -q` — 764 passed; Python unittest — 365 OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. No production C# change; compiled .NET, WPF, Windows/NTFS, and SQLite integration remain unverified.

### 2026-11-15 — Restore-journal publication crash window
- [x] Model process termination immediately after successful atomic `Move` publication.
- [x] Model process termination immediately after successful atomic `Replace` publication.
- [x] Verify the durable V2 journal fields and SHA-256 checksum remain complete after the simulated crash.
- [ ] Execute the crash-window matrix against the compiled recovery service on Windows/NTFS.

Validation: `pytest -q` — 765 passed; Python unittest — 365 OK; XML/XAML/project/config parsing — 7 parsed, 0 errors. No .NET build, WPF runtime, Windows/NTFS, or SQLite integration was run. See `IMPLEMENTATION-2026-11-15-RESTORE-JOURNAL-PUBLICATION-CRASH-WINDOW.md`.

### 2026-11-15 — Restore-journal restart recovery after publication
- [x] Add strict test-only V2 journal framing/state/checksum decoding.
- [x] Cover prepared-journal restart rollback in the filesystem recovery model.
- [x] Cover committed-journal restart cleanup in the filesystem recovery model.
- [x] Verify checksum tampering fails closed.
- [ ] Run the restart matrix against the compiled C# service on Windows/NTFS and validate SQLite state transitions.

Validation: targeted restore-journal suite — 154 passed; `pytest -q` — 768 passed; Python unittest — 365 passed; XML/XAML/project/config parsing — 7 parsed, 0 errors. `dotnet` unavailable; no C# build, WPF runtime, Windows/NTFS, or SQLite integration was run. See `IMPLEMENTATION-2026-11-15-RESTORE-JOURNAL-RESTART-RECOVERY-AFTER-PUBLICATION.md`.
